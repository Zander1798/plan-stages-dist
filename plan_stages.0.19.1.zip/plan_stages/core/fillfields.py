"""0.16.0 Scan (operator 2026-10-29): a hand-drawn layer taken over as a stage's approved revision often lacks the
plugin's fields. fill() gives each NULL or missing registry field the value the next steps read, from the layer's
own geometry and the approved layers upstream. It never changes a geometry and never overwrites a value the operator
set; a field it cannot work out stays null, and the next Check reports it as it would any null. For P4 it works the
collection points out from where the drawn drops end when no collection-point layer was drawn (spec "P4 is covered
when drops are found"). OGR only: runs in the QGIS process, right after the snapshot is written to working.gpkg.

Downstream audit (adapters/p*.py, checks/p*.py, ml/step4_drops.py, ml/step567.py; 2026-10-29): the plan-layer
fields read after approval are splitters_1to16.pon (P2, P3 Checks), collection_points.cp_id (P4 Check, P6 adapter
and Check) and .pon (P4 pon_cap fallback), drops.cp_id and .length_m (P4 Check), road_crossings.length_m (P5 Check),
splitters_8way.cp_id and dome_joints.cp_id (P6 Check). The step scripts read only geometry from the approved plan
layers. Every one has a rule below; n_drops, crosses_road, link and type are filled because the registry carries
them, though no step reads them."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from osgeo import ogr, osr
from scipy.spatial import cKDTree
from . import stages
from .fixups import next_ids

# Mirrored, not imported: checks/_plan and adapters/_plan_common call ogr.UseExceptions() at import, which would
# switch exceptions on for the whole QGIS process. tests/test_fillfields.py holds them equal to the originals.
EDGE_M = 2.0          # checks/p2_1to16.EDGE_M: a 1:16 this close to a PON (on its edge) belongs to it
HANG_M = 2.0          # adapters/p7_hardware.HANG_M: hardware this close to a collection point belongs to it
FAN_END_M = 1.0       # checks/p4_drops.FAN_END_M: a drop's collection-point end this close counts for that point
# Drop ends this close share one collection point. Measured on the Botshabelo client packages (Task 7, 2026-10-29):
# the drawn drops end ON a shared vertex (W U V S: 10,141 of 10,162 ends; Rural: 4,779 of 4,790), the rest 2 m or more
# from any other end. 0.01 to 1.0 m all give the same points (W U V S 1,433 CPs, max 10 drops, 21 single-drop; Rural
# 675, max 9, 11 single; 1,401 and 663 DC Joints), 0 ends more than FAN_END_M from their point; 2 m starts merging
# separate points (W U V S 1,432, Rural 674 with an end 1.42 m off).
CP_MERGE_M = 1.0
DRILL_MAX_M = 30.0    # 0.10.0 rule: a crossing up to 30 m is drilled, longer is trenched

_FIELD = {"str": ogr.OFTString, "int": ogr.OFTInteger, "real": ogr.OFTReal}
_GEOM = {"Point": ogr.wkbPoint, "LineString": ogr.wkbLineString, "Polygon": ogr.wkbPolygon}
_MULTI = (ogr.wkbMultiPoint, ogr.wkbMultiLineString, ogr.wkbMultiPolygon)


# ---- plumbing ---------------------------------------------------------------------------------------------------

def _srs(epsg: int):
    s = osr.SpatialReference(); s.ImportFromEPSG(int(epsg)); s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s


def _to_site(lyr, epsg: int):
    """Transform from the layer's CRS to the site CRS, or None when they are the same (or the layer has none)."""
    s = lyr.GetSpatialRef()
    code = s.GetAuthorityCode(None) if s is not None else None
    if not code or int(code) == int(epsg):
        return None
    return osr.CoordinateTransformation(_srs(int(code)), _srs(epsg))


def _geom(f, t):
    """A site-CRS 2D copy of the feature's geometry (the feature's own is never touched), or None."""
    g = f.GetGeometryRef()
    if g is None or g.IsEmpty():
        return None
    g = g.Clone(); g.FlattenTo2D()
    if ogr.GT_Flatten(g.GetGeometryType()) in _MULTI and g.GetGeometryCount() == 1:
        g = g.GetGeometryRef(0).Clone()       # final review C1: a one-part multi (every line shapefile) is its part
    if t is not None:
        g.Transform(t)
    return g


def _line_ends(g):
    """((x, y) of the first vertex, (x, y) of the last), or None for fewer than two vertices. A genuine multi line
    (final review C1, 2026-10-29) runs from the first vertex of its first part to the last vertex of its last part,
    in the order drawn; its length is the total of its parts (OGR's Length)."""
    parts = [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]
    parts = [p for p in parts if p.GetPointCount() > 0]
    if not parts or sum(p.GetPointCount() for p in parts) < 2:
        return None
    a, b = parts[0], parts[-1]
    return (a.GetX(0), a.GetY(0)), (b.GetX(b.GetPointCount() - 1), b.GetY(b.GetPointCount() - 1))


def _open(path):
    try:
        return ogr.Open(str(path)) if path and Path(path).is_file() else None
    except RuntimeError:
        return None


def _dep_layer(deps, sid, layer, log, why):
    """(datasource, layer) of an approved dependency, or (None, None) with a log line naming what was not filled."""
    ds = _open(deps.get(sid))
    lyr = ds.GetLayerByName(layer) if ds is not None else None
    if lyr is None:
        log.append(f"{why} not filled: no approved {sid} layer {layer}")
        return None, None
    return ds, lyr


def _spec(stage_id, name):
    return next(s for s in stages.get(stage_id).outputs if s.name == name)


def _layer(ds, stage_id, name, epsg):
    """The working layer `name`, with every registry field present (a hand-drawn layer may lack some); created
    empty with the registry schema when absent."""
    spec = _spec(stage_id, name)
    lyr = ds.GetLayerByName(name)
    if lyr is None:
        lyr = ds.CreateLayer(name, _srs(epsg), _GEOM[spec.geom])
    have = {lyr.GetLayerDefn().GetFieldDefn(i).GetName().lower() for i in range(lyr.GetLayerDefn().GetFieldCount())}
    for fname, typ in spec.fields:
        if fname.lower() not in have:
            lyr.CreateField(ogr.FieldDefn(fname, _FIELD[typ]))
    return lyr


def _null(f, name) -> bool:
    i = f.GetFieldIndex(name)
    if i < 0 or not f.IsFieldSetAndNotNull(i):
        return True
    v = f.GetField(i)
    return isinstance(v, str) and not v.strip()        # a blank text cell is no value the operator set


def _feats(lyr):
    lyr.ResetReading()
    out = list(lyr)
    lyr.ResetReading()
    return out


def _given(log, field, n, of, things, extra=""):
    if of:
        log.append(f"{field} given to {n} of {of} {things}{extra}")


def _pons(deps, epsg, log, why):
    """[(pon_num, site polygon)] from the approved wayleave, or None (with a log line)."""
    ds, pl = _dep_layer(deps, "wayleave", "pons", log, why)
    if pl is None:
        return None
    t = _to_site(pl, epsg); out = []
    for f in _feats(pl):
        g = _geom(f, t)
        if g is not None and f.GetFieldIndex("pon_num") >= 0 and f.GetField("pon_num") is not None:
            out.append((int(f.GetField("pon_num")), g))
    ds = None
    return out


def _pon_at(pons, pt, anywhere=False):
    """The PON the point stands in, else the nearest within EDGE_M, else None -- or, with `anywhere` (a 1:16:
    operator 2026-11-12, it need not stand inside a PON, it runs into one; P2's Check, place_1to16.pon_of), the
    nearest PON however far."""
    for num, pg in pons:
        if pg.Contains(pt):
            return num
    near = min(((pg.Distance(pt), num) for num, pg in pons), default=(None, None))
    return near[1] if near[0] is not None and (anywhere or near[0] <= EDGE_M) else None


def _point(x, y):
    p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(float(x), float(y)); return p


# Walk 2026-10-29: P4's fill froze QGIS on Botshabelo W U V S (10,162 drops x 602 roads: 5.9 M GEOS Crosses, 29 of 39 s,
# and two distances per drop to the whole distribution as one collection, 5 s). Both now test only what the bounding
# boxes allow, and give the same answers: a line can only cross a road whose box meets its own, and the distance to a
# collection of lines is the least distance to any one of them.

def _boxes(geoms) -> np.ndarray:
    """(n, 4) array of OGR envelopes (minx, maxx, miny, maxy)."""
    return np.array([g.GetEnvelope() for g in geoms], dtype=float).reshape(-1, 4)


def _box_hits(boxes: np.ndarray, g) -> np.ndarray:
    """Indices (ascending) of the boxes that meet g's envelope, edges included."""
    x0, x1, y0, y1 = g.GetEnvelope()
    return np.nonzero((boxes[:, 0] <= x1) & (boxes[:, 1] >= x0) & (boxes[:, 2] <= y1) & (boxes[:, 3] >= y0))[0]


def _nearest_distance(lines, boxes: np.ndarray, x: float, y: float) -> float:
    """Distance from (x, y) to the nearest of `lines`: what Distance() to their geometry collection gives (the least
    of the parts' distances), worked out only for the parts whose box could hold a nearer one."""
    lb = np.hypot(np.maximum(np.maximum(boxes[:, 0] - x, x - boxes[:, 1]), 0.0),
                  np.maximum(np.maximum(boxes[:, 2] - y, y - boxes[:, 3]), 0.0))
    best, p = float("inf"), _point(x, y)
    for k in np.argsort(lb, kind="stable"):
        if lb[k] > best + 1e-6:                        # every box left is farther than the best line found
            break
        best = min(best, lines[k].Distance(p))
    return best


# ---- the stages ---------------------------------------------------------------------------------------------------

def _p2(ds, deps, epsg, log):
    lyr = _layer(ds, "p2_1to16", "splitters_1to16", epsg)
    todo = [f for f in _feats(lyr) if _null(f, "pon")]
    if not todo:
        return
    pons = _pons(deps, epsg, log, "1:16 pon")
    if pons is None:
        return
    t = _to_site(lyr, epsg); n = 0
    for f in todo:
        g = _geom(f, t)
        k = _pon_at(pons, g, anywhere=True) if g is not None else None
        if k is not None:
            f.SetField("pon", k); lyr.SetFeature(f); n += 1
    _given(log, "pon", n, len(todo), "1:16s")


def _p3(ds, deps, epsg, log):
    lyr = _layer(ds, "p3_distribution", "distribution", epsg)
    feats = _feats(lyr)
    link = [f for f in feats if _null(f, "link")]
    for f in link:                                     # 0 = span; the snapshot sets 1 on lines from a Link layer
        f.SetField("link", 0); lyr.SetFeature(f)
    todo = [f for f in feats if _null(f, "pon")]
    if todo:
        pons = _pons(deps, epsg, log, "distribution pon")
        if pons is not None:
            t = _to_site(lyr, epsg); n = 0
            for f in todo:
                g = _geom(f, t)
                if g is None:
                    continue
                inside = [(g.Intersection(pg).Length(), num) for num, pg in pons if g.Intersects(pg)]
                best = max(inside, key=lambda r: r[0], default=(0.0, None))   # first PON wins a tie
                if best[0] > 0:
                    f.SetField("pon", best[1]); lyr.SetFeature(f); n += 1
            _given(log, "pon", n, len(todo), "distribution lines")
    _given(log, "link 0 (span)", len(link), len(link), "distribution lines")


def _clusters(xy: np.ndarray, tol: float) -> list[list[int]]:
    """Single-linkage groups of points within `tol` of each other, each sorted, ordered by their first member."""
    parent = list(range(len(xy)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i, j in cKDTree(xy).query_pairs(tol) if len(xy) else ():
        parent[root(i)] = root(j)
    groups = {}
    for i in range(len(xy)):
        groups.setdefault(root(i), []).append(i)
    return sorted(groups.values(), key=lambda g: g[0])


def _capped(xy: np.ndarray, groups: list[list[int]], cap: float) -> list[list[int]]:
    """Single linkage can chain: ends 0.9 m apart in a row put the outer ones more than `cap` from the group's mean,
    where P4's Check would not count those drops for the point. A group like that is split: take its first end left,
    with every end left within cap/2 of it (each then lies within cap of the mean), until none is left. A group with
    every end within `cap` of its mean is kept as it is (every Botshabelo group)."""
    out = []
    for g in groups:
        pts = xy[g]
        if np.hypot(*(pts - pts.mean(axis=0)).T).max() <= cap:
            out.append(g)
            continue
        left = list(g)
        while left:
            seed = xy[left[0]]
            near = [i for i in left if np.hypot(*(xy[i] - seed)) <= cap / 2]
            out.append(near)
            left = [i for i in left if i not in near]
    return sorted(out, key=lambda g: g[0])


def _p4(ds, deps, epsg, log):
    """Each drop is written once, after every field is set (it was three SetFeature calls per drop)."""
    drops = _layer(ds, "p4_drops", "drops", epsg)
    touched = {}
    try:
        _p4_fill(ds, deps, epsg, log, drops, touched)
    finally:
        for f in touched.values():
            drops.SetFeature(f)


def _p4_fill(ds, deps, epsg, log, drops, touched):
    def mark(f):
        touched[f.GetFID()] = f
    cps = _layer(ds, "p4_drops", "collection_points", epsg)
    if ds.GetLayerByName("drop_review") is None:       # plugin-only review markers, never scanned: always there, empty
        _layer(ds, "p4_drops", "drop_review", epsg)
    td = _to_site(drops, epsg)
    dfeats = [(f, _geom(f, td)) for f in _feats(drops)]
    dfeats = [(f, g) for f, g in dfeats if g is not None and _line_ends(g) is not None]

    todo = [f for f, _g in dfeats if _null(f, "length_m")]
    for f, g in dfeats:
        if _null(f, "length_m"):
            f.SetField("length_m", float(g.Length())); mark(f)
    _given(log, "length_m", len(todo), len(todo), "drops")

    todo = [(f, g) for f, g in dfeats if _null(f, "crosses_road")]
    if todo:
        rds, rl = _dep_layer(deps, "wayleave", "roads", log, "drop crosses_road")
        if rl is not None:
            tr = _to_site(rl, epsg)
            roads = [g for g in (_geom(r, tr) for r in _feats(rl)) if g is not None]
            boxes = _boxes(roads); n = 0
            for f, g in todo:                          # Crosses, not Intersects: ending ON a road is no crossing (P4)
                c = int(any(roads[k].Crosses(g) for k in _box_hits(boxes, g)))
                f.SetField("crosses_road", c); mark(f); n += c
            _given(log, "crosses_road", len(todo), len(todo), "drops", f" ({n} cross a road)")
        rds = None

    # the collection-point end of each drop: the end nearer the approved P3 distribution; without one, the last
    # vertex (P4's own drops run home -> collection point, the home end is vertex 0)
    pds, dl = _dep_layer(deps, "p3_distribution", "distribution", log, "drop ends by the distribution (last vertex used)")
    cable = []
    if dl is not None:
        tl = _to_site(dl, epsg)
        cable = [g for g in (_geom(f, tl) for f in _feats(dl)) if g is not None and not g.IsEmpty()]
    cboxes = _boxes(cable)
    pds = None
    ends = []                                          # (cp end, other end) per drop
    for _f, g in dfeats:
        a, b = _line_ends(g)
        if cable and _nearest_distance(cable, cboxes, *a) < _nearest_distance(cable, cboxes, *b):
            ends.append((a, b))
        else:
            ends.append((b, a))

    pons = None
    tc = _to_site(cps, epsg)
    cfeats = _feats(cps)
    if not cfeats and dfeats:
        # no collection points drawn: one at the mean of each cluster of drop ends (spec 2026-10-29), as drawn drops
        xy = np.array([e[0] for e in ends])
        groups = _capped(xy, _clusters(xy, CP_MERGE_M), FAN_END_M)
        ids = [str(n) for _i, n in next_ids([(i, None) for i in range(len(groups))])]
        pons = _pons(deps, epsg, log, "collection point pon")
        back = osr.CoordinateTransformation(_srs(epsg), _srs(int(cps.GetSpatialRef().GetAuthorityCode(None)))) \
            if tc is not None else None
        for members, cid in zip(groups, ids):
            m = xy[members].mean(axis=0)
            p = _point(*m)
            if back is not None:
                p.Transform(back)
            f = ogr.Feature(cps.GetLayerDefn()); f.SetGeometry(p)
            f.SetField("cp_id", cid); f.SetField("n_drops", len(members))
            k = _pon_at(pons, _point(*m)) if pons is not None else None
            if k is not None:
                f.SetField("pon", k)
            cps.CreateFeature(f)
            for i in members:
                df = dfeats[i][0]
                if _null(df, "cp_id"):
                    df.SetField("cp_id", cid); mark(df)
        log.append(f"{len(groups)} collection points worked out from where {len(dfeats)} drops end "
                   f"(ends within {CP_MERGE_M:g} m share one)")
        return

    # collection points drawn: used as drawn; their missing cp_id numbered as P4's Check does (fixups.next_ids)
    new = dict(next_ids([(f.GetFID(), None if _null(f, "cp_id") else f.GetField("cp_id")) for f in cfeats]))
    for f in cfeats:
        if f.GetFID() in new:
            f.SetField("cp_id", str(new[f.GetFID()])); cps.SetFeature(f)
    _given(log, "cp_id", len(new), len(new), "collection points")
    cxy = [(f, _geom(f, tc)) for f in cfeats]
    cxy = [(f, g) for f, g in cxy if g is not None]
    tree = cKDTree(np.array([(g.GetX(), g.GetY()) for _f, g in cxy])) if cxy else None
    todo = [i for i, (f, _g) in enumerate(dfeats) if _null(f, "cp_id")]
    n = 0
    for i in todo:
        for end in ends[i]:                            # the collection-point end first, then the other
            d, j = tree.query(end) if tree is not None else (float("inf"), None)
            if d <= CP_MERGE_M:
                f = dfeats[i][0]; f.SetField("cp_id", str(cxy[j][0].GetField("cp_id"))); mark(f); n += 1
                break
    _given(log, "cp_id", n, len(todo), "drops")
    count = {}
    for f, _g in dfeats:
        if not _null(f, "cp_id"):
            count[str(f.GetField("cp_id"))] = count.get(str(f.GetField("cp_id")), 0) + 1
    todo = [(f, g) for f, g in cxy if _null(f, "n_drops")]
    for f, _g in todo:
        f.SetField("n_drops", count.get(str(f.GetField("cp_id")), 0)); cps.SetFeature(f)
    _given(log, "n_drops", len(todo), len(todo), "collection points")
    todo = [(f, g) for f, g in cxy if _null(f, "pon")]
    if todo:
        pons = _pons(deps, epsg, log, "collection point pon")
        if pons is not None:
            n = 0
            for f, g in todo:
                k = _pon_at(pons, g)
                if k is not None:
                    f.SetField("pon", k); cps.SetFeature(f); n += 1
            _given(log, "pon", n, len(todo), "collection points")


def _p5(ds, deps, epsg, log):
    lyr = _layer(ds, "p5_crossings", "road_crossings", epsg)
    t = _to_site(lyr, epsg)
    feats = [(f, _geom(f, t)) for f in _feats(lyr)]
    todo = [(f, g) for f, g in feats if g is not None and _null(f, "length_m")]
    for f, g in todo:
        f.SetField("length_m", float(g.Length())); lyr.SetFeature(f)
    _given(log, "length_m", len(todo), len(todo), "road crossings")
    todo = [(f, g) for f, g in feats if _null(f, "type") and (g is not None or not _null(f, "length_m"))]
    for f, g in todo:
        L = f.GetField("length_m") if not _null(f, "length_m") else g.Length()
        f.SetField("type", "Drill" if float(L) <= DRILL_MAX_M + 1e-9 else "Trench"); lyr.SetFeature(f)
    _given(log, "type", len(todo), len(todo), "road crossings", f" (Drill up to {DRILL_MAX_M:g} m, Trench longer)")


def _p7(ds, deps, epsg, log):
    lyrs = [(name, things, _layer(ds, "p7_hardware", name, epsg))
            for name, things in (("splitters_8way", "8-way splitters"), ("dome_joints", "dome joints"))]
    todo = [(things, lyr, [f for f in _feats(lyr) if _null(f, "cp_id")]) for _n, things, lyr in lyrs]
    if not any(t[2] for t in todo):
        return
    pds, cl = _dep_layer(deps, "p4_drops", "collection_points", log, "hardware cp_id")
    if cl is None:
        return
    tc = _to_site(cl, epsg)
    cps = [(f.GetField("cp_id"), g) for f in _feats(cl) if (g := _geom(f, tc)) is not None and not _null(f, "cp_id")]
    tree = cKDTree(np.array([(g.GetX(), g.GetY()) for _c, g in cps])) if cps else None
    for things, lyr, feats in todo:
        t = _to_site(lyr, epsg); n = 0
        for f in feats:
            g = _geom(f, t)
            if g is None or tree is None:
                continue
            d, j = tree.query((g.GetX(), g.GetY()))
            if d <= HANG_M:
                f.SetField("cp_id", cps[j][0]); lyr.SetFeature(f); n += 1
        _given(log, "cp_id", n, len(feats), things)
    pds = None


_BY_STAGE = {"p2_1to16": _p2, "p3_distribution": _p3, "p4_drops": _p4, "p5_crossings": _p5, "p7_hardware": _p7}


def fill(stage_id: str, working: Path, deps: dict[str, Path], epsg: int) -> list[str]:
    """Fill the NULL or missing registry fields of `stage_id`'s layers in `working` (edited in place) from geometry
    and the approved upstream gpkgs in `deps` (stage id -> approved gpkg). One log line per kind of fill; a rule whose
    dependency is missing is skipped with a line saying so. p1_feeder has nothing to fill."""
    fn = _BY_STAGE.get(stage_id)
    if fn is None:
        return []
    ds = ogr.Open(str(working), 1)
    if ds is None:
        return [f"fields not filled: cannot open {working}"]
    log: list[str] = []
    # one transaction: each SetFeature otherwise commits on its own (Botshabelo Rural's 4,790 drops: 41 of 47 s in
    # SetFeature, in the QGIS process, Task 7 2026-10-29)
    started = ds.StartTransaction() == 0
    try:
        fn(ds, deps or {}, int(epsg), log)
        if started:
            ds.CommitTransaction()
        ds.FlushCache()
    except BaseException:
        if started:
            ds.RollbackTransaction()
        raise
    finally:
        ds = None
    return log
