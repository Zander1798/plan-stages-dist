"""Pure-Python name matching for the Wayleave box (no QGIS): which project layer feeds a registry layer, and
which source field feeds a registry field."""
from __future__ import annotations
import math
import re

# Operator ruling 2026-10-06: when a project layer has no field of the registry name, take the first field whose
# lowercased name is in this list (in this order); null when none matches.
ALIASES = {"homes": ("units", "stands", "home_count", "homes_count", "count"),
           "pon_num": ("pon", "pon_id", "pon_no", "number", "id"),
           "erf_id": ("id", "erf", "erf_no", "parcel_id", "stand_no"),
           "name": ("label", "title", "site"),
           "role": ("type", "class")}


def source_field(target: str, src_names: list[str]) -> tuple[int, str | None]:
    """(index, how) of the source field feeding registry field `target` among src_names (any case): the
    same name, else the first alias present; (-1, None) when none matches."""
    low = [n.lower() for n in src_names]
    for key in (target.lower(),) + ALIASES.get(target, ()):
        if key in low:
            i = low.index(key)
            return i, src_names[i] if key == target.lower() else f"{src_names[i]} (alias)"
    return -1, None


# A label ending in its number: a word, then optional separators, then digits (Botshabelo's "PON 047").
_LABEL_INT = re.compile(r"^\s*[A-Za-z]+[\s_#:.\-]*(\d+)\s*$")


def int_value(value) -> int | None:
    """The integer a source value holds: a number, numeric text ("47", "47.0"), or (walk 2026-10-29) a label that
    ends in its number ("PON 047" -> 47); None for anything else."""
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    try:
        f = float(value)
        return int(f) if math.isfinite(f) else None
    except (TypeError, ValueError):
        pass
    m = _LABEL_INT.match(str(value))
    return int(m.group(1)) if m else None


# Names the operator's projects use for each wayleave layer (live walk 2026-10-07: Cradock has Pon, Demand Point,
# OLT; Ventersdorp has pons, Demand Points, POP). Matched whole, case-insensitive, with spaces/underscores/hyphens
# ignored, so a required row still never fills on a partial match.
LAYER_NAMES = {
    "span": ("span", "spans", "cable span", "wayleave span", "wayleave"),
    "pons": ("pon", "pons", "pond", "ponds", "pon zones", "pon zone", "pon test"),
    "demand_points": ("demand point", "demand points", "demandpoints", "dp", "dps", "homes",
                      "demand unit", "demand units"),         # Botshabelo packages (walk 2026-10-29)
    "pop": ("pop", "pops", "olt", "olts", "exchange"),
    "roads": ("road", "roads", "road osm", "osm roads", "streets"),
    "poles": ("pole", "poles"),
    "erven": ("erf", "erven", "ervan", "erfs", "stands", "parcels"),
    "aoi": ("aoi", "area of interest", "boundary", "site boundary"),
    "buildings": ("building", "buildings", "footprints", "building footprints", "structures", "open buildings"),
}


def _norm(s: str) -> str:
    return "".join(ch for ch in s.strip().lower() if ch not in " _-")


# Known names for the hand-drawn plan layers (spec 2026-10-29, "What the scan shows"; operator rulings 2026-10-29:
# Feeder Joints are the 1:16s, DC Joints the domes, Link Joints left out). "1:8"/"8 way" are deliberately in no
# list: the spec removed them from collection_points, so a bare 1:8 stays empty for the operator to pick.
PLAN_LAYER_NAMES = {
    "feeder": ("feeder", "feeder cable", "feeder cables", "feeder fibre"),
    "splitters_1to16": ("1:16", "1-16", "1to16", "1x16", "1:16 splitter", "1:16 splitters", "feeder joint",
                        "feeder joints", "fdp",
                        # Matsafeni 2026-11-12: "1 to 16 Splitter" was not found, so Scan said Generate and P2 drew a
                        # second 1:16 layer beside the operator's
                        "1 to 16", "1 to 16 splitter", "1 to 16 splitters", "1-16 splitter", "1-16 splitters",
                        "1x16 splitter", "1x16 splitters", "feeder splitter", "feeder splitters"),
    "distribution": ("distribution", "distribution cable", "distribution cables", "dist cable", "link fibre",
                     "link cable", "link cables"),                     # Matsafeni's Link Cable (link = 1)
    "collection_points": ("collection point", "collection points", "cp", "cps"),
    "drops": ("drop", "drops", "drop cable", "drop cables", "drop fibre"),
    "road_crossings": ("road crossing", "road crossings", "crossing", "crossings"),
    "splitters_8way": ("8-way splitter", "8-way splitters", "8way", "1:8 splitter", "1:8 splitters"),
    "dome_joints": ("dome joint", "dome joints", "dome", "domes", "dc joint", "dc joints"),
}
# A normalised name starting with one of these matches too (Botshabelo: DC Fibre 12F Aerial, DC Fibre 24F Aerial).
PLAN_PREFIXES = {"distribution": ("dc fibre",)}
# Never matched to any plan layer (operator 2026-10-29: Link Joints belong to no step).
LEFT_OUT = ("link joint", "link joints")


def _plan_hits(layer: str, low: list[str]) -> set[int]:
    keys = {_norm(k) for k in PLAN_LAYER_NAMES.get(layer, ())}
    prefixes = [_norm(p) for p in PLAN_PREFIXES.get(layer, ())]
    left = {_norm(k) for k in LEFT_OUT}
    return {i for i, n in enumerate(low)
            if n not in left and (n in keys or any(n.startswith(p) for p in prefixes))}


def match_plan_layers(layer: str, layer_names: list[str]) -> list[int]:
    """Indices of the project layers that feed plan layer `layer`: whole-name matches on PLAN_LAYER_NAMES plus
    PLAN_PREFIXES. A name that fits more than one plan layer is dropped from every row (a wrong automatic match
    is worse than an empty one)."""
    low = [_norm(n) for n in layer_names]
    mine = _plan_hits(layer, low)
    others = set()
    for other in set(PLAN_LAYER_NAMES) | set(PLAN_PREFIXES):
        if other != layer:
            others |= _plan_hits(other, low)
    return sorted(mine - others)


def is_link_layer(name: str) -> bool:
    """True when the layer name says link (Link Fibre): its lines become distribution with link = 1."""
    return "link" in _norm(name)


def match_name(name: str, basename: str, optional: bool, layer_names: list[str], counts=None) -> int | None:
    """Index of the layer name that most likely is registry layer `name`: a whole-name match (case-insensitive,
    ignoring spaces, underscores and hyphens) on the registry name, the operator's shapefile basename, or one of
    the names in LAYER_NAMES, in that order; for an OPTIONAL layer only, then the shortest name containing the
    registry name or basename. None when nothing matches.
    `counts` (walk 2026-10-29; feature count per layer, -1/None = unknown): a matching layer with features is taken
    before an empty one, and a REQUIRED row is left for the operator to pick rather than given an empty layer while
    some other layer on the list has features (Botshabelo's package POP layer is empty)."""
    keys = [_norm(name), _norm(basename)] + [_norm(k) for k in LAYER_NAMES.get(name, ())]
    low = [_norm(n) for n in layer_names]
    hits = [i for key in keys for i, n in enumerate(low) if n == key]
    if not hits and optional:
        sub = [_norm(name), _norm(basename)]
        hits = sorted((i for i, n in enumerate(low) if any(k in n for k in sub)),
                      key=lambda i: (len(layer_names[i]), i))
    if not hits:
        return None
    if counts is None:
        return hits[0]
    empty = [c == 0 for c in counts]
    full = [i for i in hits if not empty[i]]
    if full:
        return full[0]
    return None if not optional and not all(empty) else hits[0]
