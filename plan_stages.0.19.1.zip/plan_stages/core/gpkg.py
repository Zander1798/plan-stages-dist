from __future__ import annotations
import shutil
from pathlib import Path
from osgeo import ogr, osr
from .stages import LayerSpec

PLACEHOLDER = "_none"   # the one empty layer of a stage with no outputs (OGR will not open a GPKG with none)
_GEOM = {"Point": ogr.wkbPoint, "LineString": ogr.wkbLineString, "Polygon": ogr.wkbPolygon}
_FIELD = {"str": ogr.OFTString, "int": ogr.OFTInteger, "real": ogr.OFTReal}


def create_empty(path: Path, epsg: int, layers: tuple[LayerSpec, ...]) -> None:
    drv = ogr.GetDriverByName("GPKG")
    ds = drv.CreateDataSource(str(path))
    srs = osr.SpatialReference(); srs.ImportFromEPSG(epsg)
    for spec in layers:
        lyr = ds.CreateLayer(spec.name, srs, _GEOM[spec.geom])
        for name, typ in spec.fields:
            lyr.CreateField(ogr.FieldDefn(name, _FIELD[typ]))
    del ds


def layer_names(path: Path) -> list[str]:
    ds = ogr.Open(str(path))
    return [ds.GetLayer(i).GetName() for i in range(ds.GetLayerCount())] if ds else []


def copy(src: Path, dst: Path) -> None:
    shutil.copyfile(src, dst)
