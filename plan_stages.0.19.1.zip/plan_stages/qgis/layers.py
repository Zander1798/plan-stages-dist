from __future__ import annotations
from pathlib import Path
from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
                       QgsCoordinateReferenceSystem, QgsLayerTree)
from ..core.stages import Stage
from ..core.checks import ChecksReport
from ..core import gpkg

STYLE_DIR = Path(__file__).resolve().parents[1] / "styles"
# Marks every layer the plugin loads (stage layers, issue layers). Saved with the project, so a reopened project's
# plugin layers stay marked; the Wayleave box never offers a marked layer (live walk 2026-10-15).
OWN_PROP = "plan_stages/own"


def group_name(site: str, stage: Stage, rev: str) -> str:
    return f"{site} · {stage.name} ({rev})"


def _find_group(site: str, stage: Stage):
    return _groups_named(site, stage.name)


def _all_groups(node) -> list:
    """Every group under `node`, at any depth (findGroups() sees only the top level, so a stage group the operator
    dragged into a group of their own was never found, and the next Generate added a second one: 2026-11-12)."""
    out = []
    for child in node.children():
        if QgsLayerTree.isGroup(child):
            out.append(child)
            out.extend(_all_groups(child))
    return out


def _groups_named(site: str, stage_name: str):
    root = QgsProject.instance().layerTreeRoot()
    prefix = f"{site} · {stage_name} ("
    return [g for g in _all_groups(root) if g.name().startswith(prefix)]


# The plan-stage display names of layout 1 (0.10.0), frozen: the registry no longer has them, so unload_stale and
# unload_all never matched an old site's groups, and their open GeoPackages stopped the move to old-layout/.
OLD_LAYOUT_NAMES = ("P1 Feeder, distribution, 1:16", "P2 Collection points and drops", "P3 Road crossings",
                    "P4 Pole reconciliation", "P5 Splitters and dome joints", "P6 Delivery")


# 0.12.0's display names of the stages 0.13.0 removed (P6 Pole reconciliation) or renamed (P7 -> P6, P8 -> P7).
# A project saved by 0.12.0 holds groups under these names; unload_stale drops them so the project opens clean.
RENAMED_NAMES = ("P6 Pole reconciliation", "P7 Splitters and dome joints", "P8 Delivery")


def _unload_named(site: str, names) -> list[str]:
    proj = QgsProject.instance()
    root = proj.layerTreeRoot(); gone = []
    for name in names:
        groups = _groups_named(site, name); issues = proj.mapLayersByName(f"{site} · {name} issues")
        if groups or issues:
            gone.append(name)
        for g in groups:
            for child in g.findLayers():
                proj.removeMapLayer(child.layerId())
            (g.parent() or root).removeChildNode(g)
        for lyr in issues:
            proj.removeMapLayer(lyr.id())
    return gone


def unload_old_layout(site: str) -> None:
    """Every layout-1 plan group and issues layer of this site leaves the project, so their files are released
    before the old plan work is moved to old-layout/ (final review 2026-10-21). The operator's layers stay."""
    _unload_named(site, OLD_LAYOUT_NAMES)


def find_stage_group(site: str, stage: Stage, rev: str | None = None):
    """The loaded layer-tree group of this stage, found by its deterministic name (exactly `rev` when given,
    else any revision); None if it is not loaded."""
    if rev is not None:
        return QgsProject.instance().layerTreeRoot().findGroup(group_name(site, stage, rev))
    groups = _find_group(site, stage)
    return groups[0] if groups else None


def unload_stage(site: str, stage: Stage) -> None:
    root = QgsProject.instance().layerTreeRoot()
    for g in _find_group(site, stage):
        for child in g.findLayers():
            QgsProject.instance().removeMapLayer(child.layerId())
        (g.parent() or root).removeChildNode(g)


def unload_issues(site: str, stage: Stage) -> None:
    for lyr in QgsProject.instance().mapLayersByName(f"{site} · {stage.name} issues"):
        QgsProject.instance().removeMapLayer(lyr.id())


def unload_all(site: str) -> None:
    """Every stage group and issues layer of this site leaves the project (the operator's layers stay). Done BEFORE
    revisions are deleted from disk: a loaded GeoPackage holds a file lock and the delete would fail (2026-10-08)."""
    from ..core import stages
    for sid in stages.order():
        unload_stage(site, stages.get(sid)); unload_issues(site, stages.get(sid))


def unload_stale(site: str, state: dict) -> list[str]:
    """Drop the plugin's OWN layers for every stage that has no current revision (pending, or wiped on open), so a
    project saved with old stage layers opens clean. Only groups named `<site> · <stage> (rev)` and the
    `<site> · <stage> issues` layers are touched: the operator's wayleave layers are never removed (2026-10-08)."""
    from ..core import stages
    gone = []
    for sid in stages.order():
        st = state.get(sid, {})
        if st.get("current_rev"):
            continue
        stage = stages.get(sid)
        if _find_group(site, stage) or QgsProject.instance().mapLayersByName(f"{site} · {stage.name} issues"):
            gone.append(sid)
        unload_stage(site, stage); unload_issues(site, stage)
    _unload_named(site, RENAMED_NAMES)
    return gone


def load_stage(iface, site: str, stage: Stage, rev_dir: Path, editable: bool):
    unload_stage(site, stage)
    root = QgsProject.instance().layerTreeRoot()
    grp = root.insertGroup(0, group_name(site, stage, rev_dir.name))
    path = rev_dir / "working.gpkg"
    for name in gpkg.layer_names(path):
        if name == gpkg.PLACEHOLDER:                      # 0.19.1: never on the map (D-PS.21, no extra layer)
            continue
        vl = QgsVectorLayer(f"{path}|layername={name}", name, "ogr")
        if not vl.isValid():
            continue
        qml = STYLE_DIR / f"{stage.id}__{name}.qml"
        if qml.exists():
            vl.loadNamedStyle(str(qml))
        vl.setReadOnly(not editable)
        vl.setCustomProperty(OWN_PROP, True)
        QgsProject.instance().addMapLayer(vl, False)
        grp.addLayer(vl)
    iface.mapCanvas().refresh()
    return grp


def load_issues(iface, site: str, stage: Stage, rev_dir: Path):
    report = ChecksReport.load(rev_dir / "checks.json")
    name = f"{site} · {stage.name} issues"
    for lyr in QgsProject.instance().mapLayersByName(name):
        QgsProject.instance().removeMapLayer(lyr.id())
    if not report.issues:
        return None
    epsg = report.issues[0].epsg
    vl = QgsVectorLayer(f"Point?crs=EPSG:{epsg}&field=code:string&field=severity:string&field=message:string"
                        f"&field=layer:string&field=fid:integer&field=source:string", name, "memory")
    pr = vl.dataProvider()
    feats = []
    for i in report.issues:
        f = QgsFeature(vl.fields()); f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i.x, i.y)))
        f.setAttributes([i.code, i.severity, i.message, i.layer, i.fid, i.source]); feats.append(f)
    pr.addFeatures(feats); vl.updateExtents()
    vl.setCustomProperty(OWN_PROP, True)
    QgsProject.instance().addMapLayer(vl)
    return vl


def on_commit(vlayers, callback) -> None:
    """Call `callback()` after any of these layers saves an edit session (afterCommitChanges). A rolled-back
    session does not count. Operator ruling 2026-10-08: errors must disappear when the operator fixes them, so
    the stage re-checks itself after every save."""
    for vl in vlayers:
        vl.afterCommitChanges.connect(lambda *_, cb=callback: cb())


def group_layers(grp) -> list:
    return [c.layer() for c in grp.findLayers() if c.layer() is not None] if grp is not None else []


def set_group_readonly(grp, readonly: bool) -> None:
    """An approved stage's layers are a record: leave edit mode (Approve already refused unsaved edits) and
    lock them; Revise loads an editable copy instead."""
    for child in grp.findLayers():
        lyr = child.layer()
        if lyr is None:
            continue
        if lyr.isEditable():
            lyr.rollBack()
        lyr.setReadOnly(readonly)


def save_all_edits(grp) -> bool:
    ok = True
    for child in grp.findLayers():
        lyr = child.layer()
        if lyr.isEditable():
            ok = lyr.commitChanges() and ok
    return ok


def has_unsaved_edits(grp) -> bool:
    return any(c.layer().isEditable() and c.layer().isModified() for c in grp.findLayers())


def flush_wal(gpkg: Path) -> bool:
    """QGIS commits GeoPackage edits into <gpkg>-wal; hashing or copying the main file alone would miss them.
    Checkpoint the WAL into the main file. False if it could not be fully checkpointed."""
    import sqlite3
    if not Path(str(gpkg) + "-wal").exists():
        return True
    con = sqlite3.connect(str(gpkg), timeout=10)
    try:
        busy, log, done = con.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
    except sqlite3.Error:
        return False
    finally:
        con.close()
    return busy == 0 and log == done
