"""One tab of stage rows (Generate / Check / Approve / Reject / Revise, plus Load after a restart) and the
selected stage's logs and issues."""
from __future__ import annotations
import html
import json
from pathlib import Path
from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal
from qgis.PyQt.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
                                 QRadioButton, QButtonGroup, QPlainTextEdit, QListWidgetItem, QSplitter)
from qgis.core import QgsApplication
from ..core import approval, dismiss, stages
from ..core.scan import SCANNED
from ..core.checks import ChecksReport, Issue
from . import layers
from .details_dialogs import confirm_details
from .issue_list import IssueList
from .runner import SubprocessTask
from .ui import ask_yes_no, ask_note, badge_style, tail, warn

BUTTONS = ("generate", "check", "approve", "reject", "revise", "remove")
LOGS = ("run.log", "check.log")          # generator output, then the last Check's output


def assign_cp_ids(grp, working_gpkg: Path) -> list[str]:
    """2026-10-14: P4's Check gives a hand-drawn collection point the next free cp_id, through the loaded layer when
    it is on screen (so the screen and the file agree), else in the file."""
    from ..core import fixups
    lyr = next((l for l in layers.group_layers(grp) if l.name() == "collection_points"), None)
    if lyr is None:
        return fixups.assign_missing_cp_ids(working_gpkg)
    idx = lyr.fields().indexOf("cp_id")
    if idx < 0:
        return []
    todo = fixups.next_ids([(f.id(), None if f["cp_id"] is None or str(f["cp_id"]) == "NULL" else f["cp_id"])
                            for f in lyr.getFeatures()])
    if todo:
        lyr.dataProvider().changeAttributeValues({fid: {idx: n} for fid, n in todo})
        lyr.reload(); lyr.triggerRepaint()
    return [f"cp_id {n} given to collection point fid {fid}" for fid, n in todo]


def write_step_snapshot(path: Path, stage_id: str, chosen: dict, epsg: int, log: list | None = None) -> dict:
    """0.16.0 Scan: a step's project layers copied into its plan layers, exactly as a takeover writes them (and as a
    rescan writes them again to compare): the snapshot outputs, and for distribution `link` 1 on every line of a layer
    named as a link layer (final review M1: any other layer keeps the operator's own link value; fill makes a null 0).
    One-part multi geometries are written single (final review C1: every line shapefile reads as MultiLineString)."""
    from ..core.layermatch import is_link_layer
    from ..core.scan import snapshot_outputs
    from . import wayleave_box
    flag = (lambda l: 1 if is_link_layer(l.name()) else None) if stage_id == "p3_distribution" else None
    return wayleave_box.write_snapshot(path, chosen, epsg, log, outputs=snapshot_outputs(stage_id), link_flag=flag,
                                       single_parts=True, int_labels=True)   # "PON 047" -> 47 (walk 2026-10-29)


# Plain names of the plan layers, for messages (2026-11-12).
_PLAIN = {"feeder": "feeder", "splitters_1to16": "1:16 splitters", "distribution": "distribution",
          "collection_points": "collection points", "drops": "drops", "road_crossings": "road crossings",
          "splitters_8way": "8-way splitters", "dome_joints": "dome joints"}


class StageTab(QWidget):
    changed = pyqtSignal()          # any flow finished: the dock re-evaluates every tab

    def __init__(self, iface, stage_ids: list[str], on_busy=None, parent=None):
        super().__init__(parent)
        self.iface, self.stage_ids, self.on_busy = iface, list(stage_ids), on_busy
        self.controller = self.store = None
        self.wayleave_layer = None       # set by the dock: name -> the project's wayleave layer the operator chose
        self.wayleave_chosen = None      # set by the dock: () -> {name: the project's wayleave layer} (2026-10-14)
        self.locked, self.busy = False, False
        self._saving_for = None          # stage whose edits the tab itself is committing (Check/Approve): no auto re-check
        self._tasks: list = []           # keep QgsTasks alive until finished
        self.selected = self.stage_ids[0] if self.stage_ids else None
        self._build()

    # ---------------- layout ----------------
    def _build(self):
        outer = QVBoxLayout(self)
        rows = QWidget(); grid = QGridLayout(rows); grid.setContentsMargins(0, 0, 0, 0)
        self.sel_group = QButtonGroup(self); self.sel_group.setExclusive(True)
        self.rows: dict[str, dict] = {}
        for r, sid in enumerate(self.stage_ids):
            radio = QRadioButton(stages.get(sid).name); radio.setChecked(sid == self.selected)
            radio.toggled.connect(lambda on, s=sid: on and self.select(s))
            self.sel_group.addButton(radio)
            badge = QLabel("-"); badge.setAlignment(Qt.AlignmentFlag.AlignCenter); badge.setMinimumWidth(70)
            grid.addWidget(radio, r, 0); grid.addWidget(badge, r, 1)
            row = {"radio": radio, "badge": badge}
            for c, name in enumerate(BUTTONS):
                b = QPushButton(name.capitalize()); b.setEnabled(False)
                b.clicked.connect(lambda _=False, s=sid, n=name: getattr(self, n)(s))
                row[name] = b
                if name != "generate":
                    grid.addWidget(b, r, 2 + c)
                    continue
                cell = QHBoxLayout(); cell.setContentsMargins(0, 0, 0, 0); cell.addWidget(b)
                if sid in SCANNED:                # 0.16.0: a step Scan found drawn, offered beside Generate in its turn
                    use = QPushButton("Use my drawn layer"); use.hide()
                    use.setToolTip("Take over the layer you drew for this step (picked in Scan) as its approved "
                                   "version; its Check still runs and lists issues")
                    use.clicked.connect(lambda _=False, s=sid: self.use_drawn(s))
                    cell.addWidget(use); row["use_drawn"] = use
                grid.addLayout(cell, r, 2 + c)
            load = QPushButton("Load"); load.setToolTip("Load this stage's current revision into the project")
            load.clicked.connect(lambda _=False, s=sid: self.load(s)); load.hide()
            grid.addWidget(load, r, 2 + len(BUTTONS)); row["load"] = load
            self.rows[sid] = row
        self.grid = grid
        outer.addWidget(rows)
        # the operator's own details for the selected stage (2026-10-14): ticked at Approve
        self.details_label = QLabel(""); self.details_label.setWordWrap(True); self.details_label.hide()
        self.details_label.setStyleSheet("QLabel { background: #fff8e1; border: 1px solid #f9a825; padding: 4px; }")
        outer.addWidget(self.details_label)
        split = QSplitter(Qt.Orientation.Vertical)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setPlaceholderText("run.log and check.log of the selected stage")
        self.issues = IssueList(self.iface, self._resolve_issue)
        # 0.8.1 (operator walk 2026-10-15): the operator decides whether an issue is a real problem (errors too: 2026-10-16)
        box = QWidget(); bl = QVBoxLayout(box); bl.setContentsMargins(0, 0, 0, 0)
        self.remove_btn = QPushButton("Remove issue"); self.remove_btn.setEnabled(False)
        self.remove_btn.setToolTip("Remove an issue you judge is not a real problem (a warning or an error). It stays "
                                   "off the list, and Approve records it.")
        self.remove_btn.clicked.connect(self._remove_toggle)
        self.issues.currentItemChanged.connect(lambda *_: self._update_remove())
        self.issues.marked.connect(self._update_remove)
        bl.addWidget(self.issues, 1); bl.addWidget(self.remove_btn, 0, Qt.AlignmentFlag.AlignLeft)
        split.addWidget(self.log); split.addWidget(box)
        outer.addWidget(split, 1)

    # ---------------- state ----------------
    def set_site(self, controller, store, locked: bool):
        self.controller, self.store, self.locked = controller, store, locked
        self.busy = False
        self.refresh()

    def refresh(self):
        """Every button state comes from controller.next_enabled; re-run after every flow."""
        usable = self.controller is not None and not self.locked and not self.busy
        state = self.store.load()["stages"] if self.controller is not None else {}
        for sid, row in self.rows.items():
            status = state.get(sid, {}).get("status", "-")
            row["badge"].setText(status); row["badge"].setStyleSheet(badge_style(status)); row["badge"].setToolTip("")
            try:                                           # one bad row must never freeze the whole tab
                en = self.controller.next_enabled(sid) if usable else {}
            except Exception as e:                         # noqa: BLE001
                en = {}
                row["badge"].setToolTip(f"{type(e).__name__}: {e}")
            for name in BUTTONS:
                row[name].setEnabled(bool(en.get(name)))
            try:
                self._update_load(sid, row, state.get(sid, {}), usable)
            except Exception:                              # noqa: BLE001
                row["load"].hide()
            try:
                self._update_use_drawn(sid, row, state, usable)
            except Exception:                              # noqa: BLE001
                if "use_drawn" in row:
                    row["use_drawn"].hide()
        try:
            self._show_selected()
        except Exception as e:                             # noqa: BLE001
            self.log.setPlainText(f"could not show the selected stage: {type(e).__name__}: {e}")

    def _update_load(self, sid: str, row: dict, s: dict, usable: bool):
        """After a restart the project may not hold a stage's current revision: offer Load (never auto-load). Never for
        a taken-over revision: the operator's own layer is the one on the map (operator 2026-11-06, no double layers)."""
        rev = self.store.rev_dir(sid, s["current_rev"]) if self.store is not None and s.get("current_rev") else None
        need = (rev is not None and (rev / "working.gpkg").exists() and not (rev / "takeover.json").exists()
                and layers.find_stage_group(self.store.site, stages.get(sid), rev.name) is None)
        row["load"].setVisible(bool(need))
        row["load"].setEnabled(bool(need) and usable)

    def load(self, stage_id: str):
        stage, store = stages.get(stage_id), self.store
        rev = self._rev(stage_id)
        if rev is None:
            return
        editable = store.stage_state(stage_id)["status"] != "approved"
        self._complete(stage_id, f"{stage.name}: load",
                       lambda: self._load_layers(stage_id, store.site, stage, rev, editable=editable))

    def _load_layers(self, stage_id: str, site: str, stage, rev: Path, editable: bool):
        grp = layers.load_stage(self.iface, site, stage, rev, editable=editable)
        layers.on_commit(layers.group_layers(grp), lambda s=stage_id: self._saved(s))
        return grp

    def _saved(self, stage_id: str):
        """A stage layer was saved by the operator: re-run its Check so fixed errors disappear and the fresh
        checks make Approve available (ruling 2026-10-08). Not when the tab itself is saving for Check/Approve."""
        if self._saving_for == stage_id or self.busy or self.locked or self.controller is None:
            return
        if self.store.stage_state(stage_id)["status"] in ("approved", "pending"):
            return
        QTimer.singleShot(0, lambda: None if self.busy else self.check(stage_id))

    def select(self, stage_id: str):
        self.selected = stage_id
        self._show_selected()

    def _rev(self, stage_id: str, store=None) -> Path | None:
        store = store or self.store
        if store is None:
            return None
        cur = store.stage_state(stage_id)["current_rev"]
        return store.rev_dir(stage_id, cur) if cur else None

    def _group(self, stage_id: str, store=None):
        store = store or self.store
        rev = self._rev(stage_id, store)
        return layers.find_stage_group(store.site, stages.get(stage_id), rev.name) if rev else None

    def _show_details(self):
        details = approval.stage_details(self.store, self.selected) if self.store is not None and self.selected else []
        self.details_label.setVisible(bool(details))
        self.details_label.setText(f"<b>Operator details for this stage ({len(details)})</b>: each is ticked as "
                                   f"checked against the plan at Approve.<br>" +
                                   "<br>".join(f"• {html.escape(x['detail'])}" for x in details))

    def _show_selected(self):
        self._show_details()
        self.log.clear(); self.issues.clear()
        rev = self._rev(self.selected) if self.selected else None
        if rev is None:
            return
        parts = [f"===== {n} =====\n" + (rev / n).read_text(encoding="utf-8", errors="replace")
                 for n in LOGS if (rev / n).exists()]
        tk = rev / "takeover.json"                        # 0.16.0: say where a taken-over layer came from
        if tk.exists():
            try:
                names = [x["name"] for ls in json.loads(tk.read_text(encoding="utf-8"))["layers"].values() for x in ls]
                parts.insert(0, f"Drawn by hand (layer {', '.join(names)}), taken over by Scan\n")
            except (OSError, ValueError, KeyError, TypeError):
                parts.insert(0, "Drawn by hand, taken over by Scan\n")
        self.log.setPlainText("\n".join(parts) if parts else "(no run.log or check.log)")
        cj = rev / "checks.json"
        if not cj.exists():
            return
        try:
            report = ChecksReport.load(cj)
        except Exception as e:                           # noqa: BLE001 - a bad file must not break the tab
            self.issues.addItem(QListWidgetItem(f"checks.json unreadable: {type(e).__name__}: {e}"))
            return
        shown, removed, fixed = dismiss.split_how(report, rev)
        self.issues.set_report(ChecksReport(report.checks, shown, report.dropped), removed=removed, fixed=fixed)
        self._update_remove()

    def _update_remove(self):
        """Remove is offered on a shown issue with a fingerprint (a warning or an error); Restore on a removed row. Never on an approved
        stage (its record is closed: Revise first), nor while locked or busy."""
        issue, removed = self.issues.current()
        st = self.store.stage_state(self.selected)["status"] if self.store is not None and self.selected else None
        edited = self.issues.current_edited()
        ok = (issue is not None and not self.locked and not self.busy and st not in (None, "approved") and not edited
              and (removed or bool(issue.geom_hash)))
        self.remove_btn.setEnabled(bool(ok))
        self.remove_btn.setText("Restore issue" if removed else "Remove issue")
        self.remove_btn.setToolTip("You edited this feature: Check again first. If the Check still finds the issue it "
                                   "stays crossed out as fixed by you." if edited else
                                   "Remove an issue you judge is not a real problem (a warning or an error). It stays "
                                   "off the list, and Approve records it.")

    def _remove_toggle(self):
        issue, removed = self.issues.current()
        rev = self._rev(self.selected)
        if issue is None or rev is None:
            return
        try:
            (dismiss.restore if removed else dismiss.add)(rev, issue)
        except ValueError as e:
            warn(self, "Remove issue", str(e)); return
        self._show_selected()
        self.refresh()                                   # a failed check whose issues are all removed no longer stops Approve

    def _resolve_issue(self, issue: Issue):
        """The loaded layer an issue of the selected stage lives in: this stage's group for source "working", else
        the loaded group of the dependency stage it names; a wayleave issue falls back to the project layer the
        operator chose in the Wayleave box."""
        if self.store is None or self.selected is None:
            return None
        if issue.source == "working":
            grp = self._group(self.selected)
        else:
            grp = layers.find_stage_group(self.store.site, stages.get(issue.source)) if issue.source in stages.order() else None
        if grp is not None:
            for child in grp.findLayers():
                if child.layer() is not None and child.layer().name() == issue.layer:
                    return child.layer()
        if issue.source == "wayleave" and self.wayleave_layer is not None:
            return self.wayleave_layer(issue.layer)
        return None

    def _set_busy(self, busy: bool):
        self.busy = busy
        try:
            self.refresh()
        finally:
            if self.on_busy is not None:
                self.on_busy()

    def _flow_done(self, stage_id: str):
        self.selected = stage_id
        try:
            self.rows[stage_id]["radio"].setChecked(True)
        finally:
            try:
                self._set_busy(False)
            finally:
                self.changed.emit()

    def _complete(self, stage_id: str, title: str, body):
        """Run a completion body; any exception is shown and the tab always recovers."""
        try:
            body()
        except Exception as e:                           # noqa: BLE001 - never leave the tab wedged
            warn(self, title, f"{type(e).__name__}: {e}")
        finally:
            self._flow_done(stage_id)

    def _launch(self, desc, cmd, env, log_path, on_done):
        task = None

        def done(rc, text):
            if task in self._tasks:
                self._tasks.remove(task)
            on_done(rc, text)
        task = SubprocessTask(desc, cmd, env, log_path, done)
        self._tasks.append(task)
        self._set_busy(True)
        QgsApplication.taskManager().addTask(task)

    def cancel_tasks(self):
        for task in list(self._tasks):
            task.cancel()

    # ---------------- Generate ----------------
    def wayleave_changes(self) -> list[str]:
        """Differences between the wayleave on screen and the approved snapshot (2026-10-14, D-PS.8); [] when the
        same, or when there is nothing to compare (no approved wayleave, or no Wayleave box wired)."""
        import tempfile
        from ..core import wayleave_diff
        from .wayleave_box import write_snapshot
        ap = self.store.approved_gpkg("wayleave") if self.store is not None else None
        if ap is None or not ap.exists() or self.wayleave_chosen is None:
            return []
        chosen = self.wayleave_chosen()
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            screen = Path(d) / "screen.gpkg"
            write_snapshot(screen, chosen, self.store.load()["epsg"])
            return wayleave_diff.diff(ap, screen, set(chosen))

    def generate(self, stage_id: str):
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store          # completions bind to the site that launched them
        # Operator 2026-11-12: a step whose layer the operator already has in the project never gets a second one.
        # Their layer stays, is taken over as the step's approved version, and the plan moves on to the next step.
        if stage_id in SCANNED:
            drawn = self.drawn_layers(stage_id)
            if drawn:
                names = ", ".join(dict.fromkeys(l.name() for ls in drawn.values() for l in ls))
                self.use_drawn(stage_id, why=f"Your layer ({names}) is this step's layer, so nothing new is drawn: "
                                             f"it stays as it is and is taken over as {stage.name}'s approved "
                                             f"version (its Check still runs).")
                return
            found = self.existing_layers(stage_id)
            if found:
                warn(self, f"{stage.name}: generate",
                     f"Your project already has {', '.join(found)} for this step, so Generate would add a second "
                     f"layer beside it. Press Scan current wayleave state in the Wayleave box: keep it ticked to use "
                     f"your layer for this step" + self._missing_text(stage_id) + ", or untick it there to have the "
                     f"plugin draw this step.")
                return
        try:
            changes = self.wayleave_changes()
        except Exception as e:                            # noqa: BLE001 - a broken comparison must not pass silently
            changes = [f"could not compare the wayleave on screen: {type(e).__name__}: {e}"]
        if changes:
            warn(self, f"{stage.name}: generate", "The wayleave on screen differs from the approved snapshot:\n\n" +
                 "\n".join(changes) + "\n\nFirst check the Wayleave box shows the layers the snapshot was taken "
                 "from. Only if you really changed the wayleave, press Use this wayleave again (every started "
                 "stage goes stale), then Generate.")
            return
        if stage.generator is None:                       # a manual re-generate copies the saved drawing
            grp = self._group(stage_id)
            if grp is not None and layers.has_unsaved_edits(grp):
                warn(self, f"{stage.name}: generate", "The layers have unsaved edits. Save or discard them first.")
                return
            if not self._flush(stage_id, "generate"):
                return
        try:
            rev, cmd, env = ctl.begin_generate(stage_id)
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            warn(self, f"{stage.name}: generate", f"{type(e).__name__}: {e}")
            self.refresh()
            return
        if cmd is None:                                   # manual stage: editable layers (seeded after rev 1)
            self._complete(stage_id, f"{stage.name}: generate",
                           lambda: self._load_layers(stage_id, store.site, stage, rev, editable=True))
            return
        self._launch(f"{store.site}: generate {stage.name}", cmd, env, rev / "run.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: generate",
                                                     lambda: self._generate_result(ctl, store, stage_id, rev, rc, text)))

    def _generate_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str):
        stage = stages.get(stage_id)
        if ctl.finish_generate(stage_id, rev, rc, log):
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        else:
            warn(self, f"{stage.name}: generate failed", f"rc={rc}\n\n{tail(log)}")

    # ---------------- Check ----------------
    def check(self, stage_id: str):
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        grp = self._group(stage_id)
        if grp is not None and not layers.save_all_edits(grp):
            warn(self, f"{stage.name}: check", "Saving the layer edits failed; fix the edits and Check again.")
            return
        if not self._flush(stage_id, "check"):
            return
        assigned = []
        if stage_id == "p4_drops":                        # 2026-10-14: number hand-drawn collection points first
            rev_now = self._rev(stage_id)
            if rev_now is not None and (rev_now / "working.gpkg").exists():
                assigned = assign_cp_ids(grp, rev_now / "working.gpkg")
                self._flush(stage_id, "check")
        try:
            rev, cmd, env = ctl.begin_check(stage_id)     # hashes working.gpkg as the Check starts
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            warn(self, f"{stage.name}: check", f"{type(e).__name__}: {e}")
            return
        start = ctl.check_start.get(stage_id)
        cj = rev / "checks.json"                          # never let an old report stand in for this run
        if cj.exists():
            cj.unlink()
        store.set_stage(stage_id, checked_hash=None)
        self._launch(f"{store.site}: check {stage.name}", cmd, env, rev / "check.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: check",
                                                     lambda: self._check_result(ctl, store, stage_id, rev, rc, text,
                                                                                start, assigned)))

    def _check_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str, start: str | None = None,
                      assigned: list | None = None):
        stage = stages.get(stage_id)
        if assigned:
            lg = rev / "check.log"
            old = lg.read_text(encoding="utf-8", errors="replace") if lg.exists() else ""
            lg.write_text("\n".join(assigned) + "\n" + old, encoding="utf-8")
        cj = rev / "checks.json"
        # rc != 0 with blocking checks in checks.json is a normal failing check (checks/common.main exits 1).
        # rc != 0 with no report, or with a report claiming success, is a crashed check: never trust it.
        report = ChecksReport.load(cj) if cj.exists() else None
        if rc != 0 and (report is None or report.ok()):
            if cj.exists():
                cj.unlink()
            warn(self, f"{stage.name}: check failed", f"The check exited rc={rc} without a usable checks.json.\n\n"
                                                      f"{tail(log)}")
            return
        report = ctl.finish_check(stage_id, rev, rc, log, start_hash=start)
        if report is None:                               # no checks.json: the check itself failed
            warn(self, f"{stage.name}: check failed", f"The check wrote no checks.json (rc={rc}).\n\n{tail(log)}")
            return
        if ctl.last_warning:
            warn(self, f"{stage.name}: check", ctl.last_warning)
        layers.load_issues(self.iface, store.site, stage, rev)

    def _flush(self, stage_id: str, what: str) -> bool:
        rev = self._rev(stage_id)
        if rev is None or layers.flush_wal(rev / "working.gpkg"):
            return True
        warn(self, f"{stages.get(stage_id).name}: {what}",
             "Could not checkpoint working.gpkg (another program is writing it). Try again.")
        return False

    # ---------------- Approve / Reject ----------------
    def approve(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            note = ask_note(self, f"Approve {stage.name}", "Approval note (required):")
            if note is None:
                return
        if not note.strip():
            warn(self, f"Approve {stage.name}", "An approval note is required.")
            return
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            warn(self, f"Approve {stage.name}", "The layers have unsaved edits. Check again (it saves them) first.")
            return
        if not self._flush(stage_id, "approve"):
            return
        details = approval.stage_details(self.store, stage_id)
        checked = []
        if details:
            checked = confirm_details(self, stage.name, details)
            if checked is None:
                return

        def body():
            refusals = self.controller.approve(stage_id, note.strip(), details_checked=checked)
            if refusals:
                checks, hard = self.controller.approve_blockers(stage_id)
                if hard or not checks:
                    warn(self, f"Approve {stage.name} refused", "\n".join(refusals))
                    return
                # Operator ruling 2026-10-07: failed checks ask, they do not block. The override is recorded.
                if not ask_yes_no(self, f"Approve {stage.name} anyway?",
                                  "These checks fail:\n\n" + "\n".join(checks) +
                                  "\n\nApprove anyway? Your note is recorded as the reason in approval.json."):
                    return
                refusals = self.controller.approve(stage_id, note.strip(), override=note.strip(), details_checked=checked)
                if refusals:
                    warn(self, f"Approve {stage.name} refused", "\n".join(refusals))
                    return
            grp_now = self._group(stage_id)
            if grp_now is not None:                       # approved layers are a record; Revise to change them
                layers.set_group_readonly(grp_now, True)
        self._complete(stage_id, f"Approve {stage.name}", body)

    # ---------------- Revise ----------------
    def revise(self, stage_id: str):
        """Rev N+1 = an editable copy of the latest approved layer (else the current working layer). A step taken over
        from the operator's own layer is never copied onto the map (2026-11-12, no double layers): Revise takes their
        layer over again, as it is now."""
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        rev_now = self._rev(stage_id)
        if stage_id in SCANNED and rev_now is not None and (rev_now / "takeover.json").exists():
            if self.drawn_layers(stage_id):
                self.use_drawn(stage_id, why=f"{stage.name} is your own layer: edit it in your project, and Revise "
                                             f"takes it over again as it is now (no copy is added to the map).")
            else:
                warn(self, f"Revise {stage.name}", "This step is your own layer, taken over by Scan, and the layer you "
                                                   "picked is no longer in the project or has no features. Add it back "
                                                   "and Scan again, or Remove this revision to have the plugin draw "
                                                   "the step.")
            return
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            warn(self, f"Revise {stage.name}", "The layers have unsaved edits. Save or discard them first.")
            return
        if not self._flush(stage_id, "revise"):
            return

        def body():
            rev = ctl.begin_revise(stage_id)
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        self._complete(stage_id, f"Revise {stage.name}", body)

    # ---------------- Remove ----------------
    def remove(self, stage_id: str, confirmed: bool = False):
        """Operator ruling 2026-10-07: delete the stage's current revision and its layers from the project.
        The stage falls back to its previous revision, or to pending; downstream built on it goes stale."""
        stage, store = stages.get(stage_id), self.store
        s = store.stage_state(stage_id)
        cur = s.get("current_rev")
        if not cur:
            return
        remaining = sorted(p.name for p in (store.site_dir / stage_id).glob("rev-*") if p.is_dir() and p.name != cur)
        after = (f"The stage goes back to {remaining[-1]}." if remaining else "The stage goes back to pending.")
        downstream = [stages.get(d).name for d in stages.downstream_of(stage_id)
                      if store.stage_state(d)["status"] != "pending"]
        extra = ("\n\nThis revision is the approved one; these stages were built on it and become stale:\n"
                 + "\n".join(downstream)) if s.get("approved_rev") == cur and downstream else ""
        if not confirmed and not ask_yes_no(self, f"Remove {stage.name} {cur}?",
                                            f"Delete {stage.name} {cur} from disk and its layers from the project? "
                                            f"This cannot be undone. {after}{extra}"):
            return

        def body():
            layers.unload_stage(store.site, stage)
            self.controller.remove(stage_id)
        self._complete(stage_id, f"Remove {stage.name}", body)

    # ---------------- Scan: take hand-drawn layers over (0.16.0) ----------------
    def drawn_layers(self, stage_id: str) -> dict:
        """{plan layer: [project layers]} the saved scan picks name for this stage, only those with features; {} when
        the picks do not cover every layer the step needs."""
        from ..core import scan
        from .wayleave_box import project_layers
        if self.store is None or stage_id not in scan.SCANNED:
            return {}
        picks = self.store.scan_picks()
        out = {}
        for spec in scan.snapshot_outputs(stage_id):
            names = picks.get(spec.name) or []
            cands = project_layers(self.store, self.controller, spec.geom)
            # final review M2: every project layer of that name and geometry, as the Scan window ticks them all
            hit = [l for n in dict.fromkeys(names) for l in cands if l.name() == n and l.featureCount() > 0]
            if hit:
                out[spec.name] = hit
        return out if all(k in out for k in scan.NEEDED[stage_id]) else {}

    def existing_layers(self, stage_id: str) -> list[str]:
        """Names of the operator's project layers, with features, that hold one of this step's plan layers: the Scan
        picks for a plan layer Scan has saved (unticked there = the operator wants it drawn), else the layers Scan
        would tick by name. Generate never draws a step one of these is already (2026-11-12)."""
        from ..core import scan
        from ..core.layermatch import match_plan_layers
        from .wayleave_box import project_layers
        if self.store is None or stage_id not in scan.SCANNED:
            return []
        saved, out = self.store.scan_picks(), []
        for spec in scan.snapshot_outputs(stage_id):
            names = [l.name() for l in project_layers(self.store, self.controller, spec.geom) if l.featureCount() > 0]
            if spec.name in saved:
                out += [n for n in names if n in saved[spec.name]]
            else:
                out += [names[i] for i in match_plan_layers(spec.name, names)]
        return list(dict.fromkeys(out))

    def _missing_text(self, stage_id: str) -> str:
        """' (it also needs a layer for ...)' when the step needs a plan layer Scan has nothing for (P6 needs both an
        8-way splitter and a dome joint layer), else ''."""
        from ..core import scan
        from ..core.layermatch import match_plan_layers
        from .wayleave_box import project_layers
        saved, missing = self.store.scan_picks(), []
        geom = {o.name: o.geom for o in stages.get(stage_id).outputs}
        for name in scan.NEEDED.get(stage_id, ()):
            names = [l.name() for l in project_layers(self.store, self.controller, geom[name]) if l.featureCount() > 0]
            hit = [n for n in names if n in saved[name]] if name in saved else \
                [names[i] for i in match_plan_layers(name, names)]
            if not hit:
                missing.append(_PLAIN.get(name, name.replace("_", " ")))
        return f" (this step also needs a layer of {' and '.join(missing)}: draw it first)" if missing else ""

    def _update_use_drawn(self, sid: str, row: dict, state: dict, usable: bool):
        """Spec "When a hand-drawn step's turn comes": a found layer that had to wait is offered beside Generate
        once every step it depends on is approved."""
        btn = row.get("use_drawn")
        if btn is None:
            return
        s = state.get(sid, {})
        turn = (s.get("status") != "approved"
                and all(state.get(d, {}).get("status") == "approved" for d in stages.get(sid).deps))
        drawn = self.drawn_layers(sid) if turn else {}
        names = ", ".join(l.name() for ls in drawn.values() for l in ls)
        btn.setText(f"Use my drawn layer ({names})")
        btn.setVisible(bool(drawn))
        btn.setEnabled(bool(drawn) and usable)

    def use_drawn(self, stage_id: str, note: str | None = None, why: str = ""):
        """The same takeover Scan does, for this one stage: note asked as at Approve, details ticked as at Approve.
        `why`: shown above the note when Generate or Revise sent the operator here (2026-11-12)."""
        stage = stages.get(stage_id)
        if not self.drawn_layers(stage_id):
            warn(self, f"{stage.name}: use my drawn layer", "The layers you picked in Scan are no longer in the "
                                                           "project or have no features. Scan again.")
            return
        if note is None:
            note = ask_note(self, f"Use my drawn layer for {stage.name}",
                            (why + "\n\n" if why else "") + "Approval note (required):")
            if note is None:
                return
        if not note.strip():
            warn(self, f"Use my drawn layer for {stage.name}", "An approval note is required.")
            return
        details = approval.stage_details(self.store, stage_id)
        checked = []
        if details:
            checked = confirm_details(self, stage.name, details)
            if checked is None:
                return

        def done(taken, stopped, msg):
            if stopped:
                warn(self, f"{stage.name}: use my drawn layer", msg)
        self.take_over([stage_id], self.drawn_layers, note.strip(), {stage_id: checked}, on_done=done)

    def take_over(self, stage_ids: list[str], layers_for, note: str, details: dict, on_step=None, on_done=None):
        """Take each stage over in order (spec "Continue from these"): snapshot the project layers as they are now,
        fill the plan fields, run its Check in the background, then approve (over failed checks, recorded). The
        chain stops at the first step that is not approved (a crashed Check, an unticked detail, a refusal), and
        that message goes on the step's run.log. on_step(sid, None, "") as each step starts, on_step(sid, ok, msg)
        after it; on_done(taken, stopped, msg) once at the end, after the tab has refreshed. Each approved step is
        loaded read-only like any approved stage (final review I2)."""
        ctl, store = self.controller, self.store
        todo, taken = list(stage_ids), []

        def finish(stopped=None, msg=""):
            try:
                self._flow_done(stopped or (taken[-1] if taken else (stage_ids[0] if stage_ids else self.selected)))
            finally:
                if on_done is not None:
                    on_done(taken, stopped, msg)

        def stop(sid, msg, rev=None):
            if rev is not None:
                try:
                    with open(rev / "run.log", "a", encoding="utf-8") as f:
                        f.write(f"\nScan takeover stopped here: {msg}\n")
                except OSError:
                    pass
            if on_step is not None:
                on_step(sid, False, msg)
            finish(sid, msg)

        def result(sid, rev, start, rc, text):
            try:
                ok, msg = ctl.finish_takeover(sid, rev, rc, text, start, note, details.get(sid, ()))
                if ok:                                   # operator 2026-11-06: no copy on the map; old group gone
                    try:
                        layers.unload_stage(store.site, stages.get(sid))
                    except Exception as e:               # noqa: BLE001 - approved all the same; say why it stayed
                        with open(rev / "run.log", "a", encoding="utf-8") as f:
                            f.write(f"\ncould not remove the stage's old layers: {type(e).__name__}: {e}\n")
                if (rev / "checks.json").exists():
                    layers.load_issues(self.iface, store.site, stages.get(sid), rev)
            except Exception as e:                       # noqa: BLE001 - never leave the tab wedged
                ok, msg = False, f"{type(e).__name__}: {e}"
            if not ok:
                stop(sid, msg, rev)
                return
            taken.append(sid)
            if on_step is not None:
                on_step(sid, True, msg)
            step()

        def step():
            if not todo:
                finish()
                return
            sid = todo.pop(0)
            made: list[Path] = []                        # the revision begin_takeover made, once it exists
            if on_step is not None:                      # final review I3: the window names the step being taken
                on_step(sid, None, "")
            try:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                try:                                     # final review I3: export + snapshot + fill block the UI
                    rev, start, cmd, env = self._takeover_start(ctl, store, sid, layers_for(sid), made)
                finally:
                    QApplication.restoreOverrideCursor()
                self._launch(f"{store.site}: take over {stages.get(sid).name}", cmd, env, rev / "check.log",
                             lambda rc, text: result(sid, rev, start, rc, text))
            except Exception as e:                       # noqa: BLE001 - never leave the tab busy
                msg = f"{type(e).__name__}: {e}"
                if made:                                 # fix round T6: a half-made rev is no work to keep
                    try:
                        ctl.takeover_failed(sid, made[0], e)
                    except Exception:                    # noqa: BLE001
                        pass
                stop(sid, msg)

        self._set_busy(True)
        step()

    def _takeover_start(self, ctl, store, sid: str, chosen: dict, made: list):
        """begin_takeover, the snapshot of the layers as they are now (its fingerprint hash recorded in takeover.json
        before any field is filled), the field fill, P4's collection point ids and begin_check. Returns (rev, start
        hash, cmd, env); the new revision is appended to `made` as soon as it exists."""
        import datetime
        from ..core import wayleave_diff
        if not chosen:
            raise ValueError("no project layer picked for this step")
        source = {"layers": {pl: [{"name": l.name(), "source": l.source(), "features": l.featureCount()}
                                  for l in ls] for pl, ls in chosen.items()},
                  "when": datetime.datetime.now().isoformat(timespec="seconds")}
        rev = ctl.begin_takeover(sid, source)
        made.append(rev)
        log: list[str] = []
        counts = write_step_snapshot(rev / "working.gpkg", sid, chosen, store.load()["epsg"], log)
        source["snapshot_hash"] = wayleave_diff.fingerprint_hash(rev / "working.gpkg")   # the raw copy, as drawn
        (rev / "takeover.json").write_text(json.dumps(source, indent=2), encoding="utf-8")
        (rev / "run.log").write_text("drawn by hand, taken over by Scan: snapshot of project layers\n" + "".join(
            f"{n}: {c} features from {', '.join(l.name() for l in chosen[n])}\n" for n, c in counts.items())
            + "".join(line + "\n" for line in log), encoding="utf-8")
        ctl.after_snapshot(sid, rev)
        if sid == "p4_drops":                             # numbered as P4's Check numbers hand-drawn points
            assigned = assign_cp_ids(None, rev / "working.gpkg")
            if assigned:
                with open(rev / "run.log", "a", encoding="utf-8") as f:
                    f.write("\n".join(assigned) + "\n")
        rev2, cmd, env = ctl.begin_check(sid)
        start = ctl.check_start.get(sid)
        cj = rev2 / "checks.json"                         # never let an old report stand in for this run
        if cj.exists():
            cj.unlink()
        store.set_stage(sid, checked_hash=None)
        return rev2, start, cmd, env

    def reject(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            note = ask_note(self, f"Reject {stage.name}", "Rejection note:")
            if note is None:
                return
        self._complete(stage_id, f"Reject {stage.name}", lambda: self.controller.reject(stage_id, note))

