"""
The end-of-run gate of step4_drops (Plan Stages 0.17.0). Pure numpy: coordinates in site metres, `assigned[i]` is the
index of home i's collection point in `cps` or -1, and `blocked(i, js)` says whether home i's drop to each point in
`js` crosses a road.

Operator, 2026-10-30:
  "if there are cable drops that span longer than the spec, those cable drops should not be drawn ... just flag those
   in the error box. ... That's important for all of the specs."
  "if there are less than 112 demand points and/or exactly 112 demand points in any given PON, then there have to be
   14 collection points max or less. At all times." (HeroTel 14; a PON over 112 is planned and flagged.)
Enforced here, on the final assignment, for the same reason the road-crossing repair is: a dozen passes upstream move
collection points for their own reasons, and the rule is simply true or not at the end.
"""
import numpy as np


def _dist(dps, cps, i, js):
    return np.hypot(*(cps[np.asarray(js, int)] - dps[i]).T) if len(js) else np.zeros(0)


def enforce_pon_cap(assigned, dps, cps, dp_pon, cp_pon, pinned, drop_cap, fan_cap, pon_cap, pon_max, blocked):
    """(assigned, keep): in every PON of at most `pon_max` homes, remove the emptiest collection points the operator
    did not place until at most `pon_cap` remain, re-homing each of their drops to the nearest kept point of the same
    PON with a free port, within the cap and not across a road; a home that fits nowhere is left at -1."""
    assigned = np.array(assigned, int)
    keep = np.ones(len(cps), bool)
    fan = np.bincount(assigned[assigned >= 0], minlength=len(cps))
    for p in np.unique(cp_pon[cp_pon >= 0]):
        if int((dp_pon == p).sum()) > pon_max:
            continue
        while True:
            live = np.flatnonzero((cp_pon == p) & keep)
            if len(live) <= pon_cap:
                break
            free = [j for j in live if not pinned[j]]
            if not free:
                break                                   # all the operator's own: kept, the check flags the PON
            j = min(free, key=lambda k: (fan[k], k))
            keep[j] = False
            members = list(np.flatnonzero(assigned == j))
            others = np.flatnonzero((cp_pon == p) & keep)

            def options(i):
                d = _dist(dps, cps, i, others)
                ok = (d <= drop_cap + 1e-6) & (fan[others] < fan_cap)
                if ok.any():
                    ok &= ~np.asarray(blocked(i, others), bool)
                return others[ok], d[ok]

            members.sort(key=lambda i: len(options(i)[0]))    # most constrained first
            for i in members:
                fan[j] -= 1
                js, d = options(i)
                if len(js):
                    k = int(js[int(np.argmin(d))]); assigned[i] = k; fan[k] += 1
                else:
                    assigned[i] = -1
    return assigned, keep


def unserve_over_cap(assigned, dps, cps, drop_cap, fan_cap=None, cp_pon=None, dp_pon=None, keep=None, blocked=None):
    """(assigned, n): every drop longer than the cap goes to the nearest kept point of its PON within the cap, with a
    free port and not across a road (when fan_cap, cp_pon, dp_pon, keep and blocked are given); otherwise it is taken
    away. n counts the drops taken away."""
    assigned = np.array(assigned, int)
    on = np.flatnonzero(assigned >= 0)
    d = np.hypot(*(cps[assigned[on]] - dps[on]).T) if len(on) else np.zeros(0)
    over = on[d > drop_cap + 1e-6]
    rehome = fan_cap is not None and cp_pon is not None and dp_pon is not None and keep is not None and blocked is not None
    fan = np.bincount(assigned[assigned >= 0], minlength=len(cps))
    n = 0
    for i in over:
        fan[assigned[i]] -= 1
        assigned[i] = -1
        if rehome:
            js = np.flatnonzero(np.asarray(keep, bool) & (cp_pon == dp_pon[i]) & (fan < fan_cap))
            dd = _dist(dps, cps, i, js)
            ok = dd <= drop_cap + 1e-6
            if ok.any():
                ok &= ~np.asarray(blocked(i, js), bool)
            if ok.any():
                k = int(js[ok][int(np.argmin(dd[ok]))]); assigned[i] = k; fan[k] += 1
                continue
        n += 1
    return assigned, n


def unserve_crossing(assigned, dps, cps, blocked, drop_cap, fan_cap, cp_pon, dp_pon, keep):
    """(assigned, n): every drop that still crosses a road goes to the nearest kept point of its PON within the cap,
    with a free port and not across a road; otherwise it is taken away. n counts the drops taken away.

    Operator 2026-11-12: "We can't have drops cross roads at all. It's not allowed." The road repair in step4 re-homes
    or opens a point on the home's own side, but what it cannot fix used to be drawn and flagged; now it is not drawn,
    and the home gets a review row like an over-cap drop (0.17.0)."""
    assigned = np.array(assigned, int)
    fan = np.bincount(assigned[assigned >= 0], minlength=len(cps))
    keep = np.asarray(keep, bool)
    n = 0
    for i in np.flatnonzero(assigned >= 0):
        if not bool(np.asarray(blocked(int(i), [int(assigned[i])]), bool)[0]):
            continue
        fan[assigned[i]] -= 1
        assigned[i] = -1
        js = np.flatnonzero(keep & (cp_pon == dp_pon[i]) & (fan < fan_cap))
        dd = _dist(dps, cps, i, js)
        ok = dd <= drop_cap + 1e-6
        if ok.any():
            ok &= ~np.asarray(blocked(int(i), js), bool)
        if ok.any():
            k = int(js[ok][int(np.argmin(dd[ok]))]); assigned[i] = k; fan[k] += 1
            continue
        n += 1
    return assigned, n


def no_drop_reason(i, dps, cps, keep, cp_pon, dp_pon, fan, drop_cap, fan_cap, blocked):
    """(reason, nearest_m) for a home left without a drop: "far" (no point of its PON within the cap), "road" (every
    one within the cap is across a road), "full" (every one within the cap and on its side has fan_cap drops), else
    "free" (one has room: nothing upstream used it)."""
    own = np.flatnonzero(keep & (cp_pon == dp_pon[i]))
    if not len(own):
        own = np.flatnonzero(keep)
    if not len(own):
        return "far", float("inf")
    d = _dist(dps, cps, i, own)
    near = float(d.min())
    within = own[d <= drop_cap + 1e-6]
    if not len(within):
        return "far", near
    b = np.asarray(blocked(i, within), bool)
    if b.all():
        return "road", near
    return ("full" if (np.asarray(fan)[within[~b]] >= fan_cap).all() else "free"), near


def reason_text(reason, nearest_m, drop_cap, pon_cap, hard=False, fan_cap=8):
    """The issue text. `hard`: the PON's collection-point count was capped (HeroTel 14, a PON of up to pon_max)."""
    if reason == "far":
        if not np.isfinite(nearest_m):
            return "no drop: no collection point in this PON"
        return f"no drop: nearest collection point {nearest_m:.0f} m, spec {drop_cap:.0f} m"
    if reason == "road":
        return f"no drop: every collection point within {drop_cap:.0f} m is across a road"
    if reason == "free":
        return f"no drop: a collection point within {drop_cap:.0f} m has room; draw the drop or Generate again"
    if hard:
        return f"no drop: collection points within {drop_cap:.0f} m are full ({pon_cap}-point limit in this PON)"
    return f"no drop: collection points within {drop_cap:.0f} m are full ({fan_cap} drops each)"


def drop_empty(collections, assigned, keep, pinned):
    """(collections, assigned) without the removed points and the empty ones; the operator's are always kept."""
    assigned = np.array(assigned, int)
    fan = np.bincount(assigned[assigned >= 0], minlength=len(collections))
    alive = np.asarray(keep, bool) & ((fan > 0) | np.asarray(pinned, bool))
    new = np.cumsum(alive, dtype=int) - 1
    out = np.full(len(assigned), -1, int)
    on = np.flatnonzero(assigned >= 0)
    live = on[alive[assigned[on]]]
    out[live] = new[assigned[live]]
    return np.asarray(collections, int)[alive], out
