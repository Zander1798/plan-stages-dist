import sys
import numpy as np
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult


def _issue(report, lyr, f, code, msg):
    add_issue(report, lyr, f, code, "error", msg)


def _num(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 1 << 30


FAN_END_M = 1.0                                          # a drop's collection-point end this close counts for that point
STRAY_M = 25.0                                          # step4_drops attaches a stray CP to the nearest PON within this


def _pon_of(pl, g, epsg):
    """The PON polygon holding collection point g, else the nearest one within STRAY_M (step4's own rule)."""
    poly = P.polygon_containing(pl, g, epsg)
    if poly is not None:
        return poly
    q = g.Clone(); q.Transform(P.to_site(epsg)); t = P.to_site(P.layer_epsg(pl))
    best, bd = None, STRAY_M
    for f in pl:
        pg = f.GetGeometryRef()
        if pg is None:
            continue
        pg = pg.Clone(); pg.Transform(t); d = pg.Distance(q)
        if d <= bd:
            best, bd = f, d
    pl.ResetReading()
    return best


def extra(report, rev):
    ds, drops = open_layer(str(rev / "working.gpkg"), "drops")
    ds2, cps = open_layer(str(rev / "working.gpkg"), "collection_points")
    cap, fan, pon = P.spec_limit("drop_cap_m"), P.spec_limit("fan_cap"), P.spec_limit("pon_cap")
    ds3, review = open_layer(str(rev / "working.gpkg"), "drop_review")
    if drops is None or cap is None or review is None:
        report.checks.append(CheckResult("drop_cap_escalated", True, "skipped", "drops, drop_review or drop_cap_m missing"))
        report.checks.append(CheckResult("drop_cap", False, "skipped", "drops layer or drop_cap_m missing"))
    else:
        t = P.to_site(P.layer_epsg(drops))
        rv = P.points_site(review)
        tree = cKDTree(rv) if len(rv) else None
        over = unesc = 0; worst = 0.0
        for f in drops:
            L = P.cap_length(drops, f); worst = max(worst, L)
            if L <= cap + 1e-6:
                continue
            over += 1
            g = f.GetGeometryRef()                       # DP -> collection point: the home end is vertex 0
            hx, hy = t.TransformPoint(g.GetX(0), g.GetY(0))[:2]
            if tree is None or tree.query([hx, hy])[0] > 1.0:
                unesc += 1; _issue(report, drops, f, "drop_cap_escalated", f"drop {L:.1f} m over cap {cap} m has no drop_review point at its home end")
            else:
                add_issue(report, drops, f, "drop_cap", "warn", f"drop {L:.1f} m over cap {cap} m (escalated)")
        report.checks.append(CheckResult("drop_cap_escalated", True, "passed" if unesc == 0 else "failed",
                                         f"{unesc} over-cap drops without a drop_review point (of {over} over cap)"))
        report.checks.append(CheckResult("drop_cap", False, "passed" if over == 0 else "failed",
                                         f"{over} drops longer than {cap} m (longest {worst:.1f} m)"))
    _drop_none(report, drops, review)
    _drops_drawn(report, drops)
    if cps is None or fan is None:
        report.checks.append(CheckResult("fan_cap", True, "skipped", "collection_points or fan_cap missing"))
    else:
        # 2026-10-14: count the drops DRAWN to each collection point (their collection-point end, the last vertex,
        # within FAN_END_M), never the n_drops attribute, which a hand edit leaves behind.
        cps_l = list(cps); t_cp = P.to_site(P.layer_epsg(cps))
        cxy = np.array([t_cp.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2]
                        for f in cps_l]).reshape(-1, 2)
        counts = [0] * len(cps_l)
        ids = [str(f.GetField("cp_id")) if f.GetField("cp_id") is not None else None for f in cps_l]
        if drops is not None and len(cps_l):
            tree = cKDTree(cxy); t_dr = P.to_site(P.layer_epsg(drops)); drops.ResetReading()
            has_id = drops.GetLayerDefn().GetFieldIndex("cp_id") >= 0
            loose = 0
            for f in drops:
                g = f.GetGeometryRef()
                if g is None or g.IsEmpty() or g.GetPointCount() == 0:
                    continue
                # generated drops end at the collection point; one drawn by hand may start there instead
                n_ = g.GetPointCount()
                near = tree.query_ball_point(t_dr.TransformPoint(g.GetX(n_ - 1), g.GetY(n_ - 1))[:2], FAN_END_M) or \
                    tree.query_ball_point(t_dr.TransformPoint(g.GetX(0), g.GetY(0))[:2], FAN_END_M)
                if not near:
                    loose += 1; add_issue(report, drops, f, "drop_unattached", "warn",
                                          f"drop has neither end within {FAN_END_M:.0f} m of a collection point")
                    continue
                # two collection points can share a pole (3 on live Ventersdorp): a drop counts for the one it names;
                # a hand-drawn drop (no matching cp_id) for the one serving the fewest so far
                own = str(f.GetField("cp_id")) if has_id and f.GetField("cp_id") is not None else None
                j = next((k for k in near if own is not None and ids[k] == own), None)
                counts[j if j is not None else min(near, key=lambda k: (counts[k], k))] += 1
            drops.ResetReading()
            report.checks.append(CheckResult("drop_unattached", False, "passed" if loose == 0 else "failed",
                                             f"{loose} drops with neither end at a collection point (not counted in the fan cap)"))
        over = 0
        for f, n in zip(cps_l, counts):
            if n > fan:
                over += 1; _issue(report, cps, f, "fan_cap", f"{n} drops exceeds fan cap {fan}")
        report.checks.append(CheckResult("fan_cap", True, "passed" if over == 0 else "failed",
                                         f"{over} collection points serve more than {fan} drops (counted as drawn)"))
        cps.ResetReading()
    if cps is None or pon is None:
        report.checks.append(CheckResult("pon_cap", False, "skipped", "collection_points or pon_cap missing"))
    else:
        # Count by the PON polygon that HOLDS each collection point, not by its `pon` attribute: on 2026-10-09 the
        # attribute was the polygon's file position (pon_num - 1), so every Ventersdorp row named and located the
        # wrong PON. The polygon is also what the operator changes when they move a collection point by hand.
        # Operator ruling 2026-10-12: a WARNING, not a block. The hard rules (no road-crossing drops, the drop cap,
        # collection points on poles) can force a PON past the cap; the operator decides (re-cut, accept, edit).
        # Operator ruling 2026-10-08: ONE row per thing to fix (the PON), located on the PON polygon of the approved
        # wayleave (site_export/Pons.shp); the first collection point of the PON when no polygon holds it.
        pds, pl, key = P.open_pons(P.export_dir() / "Pons.shp")
        epsg = P.layer_epsg(cps)
        # 0.17.0 HeroTel 14 (operator 2026-10-30): "if there are less than 112 demand points and/or exactly 112 demand
        # points in any given PON, then there have to be 14 collection points max or less. At all times." Such a PON
        # over the cap is an ERROR; a PON over pon_max cannot help it and keeps the warning above.
        pmax = P.spec_limit("pon_max")
        hard = P.spec_limit("pon_cap_hard") is True and pmax is not None and pl is not None
        homes = _homes_per_pon(pl) if hard else None     # None: the export holds no demand points
        groups = {}                                      # group -> [label, count, polygon feature or None, first CP]
        for f in cps:
            g = f.GetGeometryRef()
            poly = _pon_of(pl, g, epsg) if pl is not None and g is not None else None
            if poly is not None:
                gk = ("pons", poly.GetFID()); label = poly.GetField(key)
            else:
                gk = ("cp", f.GetField("pon")); label = None
            e = groups.setdefault(gk, [None, 0, poly, f])
            e[1] += 1
            if e[0] is None:
                e[0] = label if label is not None else f.GetField("pon")
        bad = sorted((e for e in groups.values() if e[1] > pon), key=lambda e: (_num(e[0]), str(e[0])))
        hard_bad = [e for e in bad if hard and homes is not None and e[2] is not None and homes.get(e[2].GetFID(), 1 << 30) <= pmax]
        for label, n, poly, f in hard_bad:
            k = poly.GetField(key)
            add_issue(report, pl, None, "pon_cap_hard", "error",
                      f"PON {label} has {n} collection points; up to {pmax} demand points allows only {pon}",
                      xy=inside_xy(poly.GetGeometryRef()), source="wayleave", layer="pons",
                      match=f"pon_num={int(k)}" if _num(k) < 1 << 30 else "")
        if hard and homes is None:
            report.checks.append(CheckResult("pon_cap_hard", True, "skipped",
                                             "no demand points in the export: PONs over the cap are warnings"))
        elif hard:
            report.checks.append(CheckResult("pon_cap_hard", True, "passed" if not hard_bad else "failed",
                                             f"{len(hard_bad)} PONs of up to {pmax} demand points exceed {pon} collection points"))
        bad = [e for e in bad if not any(e is h for h in hard_bad)]
        for label, n, poly, f in bad:
            msg = (f"PON {label} has {n} collection points but its 1:16 has only {pon} outputs "
                   f"({n - pon} 1:8 splitters without a feed)")
            if poly is not None:
                k = poly.GetField(key)
                add_issue(report, pl, None, "pon_cap", "warn", msg, xy=inside_xy(poly.GetGeometryRef()), source="wayleave",
                          layer="pons", match=f"pon_num={int(k)}" if _num(k) < 1 << 30 else "")
            else:                                        # no PON polygon holds it: the PON's first collection point
                add_issue(report, cps, f, "pon_cap", "warn", msg)
        report.checks.append(CheckResult("pon_cap", False, "passed" if not bad else "failed",
                                         f"{len(bad)} PONs exceed {pon} collection points: " + ", ".join(f"{e[0]} ({e[1]})" for e in bad)))
    _cable_check(report, cps)
    _pole_check(report, cps)
    _roads_check(report, drops)


DROP_HOME_M = 1.0                                       # a drop with an end this close serves the review point's home


def _drop_none(report, drops, review):
    """0.17.0 (operator 2026-10-30): P4 never draws a drop longer than the cap; the home gets none and a drop_review
    point whose `reason` says why. Each such home is an ERROR on the point (removable, as every error). A review point
    with a drop at it is a revision from before 0.17.0 (the over-cap drop was drawn): not this check's."""
    if review is None:
        report.checks.append(CheckResult("drop_none", True, "skipped", "drop_review missing"))
        return
    ends = []
    if drops is not None:
        t = P.to_site(P.layer_epsg(drops)); drops.ResetReading()
        for f in drops:
            g = f.GetGeometryRef()
            if g is None or g.IsEmpty() or g.GetPointCount() == 0:
                continue
            for v in (0, g.GetPointCount() - 1):
                ends.append(t.TransformPoint(g.GetX(v), g.GetY(v))[:2])
        drops.ResetReading()
    tree = cKDTree(np.array(ends)) if ends else None
    has = review.GetLayerDefn().GetFieldIndex("reason") >= 0
    t = P.to_site(P.layer_epsg(review)); n = 0; review.ResetReading()
    for f in review:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        xy = t.TransformPoint(g.GetX(), g.GetY())[:2]
        if tree is not None and tree.query(xy)[0] <= DROP_HOME_M:
            continue
        n += 1
        add_issue(report, review, f, "drop_none", "error", (f.GetField("reason") if has else None) or "no drop")
    review.ResetReading()
    report.checks.append(CheckResult("drop_none", True, "passed" if n == 0 else "failed",
                                     f"{n} homes without a drop (nothing within the drop cap had room)"))


def _drops_drawn(report, drops):
    """0.18.0 (operator 2026-11-04): on the headless Frankfort test P4 drew 0 drops for 9,017 demand points (all of
    them outside every PON: written in the wrong coordinate system) and its Check raised nothing. Demand points in the
    wayleave and not one drop drawn is a required ERROR, located on the AOI of the approved wayleave."""
    shp = P.export_dir() / "Demand points.shp"
    dds = ogr.Open(str(shp)) if shp.exists() else None
    if dds is None:
        report.checks.append(CheckResult("drops_drawn", True, "skipped", "no exported demand points"))
        return
    homes = sum(1 for f in dds.GetLayer(0) if f.GetGeometryRef() is not None and not f.GetGeometryRef().IsEmpty())
    n = drops.GetFeatureCount() if drops is not None else 0
    if homes == 0 or n > 0:
        report.checks.append(CheckResult("drops_drawn", True, "passed", f"{n} drops for {homes} demand points"))
        return
    msg = (f"no drops were drawn, yet the wayleave has {homes} demand points: check that they sit inside the PONs "
           f"(a demand points layer with no or the wrong coordinate system lands elsewhere)")
    ads = ogr.Open(str(P.export_dir() / "AOI.shp")) if (P.export_dir() / "AOI.shp").exists() else None
    al = ads.GetLayer(0) if ads is not None else None
    a = al.GetNextFeature() if al is not None else None
    if a is not None and a.GetGeometryRef() is not None:
        add_issue(report, al, None, "drops_drawn", "error", msg, xy=inside_xy(a.GetGeometryRef()),
                  source="wayleave", layer="aoi")
    report.checks.append(CheckResult("drops_drawn", True, "failed", msg))


def _homes_per_pon(pl):
    """{PON polygon fid: demand points inside it} from the exported demand points (site_export); None without them."""
    shp = P.export_dir() / "Demand points.shp"
    ds = ogr.Open(str(shp)) if shp.exists() else None
    if ds is None:
        return None
    dl = ds.GetLayer(0); out = {}
    polys = [(f.GetFID(), f.GetGeometryRef().Clone()) for f in pl if f.GetGeometryRef() is not None]
    pl.ResetReading()
    t = P.to_site(P.layer_epsg(dl)); tp = P.to_site(P.layer_epsg(pl))
    for _, g in polys:
        g.Transform(tp)
    for f in dl:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone(); g.Transform(t)
        for fid, pg in polys:
            if pg.Contains(g):
                out[fid] = out.get(fid, 0) + 1
                break
    return out


ON_CABLE_M = 2.0


def _cable_check(report, cps):
    """2026-10-14 (live Ventersdorp): with wayleave poles, step4 stands collection points on poles wherever the
    approved P1 distribution cable runs, so a cable moved in P1 leaves them behind (21 of 1,264 for one moved
    line; 0 before the move). Each collection point more than ON_CABLE_M from the approved cable is a warning.
    Since 0.8.0 P4 follows the cable; this still catches a collection point dragged off it by hand."""
    p3 = P.approved_path("p3_distribution")      # 2026-10-21: the distribution is P3's since the P1 split
    ds = ogr.Open(p3) if p3 else None
    dl = ds.GetLayerByName("distribution") if ds is not None else None
    if cps is None or dl is None:
        report.checks.append(CheckResult("cp_on_cable", False, "skipped", "collection_points or approved P3 distribution missing"))
        return
    t = P.to_site(P.layer_epsg(dl)); cable = ogr.Geometry(ogr.wkbMultiLineString)
    for f in dl:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone(); g.Transform(t); g.FlattenTo2D()
        for part in ([g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]):
            cable.AddGeometry(part)
    tc = P.to_site(P.layer_epsg(cps)); n = 0; cps.ResetReading()
    for f in cps:
        g = f.GetGeometryRef()
        if g is None:
            continue
        g = g.Clone(); g.Transform(tc)
        d = cable.Distance(g) if cable.GetGeometryCount() else float("inf")
        if d > ON_CABLE_M:
            n += 1; add_issue(report, cps, f, "cp_on_cable", "warn",
                              f"collection point {d:.1f} m from the approved distribution cable")
    cps.ResetReading()
    report.checks.append(CheckResult("cp_on_cable", False, "passed" if n == 0 else "failed",
                                     f"{n} collection points more than {ON_CABLE_M:.0f} m from the approved P1 cable"))


NEEDS_POLE_M = 2.0


def _pole_check(report, cps):
    """0.8.0 (operator 2026-10-15): P4 follows the corrected cable; where it runs with no wayleave pole, the
    collection point stands on the cable. Each collection point more than NEEDS_POLE_M from every wayleave pole
    is a warning, so the operator knows where a pole is missing: since 0.13.0 nothing proposes one (P6 Pole
    reconciliation is gone), the operator draws it in the wayleave poles. From geometry, never from on_pole (D-PS.7)."""
    shp = P.export_dir() / "poles.shp"
    ds = ogr.Open(str(shp)) if shp.exists() else None
    if cps is None or ds is None:
        report.checks.append(CheckResult("cp_needs_pole", False, "skipped", "collection_points or wayleave poles missing"))
        return
    pl = ds.GetLayer(); t = P.to_site(P.layer_epsg(pl)); xy = []
    for f in pl:
        g = f.GetGeometryRef()
        if g is not None and not g.IsEmpty():
            g = g.Clone(); g.Transform(t); xy.append((g.GetX(), g.GetY()))
    tree = cKDTree(np.array(xy)) if xy else None
    tc = P.to_site(P.layer_epsg(cps)); n = 0; cps.ResetReading()
    for f in cps:
        g = f.GetGeometryRef()
        if g is None:
            continue
        g = g.Clone(); g.Transform(tc)
        d = float(tree.query((g.GetX(), g.GetY()))[0]) if tree is not None else float("inf")
        if d > NEEDS_POLE_M:
            n += 1; add_issue(report, cps, f, "cp_needs_pole", "warn",
                              f"collection point {d:.1f} m from the nearest wayleave pole: draw a pole here in the wayleave, or move the collection point onto one")
    cps.ResetReading()
    report.checks.append(CheckResult("cp_needs_pole", False, "passed" if n == 0 else "failed",
                                     f"{n} collection points with no wayleave pole within {NEEDS_POLE_M:.0f} m"))


def _env_overlap(a, b) -> bool:
    ax0, ax1, ay0, ay1 = a.GetEnvelope(); bx0, bx1, by0, by1 = b.GetEnvelope()
    return ax0 <= bx1 and bx0 <= ax1 and ay0 <= by1 and by0 <= ay1


def _roads_check(report, drops):
    """2026-10-14: a drop drawn across a road. Crosses, not Intersects: a drop that only ends on the road line is not a
    crossing. An ERROR since 2026-11-12, every spec (operator: "We can't have drops cross roads at all. It's not
    allowed"); it was a warning. Generate never draws one; this catches a hand-drawn or moved drop."""
    road = P.export_dir() / "road.shp"
    if drops is None or not road.exists():
        report.checks.append(CheckResult("drop_crosses_road", True, "skipped", "drops or road.shp missing"))
        return
    rds = ogr.Open(str(road)); rl = rds.GetLayer(0); t_rd = P.to_site(P.layer_epsg(rl)); roads = []
    for f in rl:
        g = f.GetGeometryRef()
        if g is not None and not g.IsEmpty():
            g = g.Clone(); g.Transform(t_rd); roads.append(g)
    t_dr = P.to_site(P.layer_epsg(drops)); n = 0; drops.ResetReading()
    for f in drops:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone(); g.Transform(t_dr)
        if any(_env_overlap(r, g) and r.Crosses(g) for r in roads):
            n += 1; add_issue(report, drops, f, "drop_crosses_road", "error",
                              "drop crosses a road: drops never cross a road. Serve the home from a collection point "
                              "on its own side of the road (add one if none is in reach)")
    report.checks.append(CheckResult("drop_crosses_road", True, "passed" if n == 0 else "failed",
                                     f"{n} drops cross a road"))

if __name__ == "__main__":
    sys.exit(main(extra))
