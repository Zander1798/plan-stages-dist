"""Find in PDFs (operator 2026-10-13): the planning values found in a client's spec PDFs by that client's own
patterns -- no Claude, no API key. The PDF text is read with pypdf (it ships with QGIS); wrapped lines are joined
into sentences, each sentence is matched against the patterns, and every match becomes a statement in the same
form Claude reports (spec_claude.build_sheet checks and groups both alike). The quote is the sentence itself.

Patterns are taught per client: HeroTel's come from the 2026 GPON FTTH planning standard and the aerial TSD (the
spike of 2026-10-13 found every value those two state). A client without patterns gets the general ones only, and
the Spec tab says so. To teach a new client, add its entry to CLIENT_RULES from its own documents' wording, with a
test on a PDF phrased like theirs.

Split ratios found under a density heading ("High dense areas / Small Erf sizes", "Lower dense areas / Large Erf
sizes") carry that density as `regime`; the operator's density choice keeps one section (Sheet.apply_density).
PON and fan caps worked out from the splits (a 1:16 feeder dome feeds 16 collection points) say so in `derived`."""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from . import spec_verify as sv

N = r"(\d+(?:[.,]\d+)?)"
# key: [(pattern, pattern that disqualifies the sentence or None)]; group 1 holds the value
GENERAL = {
    "span_cap_m": [(rf"(?:max\w*|not exceed\w*)\W+(?:\w+\W+){{0,3}}?span\w*(?:\W+\w+){{0,3}}?\W+{N}\s?m\b", r"\broad|\bcross"),
                   (rf"\bspan\w*(?:\W+\w+){{0,4}}?\W+(?:of|is|max\w*|not exceed\w*)\W+{N}\s?m\b", r"\broad|\bcross")],
    "cross_span_m": [(rf"(?:\broad|\bcross)\w*.*\bspan\w*.*(?:not exceed\w*|max\w*)\W+{N}\s?m\b", None)],
    "drop_cap_m": [(rf"\bdrop\w*.*(?:max\w*|not exceed\w*|longer than|up to|no more than)\W*{N}\s?m\b", r"slack|coil")],
    "feeder_split": [(r"\bfeeder\b.{0,30}?\b1\s?[:/-]\s?(\d+)\b", None)],
    "dist_split": [(r"\bdistribution\b\W{0,5}1\s?[:/-]\s?(\d+)\b", None)],
}
CLIENT_RULES = {
    "herotel": {
        **GENERAL,
        "pole_feeder_m": [(rf"\bfeeder poles?\b.{{0,30}}?\b{N}\s?m\b", r"\bhigher\b|\bmay only\b")],
        "pole_midblock_m": [(rf"\b{N}\s?m(?:\s?or\s?\d+\s?m)?\s+poles?\b.{{0,40}}\bmidblock", r"\bcan also\b|\balternative\b|\broad\b")],
        "pole_crossing_m": [(rf"\b{N}\s?m\s+poles?\b.{{0,60}}\broad crossing", None)],
        "fan_cap": [(r"\bpole to feed (\d+) homes", None)],
        # the "other values" (information only) the two standards state
        "pon_max": [(rf"\bmax\w*\s+of\s+{N}\s+clients per PON", None)],
        "pon_target": [(rf"\b(?:approximately|about|aim\w*)\b.{{0,20}}?\b{N}\s+stands per PON", None)],
        "cable_span_rating_m": [(rf"\baccommodate\s+{N}\s?m\s+suspension", None)],
        "span_typical_m": [(rf"\bspan lengths? (?:are |is )?(?:usually |typically )?(?:around |about )?{N}\s?m\b", None)],
        "pole_boundary_setback_m": [(rf"\bpoles?\b.*\bcloser than\s+{N}\s?-?\s?(?:m\b|met)", None)],
    },
}
DERIVED = {"pon_cap": ("feeder_split", "worked out from the feeder split"),
           "fan_cap": ("dist_split", "worked out from the distribution split")}
HIGH = re.compile(r"high dens|small erf", re.I)
LOW = re.compile(r"low(?:er)? dens|large erf", re.I)
TOPIC_WORDS = (("spans and crossings", r"\bspan|\broad|\bcrossing|\bsag"), ("drops", r"\bdrops?\b|\bdrop cable"),
               ("splitters and PONs", r"\bsplit|\bpons?\b|\bdome|\bgpon"), ("cable", r"\bcable|\b\d+F\b|fibre count"),
               ("poles", r"\bpole|\bstay|\bstrut"), ("labelling and naming", r"\blabel|\bnaming|\bcolou?r"),
               ("clearances and safety", r"clearance|distance from|electric|boundar|setback|height"))
NOISE = re.compile(r"^figure\b|^page \d|docusign|\.{4,}|^table\b|custodian|\bdate:", re.I)
# the extras most worth a planner's time first: rules ("never", "maximum", "closer than" ...) on planning topics
RULE_WORDS = re.compile(r"\b(?:must|never|always|should|shall|maximum|minimum|max|min|not exceed\w*|no more than|"
                        r"at least|closer than|only)\b", re.I)
TOPIC_WEIGHT = {"spans and crossings": 3, "clearances and safety": 3, "drops": 3, "splitters and PONs": 2,
                "poles": 2, "cable": 1, "labelling and naming": 1}
TRAILING_NUMBER = re.compile(r"\s+\d+(?:\.\d+)*\.$")      # "… for security reasons. 5." (a list or section number)
BULLET = re.compile(r"^(?:[•\-–o]|\d+\.)\s+")
MAX_EXTRAS = 40


@dataclass
class Found:
    statements: list = field(default_factory=list)
    extras: list = field(default_factory=list)
    note: str = ""


def _heading(line: str) -> bool:
    letters = [c for c in line if c.isalpha()]
    return len(letters) >= 4 and all(c.isupper() for c in letters)


def sentences(page: str):
    """The page's sentences: inline bullets and bullet lines start a paragraph, so do blank lines and headings in
    capitals; wrapped lines inside a paragraph are joined; paragraphs are split at full stops."""
    page = re.sub(r"\s*[•]\s*", "\n• ", page)
    paras, cur = [], []
    for raw in page.splitlines():
        line = raw.strip()
        if (not line or BULLET.match(line) or _heading(line) or (cur and _heading(cur[-1]))) and cur:
            paras.append(" ".join(cur)); cur = []
        if line:
            cur.append(BULLET.sub("", line))
    if cur:
        paras.append(" ".join(cur))
    for p in paras:
        for s in re.split(r"(?<=[.;])\s+(?=[A-Z(])", p):
            s = TRAILING_NUMBER.sub("", s.strip(" -")).strip()
            if s:
                yield s


def _rules(client: str) -> tuple[dict, str]:
    rules = CLIENT_RULES.get(client.strip().lower())
    if rules is not None:
        return rules, ""
    return GENERAL, (f"No patterns for {client} yet: only the general ones were used. Type the values the documents "
                     f"state, or send the PDFs so {client}'s patterns can be added.")


def find(pdf_paths: list[Path], client: str) -> Found:
    rules, note = _rules(client)
    texts = sv.PdfTexts()
    out = Found(note=note)
    seen_extra = set()
    for di, pdf in enumerate(pdf_paths):
        pages = texts.pages(pdf) or []
        if not any(p.strip() for p in pages):
            out.note = (out.note + " " if out.note else "") + f"{Path(pdf).name} has no readable text (a scan?)."
        for pi, page in enumerate(pages):
            density = None
            for s in sentences(page):
                if HIGH.search(s):
                    density = "high"
                elif LOW.search(s):
                    density = "low"
                used = False
                for key, pats in rules.items():
                    for rx, bad in pats:
                        m = re.search(rx, s, re.I)
                        if not m or (bad and re.search(bad, s, re.I)):
                            continue
                        v = m.group(1).replace(",", ".")
                        regime = density if key.endswith("_split") else None
                        st = {"key": key, "value": f"1:{v}" if key.endswith("_split") else v, "unit": "",
                              "document_index": di, "page": pi + 1, "quoted_text": s, "regime": regime}
                        out.statements.append(st); used = True
                        for dkey, (src, how) in DERIVED.items():
                            if src == key:
                                out.statements.append({**st, "key": dkey, "value": int(v), "derived": f"{how} ({st['value']})"})
                        break
                if not used:
                    _maybe_extra(out, seen_extra, s, di, pi + 1)
    # the best MAX_EXTRAS by rank, shown in document order
    best = sorted(range(len(out.extras)), key=lambda i: -out.extras[i]["_score"])[:MAX_EXTRAS]
    out.extras = [{k: v for k, v in out.extras[i].items() if k != "_score"} for i in sorted(best)]
    return out


def _maybe_extra(out: Found, seen: set, s: str, di: int, page: int):
    """A sentence on a planning topic that states a number and was not used for a value: an extra detail."""
    if not (20 <= len(s) <= 400) or not re.search(r"\d", s) or NOISE.search(s):
        return
    topic = next((t for t, rx in TOPIC_WORDS if re.search(rx, s, re.I)), None)
    flat = re.sub(r"\W+", "", s.lower())
    if topic is None or flat in seen:
        return
    seen.add(flat)
    score = TOPIC_WEIGHT.get(topic, 0) + (3 if RULE_WORDS.search(s) else 0)
    out.extras.append({"topic": topic, "detail": s, "document_index": di, "page": page, "quoted_text": s,
                       "_score": score})
