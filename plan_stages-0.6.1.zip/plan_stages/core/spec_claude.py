from __future__ import annotations
import base64
from pathlib import Path
from .specsheet import Sheet, SheetEntry, SPEC_KEYS, UNITS, entry_from_candidates
from . import spec_verify as sv

MODEL = "claude-opus-5-5"
MEANING = {
    "density": "erf-size regime: 'high' (small erven, 1:16 then 1:8) or 'low' (large erven, 1:32 then 1:4)",
    "drop_cap_m": "longest drop cable from pole to home, metres",
    "span_cap_m": "longest pole-to-pole span, metres",
    "span_typical_m": "typical midblock span length, metres (a norm, not a cap)",
    "cable_span_rating_m": "cable's rated suspension distance, metres",
    "cross_span_m": "longest span permitted across a road, metres",
    "fan_cap": "drops per collection point (distribution splitter ratio)",
    "pon_cap": "collection points per PON (feeder/entry splitter ratio)",
    "feeder_split": "feeder/entry dome splitter ratio, e.g. '1:16'",
    "dist_split": "distribution splitter ratio, e.g. '1:8'",
    "pon_target": "stands per PON planners should aim at",
    "pon_max": "hard ceiling of clients per PON",
    "pole_midblock_m": "midblock distribution pole height, metres",
    "pole_crossing_m": "road-crossing pole height, metres",
    "pole_feeder_m": "feeder pole height, metres",
    "pole_boundary_setback_m": "minimum pole distance from a property boundary, metres",
    "pole_pitch_m": "design spacing between poles along the span, metres",
    "direction_change_stay_deg": "route direction change above which a stay or strut is mandatory, degrees",
    "aerial": "true if the deployment is aerial on poles",
}
# what the extra details are grouped by on the Spec tab; anything else is "other"
TOPICS = ("poles", "spans and crossings", "drops", "splitters and PONs", "cable", "labelling and naming",
          "clearances and safety", "other")
MAX_EXTRAS = 40

TOOL = {
    "name": "report_spec_statements",
    "description": "Report every statement of a planning parameter in the supplied client standards: one entry per "
                   "place a value is stated, with the document, page and exact quoted sentence.",
    "strict": True,
    "input_schema": {
        "type": "object", "additionalProperties": False, "required": ["statements", "extras"],
        "properties": {
            "extras": {"type": "array", "items": {
                "type": "object", "additionalProperties": False,
                "required": ["topic", "detail", "document_index", "page", "quoted_text"],
                "properties": {"topic": {"type": "string", "enum": list(TOPICS)}, "detail": {"type": "string"},
                               "document_index": {"type": "integer"}, "page": {"type": "integer"},
                               "quoted_text": {"type": "string"}}}},
            "statements": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["key", "value", "unit", "document_index", "page", "quoted_text"],
            "properties": {"key": {"type": "string"},
                           "value": {"type": ["number", "string", "boolean", "null"]}, "unit": {"type": "string"},
                           "document_index": {"type": "integer"}, "page": {"type": "integer"},
                           "quoted_text": {"type": "string"}}}}}},
}


class ProposalRefused(Exception):
    pass


class ProposalFailed(Exception):
    pass


def _default_call(api_key: str):
    import anthropic
    client = anthropic.Anthropic(api_key=api_key or None)
    return lambda params: client.messages.create(**params)


def propose_sheet(pdf_paths: list[Path], client: str, api_key: str, call=None) -> Sheet:
    call = call or _default_call(api_key)
    content = []
    for p in pdf_paths:
        data = base64.standard_b64encode(Path(p).read_bytes()).decode("ascii")
        content.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": data},
                        "title": Path(p).name, "citations": {"enabled": True}})
    keys = "\n".join(f"- {k}: {MEANING[k]}" for k in SPEC_KEYS)
    content.append({"type": "text", "text":
        f"These are the planning standards for the client {client}. For each parameter below, report EVERY place the "
        f"documents state a value for it: one statement per place, even when the same value is repeated or two "
        f"documents disagree. Give the value, the document index (0-based, in the order given), the 1-based page "
        f"number of the PDF, and the quoted sentence copied exactly as printed (it is checked against the PDF text). "
        f"Leave out a parameter the documents do not state. Never infer, convert or default a value.\n\n"
        f"Then, under extras, list up to {MAX_EXTRAS} OTHER details a fibre network planner must know before or "
        f"while planning this client's network that the parameters below do not cover (for example pole setbacks "
        f"and clearances, stay and strut rules, road-crossing rules, cable sizes, slack, labelling and naming). Most "
        f"planning-relevant first. For each: a topic, a one-line plain summary (at most 25 words), the document "
        f"index, the 1-based page and the quoted sentence copied exactly as printed (it is checked against the PDF "
        f"text). Leave out installation-crew procedure that does not affect the plan.\n\n"
        f"Call report_spec_statements exactly once.\n\n{keys}"})
    params = {"model": MODEL, "max_tokens": 32000, "tools": [TOOL], "tool_choice": {"type": "auto"},
              "messages": [{"role": "user", "content": content}]}
    resp = call(params)
    if resp.stop_reason == "refusal":
        raise ProposalRefused("the model declined to read these documents")
    if resp.stop_reason == "max_tokens":
        raise ProposalFailed("response truncated at max_tokens; proposal not usable")
    tool = next((b for b in resp.content if getattr(b, "type", "") == "tool_use"), None)
    if tool is None:
        raise ProposalFailed("no tool call in response")
    try:
        statements = tool.input["statements"]
    except (KeyError, TypeError) as e:
        raise ProposalFailed(f"malformed tool input: {e}")
    return build_sheet(client, pdf_paths, statements, tool.input.get("extras") or [])


def build_sheet(client: str, pdf_paths: list[Path], statements: list, raw_extras: list) -> Sheet:
    """The sheet from statements found in the PDFs, by Claude or by Find in PDFs (core/spec_rules) alike: every
    statement checked against its PDF, grouped per value (entry_from_candidates), the extras checked too.
    A statement may carry `regime` (the density section it sits in) and `derived` (how it was worked out)."""
    texts = sv.PdfTexts()
    found: dict[str, list[dict]] = {}
    for st in statements:
        try:
            k = st["key"]
            if k not in SPEC_KEYS or st["value"] is None:
                continue
            i = st["document_index"]
            path = pdf_paths[i] if 0 <= i < len(pdf_paths) else None
            c = sv.Candidate(k, st["value"], UNITS.get(k, ""), str(path or ""), st["page"] or None,
                             st["quoted_text"])
        except (KeyError, TypeError) as ex:
            raise ProposalFailed(f"malformed tool input: {ex}")
        r = sv.check(c, texts) if path is not None else sv.Result(sv.QUOTE_NOT_FOUND, f"no document {i}", c.page,
                                                                  sv.normalise(k, c.value))
        derived = st.get("derived") or ""
        found.setdefault(k, []).append({"value": r.value if r.value is not None else c.value, "unit": c.unit,
                                        "document": Path(c.document).name if path else "", "page": r.page,
                                        "quoted_text": c.quoted_text, "check": r.check,
                                        "check_note": f"{derived}; {r.note}" if derived else r.note,
                                        "regime": st.get("regime")})
    sheet = Sheet.blank(client)
    for k, cands in found.items():
        sheet.entries[k] = entry_from_candidates(k, cands)
    sheet.extras = _extras(raw_extras, pdf_paths, texts)
    return sheet


def _extras(raw: list, pdf_paths: list[Path], texts) -> list[dict]:
    """The other details, each quote checked against its PDF; every one starts unread."""
    out = []
    for x in raw[:MAX_EXTRAS]:
        try:
            i, page, quote = x["document_index"], x["page"] or None, x["quoted_text"]
            path = pdf_paths[i] if 0 <= i < len(pdf_paths) else None
            r = sv.check_quote(path, page, quote, texts) if path is not None else \
                sv.Result(sv.QUOTE_NOT_FOUND, f"no document {i}", page, None)
            out.append({"topic": x["topic"] if x["topic"] in TOPICS else "other", "detail": x["detail"],
                        "document": Path(path).name if path else "", "page": r.page, "quoted_text": quote,
                        "check": r.check, "check_note": r.note, "read": False})
        except (KeyError, TypeError) as ex:
            raise ProposalFailed(f"malformed extra detail: {ex}")
    return out
