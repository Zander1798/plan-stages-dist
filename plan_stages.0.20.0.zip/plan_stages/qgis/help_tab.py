"""The Help tab: help/help.md, what an operator needs before and while using the plugin (design approved
2026-10-13). The dock opens on it the first time the plugin is opened; a QgsSettings flag remembers that.

Frontend spec 14: a search box (Enter = next match, wraps round, "No match" said in words), a Jump to list of
the sections, headings styled for the light and the dark QGIS theme, and show_section(n) so a "What to do" link
elsewhere in the dock can open the right section."""
from __future__ import annotations

from pathlib import Path

from qgis.core import QgsSettings
from qgis.PyQt.QtGui import QTextCursor, QTextDocument
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QTextBrowser,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

HELP_MD = Path(__file__).resolve().parents[1] / "help" / "help.md"
SEEN_KEY = "plan_stages/help_seen"


def help_seen() -> bool:
    return QgsSettings().value(SEEN_KEY, False, type=bool)


def mark_help_seen() -> None:
    QgsSettings().setValue(SEEN_KEY, True)


def _css(dark: bool) -> str:
    from .theme import tone
    head, sub, code_bg = tone("info", dark), tone("idle", dark), ("#3a3a3a" if dark else "#eceff3")
    return (f"h1 {{ color: {head}; font-size: 15pt; }}"
            f"h2 {{ color: {head}; font-size: 12pt; margin-top: 14px; }}"
            f"h3 {{ color: {sub}; font-size: 10pt; }}"
            f"code {{ background: {code_bg}; }}"
            f"td, th {{ padding: 2px 6px; }}")


class HelpTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        bar = QHBoxLayout(); bar.setSpacing(4)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search help")
        self.search.setClearButtonEnabled(True)
        self.search.returnPressed.connect(lambda: self.find_next(1))
        self.search.textChanged.connect(lambda _t: self._search_changed())
        self.prev_btn = QToolButton(); self.prev_btn.setText("‹"); self.prev_btn.setToolTip("Previous match")
        self.next_btn = QToolButton(); self.next_btn.setText("›"); self.next_btn.setToolTip("Next match (Enter)")
        self.prev_btn.clicked.connect(lambda: self.find_next(-1)); self.next_btn.clicked.connect(lambda: self.find_next(1))
        bar.addWidget(self.search, 1); bar.addWidget(self.prev_btn); bar.addWidget(self.next_btn)
        lay.addLayout(bar)
        row = QHBoxLayout(); row.setSpacing(6)
        self.match_label = QLabel(""); row.addWidget(self.match_label, 1)
        self.jump = QComboBox(); self.jump.setToolTip("Go to a section of the help")
        self.jump.activated.connect(lambda i: i > 0 and self.show_section(self.jump.itemData(i)))
        row.addWidget(self.jump)
        lay.addLayout(row)
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        self.sections: dict[int, str] = {}
        self._load()
        lay.addWidget(self.browser)
        self._search_changed()

    def _load(self):
        from .theme import is_dark
        try:
            md = HELP_MD.read_text(encoding="utf-8")
        except OSError as e:
            self.browser.setPlainText(f"The help page is missing ({e}). Reinstall the plugin.")
            self.jump.hide()
            return
        doc = QTextDocument(); doc.setMarkdown(md)
        self.browser.document().setDefaultStyleSheet(_css(is_dark(self)))
        self.browser.setHtml(doc.toHtml())             # through HTML so the theme's heading style applies
        self.jump.clear(); self.jump.addItem("Jump to…", None)
        for line in md.splitlines():
            if line.startswith("## "):
                title = line[3:].strip()
                num = title.split(".", 1)[0]
                if num.isdigit():
                    self.sections[int(num)] = title
                    self.jump.addItem(title, int(num))

    # ---------------- sections ----------------
    def _heading_block(self, number: int):
        block = self.browser.document().begin()
        while block.isValid():
            if block.blockFormat().headingLevel() == 2 and block.text().startswith(f"{number}."):
                return block
            block = block.next()
        return None

    def show_section(self, number: int) -> bool:
        """Scroll so section `number` (the "## 8." heading) is at the top. False when there is no such section."""
        block = self._heading_block(int(number)) if number is not None else None
        if block is None:
            return False
        cur = QTextCursor(block)
        self.browser.setTextCursor(cur)
        y = int(self.browser.document().documentLayout().blockBoundingRect(block).top())
        self.browser.verticalScrollBar().setValue(y)
        return True

    # ---------------- search ----------------
    def _search_changed(self):
        has = bool(self.search.text().strip())
        self.prev_btn.setEnabled(has); self.next_btn.setEnabled(has)
        self.match_label.setText("")
        if has:
            cur = self.browser.textCursor(); cur.movePosition(QTextCursor.MoveOperation.Start)
            self.browser.setTextCursor(cur)
            self.find_next(1)

    def find_next(self, direction: int = 1) -> bool:
        """Select the next (or previous) match, wrapping round once; says "No match" in words when there is none."""
        from .theme import is_dark, tone
        text = self.search.text().strip()
        if not text:
            return False
        flags = QTextDocument.FindFlag.FindBackward if direction < 0 else QTextDocument.FindFlag(0)
        found = self.browser.find(text, flags)
        if not found:                                  # wrap round once
            cur = self.browser.textCursor()
            cur.movePosition(QTextCursor.MoveOperation.End if direction < 0 else QTextCursor.MoveOperation.Start)
            self.browser.setTextCursor(cur)
            found = self.browser.find(text, flags)
        self.match_label.setText("" if found else f"No match for “{text}”")
        self.match_label.setStyleSheet(f"color: {tone('warn', is_dark(self))};")
        return found
