"""Auto from wayleave (frontend spec 5): one press runs Use this wayleave, Gate 0, P1 ... P7, each as Generate ->
Check -> then waits for the planner's own Approve before it moves on (JJ 23 Nov: "it should stop at every stage for my
approval"). It only calls what the buttons call (StageTab.generate / check /
approve / take_over, WayleaveBox.use_wayleave) and reads the site state between steps; nothing in core changes.

Stop rules (spec 5.2): a failed script or crashed check, a check with blocking failures left, the planner's own
notes to tick, a hard refusal, a step that would need a question answered, the planner pressing Stop, or the stage
the planner chose to pause after. It never approves anything itself: after a clean check, and before taking over a
layer the planner drew, it waits; when the planner approves (or takes over) the stage, it goes on. Sending the stage
back while it waits stops the run.

AutoRun is the state machine (no widgets); AutoBar is the dock's strip: the button, the confirm sheet, the run strip
and the end line."""
from __future__ import annotations

import datetime as _dt
import getpass
import time

from qgis.PyQt.QtCore import QObject, Qt, QTimer, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMenu,
    QProgressBar,
    QPushButton,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..core import approval, stages
from ..core.checks import ChecksReport
from ..core.scan import SCANNED
from . import progress, words
from .theme import is_dark, primary_button, quiet_button, tone

PLAN = [s.id for s in stages.REGISTRY if s.phase in ("gate", "plan")]
WAYLEAVE = "wayleave"


def auto_note() -> str:
    try:
        who = getpass.getuser()
    except Exception:                                   # noqa: BLE001
        who = "planner"
    now = _dt.datetime.now()
    return f"Auto run, {who}, {now.day} {now:%b %H:%M}"


def short(sid: str) -> str:
    return words.stage_label(sid).split(" ")[0]


class AutoRun(QObject):
    """One run. Signals: step(text) as each sub-step starts, finished(ok, line) once."""
    step = pyqtSignal(str)
    finished = pyqtSignal(bool, str)
    waiting_for = pyqtSignal(str, str)                  # stage, what the planner must do

    def __init__(self, tab, box, pause_after: str | None = None, parent=None):
        super().__init__(parent)
        self.tab, self.box, self.pause_after = tab, box, pause_after
        self.store, self.ctl = tab.store, tab.controller
        self.started = time.time()
        self.times: dict[str, float] = {}               # stage -> seconds it took in this run
        self._t_stage: dict[str, float] = {}
        self.done: list[str] = []                       # approved by this run, in order
        self.current: str | None = None
        self.phase = ""                                 # "Drawing" | "Checking" | "Approving" | "Taking over"
        self._did: dict[str, set] = {}                  # stage -> phases already tried (never loops)
        self.stop_after_stage = False
        self.running = False
        self.waiting: str | None = None                 # stage waiting for the planner's Approve
        self.result: tuple[bool, str] | None = None
        self._timer = QTimer(self); self._timer.setInterval(400); self._timer.timeout.connect(self._poll)

    # ---------------- what will happen ----------------
    def todo(self) -> list[str]:
        st = self.store.load()["stages"]
        out = [WAYLEAVE] if st[WAYLEAVE]["status"] != "approved" else []
        return out + [s for s in PLAN if st.get(s, {}).get("status") != "approved"]

    def refusals(self) -> list[str]:
        """Why the run cannot start (spec 5.1), in plain words; [] = it can."""
        why = []
        if self.tab.locked:
            why.append("This site is open in another QGIS.")
        if self.tab.blocked_reason:
            why.append(self.tab.blocked_reason)
        for sid in self.todo():
            if sid == WAYLEAVE:
                r = self.box.use_blocked_reason()
                if r:
                    from .wayleave_box import _plain_reason
                    why.append("Wayleave: " + _plain_reason(r))
                continue
            hb = self.tab.herotel_block(sid) if self.tab.herotel_block is not None else None
            if hb:
                why.append(hb); break
        if self.tab.busy:
            why.append("A stage is running. Wait for it to finish.")
        return list(dict.fromkeys(why))

    def estimate(self) -> str:
        known, secs = 0, 0.0
        todo = [s for s in self.todo() if s != WAYLEAVE]
        for sid in todo:
            h = progress.history(sid)
            if h:
                known += 1; secs += sorted(h)[len(h) // 2]
        if not todo:
            return ""
        if known == len(todo):
            return f"about {progress.minutes(secs)} (from earlier runs on this PC)"
        if known:
            return f"at least {progress.minutes(secs)}; no estimate yet for {len(todo) - known} stage(s)"
        return "No estimate yet: first run on this PC. P4 can take over half an hour on a big site."

    # ---------------- run ----------------
    def start(self):
        self.running = True
        self.tab.auto_sink = []; self.box.auto_sink = []
        self.step.emit("Starting…")
        QTimer.singleShot(0, self._poll)
        self._timer.start()

    def stop_now(self):
        self.tab.cancel_tasks()
        self._finish(False, f"Stopped by you at {short(self.current) if self.current else 'the start'}.")

    def _finish(self, ok: bool, line: str):
        if not self.running:
            return
        self.running = False
        self.waiting = None
        self._timer.stop()
        self.tab.auto_sink = None; self.box.auto_sink = None
        if self.current and self.current in self._t_stage and self.current not in self.times:
            self.times[self.current] = time.time() - self._t_stage[self.current]
        self.result = (ok, line)
        self.finished.emit(ok, line)

    def elapsed(self) -> float:
        return time.time() - self.started

    def _messages(self) -> str:
        sink = (self.tab.auto_sink or []) + (self.box.auto_sink or [])
        if not sink:
            return ""
        return sink[-1][1].split("\n\n")[0]

    def _tried(self, sid: str, phase: str) -> bool:
        return phase in self._did.setdefault(sid, set())

    def _mark(self, sid: str, phase: str, words_: str):
        self._did.setdefault(sid, set()).add(phase)
        self.phase = words_
        if sid not in self._t_stage:
            self._t_stage[sid] = time.time()
        self.current = sid
        self.step.emit(f"{words.stage_label(sid) if sid != WAYLEAVE else 'Wayleave'} · {words_}…")

    def _blocking_left(self, sid: str) -> int:
        s = self.store.stage_state(sid)
        cj = self.store.rev_dir(sid, s["current_rev"]) / "checks.json" if s.get("current_rev") else None
        if cj is None or not cj.exists():
            return 0
        from ..core import dismiss
        report = ChecksReport.load(cj)
        shown, _removed, _fixed = dismiss.split_how(report, cj.parent)
        return sum(1 for i in shown if i.severity == "error") or (0 if report.ok() else 1)

    def _poll(self):
        """Every 0.4 s: nothing while a stage runs; otherwise look at the state and press the next button."""
        if not self.running or self.tab.busy or self.box.busy:
            return
        try:
            self._advance()
        except Exception as e:                          # noqa: BLE001 - a run never wedges the dock
            self._finish(False, f"Auto stopped: {type(e).__name__}: {e}")

    def _wait(self, sid: str, what: str):
        """Hand the stage to the planner; the run goes on once it is approved."""
        self.current, self.waiting, self.phase = sid, sid, "Waiting for you"
        if sid not in self._t_stage:
            self._t_stage[sid] = time.time()
        self.step.emit(f"{'Wayleave' if sid == WAYLEAVE else words.stage_label(sid)} · waiting for you: {what}")
        self.waiting_for.emit(sid, what)

    def _advance(self):
        st = self.store.load()["stages"]
        if self.waiting:
            ws = st.get(self.waiting, {}).get("status", "pending")
            if ws != "approved":
                if ws == "checked" or self.waiting == WAYLEAVE or (ws == "pending" and self.waiting in SCANNED):
                    return                                  # still the planner's turn
                self._finish(False, f"{short(self.waiting)} was not approved "
                                    f"({words.status_label(ws).lower()}). Auto stopped."); return
            self.waiting = None
        # the stage just finished?
        if self.current and st.get(self.current, {}).get("status") == "approved" and self.current not in self.done:
            self.done.append(self.current)
            self.times[self.current] = time.time() - self._t_stage.get(self.current, time.time())
            try:                                         # spec 5.2: a crash or a closed QGIS never wipes a long run
                self.ctl.save_progress()
            except Exception:                            # noqa: BLE001
                pass
            if self.pause_after and self.current == self.pause_after:
                self._finish(True, f"Paused after {short(self.current)}, as you asked."); return
            if self.stop_after_stage:
                self._finish(False, f"Stopped by you after {short(self.current)}."); return
        todo = self.todo()
        if not todo:
            self._finish(True, "Done."); return
        sid = todo[0]
        status = st.get(sid, {}).get("status", "pending")
        msg = self._messages()
        if sid == WAYLEAVE:
            self._wait(sid, "press “Use this wayleave” to check and approve it.")
            return
        if status in ("pending", "stale", "rejected") or (status == "failed" and not self._tried(sid, "generate")):
            if self._tried(sid, "generate") or self._tried(sid, "takeover"):
                self._finish(False, f"{short(sid)} stopped: {msg or 'it did not finish'}."); return
            if sid in SCANNED and self.tab.drawn_layers(sid):
                self._wait(sid, "you drew this layer. Take it over with “Use what I've drawn…”.")
                return
            if sid in SCANNED and self.tab.existing_layers(sid):
                self._finish(False, f"{short(sid)}: your project already has a layer for this step. Use "
                                    f"“Use what I've drawn…” to take it over, or untick it there."); return
            self._mark(sid, "generate", "Drawing")
            self.tab.generate(sid)
            return
        if status == "failed":
            self._finish(False, f"{short(sid)} stopped: the script failed. {msg}".strip()); return
        if status == "generated":
            if self._tried(sid, "check"):
                n = self._blocking_left(sid)
                if n:
                    self._finish(False, f"Stopped at {short(sid)}: {n} error{'s' if n != 1 else ''} to look at."); return
                self._finish(False, f"{short(sid)}: the check did not finish. {msg}".strip()); return
            self._mark(sid, "check", "Checking")
            self.tab.check(sid)
            return
        if status == "checked":
            checks, hard = self.ctl.approve_blockers(sid)
            if checks or hard:                           # never waits on a stage that cannot be approved cleanly
                self._finish(False, f"Stopped at {short(sid)}: " + " ".join(words.explain_reasons(hard or checks))); return
            n = len(approval.stage_details(self.store, sid))
            self._wait(sid, "checked clean. Look at it, then press Approve" +
                       (f" (tick your {n} note{'s' if n != 1 else ''})." if n else "."))
            return
        self._finish(False, f"{short(sid)} is {words.status_label(status).lower()}: Auto does not know the next step.")


class AutoBar(QFrame):
    """The dock strip (spec 3.2, 5.1, 5.3): idle button -> confirm sheet -> run strip -> end line."""
    report_requested = pyqtSignal()
    show_issues = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("autoBar")
        self.tab = self.box = self.dock = None
        self.run: AutoRun | None = None
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 2, 0, 2); lay.setSpacing(4)
        # idle
        self.idle = QWidget(); il = QHBoxLayout(self.idle); il.setContentsMargins(0, 0, 0, 0)
        self.go_btn = QPushButton("▶ Auto from wayleave")
        self.go_btn.setToolTip("Draw and check every stage still to do; it stops for your Approve at each one")
        self.go_btn.clicked.connect(self.open_sheet)
        self.hint = QLabel("draws and checks each stage; you approve each one"); self.hint.setWordWrap(True)
        il.addWidget(self.go_btn); il.addWidget(self.hint, 1)
        lay.addWidget(self.idle)
        # confirm sheet
        self.sheet = QFrame(); self.sheet.setObjectName("autoSheet")
        sl = QVBoxLayout(self.sheet); sl.setContentsMargins(10, 8, 10, 8); sl.setSpacing(3)
        self.sheet_text = QLabel(""); self.sheet_text.setWordWrap(True); self.sheet_text.setTextFormat(Qt.TextFormat.RichText)
        prow = QHBoxLayout(); prow.addWidget(QLabel("Pause after"))
        self.pause = QComboBox(); self.pause.addItem("none", None)
        prow.addWidget(self.pause, 1)
        brow = QHBoxLayout(); brow.addStretch(1)
        self.cancel_btn = QPushButton("Cancel"); self.cancel_btn.clicked.connect(self.close_sheet)
        self.start_btn = QPushButton("▶ Start"); self.start_btn.clicked.connect(self.start)
        brow.addWidget(self.cancel_btn); brow.addWidget(self.start_btn)
        sl.addWidget(self.sheet_text); sl.addLayout(prow); sl.addLayout(brow)
        self.sheet.hide(); lay.addWidget(self.sheet)
        # run strip
        self.strip = QFrame(); self.strip.setObjectName("autoStrip")
        rl = QVBoxLayout(self.strip); rl.setContentsMargins(10, 6, 10, 6); rl.setSpacing(3)
        top = QHBoxLayout()
        self.strip_head = QLabel(""); self.strip_head.setWordWrap(True)
        self.stop_btn = QToolButton(); self.stop_btn.setText("Stop ▾")
        self.stop_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        m = QMenu(self.stop_btn)
        m.addAction("Stop after this stage").triggered.connect(self._stop_after)
        m.addAction("Stop now").triggered.connect(self._stop_now)
        self.stop_btn.setMenu(m)
        top.addWidget(self.strip_head, 1); top.addWidget(self.stop_btn)
        self.strip_bar = QProgressBar(); self.strip_bar.setTextVisible(False); self.strip_bar.setFixedHeight(5)
        self.strip_step = QLabel(""); self.strip_step.setWordWrap(True)
        self.look_btn = QPushButton("Show it"); self.look_btn.hide()
        self.look_btn.clicked.connect(self._show_waiting)
        srow = QHBoxLayout(); srow.addWidget(self.strip_step, 1); srow.addWidget(self.look_btn)
        rl.addLayout(top); rl.addWidget(self.strip_bar); rl.addLayout(srow)
        self.strip.hide(); lay.addWidget(self.strip)
        # end line
        self.end = QFrame(); self.end.setObjectName("autoEnd")
        el = QHBoxLayout(self.end); el.setContentsMargins(10, 6, 10, 6)
        self.end_text = QLabel(""); self.end_text.setWordWrap(True)
        self.issues_btn = QPushButton("Show them"); self.issues_btn.clicked.connect(lambda: self.show_issues.emit(self._stopped_at or ""))
        self.report_btn = QPushButton("See report"); self.report_btn.clicked.connect(self.report_requested.emit)
        self.end_close = QToolButton(); self.end_close.setText("✕"); self.end_close.setAutoRaise(True)
        self.end_close.setToolTip("Hide"); self.end_close.clicked.connect(lambda: (self.end.hide(), self.idle.show()))
        el.addWidget(self.end_text, 1); el.addWidget(self.issues_btn); el.addWidget(self.report_btn); el.addWidget(self.end_close)
        self.end.hide(); lay.addWidget(self.end)
        self._stopped_at = None
        self._tick = QTimer(self); self._tick.setInterval(1000); self._tick.timeout.connect(self._update_strip)
        self._style()

    def _style(self):
        dark = is_dark(self)
        border = "#4a4a4a" if dark else "#d4d4d4"
        run = tone("run", dark)
        self.setStyleSheet(f"#autoSheet, #autoEnd {{ border: 1px solid {border}; border-radius: 6px; }}"
                           f"#autoStrip {{ border: 1px solid {run}; border-radius: 6px; }}")
        self.go_btn.setStyleSheet(quiet_button(dark, "info"))
        self.start_btn.setStyleSheet(primary_button(dark))
        self.hint.setStyleSheet(f"color: {tone('idle', dark)};")
        self.strip_head.setStyleSheet(f"color: {run}; font-weight: 600;")

    def set_context(self, tab, box, dock):
        self.tab, self.box, self.dock = tab, box, dock

    def refresh(self):
        """Hidden with no site; the button is offered once a site is open and nothing runs."""
        has = self.tab is not None and self.tab.store is not None
        self.setVisible(has)
        if not has or (self.run is not None and self.run.running):
            return
        self.go_btn.setEnabled(not self.tab.busy and not self.tab.locked)

    # ---------------- confirm sheet (spec 5.1) ----------------
    def open_sheet(self):
        r = AutoRun(self.tab, self.box)
        todo = r.todo()
        st = self.tab.store.load()
        from .dock import _wayleave_counts
        rules = st.get("client") or ""
        try:
            from ..core import presets
            if st.get("spec_preset"):
                rules = presets.get(st["spec_preset"]).label.split(" (")[0]
        except Exception:                                # noqa: BLE001
            pass
        spec = f" · spec {int(st['spec_rev'][4:])}" if st.get("spec_rev") else " · spec not saved yet"
        replaces = [short(s) for s in todo if s != WAYLEAVE and st["stages"].get(s, {}).get("current_rev")]
        mine = [short(s) for s in todo if s in SCANNED and self.tab.drawn_layers(s)]
        why = r.refusals()
        rows = [("Rules", f"{rules}{spec}"),
                ("Wayleave", " · ".join(_wayleave_counts(self.tab.store)) or ("to be copied first" if WAYLEAVE in todo else "")),
                ("Will do", ", ".join(("Wayleave" if s == WAYLEAVE else short(s)) for s in todo) +
                 f" ({len(todo)} step{'s' if len(todo) != 1 else ''})" if todo else "nothing: every stage is approved"),
                ("Your layers", ", ".join(mine) + ": taken over, not changed" if mine else ""),
                ("Replaces", ", ".join(replaces) + " (older versions stay on disk)" if replaces else ""),
                ("Estimate", r.estimate())]
        html = "<b>Auto run · " + self.tab.store.site + "</b><table cellspacing=2>" + "".join(
            f"<tr><td style='padding-right:8px'>{k}</td><td>{v}</td></tr>" for k, v in rows if v) + "</table>"
        if why:
            c = tone("error", is_dark(self))
            html += f"<p style='color:{c}'>Cannot start: " + " ".join(why) + "</p>"
        html += ("<p>After each clean check it waits for your Approve, then goes on. It never approves by itself, "
                 "and stops on errors and where you pause it.</p>")
        self.sheet_text.setText(html)
        self.pause.clear(); self.pause.addItem("none", None)
        for s in todo:
            if s != WAYLEAVE:
                self.pause.addItem(words.stage_label(s), s)
        self.start_btn.setEnabled(not why and bool(todo))
        self.idle.hide(); self.end.hide(); self.sheet.show()

    def close_sheet(self):
        self.sheet.hide(); self.idle.show()

    # ---------------- running (spec 5.3) ----------------
    def start(self):
        self.run = AutoRun(self.tab, self.box, pause_after=self.pause.currentData())
        if self.run.refusals():
            self.open_sheet(); return
        self._total = max(1, len(self.run.todo()))
        self.run.step.connect(lambda t: (self.strip_step.setText(t), self._update_strip()))
        self.run.finished.connect(self._finished)
        self.run.waiting_for.connect(self._waiting)
        self.sheet.hide(); self.idle.hide(); self.strip.show()
        self.strip_bar.setRange(0, self._total); self.strip_bar.setValue(0)
        self._tick.start()
        self.run.start()

    def _show_waiting(self):
        if self.run is not None and self.run.waiting and self.run.waiting != WAYLEAVE:
            self.tab.select(self.run.waiting)

    def _waiting(self, sid: str, what: str):
        self._update_strip()
        try:
            if sid != WAYLEAVE:
                self.tab.select(sid)
        except Exception:                                # noqa: BLE001 - selecting is a courtesy
            pass
        self._notify(True, f"{'Wayleave' if sid == WAYLEAVE else words.stage_label(sid)}: {what}", wait=True)

    def _update_strip(self):
        if self.run is None:
            return
        n = len(self.run.done) + (1 if self.run.running else 0)
        wait = self.run.running and self.run.waiting is not None
        self.strip_head.setText(f"AUTO RUN · step {min(n, self._total)} of {self._total} · " +
                                ("waiting for your Approve" if wait else f"{progress.clock(self.run.elapsed())} so far"))
        self.strip_head.setStyleSheet(f"color: {tone('warn' if wait else 'run', is_dark(self))}; font-weight: 600;")
        self.look_btn.setVisible(wait)
        self.strip_bar.setValue(len(self.run.done))

    def _stop_after(self):
        if self.run is not None:
            self.run.stop_after_stage = True
            self.strip_step.setText(self.strip_step.text() + "  (stops after this stage)")

    def _stop_now(self):
        if self.run is not None:
            self.run.stop_now()

    def _finished(self, ok: bool, line: str):
        self._tick.stop()
        run = self.run
        took = progress.clock(run.elapsed())
        st = self.tab.store.load()["stages"]
        approved = sum(1 for s in PLAN if st.get(s, {}).get("status") == "approved")
        self._stopped_at = None if ok else run.current
        if ok:
            text = f"{line} in {took} — {approved} of {len(PLAN)} approved."
        else:
            text = f"{line} ({took})"
        c = tone("ok" if ok else "warn", is_dark(self))
        self.end_text.setText(text); self.end_text.setStyleSheet(f"color: {c};")
        self.issues_btn.setVisible(not ok and run.current is not None and run.current != WAYLEAVE)
        self.strip.hide(); self.idle.hide(); self.end.show()
        self._notify(ok, text)

    def _notify(self, ok: bool, text: str, wait: bool = False):
        """Spec 5.3: the planner is working elsewhere: a message-bar notice and a taskbar flash."""
        try:
            iface = self.tab.iface
            bar = iface.messageBar() if hasattr(iface, "messageBar") else None
            if bar is not None:
                from qgis.core import Qgis
                level = Qgis.MessageLevel.Info if wait else (Qgis.MessageLevel.Success if ok else Qgis.MessageLevel.Warning)
                bar.pushMessage("Plan Stages", text, level, 15 if wait else 0)
            win = iface.mainWindow() if hasattr(iface, "mainWindow") else None
            if win is not None:
                QApplication.alert(win)
        except Exception:                                # noqa: BLE001 - a notice never breaks the run's end
            pass
