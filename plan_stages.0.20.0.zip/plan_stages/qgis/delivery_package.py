"""Save the Delivery somewhere else, for example a SharePoint folder (JJ, 2026-11-26: "a Save to SharePoint button ...
the person can choose where he wants to save everything").

The delivery project points at layer files all over the site folder (stepN/*.gpkg and the wayleave snapshot), so a
plain folder copy would open with broken layers on anyone else's laptop. package_delivery reads the delivery project
into its own QgsProject (never the one open on screen), writes every file-based vector layer into ONE GeoPackage next
to it, points each layer at its copy (style kept), saves the project beside it with relative paths, and copies the
map images. Web layers (basemaps) stay as they are. Nothing in the site folder changes, and it only ever writes into
a folder it has just made."""
from __future__ import annotations

import re
import shutil
from pathlib import Path


def target_folder(parent: Path, site: str, rev_name: str) -> Path:
    """A new folder under parent: "<site> delivery rev-003", then "... (2)" and so on; never an existing one."""
    base = f"{site} delivery {rev_name}"
    out, n = Path(parent) / base, 2
    while out.exists():
        out, n = Path(parent) / f"{base} ({n})", n + 1
    return out


def _safe(name: str, used: set) -> str:
    s = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_").lower() or "layer"
    out, n = s, 2
    while out in used:
        out, n = f"{s}_{n}", n + 1
    used.add(out)
    return out


def package_delivery(rev: Path, dest_parent: Path, site: str, on_step=None) -> tuple[Path, list[str]]:
    """Package the delivery revision into a new folder under dest_parent. Returns (folder, [layers left as they
    were, with why]). Raises FileNotFoundError when the revision has no delivery project."""
    from qgis.core import Qgis, QgsProject, QgsVectorFileWriter, QgsVectorLayer

    rev = Path(rev)
    projects = sorted((rev / "qgis").glob("*.qgz")) if (rev / "qgis").is_dir() else []
    if not projects:
        raise FileNotFoundError("This version has no delivery project yet. Generate Delivery first.")
    proj = QgsProject()
    if not proj.read(str(projects[0])):
        raise OSError(f"Could not read {projects[0].name}.")
    out = target_folder(Path(dest_parent), site, rev.name)
    out.mkdir(parents=True)
    gpkg = out / f"{site}_delivery.gpkg"
    skipped, used, first = [], set(), True
    layers = [lyr for lyr in proj.mapLayers().values() if isinstance(lyr, QgsVectorLayer)]
    for i, lyr in enumerate(layers, 1):
        if on_step is not None:
            on_step(i, len(layers), lyr.name())
        if lyr.providerType() != "ogr":
            skipped.append(f"{lyr.name()}: not a file layer, left as it is"); continue
        if not lyr.isValid():
            skipped.append(f"{lyr.name()}: its file is missing"); continue
        name = _safe(lyr.name(), used)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName, opts.layerName = "GPKG", name
        if not first:
            opts.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
        err = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, str(gpkg), proj.transformContext(), opts)
        if err[0] != QgsVectorFileWriter.WriterError.NoError:
            skipped.append(f"{lyr.name()}: {err[1] or 'could not be written'}"); continue
        first = False
        lyr.setDataSource(f"{gpkg.as_posix()}|layername={name}", lyr.name(), "ogr")
    proj.setFilePathStorage(Qgis.FilePathType.Relative)
    if not proj.write(str(out / projects[0].name)):
        raise OSError(f"Could not save {projects[0].name} in {out}.")
    if (rev / "render").is_dir():
        shutil.copytree(rev / "render", out / "map images")
    proj.clear()
    return out, skipped
