"""Plain words for the dock (frontend spec section 1 and 10).

One map from the ids the backend already uses to the words a planner reads, and `explain()`, which turns the
backend's own refusal and error strings into a headline plus what to do next. Nothing in core/ changes: the
backend keeps its ids and its messages, and the raw text stays available under "Show details" for support.
"""
from __future__ import annotations

import re

STAGE_NAMES = {
    "wayleave": "Wayleave",
    "gate0": "Gate 0 · Wayleave test",
    "p1_feeder": "P1 Feeder",
    "p2_1to16": "P2 1:16 splitters",
    "p3_distribution": "P3 Distribution",
    "p4_drops": "P4 Collection points + drops",
    "p5_crossings": "P5 Road crossings",
    "p7_hardware": "P6 Splitters + dome joints",
    "p8_delivery": "P7 Delivery",
}

# status -> (label, colour). Colours pass 4.5:1 with the text colour given in STATUS_TEXT.
STATUS = {
    "pending": ("Not started", "#e0e0e0"),
    "generating": ("Running", "#3949ab"),
    "generated": ("Drawn · check it", "#1565c0"),
    "needs_fixes": ("Needs fixes", "#c62828"),
    "checked": ("Checked · ready", "#00695c"),
    "approved": ("Approved", "#2e7d32"),
    "stale": ("Out of date", "#f9a825"),
    "rejected": ("Sent back", "#c62828"),
    "failed": ("Failed", "#c62828"),
}
STATUS_TEXT = {"pending": "#212121", "stale": "#212121"}     # light backgrounds get dark text (contrast)

LAYER_NAMES = {
    "span": "Span", "pons": "PON areas", "demand_points": "Homes", "pop": "POP", "roads": "Roads",
    "poles": "Poles", "erven": "Erven", "aoi": "Site boundary", "buildings": "Buildings",
}


# check code -> (plain title, what to do). Codes stay in tooltips for support.
CHECK_TITLES = {
    "drop_none": ("Homes with no drop", "Add or move a collection point on the home's side of the road."),
    "drop_crosses_road": ("Drops that cross a road", "Move the drop to a collection point on the same side."),
    "drop_cap": ("Drops longer than the limit", "Add a nearer collection point."),
    "drop_cap_escalated": ("Drops longer than the limit", "Add a nearer collection point."),
    "drop_unattached": ("Drops not joined to a collection point", "Snap the drop end to its collection point."),
    "fan_cap": ("Too many drops on one collection point", "Move drops to a neighbour or add a point."),
    "pon_cap": ("Too many collection points in a PON", "Merge points or split the PON."),
    "pon_cap_hard": ("Too many collection points in a PON", "Merge points or split the PON."),
    "pon_range": ("PON outside the client's home range", "Redraw the PON edge."),
    "pon_homes": ("PON with no homes, or a wrong home count", "Fix the PON area in the wayleave."),
    "cp_on_cable": ("Collection point off the cable", "Move it onto the distribution."),
    "cp_needs_pole": ("Collection point needs a pole", "Draw a pole there in the wayleave."),
    "drops_drawn": ("No drops were drawn", "Check the wayleave: a layer may be in the wrong place."),
    "feeder_reaches_pon": ("Feeder does not reach a PON", "Extend the feeder to that PON's span."),
    "feeder_not_midblock": ("Feeder away from the road", "Move the feeder to the road side."),
    "feeder_midblock_hard": ("Feeder away from the road", "Move the feeder to the road side."),
    "one_1to16_per_pon": ("PON without exactly one 1:16", "Add, move or delete a 1:16."),
    "1to16_on_pole": ("1:16 not on a pole", "Move it to a pole, or draw one."),
    "1to16_joins_distribution": ("1:16 not joined to the distribution", "Link it to its PON's span."),
    "pon_number_unique": ("Two PONs share a number", "Renumber one."),
    "cross_span": ("Road crossing too long", "Move the crossing or add a pole."),
    "cross_span_hard": ("Road crossing too long", "Move the crossing or add a pole."),
    "hardware_on_pole": ("Splitter or dome not on a pole", "Move it to a pole."),
    "one_per_cp": ("Collection point without one splitter and one dome", "Add or delete hardware."),
    "layer_in_aoi": ("A layer is nowhere near the site", "Set the layer's coordinate system."),
    "roads_usable": ("Roads layer cannot be used", "Check the Roads layer."),
    "geom_valid": ("Broken shape", "Fix the geometry (Vector > Geometry > Fix geometries)."),
}


# spec keys -> the rule's name as a planner says it (frontend spec 8.2). The key stays the row's data and tooltip.
RULE_NAMES = {
    "density": "Density", "drop_cap_m": "Longest drop", "span_cap_m": "Longest span",
    "span_typical_m": "Typical span", "cable_span_rating_m": "Cable span rating",
    "cross_span_m": "Longest span across a road", "fan_cap": "Drops per collection point",
    "pon_cap": "Collection points per PON", "feeder_split": "Feeder splitter", "dist_split": "Distribution splitter",
    "pon_target": "Homes per PON (aim)", "pon_max": "Homes per PON (most)", "pole_midblock_m": "Midblock pole height",
    "pole_crossing_m": "Crossing pole height", "pole_feeder_m": "Feeder pole height",
    "pole_boundary_setback_m": "Pole setback from a boundary", "pole_pitch_m": "Pole spacing",
    "direction_change_stay_deg": "Turn that needs a stay", "aerial": "Aerial build",
}


def rule_name(key: str) -> str:
    return RULE_NAMES.get(key, key.replace("_", " ").capitalize())


def check_title(code: str) -> str:
    return CHECK_TITLES.get(code, (code.replace("_", " ").capitalize(), ""))[0]


def check_todo(code: str) -> str:
    return CHECK_TITLES.get(code, ("", ""))[1]


def stage_label(stage_id: str, fallback: str | None = None) -> str:
    return STAGE_NAMES.get(stage_id, fallback or stage_id)


def status_label(status: str | None, blocking_failures: bool = False) -> str:
    if status == "generated" and blocking_failures:
        status = "needs_fixes"
    return STATUS.get(status or "", ("—", "#e0e0e0"))[0]


def status_colours(status: str | None, blocking_failures: bool = False) -> tuple[str, str]:
    if status == "generated" and blocking_failures:
        status = "needs_fixes"
    bg = STATUS.get(status or "", ("", "#e0e0e0"))[1]
    return bg, STATUS_TEXT.get(status or "", "#212121" if bg == "#e0e0e0" else "#ffffff")


def _name(stage_id: str) -> str:
    return STAGE_NAMES.get(stage_id, stage_id)


def _sub_ids(text: str) -> str:
    """Stage ids inside free text become their display names (longest id first, whole words only)."""
    for sid in sorted(STAGE_NAMES, key=len, reverse=True):
        text = re.sub(rf"\b{re.escape(sid)}\b", STAGE_NAMES[sid], text)
    return text


# (pattern over one backend reason, headline builder). The first match wins. Keep the most specific first.
_RULES: list[tuple[str, object]] = [
    (r"^approval note required$", "Type a short note to approve."),
    (r"^nothing generated$", "Nothing is drawn yet. Press Generate first."),
    (r"^checks have not run on this revision$", "Check this stage first."),
    (r"^checks stale: layer edited since last Check$", "You edited the layer after the last check. Check again."),
    (r"^checks\.json missing; re-check$", "The last check left no result. Check again."),
    (r"^layer edited during Check; re-check$", "You edited the layer while it was being checked. Check again."),
    (r"^stage is (failed|rejected); regenerate first$",
     lambda m: ("The last run failed." if m[1] == "failed" else "This stage was sent back.") + " Generate it again."),
    (r"^no working layer for rev-\d+$", "This version has no layer on disk. Generate it again."),
    (r"^dependency (\w+) has no approved revision$", lambda m: f"Approve {_name(m[1])} first."),
    (r"^dependency (\w+) re-approved as rev-\d+; this revision used rev-\d+$",
     lambda m: f"{_name(m[1])} changed after this was made. Generate this stage again."),
    (r"^built on (\w+), a stage Plan Stages no longer has; Generate again$",
     "This was made by an older Plan Stages. Generate it again."),
    (r"^spec changed to rev-\d+; this revision used rev-\d+$",
     "The rules changed after this was made. Generate this stage again."),
    (r"^operator detail ([\w-]+) not checked against this plan: (.*)$",
     lambda m: f"Tick your note “{m[2].strip()}” to approve."),
    (r"^check (\w+) failed: (.*)$", lambda m: f"Check failed: {m[2].strip()}"),
    (r"^check (\w+) (\w+): (.*)$", lambda m: f"Check {m[2]}: {m[3].strip()}"),
    (r"^GeoPackage busy; close edits and retry$", "Stop editing the layer first, then try again."),
    (r"^nothing to remove$", "There is no version to delete."),
    (r"(PermissionError|WinError 32)", "A file is in use. Close any other program using this site, then try again."),
    (r"NoQgisFound", "Plan Stages could not find QGIS's Python. Open Settings and set it."),
    (r"Could not checkpoint working\.gpkg", "The layer is still being saved. Wait a moment and try again."),
]


def explain_one(reason: str) -> str:
    """One backend reason in plain words. Unknown text is returned as it is, with stage ids renamed."""
    r = (reason or "").strip()
    for pat, out in _RULES:
        m = re.search(pat, r)
        if m:
            return out(m) if callable(out) else out
    return _sub_ids(r)


def explain_reasons(reasons: list[str] | str) -> list[str]:
    """A refusal list (or the '; '-joined Refusal text) in plain words, duplicates dropped, order kept."""
    if isinstance(reasons, str):
        # Refusal joins its reasons with "; ", and some reasons hold "; " themselves ("...; regenerate first"),
        # so split only where a known reason starts.
        starts = r"stage is |nothing generated|no working layer|checks |check |built on |dependency |spec changed|operator detail"
        reasons = [p for p in re.split(rf";\s+(?={starts})", reasons) if p]
    return list(dict.fromkeys(explain_one(x) for x in reasons))


def explain_exception(e: BaseException) -> str:
    """A raised error as one plain line; the type and raw message go to the details."""
    raw = f"{type(e).__name__}: {e}"
    plain = explain_one(raw)
    if plain != _sub_ids(raw):
        return plain
    if type(e).__name__ == "Refusal":
        return " ".join(explain_reasons(str(e)))
    return "Something went wrong. Show details has the full message."


_TRACE = re.compile(r'^\s*(File "|Traceback|\^|~)|^\s{4}\S')


def last_useful_line(log: str) -> str:
    """The last log line that is not a traceback frame: usually the real error."""
    for line in reversed((log or "").splitlines()):
        s = line.strip()
        if s and not _TRACE.match(line):
            return s
    return ""
