"""Running feedback for long stages (frontend spec 4): phase words from known log lines, elapsed time, and an
estimate from earlier runs on this PC. No Qt here except the QgsSettings store at the bottom.

Honest limit: the long middle of P4 prints nothing per PON, so there is no "PON 31 of 56" counter; the phase
words and elapsed time are what the log allows. No number is ever invented: with no history the line says so.
"""
from __future__ import annotations

# stage -> [(log line starts with, phase words, share of the run done when it appears)]
PHASES = {
    "p4_drops": [
        ("USING OUR OWN Step 3 cable", "Reading the cable", 0.02),
        ("CANDIDATES =", "Finding pole positions", 0.05),
        ("road layer:", "Reading roads", 0.08),
        ("pruned", "Trimming extra collection points", 0.70),
        ("spread", "Spacing joints", 0.78),
        ("un-stacked", "Separating stacked points", 0.84),
        ("pulled in", "Shortening drops", 0.88),
        ("uncrossed", "Untangling drops", 0.92),
        ("[repair]", "Fixing road crossings", 0.95),
        ("--- Step 4 result ---", "Writing the result", 0.99),
    ],
}
LONG_MIDDLE = {"p4_drops": ("road layer:", "Placing collection points, PON by PON")}


def phase(stage_id: str, lines: list[str]) -> tuple[str, float | None]:
    """(words, share done) from the lines seen so far; ("", None) when nothing known has appeared."""
    best: tuple[str, float | None] = ("", None)
    table = PHASES.get(stage_id, [])
    for line in lines:
        s = line.strip()
        for start, words, share in table:
            if s.startswith(start) and (best[1] is None or share >= best[1]):
                best = (words, share)
    mid = LONG_MIDDLE.get(stage_id)
    if mid and best[0] and best[0] == next((w for st, w, _ in table if st == mid[0]), None):
        best = (mid[1], best[1])                       # after "Reading roads" the long silent part starts
    return best


def clock(seconds: float) -> str:
    s = max(0, int(seconds))
    return f"{s // 3600}:{s // 60 % 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


def minutes(seconds: float) -> str:
    m = max(1, round(seconds / 60))
    return f"{m} min"


def running_line(stage_id: str, elapsed: float, history: list[float], lines: list[str]) -> str:
    """'Running · Placing collection points, PON by PON · 12:04 · about 9 min left (last time 21 min)'."""
    words, _share = phase(stage_id, lines)
    bits = ["Running"] + ([words] if words else []) + [clock(elapsed)]
    if history:
        last = history[-1]
        typical = sorted(history)[len(history) // 2]
        left = typical - elapsed
        if left > 30:
            bits.append(f"about {minutes(left)} left (last time {minutes(last)})")
        else:
            bits.append(f"taking longer than last time ({minutes(last)})" if left < -30 else "almost done")
    else:
        bits.append("no estimate yet, first run on this PC")
    return " · ".join(bits)


# ---- history on this PC (QgsSettings plan_stages/ui/timing/<stage>, last 5 finished runs, seconds) ----
def history(stage_id: str) -> list[float]:
    try:
        from qgis.core import QgsSettings
        raw = QgsSettings().value(f"plan_stages/ui/timing/{stage_id}", "", type=str) or ""
        return [float(x) for x in raw.split(",") if x.strip()]
    except Exception:                                   # noqa: BLE001
        return []


def remember(stage_id: str, seconds: float) -> None:
    if seconds < 1:
        return
    try:
        from qgis.core import QgsSettings
        runs = (history(stage_id) + [round(seconds, 1)])[-5:]
        QgsSettings().setValue(f"plan_stages/ui/timing/{stage_id}", ",".join(str(x) for x in runs))
    except Exception:                                   # noqa: BLE001
        pass
