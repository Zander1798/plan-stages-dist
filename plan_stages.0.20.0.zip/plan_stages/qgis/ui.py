"""Small dialog and styling helpers shared by the dock tabs."""
from __future__ import annotations
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox,
                                 QProgressBar, QVBoxLayout, QWidget)

_BADGE = {"pending": "#9e9e9e", "generating": "#5c6bc0", "generated": "#1976d2", "checked": "#00897b", "approved": "#2e7d32",
          "stale": "#f9a825", "rejected": "#c62828", "failed": "#c62828"}


def badge_style(status: str) -> str:
    return f"QLabel {{ background: {_BADGE.get(status, '#757575')}; color: white; border-radius: 3px; padding: 1px 6px; }}"


def status_badge_style(status: str, blocking_failures: bool = False) -> str:
    """Badge colours from the words map: light badges get dark text, so every badge passes 4.5:1."""
    from .words import status_colours
    bg, fg = status_colours(status, blocking_failures)
    return f"QLabel {{ background: {bg}; color: {fg}; border-radius: 3px; padding: 1px 6px; }}"


def warn(parent, title: str, text: str, details: str = "") -> None:
    """A warning in plain words. `details` (the backend's raw message and log tail) sits under "Show details",
    so support still sees exactly what the backend said."""
    if not details:
        QMessageBox.warning(parent, title, text)
        return
    box = QMessageBox(QMessageBox.Icon.Warning, title, text, QMessageBox.StandardButton.Ok, parent)
    box.setDetailedText(details)
    box.exec()


def info(parent, title: str, text: str) -> None:
    QMessageBox.information(parent, title, text)


def ask_yes_no(parent, title: str, text: str) -> bool:
    btn = QMessageBox.question(parent, title, text, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                               QMessageBox.StandardButton.No)
    return btn == QMessageBox.StandardButton.Yes


def ask_note(parent, title: str, label: str) -> str | None:
    text, ok = QInputDialog.getText(parent, title, label, QLineEdit.EchoMode.Normal, "")
    return text if ok else None


def tail(text: str, lines: int = 25) -> str:
    return "\n".join((text or "").splitlines()[-lines:]) or "(no output)"


class BusyLine(QWidget):
    """Frontend spec 4 "Other waits": words saying what is happening, a thin moving bar, and the time it has taken
    once it passes 2 s. Never only a wait cursor. start() paints at once (the work after it may block the UI)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 2, 0, 2); lay.setSpacing(2)
        self.label = QLabel(""); self.label.setWordWrap(True)
        self.bar = QProgressBar(); self.bar.setRange(0, 0); self.bar.setTextVisible(False); self.bar.setFixedHeight(4)
        lay.addWidget(self.label); lay.addWidget(self.bar)
        self._t0 = None
        self.hide()

    def start(self, text: str, pct: int | None = None) -> None:
        import time
        from .theme import is_dark, tone
        self._t0 = self._t0 or time.time()
        self.label.setText(text)
        self.label.setStyleSheet(f"color: {tone('run', is_dark(self))};")
        if pct is None:
            self.bar.setRange(0, 0)
        else:
            self.bar.setRange(0, 100); self.bar.setValue(max(0, min(100, int(pct))))
        self.show()
        QApplication.processEvents()                 # paint now, before a long synchronous step

    def stop(self) -> None:
        self._t0 = None
        self.hide()


class WheelSafeCombo(QComboBox):
    """A combo in the dock's scroll area (2026-10-19 review; the Wayleave box's LayerCombo does the same): unfocused,
    the wheel is ignored so the dock scrolls instead of the pick changing; a click or Tab gives it focus."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def wheelEvent(self, event):
        if not self.hasFocus():
            event.ignore()
            return
        super().wheelEvent(event)
