"""One stage in the Plan tab's timeline (frontend spec 3.3).

  ●─ P3 Distribution                      [Redo]  ⋯
  │  Out of date · P2 changed

The row is a click target (it selects the stage), draws its piece of the timeline line, and holds the stage's
action buttons in one slot where exactly one is visible: the main button for the state the row is in. The
other actions live in the ⋯ menu. The buttons are the tab's own QPushButtons, so every existing flow and
test that presses them is unchanged.
"""
from __future__ import annotations

from qgis.PyQt.QtCore import QPointF, Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QPen
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMenu,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
)

from .theme import is_dark, tone

DOT_W = 22


class StageRow(QFrame):
    clicked = pyqtSignal()
    menu_action = pyqtSignal(str)

    def __init__(self, name: str, first: bool, last: bool, parent=None):
        super().__init__(parent)
        self.setObjectName("stageRow")
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)   # rows never squash; the pane gives
        self.first, self.last, self.selected, self._tone = first, last, False, "idle"
        self._kbd_focus = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)          # keyboard: Tab to a row, Space/Enter selects it
        outer = QVBoxLayout(self); outer.setContentsMargins(4, 5, 4, 5); outer.setSpacing(1)
        top = QHBoxLayout(); top.setSpacing(6)
        self.dot = QLabel(); self.dot.setFixedWidth(DOT_W); self.dot.setAlignment(Qt.AlignmentFlag.AlignCenter)
        f = QFont(self.font()); f.setPointSizeF(f.pointSizeF() * 1.15); self.dot.setFont(f)
        self.name = QLabel(name); nf = QFont(self.font()); nf.setBold(True); self.name.setFont(nf)
        self.name.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)   # long names elide, never widen
        self.slot = QHBoxLayout(); self.slot.setContentsMargins(0, 0, 0, 0); self.slot.setSpacing(4)
        self.more = QToolButton(); self.more.setText("\u2022\u2022\u2022"); self.more.setAutoRaise(True)
        self.more.setStyleSheet("QToolButton::menu-indicator { image: none; width: 0; }")
        self.more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.more.setToolTip("More for this stage"); self.more.setAccessibleName(f"More actions for {name}")
        self._menu = QMenu(self.more); self.more.setMenu(self._menu)
        top.addWidget(self.dot); top.addWidget(self.name, 1); top.addLayout(self.slot); top.addWidget(self.more)
        self.status = QLabel(""); self.status.setWordWrap(False)
        self.status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.status.setContentsMargins(DOT_W + 6, 0, 0, 0)
        self.status.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        outer.addLayout(top); outer.addWidget(self.status)
        from qgis.PyQt.QtWidgets import QProgressBar
        self.bar = QProgressBar(); self.bar.setTextVisible(False); self.bar.setFixedHeight(3)
        self.bar.setContentsMargins(DOT_W + 6, 0, 0, 0); self.bar.hide()
        outer.addWidget(self.bar)

    # ---- content ----
    def set_progress(self, pct):
        """Spec 4: a thin bar while the stage runs; pct None = moving (no share known yet), -1 = hidden. A running
        line wraps (phase, time and estimate do not fit one line at 420 px); other lines stay one line."""
        self.status.setWordWrap(pct != -1)
        if pct == -1:
            self.bar.hide(); return
        if pct is None or pct <= 0:
            self.bar.setRange(0, 0)
        else:
            self.bar.setRange(0, 100); self.bar.setValue(int(pct))
        self.bar.show()

    def add_button(self, btn):
        self.slot.addWidget(btn)

    def show_view(self, v, raw_status: str):
        """Paint a RowView: dot, status line, menu. The tab shows/hides the buttons in the slot."""
        self._tone = v.tone
        dark = is_dark(self)
        c = tone(v.tone, dark)
        self.dot.setText("")                               # painted in paintEvent: no font glyph needed
        self.status.setText(v.status)
        self.status.setStyleSheet(f"QLabel {{ color: {c}; }}")
        self.setToolTip(f"{self.name.text()}: {v.status}\n(status: {raw_status})")
        self.setAccessibleName(f"{self.name.text()}, {v.status}")
        self._menu.clear()
        for action, label in v.menu:
            a = self._menu.addAction(label)
            a.triggered.connect(lambda _=False, x=action: self.menu_action.emit(x))
        self.more.setVisible(bool(v.menu))
        self.update()

    def set_selected(self, on: bool):
        self.selected = on
        self.update()

    # ---- input ----
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(e)

    def focusInEvent(self, e):
        self._kbd_focus = e.reason() in (Qt.FocusReason.TabFocusReason, Qt.FocusReason.BacktabFocusReason)
        super().focusInEvent(e); self.update()

    def focusOutEvent(self, e):
        self._kbd_focus = False
        super().focusOutEvent(e); self.update()

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key.Key_Space, Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.clicked.emit(); return
        super().keyPressEvent(e)

    # ---- drawing: selection wash + the timeline line through the dots ----
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        dark = is_dark(self)
        if self.selected:
            hl = QColor(self.palette().highlight().color()); hl.setAlpha(46 if dark else 34)
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(hl)
            p.drawRoundedRect(self.rect().adjusted(0, 1, -1, -1), 6, 6)
            bar = QColor(self.palette().highlight().color())
            p.setBrush(bar); p.drawRoundedRect(0, 4, 3, self.height() - 8, 1.5, 1.5)
        if self.hasFocus() and self._kbd_focus:
            pen = QPen(self.palette().highlight().color()); pen.setWidthF(1.2); p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(self.rect().adjusted(1, 1, -2, -2), 6, 6)
        x = self.layout().contentsMargins().left() + DOT_W / 2
        dot_c = self.dot.geometry().center().y()
        line = QColor(tone("idle", dark)); line.setAlpha(110)
        pen = QPen(line); pen.setWidthF(1.4); p.setPen(pen)
        if not self.first:
            p.drawLine(QPointF(x, 0), QPointF(x, dot_c - 8))
        if not self.last:
            p.drawLine(QPointF(x, dot_c + 8), QPointF(x, self.height()))
        self._paint_dot(p, x, dot_c, dark)
        p.end()
        super().paintEvent(e)

    def _paint_dot(self, p, x: float, y: float, dark: bool):
        """Shape AND colour carry the state: filled = done, ring = to do, half = in between, cross = failed."""
        c = QColor(tone(self._tone, dark)); r = 5.5
        pen = QPen(c); pen.setWidthF(1.8); p.setPen(pen)
        bg = self.palette().window().color()
        centre = QPointF(x, y)
        if self._tone == "ok":
            p.setBrush(c); p.drawEllipse(centre, r, r)
            tick = QPen(bg); tick.setWidthF(1.6); p.setPen(tick)
            p.drawLine(QPointF(x - 2.6, y + 0.2), QPointF(x - 0.6, y + 2.2)); p.drawLine(QPointF(x - 0.6, y + 2.2), QPointF(x + 2.8, y - 2))
        elif self._tone == "error":
            p.setBrush(bg); p.drawEllipse(centre, r, r)
            p.drawLine(QPointF(x - 2.4, y - 2.4), QPointF(x + 2.4, y + 2.4)); p.drawLine(QPointF(x - 2.4, y + 2.4), QPointF(x + 2.4, y - 2.4))
        elif self._tone in ("ready", "info", "warn", "run"):
            p.setBrush(bg); p.drawEllipse(centre, r, r)
            p.setBrush(c); p.setPen(Qt.PenStyle.NoPen)
            span = {"ready": 270, "info": 180, "warn": 180, "run": 90}[self._tone]
            p.drawPie(int(x - r), int(y - r), int(2 * r), int(2 * r), 90 * 16, -span * 16)
        else:                                             # idle: hollow ring
            p.setBrush(bg); p.drawEllipse(centre, r, r)
