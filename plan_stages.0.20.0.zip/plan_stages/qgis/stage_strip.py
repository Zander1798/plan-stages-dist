"""The plan at a glance (frontend polish): one rounded segment per stage under the dock header, coloured by state,
with "3 of 8 approved" beside it. Hover a segment for its stage and status; click it to select that stage.
Frontend only: it reads site.json statuses the dock already has."""
from __future__ import annotations

from qgis.PyQt.QtCore import QRectF, Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QPainter, QPainterPath
from qgis.PyQt.QtWidgets import QToolTip, QWidget

from .theme import is_dark, tone
from .words import stage_label, status_label

STATUS_TONE = {"approved": "ok", "checked": "ready", "generated": "info", "stale": "warn", "failed": "error",
               "rejected": "idle", "generating": "run"}


class StageStrip(QWidget):
    picked = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.stages: list[tuple[str, str]] = []           # (stage id, status)
        self.setMinimumHeight(10); self.setMaximumHeight(10)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_stages(self, stages: list[tuple[str, str]]):
        self.stages = list(stages)
        done = sum(1 for _s, st in self.stages if st == "approved")
        self.setAccessibleName(f"{done} of {len(self.stages)} stages approved")
        self.update()

    def _rects(self) -> list[QRectF]:
        n = len(self.stages)
        if not n:
            return []
        gap = 3.0
        w = (self.width() - gap * (n - 1)) / n
        return [QRectF(i * (w + gap), 1, w, self.height() - 2) for i in range(n)]

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        dark = is_dark(self)
        for (sid, st), r in zip(self.stages, self._rects()):
            name = STATUS_TONE.get(st)
            if name is None:                               # not started: a quiet track
                c = QColor(tone("idle", dark)); c.setAlpha(70)
            else:
                c = QColor(tone(name, dark))
            path = QPainterPath(); path.addRoundedRect(r, r.height() / 2, r.height() / 2)
            p.fillPath(path, c)
        p.end()

    def _index_at(self, x: float) -> int | None:
        for i, r in enumerate(self._rects()):
            if r.left() - 2 <= x <= r.right() + 2:
                return i
        return None

    def mouseMoveEvent(self, e):
        i = self._index_at(e.position().x() if hasattr(e, "position") else e.x())
        if i is not None:
            sid, st = self.stages[i]
            QToolTip.showText(e.globalPosition().toPoint() if hasattr(e, "globalPosition") else e.globalPos(),
                              f"{stage_label(sid)}: {status_label(st)}", self)

    def mousePressEvent(self, e):
        i = self._index_at(e.position().x() if hasattr(e, "position") else e.x())
        if i is not None:
            self.picked.emit(self.stages[i][0])
