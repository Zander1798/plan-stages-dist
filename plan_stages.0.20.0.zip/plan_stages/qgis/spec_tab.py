"""Spec tab: client PDFs, Claude's proposed parameter sheet checked against the PDFs by the plugin, operator
confirmation, Save revision. The values planning needs come first, with a readiness line (2026-10-13)."""
from __future__ import annotations
import json, shutil
from pathlib import Path
from qgis.PyQt.QtCore import Qt, pyqtSignal, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QTableWidget,
                                 QTableWidgetItem, QFileDialog, QLabel, QHeaderView, QInputDialog,
                                 QGroupBox, QToolButton, QMenu, QComboBox)
from qgis.core import QgsApplication, QgsTask
from ..core.specsheet import Sheet, SheetEntry, SheetIncomplete, SPEC_KEYS, UNITS, required_keys, spec_sources, copy_sheet, is_operator
from ..core.spec_claude import MEANING, propose_sheet, build_sheet, ProposalRefused, ProposalFailed
from ..core import spec_rules
from ..core.spec_verify import LABELS as CHECK_LABELS, BLOCKING
from ..core import deps, env as envmod, stages, presets
from .ui import WheelSafeCombo, ask_yes_no, info, warn
from .details_dialogs import ask_detail

COLS = ("key", "meaning", "proposed value", "check", "citation", "value", "status", "confirm")
C_KEY, C_MEANING, C_PROPOSED, C_CHECK, C_CITE, C_VALUE, C_STATUS, C_CONFIRM = range(len(COLS))
DCOLS = ("topic", "detail", "stages", "check", "citation", "read")
D_TOPIC, D_DETAIL, D_STAGES, D_CHECK, D_CITE, D_READ = range(len(DCOLS))
NA_WORDS = ("n/a", "na", "not applicable")


def _show(v) -> str:
    if v is None:
        return ""
    return v if isinstance(v, str) else json.dumps(v)


def _stage_names(ids) -> str:
    """A detail's stages by name; an id this plugin does not know is skipped, never a crash (final review
    2026-10-21: a 0.10.0 sheet's p2_drops raised KeyError and the Spec tab did not draw)."""
    known = set(stages.order())
    return ", ".join(stages.get(s).name for s in ids or () if s in known)


def _parse(text: str):
    try:
        v = json.loads(text)
    except ValueError:
        return text
    return v if isinstance(v, (int, float, bool, str)) else text


HEROTEL_NOTE = "HeroTel value used"

# Speed (measured 2026-11-23): core.deps.have_anthropic() imports the whole anthropic package, 6.9 s of a cold
# 7.7 s dock open, and the Spec tab asked on every refresh. The tab only needs to know whether the packages are
# installed: find_spec answers that without importing, once per session (cleared after an install).
_FOUND: dict = {}


def installed(name: str) -> bool:
    if name not in _FOUND:
        import importlib.util
        try:
            _FOUND[name] = importlib.util.find_spec(name) is not None
        except (ImportError, ValueError):
            _FOUND[name] = False
    return _FOUND[name]


def missing_packages() -> list[str]:
    return [n for n in ("anthropic", "pypdf") if not installed(n)]


def _short_doc(name: str) -> str:
    """'Fibertime Design Standard v3.pdf' -> 'Fibertime Design Standard v3' (cut to 22 characters)."""
    stem = name.rsplit(".", 1)[0] if name.lower().endswith(".pdf") else name
    return stem if len(stem) <= 22 else stem[:21] + "\u2026"


def source_state(e, client: str, required: bool) -> tuple[str, str]:
    """Spec 8.2: where a value comes from, in plain words, and its tone. Never looks settled without a source."""
    if e.status == "conflict":
        return "\u26a0 Documents disagree", "warn"
    if e.status == "not_applicable":
        return "Not used on this site", "idle"
    if HEROTEL_NOTE in (e.note or "") and client != "HeroTel":
        return "\u26a0 HeroTel value", "warn"
    if e.status == "operator_stated" or e.document == "operator-stated":   # a saved sheet keeps the mark here
        return "Typed by you", "info"
    if e.status not in ("proposed", "confirmed") or e.value is None:
        return "Not set", "error" if required else "idle"
    if e.check in BLOCKING:
        return "\u26a0 Not found in PDF", "warn"
    if e.document and e.page:
        ok = e.check == "verified"
        return f"p.{e.page}" + (" \u2713" if ok else "") + f" \u00b7 {_short_doc(e.document)}", "ok" if ok else "idle"
    if e.document:
        return _short_doc(e.document), "idle"
    return "No source given", "warn"


def _extras_summary(extras: list) -> str:
    pdf = [x for x in extras if not is_operator(x)]
    parts = [f"{len(pdf)} extra details, {sum(1 for x in pdf if x.get('read'))} read"] if pdf else []
    mine = len(extras) - len(pdf)
    return ", ".join(parts + ([f"{mine} of your own"] if mine else []))


class SpecTab(QWidget):
    changed = pyqtSignal()

    def __init__(self, on_busy=None, parent=None):
        super().__init__(parent)
        self.store = self.config = None
        self.locked, self.external_busy, self.on_busy = False, False, on_busy
        self.pdfs: list[Path] = []
        self.sheet: Sheet | None = None
        self._task = None
        lay = QVBoxLayout(self)
        self.title = QLabel("No site selected"); self.title.setWordWrap(True); lay.addWidget(self.title)
        # 2026-10-16: the client's preset, one per client and build method (core/presets)
        prow = QHBoxLayout()
        prow.addWidget(QLabel("Client rules:"))
        self.preset_combo = WheelSafeCombo()
        self.preset_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.preset_combo.setMinimumContentsLength(14)        # long preset names never widen the dock
        self.preset_combo.addItem("(none)", None)
        for p in presets.list_presets():
            self.preset_combo.addItem(p.label, p.id)
        self.preset_combo.setToolTip("Fill the sheet from a client's preset: every value with its document, page and "
                                     "sentence, for you to tick. Nothing is saved until Save spec.")
        self.preset_combo.activated.connect(self._preset_picked)
        prow.addWidget(self.preset_combo, 1)
        lay.addLayout(prow)
        # spec 9.3.4: a rule that is a HeroTel value on another client's site is named, and kept or changed once
        self.herotel_bar = QWidget(); self.herotel_bar.setObjectName("herotelBar")
        self.herotel_bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        hb = QVBoxLayout(self.herotel_bar); hb.setContentsMargins(8, 6, 8, 6)
        self.preset_note = QLabel(""); self.preset_note.setWordWrap(True)
        hbtn = QHBoxLayout()
        self.herotel_keep = QPushButton("Keep"); self.herotel_keep.clicked.connect(self.acknowledge_herotel)
        self.herotel_change = QPushButton("Change"); self.herotel_change.clicked.connect(self._change_herotel)
        hbtn.addStretch(1); hbtn.addWidget(self.herotel_change); hbtn.addWidget(self.herotel_keep)
        hb.addWidget(self.preset_note); hb.addLayout(hbtn)
        self.herotel_bar.hide()
        lay.addWidget(self.herotel_bar)
        self.pending_preset = None                 # chosen since the last Save revision
        self.files = QListWidget(); self.files.setMaximumHeight(90); lay.addWidget(self.files)
        self.files.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.files.setWordWrap(True)
        bar = QHBoxLayout()
        self.add_btn = QPushButton("Add PDF…"); self.add_btn.clicked.connect(self._add_pdf_dialog)
        self.add_btn.setToolTip("Import a client standards PDF; it is read whole and the sheet is proposed from it")
        self.find_btn = QPushButton("Find in PDFs"); self.find_btn.clicked.connect(self.find_in_pdfs)
        self.find_btn.setToolTip("Find the planning values in the listed PDFs with the client's patterns: no API key, "
                                 "no internet. Anything not found is typed by hand.")
        self.remove_pdf_btn = QPushButton("Remove PDF"); self.remove_pdf_btn.clicked.connect(self.remove_selected_pdf)
        self.propose_btn = QPushButton("Propose"); self.propose_btn.clicked.connect(self.propose)
        self.clear_btn = QPushButton("Clear spec…"); self.clear_btn.clicked.connect(self._clear_spec_dialog)
        self.clear_btn.setToolTip("Remove every saved spec revision and imported PDF so a new spec can be imported or typed")
        self.copy_btn = QPushButton("Copy from…"); self.copy_btn.clicked.connect(self._copy_dialog)
        self.copy_btn.setToolTip("Fill the sheet from another site's saved spec; review it, then Save spec")
        self.save_btn = QPushButton("Save revision"); self.save_btn.clicked.connect(self.save_revision)
        self.install_btn = QPushButton("Install anthropic…"); self.install_btn.clicked.connect(self.install_anthropic)
        self.install_btn.setToolTip("Reading a spec PDF needs the anthropic package (and pypdf to check its quotes) in "
                                    "QGIS's Python; this runs pip to add what is missing. Until then, type the values by hand.")
        # Frontend spec 8.4: two buttons and a menu instead of eight buttons in one row (which set the whole dock's
        # minimum width). The buttons stay as objects; the menu's actions press them, so every flow is unchanged.
        self.save_btn.setText("Save spec"); self.save_btn.setDefault(True)
        from .theme import is_dark, primary_button
        self.save_btn.setStyleSheet(primary_button(is_dark()))
        self.files.setToolTip("The client's standards PDFs for this site. Add PDF… to add one.")
        self.more_spec_btn = QToolButton(); self.more_spec_btn.setText("More")
        self.more_spec_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self._spec_menu = QMenu(self.more_spec_btn); self.more_spec_btn.setMenu(self._spec_menu)
        self._menu_for: dict = {}
        for b, label in ((self.find_btn, "Find the rules in the PDFs"), (self.propose_btn, "Read the PDFs with Claude"),
                         (self.copy_btn, "Copy rules from another site…"), (self.remove_pdf_btn, "Remove the selected PDF"),
                         (None, None), (self.clear_btn, "Clear the spec…"), (self.install_btn, "Install the PDF reader…")):
            if b is None:
                self._spec_menu.addSeparator(); continue
            a = self._spec_menu.addAction(label); a.setToolTip(b.toolTip())
            a.triggered.connect(lambda _=False, btn=b: btn.click())
            self._menu_for[b] = a
            b.hide()
        bar.addWidget(self.add_btn); bar.addWidget(self.more_spec_btn); bar.addStretch(1); bar.addWidget(self.save_btn)
        self._spec_menu.setToolTipsVisible(True)
        lay.addLayout(bar)
        from .ui import BusyLine
        self.busy_line = BusyLine(); lay.addWidget(self.busy_line)   # spec 4: every wait says what it is doing
        self._sel = None                          # the selected row: ("key", key) or ("extra", index)
        # block 1: the values the planning stages read
        self.saved_line = QLabel(""); self.saved_line.setWordWrap(True); self.saved_line.hide()
        lay.addWidget(self.saved_line)
        self.ready_label = QLabel(""); self.ready_label.setWordWrap(True); lay.addWidget(self.ready_label)
        # spec 8.2: density is one of two words, so two buttons; they set the density cell and tick it
        drow = QHBoxLayout(); drow.setSpacing(4)
        self.density_label = QLabel("Density")
        drow.addWidget(self.density_label); drow.addStretch(1)
        self.density_btns = {}
        for word in ("high", "low"):
            b = QPushButton(word.capitalize()); b.setCheckable(True); b.setAutoExclusive(True)
            b.setToolTip(f"{word.capitalize()} density: the split ratios follow that section of the client's rules")
            b.clicked.connect(lambda _=False, w=word: self.set_density(w))
            from .theme import ACCENT, is_dark as _dk
            a = ACCENT[1 if _dk() else 0]
            b.setStyleSheet(f"QPushButton {{ padding: 2px 14px; border: 1px solid palette(mid); border-radius: 5px; }}"
                            f"QPushButton:checked {{ background: {a}; border-color: {a}; color: #ffffff; font-weight: 600; }}")
            drow.addWidget(b); self.density_btns[word] = b
        lay.addLayout(drow)
        self.table = self._value_table()
        lay.addWidget(self.table, 3)
        # block 2 (operator 2026-10-13): everything else the submitted PDFs say, kept apart; never blocks saving
        self.extras_box = QGroupBox("Extra details")         # a long title set the whole dock's minimum width
        self.extras_box.setToolTip("Not used by the plan: what the documents say besides the planning values, and your own notes")
        xl = QVBoxLayout(self.extras_box)
        self.extras_label = QLabel(""); self.extras_label.setWordWrap(True); xl.addWidget(self.extras_label)
        xl.addWidget(QLabel("Other values"))
        self.other_table = self._value_table()
        xl.addWidget(self.other_table, 1)
        xl.addWidget(QLabel("Other details"))
        self.details_table = QTableWidget(0, len(DCOLS))
        self.details_table.setHorizontalHeaderLabels(["Topic", "Detail", "Stages", "Check", "Source", "Read"])
        self.details_table.verticalHeader().setVisible(False); self.details_table.setShowGrid(False)
        self.details_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        for c in (D_CHECK, D_CITE):                     # in the tooltip of each row; the card stays narrow
            self.details_table.setColumnHidden(c, True)
        self.details_table.horizontalHeader().setSectionResizeMode(D_DETAIL, QHeaderView.ResizeMode.Stretch)
        self.details_table.setToolTip("Tick read once you have looked at a detail. Unread details never block saving.")
        self.details_table.itemChanged.connect(lambda _it: self._update_extras_label())
        self.details_table.currentCellChanged.connect(lambda r, _c, _pr, _pc: self._extra_selected(r))
        xl.addWidget(self.details_table, 1)
        dbar = QHBoxLayout()
        self.add_detail_btn = QPushButton("Add a detail…"); self.add_detail_btn.clicked.connect(self._add_detail_dialog)
        self.add_detail_btn.setToolTip("Your own detail for this site, tagged to the stages it affects: each one is "
                                       "ticked as checked against the plan before that stage can be approved")
        self.edit_detail_btn = QPushButton("Edit…"); self.edit_detail_btn.clicked.connect(self._edit_detail_dialog)
        self.remove_detail_btn = QPushButton("Remove"); self.remove_detail_btn.clicked.connect(self._remove_detail_dialog)
        for b in (self.add_detail_btn, self.edit_detail_btn, self.remove_detail_btn):
            dbar.addWidget(b)
        dbar.addStretch(1)
        xl.addLayout(dbar)
        lay.addWidget(self.extras_box, 2)
        # the selected row's source: its quote, every statement the documents make about it, and its page
        self.source_label = QLabel("Select a row to see where its value comes from.")
        self.source_label.setWordWrap(True); self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.source_label)
        src = QHBoxLayout()
        self.cand_combo = WheelSafeCombo(); self.cand_combo.setMinimumWidth(100)
        self.cand_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.cand_combo.setMinimumContentsLength(10)
        self.use_btn = QPushButton("Use this statement"); self.use_btn.clicked.connect(lambda: self.use_statement(self.cand_combo.currentIndex()))
        self.use_btn.setToolTip("Take this statement's value for the row (the documents state more than one)")
        self.open_page_btn = QPushButton("Open page"); self.open_page_btn.clicked.connect(self.open_page)
        self.open_page_btn.setToolTip("Show the PDF page the value was quoted from, with the sentence highlighted")
        src.addWidget(self.cand_combo, 1); src.addWidget(self.use_btn); src.addWidget(self.open_page_btn)
        lay.addLayout(src)

    # ---------------- state ----------------
    def set_site(self, store, config, locked: bool):
        self.store, self.config, self.locked = store, config, locked
        self.pdfs, self.sheet = [], None
        self.pending_preset = None
        if store is not None:
            st = store.load()
            self.title.setText(self._head_text(st))
            if st.get("spec_rev"):
                rd = store.site_dir / "spec" / st["spec_rev"]
                self.pdfs = sorted((rd / "docs").glob("*.pdf"))
                if (rd / "sheet.json").exists():
                    self.sheet = Sheet.load(rd / "sheet.json")
            if self.sheet is None and st.get("spec_preset"):
                try:
                    self.sheet = presets.preset_sheet(st["spec_preset"])     # New site: unsaved until Save revision
                except KeyError:
                    self.sheet = None
            if self.sheet is None:
                self.sheet = Sheet.blank(st["client"])
        else:
            self.title.setText("No site selected")
        self._fill()
        self._show_preset(self._current_preset())
        self.refresh()

    # ---------------- client spec presets (2026-10-16) ----------------
    def _preset_picked(self, index: int):
        pid = self.preset_combo.itemData(index)
        if pid is None or self.store is None:
            self._show_preset(self._current_preset())
            return
        if not self.choose_preset(pid):
            self._show_preset(self._current_preset())         # put the combo back

    def _current_preset(self):
        if self.pending_preset is not None:
            return self.pending_preset or None           # "": the sheet was replaced by something other than a preset
        return self.store.load().get("spec_preset") if self.store is not None else None

    def _show_preset(self, pid):
        i = self.preset_combo.findData(pid)
        self.preset_combo.blockSignals(True); self.preset_combo.setCurrentIndex(max(i, 0)); self.preset_combo.blockSignals(False)
        self._update_herotel()

    def _head_text(self, st: dict) -> str:
        """'Fibertime · Formal rules · spec 2 · saved 18 Nov' (spec 8.1)."""
        import datetime as _dt
        label = st.get("client") or "No client"
        try:
            if st.get("spec_preset"):
                label = presets.get(st["spec_preset"]).label.split(" (")[0]
        except Exception:                                 # noqa: BLE001
            pass
        rev = st.get("spec_rev")
        if not rev:
            return f"{label} rules \u00b7 not saved yet"
        when = ""
        try:
            t = _dt.datetime.fromtimestamp((self.store.site_dir / "spec" / rev).stat().st_mtime)
            when = f" \u00b7 saved {t:%H:%M}" if t.date() == _dt.date.today() else f" \u00b7 saved {t.day} {t:%b}"
        except OSError:
            pass
        return f"{label} rules \u00b7 spec {int(rev[4:])}{when}"

    # ---------------- density buttons (spec 8.2) ----------------
    def set_density(self, word: str):
        r = self.row_of("density")
        if r < 0 or self.table.item(r, C_VALUE) is None:
            return
        self.table.item(r, C_VALUE).setText(word)          # itemChanged runs _value_changed as typing did
        self.table.item(r, C_CONFIRM).setCheckState(Qt.CheckState.Checked)
        self._update_ready()

    def _sync_density_buttons(self):
        r = self.row_of("density") if self.sheet is not None and self.table.rowCount() else -1
        text = self.table.item(r, C_VALUE).text().strip().lower() if r >= 0 and self.table.item(r, C_VALUE) else ""
        for word, b in self.density_btns.items():
            b.blockSignals(True); b.setChecked(text == word); b.blockSignals(False)
        for w in (self.density_label, *self.density_btns.values()):
            w.setVisible(r >= 0)

    # ---------------- HeroTel values on another client's site (spec 9.3.4) ----------------
    def herotel_keys(self) -> list[str]:
        """Planning rules whose value is HeroTel's because this client's documents give none."""
        if self.sheet is None or self.sheet.client == "HeroTel":
            return []
        return [k for k in self.planning_keys()
                if HEROTEL_NOTE in (self.sheet.entries.get(k, SheetEntry(k)).note or "")
                and self.sheet.entries[k].value is not None]

    def _ack_key(self, k: str) -> str:
        site = self.store.site if self.store is not None else "-"
        return f"plan_stages/ui/herotel_ack/{site}/{k}"

    def herotel_unacked(self) -> list[str]:
        """The HeroTel values not yet kept (or kept with a different value): Generate waits on the stages reading them."""
        from qgis.core import QgsSettings
        s = QgsSettings()
        return [k for k in self.herotel_keys()
                if s.value(self._ack_key(k), "", type=str) != _show(self.sheet.entries[k].value)]

    def acknowledge_herotel(self):
        from qgis.core import QgsSettings
        s = QgsSettings()
        for k in self.herotel_keys():
            s.setValue(self._ack_key(k), _show(self.sheet.entries[k].value))
        self._update_herotel()
        self.changed.emit()

    def _change_herotel(self):
        keys = self.herotel_unacked() or self.herotel_keys()
        if keys:
            self.select_key(keys[0])
            self.table.editItem(self.table.item(self.row_of(keys[0]), C_VALUE))

    def _update_herotel(self):
        from .words import rule_name
        from .theme import is_dark, tone
        keys = self.herotel_keys() if self.store is not None else []
        todo = self.herotel_unacked() if keys else []
        if not todo:
            self.preset_note.setText(""); self.herotel_bar.hide(); return
        e = self.sheet.entries
        what = "; ".join(f"{rule_name(k)}, {_show(e[k].value)}{(' ' + e[k].unit) if e[k].unit else ''}" for k in todo)
        n = len(todo)
        self.preset_note.setText(f"{n} rule{'s are' if n != 1 else ' is'} a HeroTel value because "
                                 f"{self.sheet.client} gives none: {what}. Keep {'them' if n != 1 else 'it'}, "
                                 f"or change {'them' if n != 1 else 'it'} to the client's value.")
        c = tone("warn", is_dark(self))
        self.herotel_bar.setStyleSheet(f"#herotelBar {{ border: 1px solid {c}; border-radius: 6px; }}")
        self.preset_note.setStyleSheet(f"color: {c};")
        self.herotel_keep.setText("Keep " + ("these" if n != 1 else f"{_show(e[todo[0]].value)}"
                                             f"{(' ' + e[todo[0]].unit) if e[todo[0]].unit else ''}"))
        self.herotel_bar.show()

    def _dirty(self) -> bool:
        """The table differs from the last saved revision (or, with none saved, holds anything resolved or any PDF
        extra ticked as read)."""
        now = self._sheet_from_table()
        st = self.store.load()
        saved = self.store.site_dir / "spec" / str(st.get("spec_rev")) / "sheet.json"
        reads = [t for x, t in zip(self.sheet.extras, self._read_ticks()) if not is_operator(x)] if self.sheet else []
        if st.get("spec_rev") and saved.exists():
            old = Sheet.load(saved)
            return any((e.status, e.value) != (old.entries.get(k, SheetEntry(k)).status, old.entries.get(k, SheetEntry(k)).value)
                       for k, e in now.entries.items()) or                 reads != [bool(x.get("read")) for x in old.extras if not is_operator(x)]
        return any(e.status in ("confirmed", "operator_stated") for e in now.entries.values()) or any(reads)

    def _not_from_preset(self):
        """The sheet was just replaced by Copy from, Find in PDFs or a proposal: Save revision records no preset."""
        self.pending_preset = ""
        self._show_preset(None)

    def choose_preset(self, preset_id: str, ask: bool = True) -> bool:
        """Replace the sheet with the preset's (the operator's own details stay). Not saved. Asked first when the
        table has unsaved changes or the site has a saved revision (2026-10-19 review)."""
        p = presets.get(preset_id)
        if ask and (self._dirty() or self.store.load().get("spec_rev")) and not ask_yes_no(
                self, "Replace the sheet?", f"Replace the sheet with {p.label}? Your own details are kept. "
                                            f"The saved spec stays until you press Save spec."):
            return False
        self._sync_read_ticks()
        self.sheet = presets.preset_sheet(preset_id).with_operator_extras(self.sheet)
        self.pending_preset = preset_id
        self._fill()
        self._show_preset(preset_id)
        self.refresh()
        return True

    def refresh(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        self.preset_combo.setEnabled(usable)
        self.add_btn.setEnabled(usable)
        self.remove_pdf_btn.setEnabled(usable and bool(self.pdfs))
        self.find_btn.setEnabled(usable and bool(self.pdfs))
        self.clear_btn.setEnabled(usable)
        self.copy_btn.setEnabled(usable)
        self.save_btn.setEnabled(usable)
        has_key = bool(self.config and self.config.effective_api_key())
        has_pkg = installed("anthropic")
        missing = missing_packages()
        self.install_btn.setEnabled(usable)
        self._menu_for[self.install_btn].setVisible(bool(missing))
        if missing:
            self.install_btn.setText(f"Install {' and '.join(missing)}…")
        self.propose_btn.setEnabled(usable and has_key and has_pkg and bool(self.pdfs))
        self.propose_btn.setToolTip("Read the PDFs again and propose the sheet" if has_key and has_pkg else
                                    "Install the anthropic package (button to the right), then set the API key in Settings"
                                    if not has_pkg else
                                    "Set the Claude API key in Settings (or the ANTHROPIC_API_KEY environment variable)")
        for t in (self.table, self.other_table, self.details_table):
            t.setEnabled(self.store is not None and not self.locked)
        for b, a in self._menu_for.items():               # the menu mirrors the hidden buttons' state
            a.setEnabled(b.isEnabled()); a.setToolTip(b.toolTip())
        self.more_spec_btn.setEnabled(any(a.isEnabled() and a.isVisible() for a in self._menu_for.values()))
        self._update_detail_buttons()

    def _update_detail_buttons(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        mine = self._selected_operator() is not None
        self.add_detail_btn.setEnabled(usable and self.sheet is not None)
        self.edit_detail_btn.setEnabled(usable and mine); self.remove_detail_btn.setEnabled(usable and mine)

    def _selected_operator(self) -> dict | None:
        if not (self._sel and self._sel[0] == "extra" and self.sheet and self._sel[1] < len(self.sheet.extras)):
            return None
        x = self.sheet.extras[self._sel[1]]
        return x if is_operator(x) else None

    def _value_table(self) -> QTableWidget:
        t = QTableWidget(0, len(COLS))
        # frontend polish: plain headings; the rule's meaning lives in the Rule cell's tooltip; no row numbers
        t.setHorizontalHeaderLabels(["Rule", "Meaning", "Found", "Check", "Source", "Value", "Status", "OK"])
        for c in (C_MEANING, C_PROPOSED, C_CHECK, C_STATUS):     # kept as the model (tests read them), not shown
            t.setColumnHidden(c, True)
        t.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        t.setTextElideMode(Qt.TextElideMode.ElideRight)
        t.setWordWrap(False)
        t.verticalHeader().setVisible(False)
        t.setShowGrid(False)
        h = t.horizontalHeader()
        h.setSectionResizeMode(C_KEY, QHeaderView.ResizeMode.Stretch)       # the rule name gets the room
        for c, w in ((C_PROPOSED, 64), (C_CHECK, 64), (C_CITE, 104), (C_VALUE, 58), (C_STATUS, 70), (C_CONFIRM, 30)):
            h.setSectionResizeMode(c, QHeaderView.ResizeMode.Interactive); t.setColumnWidth(c, w)
        h.setMinimumSectionSize(30)
        t.verticalHeader().setDefaultSectionSize(24)
        t.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        t.setToolTip("Click a value to type your own; type n/a when a rule does not apply; tick OK to accept it.")
        t.itemChanged.connect(self._value_changed)
        t.currentCellChanged.connect(lambda r, _c, _pr, _pc, t=t: self._value_selected(t, r))
        return t

    @staticmethod
    def planning_keys() -> list[str]:
        req = set(required_keys())
        return [k for k in SPEC_KEYS if k in req]

    @staticmethod
    def other_keys() -> list[str]:
        req = set(required_keys())
        return [k for k in SPEC_KEYS if k not in req]

    def _value_tables(self):
        return (self.table, self.other_table)

    def _fill(self):
        self._fill_files_only()
        tables = (self.table, self.other_table, self.details_table)
        for t in tables:
            t.blockSignals(True); t.setRowCount(0)
        if self.sheet is not None:
            for t, keys in ((self.table, self.planning_keys()), (self.other_table, self.other_keys())):
                t.setRowCount(len(keys))
                for r, k in enumerate(keys):
                    self._fill_row(t, r, k)
            self.details_table.setRowCount(len(self.sheet.extras))
            for r, x in enumerate(self.sheet.extras):
                self._fill_extra(r, x)
        for t in tables:
            t.blockSignals(False)
        # every planning value and other value visible without scrolling the table; the dock itself scrolls
        for t, rows in ((self.table, self.table.rowCount()), (self.other_table, self.other_table.rowCount()),
                        (self.details_table, min(max(self.details_table.rowCount(), 2), 10))):
            t.setMinimumHeight(t.horizontalHeader().height() + 4 + rows * t.verticalHeader().defaultSectionSize())
        self._update_ready()
        self._update_extras_label()
        self._show_source()

    def _fill_row(self, table: QTableWidget, r: int, k: str):
        e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
        cite = f"{e.document} p.{e.page}: {e.quoted_text}" if e.document and e.page else (e.document or e.note)
        if e.status == "conflict":
            proposed, check = f"{len(e.candidates)} statements", "⚠ documents disagree: pick one below"
        else:
            proposed = (_show(e.value) + (f" {e.unit}" if e.unit and e.value is not None else "")) \
                if e.status in ("proposed", "confirmed") else ""
            check = CHECK_LABELS.get(e.check, "") + (f" p.{e.page}" if e.check == "verified" and e.page else "")
        from .words import rule_name
        from .theme import is_dark, tone
        from qgis.PyQt.QtGui import QColor
        client = self.sheet.client if self.sheet is not None else ""
        src, src_tone = source_state(e, client, k in set(required_keys()))
        name = rule_name(k) + (f" ({e.unit or UNITS.get(k, '')})" if (e.unit or UNITS.get(k, "")) else "")
        cells = {C_KEY: name, C_MEANING: MEANING.get(k, ""), C_PROPOSED: proposed, C_CHECK: check, C_CITE: src,
                 C_VALUE: "n/a" if e.status == "not_applicable" else _show(e.value), C_STATUS: e.status}
        for c, text in cells.items():
            it = QTableWidgetItem(text)
            if c != C_VALUE:
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if c == C_KEY:
                it.setData(Qt.ItemDataRole.UserRole, k)
                it.setToolTip(f"{MEANING.get(k, '')}\n({k})")
            if c == C_CHECK:
                it.setToolTip(e.check_note or text)
            if c == C_CITE:
                it.setToolTip("\n".join(x for x in (cite, check, e.check_note) if x) or text)
                it.setForeground(QColor(tone(src_tone, is_dark(self))))
            table.setItem(r, c, it)
        chk = QTableWidgetItem()
        chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if e.status in ("confirmed", "not_applicable")
                          else Qt.CheckState.Unchecked)
        table.setItem(r, C_CONFIRM, chk)

    def _fill_extra(self, r: int, x: dict):
        mine = is_operator(x)
        check = "operator" if mine else \
            CHECK_LABELS.get(x.get("check", ""), "") + (f" p.{x['page']}" if x.get("check") == "verified" and x.get("page") else "")
        cite = "" if mine else f"{x.get('document', '')} p.{x.get('page')}: {x.get('quoted_text', '')}"
        names = _stage_names(x.get("stages")) if mine else ""
        for c, text in {D_TOPIC: x.get("topic", ""), D_DETAIL: x.get("detail", ""), D_STAGES: names, D_CHECK: check,
                        D_CITE: cite}.items():
            it = QTableWidgetItem(text)
            it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            it.setToolTip(x.get("check_note", "") if c == D_CHECK else text)
            self.details_table.setItem(r, c, it)
        chk = QTableWidgetItem()
        # your own details are ticked at Approve on their stages, not here
        chk.setFlags(Qt.ItemFlag.ItemIsEnabled if mine else Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if mine or x.get("read") else Qt.CheckState.Unchecked)
        self.details_table.setItem(r, D_READ, chk)

    def _table_of(self, key: str) -> QTableWidget:
        return self.table if key in set(required_keys()) else self.other_table

    def row_of(self, key: str) -> int:
        t = self._table_of(key)
        for r in range(t.rowCount()):
            if t.item(r, C_KEY).data(Qt.ItemDataRole.UserRole) == key:
                return r
        return -1

    def _value_changed(self, item):
        """A value cell changed. Density typed on the sheet keeps only that density section's statements on the
        split rows (and the caps worked out from them); any other density text, or none, shows them all again."""
        if item.column() == C_VALUE and self._key_at(item.tableWidget(), item.row()) == "density" and self.sheet:
            text = item.text().strip().lower()
            self.sheet.apply_density(text if text in ("high", "low") else None)
            req = set(required_keys())
            for k, e in self.sheet.entries.items():
                if any(c.get("regime") for c in e.candidates):
                    t = self._table_of(k)
                    t.blockSignals(True); self._fill_row(t, self.row_of(k), k); t.blockSignals(False)
            self._show_source()
        self._update_ready()

    def _update_ready(self):
        """'Ready to plan: N of 11': the values the planning stages read that the table settles right now."""
        if self.sheet is None or self.table.rowCount() == 0:
            self.ready_label.setText(""); return
        from .words import rule_name
        from .theme import is_dark, tone
        req = required_keys()
        missing = self._sheet_from_table().unresolved(req)
        done = len(req) - len(missing)
        self.ready_label.setText(f"\u2713 {done} of {len(req)} plan rules set" if not missing else
                                 f"{done} of {len(req)} plan rules set \u2014 still needed: "
                                 + ", ".join(rule_name(k) for k in missing))
        self.ready_label.setStyleSheet(f"color: {tone('ok' if not missing else 'warn', is_dark(self))};"
                                       + ("" if missing else " font-weight: 600;"))
        self._sync_density_buttons()
        self._update_herotel()
        self.ready_label.setToolTip("Still to settle (tick, type a value, or n/a): " + ", ".join(missing)
                                    if missing else "Every value the planning stages read is settled.")

    def _read_ticks(self) -> list[bool]:
        t = self.details_table
        return [t.item(r, D_READ) is not None and t.item(r, D_READ).checkState() == Qt.CheckState.Checked
                for r in range(t.rowCount())]

    def _update_extras_label(self):
        rows = list(zip(self.sheet.extras, self._read_ticks())) if self.sheet is not None else []
        pdf = [t for x, t in rows if not is_operator(x)]
        mine = len(rows) - len(pdf)
        text = (f"Extra details: {sum(pdf)} of {len(pdf)} read. Tick each one you have looked at; unread details "
                f"never block Save spec." if pdf else
                "No extra details from the documents yet. Add the client's PDFs to fill this block: they come only "
                "from the PDFs submitted for this site.")
        if mine:
            text += f" Your own details: {mine}; each is ticked at Approve on the stages it affects."
        self.extras_label.setText(text)

    # ---------------- source of the selected row (2026-10-13) ----------------
    def _key_at(self, table: QTableWidget, row: int) -> str | None:
        it = table.item(row, C_KEY) if 0 <= row < table.rowCount() else None
        return it.data(Qt.ItemDataRole.UserRole) if it is not None else None

    def _value_selected(self, table: QTableWidget, row: int):
        k = self._key_at(table, row)
        self._sel = ("key", k) if k else None
        self._show_source()

    def _extra_selected(self, row: int):
        self._sel = ("extra", row) if self.sheet and 0 <= row < len(self.sheet.extras) else None
        self._show_source()

    def _show_source(self):
        """The selected row's quote, page and check; for documents that disagree, every statement to pick from."""
        self.cand_combo.clear()
        kind, ref = self._sel if self._sel else (None, None)
        e = self.sheet.entries.get(ref) if (kind == "key" and self.sheet) else None
        x = self.sheet.extras[ref] if (kind == "extra" and self.sheet and ref < len(self.sheet.extras)) else None
        doc = page = None
        if e is not None:
            where = f"{e.document}, page {e.page}" if e.document and e.page else (e.document or "no document")
            quote = f"“{e.quoted_text}”" if e.quoted_text else (e.note or "")
            check = f" ({e.check_note})" if e.check_note else ""
            from .words import rule_name
            self.source_label.setText(f"{rule_name(ref)}: {quote} — {where}{check}" if e.status != "conflict" else
                                      f"{rule_name(ref)}: the documents state {len(e.candidates)} values. Pick the one that "
                                      f"applies to this site and press Use this statement, or type your own value.")
            for c in e.candidates:
                self.cand_combo.addItem(f"{_show(c['value'])} {c.get('unit', '')} — {c.get('document', '')} "
                                        f"p.{c.get('page')}: {c.get('quoted_text', '')[:70]} "
                                        f"[{CHECK_LABELS.get(c.get('check', ''), '')}]")
            doc, page = e.document, e.page
        elif x is not None and is_operator(x):
            names = _stage_names(x.get("stages"))
            self.source_label.setText(f"{x.get('topic', '')}: {x.get('detail', '')}\nYour own detail ({x['id']}); "
                                      f"ticked at Approve on: {names}")
        elif x is not None:
            note = f" ({x['check_note']})" if x.get("check_note") else ""
            self.source_label.setText(f"{x.get('topic', '')}: {x.get('detail', '')}\n“{x.get('quoted_text', '')}” — "
                                      f"{x.get('document', '')}, page {x.get('page')}{note}")
            doc, page = x.get("document"), x.get("page")
        else:
            self.source_label.setText("Select a row to see where its value comes from.")
        many = e is not None and len(e.candidates) > 1
        self.cand_combo.setVisible(many); self.use_btn.setVisible(many)
        self.open_page_btn.setEnabled(bool(doc and page) and self._pdf_named(doc) is not None)
        self._update_detail_buttons()

    def select_key(self, key: str):
        t = self._table_of(key)
        t.setCurrentCell(self.row_of(key), C_KEY)
        self._value_selected(t, self.row_of(key))

    def select_extra(self, index: int):
        self.details_table.setCurrentCell(index, D_TOPIC)
        self._extra_selected(index)

    def use_statement(self, index: int):
        """Take statement `index` of the selected row (documents that disagree). The operator still ticks it."""
        k = self._sel[1] if self._sel and self._sel[0] == "key" else None
        if not k or index < 0 or index >= len(self.sheet.entries[k].candidates):
            return
        self.sheet.pick(k, index)
        t = self._table_of(k)
        t.blockSignals(True)
        self._fill_row(t, self.row_of(k), k)
        t.blockSignals(False)
        self._show_source()
        self._update_ready()

    # ---------------- your own details (2026-10-14) ----------------
    def _sync_read_ticks(self):
        """The table's read ticks back into the sheet, so rebuilding the table never loses them."""
        if self.sheet is not None and self.details_table.rowCount() == len(self.sheet.extras):
            self.sheet.extras = [{**x, "read": t} for x, t in zip(self.sheet.extras, self._read_ticks())]

    def _show_extra(self, x: dict):
        self._fill(); self.select_extra(self.sheet.extras.index(x))

    def add_detail(self, stage_ids, topic: str, text: str) -> dict:
        self._sync_read_ticks()
        x = self.sheet.add_detail(stage_ids, topic, text)
        self._show_extra(x)
        return x

    def edit_detail(self, detail_id: str, stage_ids, topic: str, text: str) -> dict:
        self._sync_read_ticks()
        x = self.sheet.edit_detail(detail_id, stage_ids, topic, text)
        self._show_extra(x)
        return x

    def remove_detail(self, detail_id: str) -> None:
        self._sync_read_ticks()
        self.sheet.remove_detail(detail_id)
        self._sel = None
        self._fill()

    def _add_detail_dialog(self):
        got = ask_detail(self) if self.sheet is not None else None
        if got:
            try:
                self.add_detail(*got)
            except ValueError as e:
                warn(self, "Add a detail", str(e))

    def _edit_detail_dialog(self):
        x = self._selected_operator()
        got = ask_detail(self, x) if x is not None else None
        if got:
            try:
                self.edit_detail(x["id"], *got)
            except ValueError as e:
                warn(self, "Edit detail", str(e))

    def _remove_detail_dialog(self):
        x = self._selected_operator()
        if x is not None and ask_yes_no(self, "Remove detail?", f"Remove your detail “{x['detail']}”? It is gone "
                                        f"from the spec once you press Save spec."):
            self.remove_detail(x["id"])

    def _pdf_named(self, name: str) -> Path | None:
        return next((p for p in self.pdfs if p.name == name and p.exists()), None)

    def _dialog(self, doc: str, page, quote: str):
        from .pdf_page import HAVE_QTPDF, PdfPageDialog
        pdf = self._pdf_named(doc) if doc else None
        if pdf is None or not page or not HAVE_QTPDF:
            return None
        return PdfPageDialog(pdf, int(page), quote, self)

    def page_dialog(self, key: str):
        """The page the key's value was quoted from, in a dialog (not shown); None without Qt's PDF module."""
        e = self.sheet.entries.get(key) if self.sheet else None
        return self._dialog(e.document, e.page, e.quoted_text) if e is not None else None

    def extra_page_dialog(self, index: int):
        x = self.sheet.extras[index]
        return self._dialog(x.get("document", ""), x.get("page"), x.get("quoted_text", ""))

    def open_page(self):
        if not self._sel:
            return
        kind, ref = self._sel
        dlg = self.page_dialog(ref) if kind == "key" else self.extra_page_dialog(ref)
        if dlg is not None:
            dlg.exec(); dlg.deleteLater()
            return
        doc = self.sheet.entries[ref].document if kind == "key" else self.sheet.extras[ref].get("document", "")
        pdf = self._pdf_named(doc)
        if pdf is not None:                     # no Qt PDF module: the system viewer, at page 1
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(pdf)))

    @property
    def proposing(self) -> bool:
        return self._task is not None

    def _busy_changed(self):
        self.refresh()
        if self.on_busy is not None:
            self.on_busy()

    # ---------------- PDFs + proposal ----------------
    def _add_pdf_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Client standards", "", "PDF (*.pdf)")
        self.add_pdfs([Path(p) for p in paths])

    def add_pdfs(self, paths: list[Path]):
        """Import PDFs. Operator ruling 2026-10-07: an imported PDF is read whole at once and the sheet proposed
        from it, so its values are on the table (with page citations) ready to confirm; no key, no proposal."""
        added = False
        for p in paths:
            if p not in self.pdfs:
                self.pdfs.append(p); added = True
        self._fill_files_only()
        self.refresh()
        if added and self.pdfs:
            if self._current_preset() not in (None, "herotel"):
                # 2026-10-16: a preset sheet is checked against the client's PDFs, never replaced
                self._sync_read_ticks()
                self.busy_line.start("Checking the rules against your PDFs\u2026")
                try:
                    self.sheet = presets.verify(self.sheet, list(self.pdfs))
                finally:
                    self.busy_line.stop()
                self._fill(); self.refresh()
                n = sum(1 for e in self.sheet.entries.values() if e.check == "verified")
                cited = presets.cited_documents(self.sheet)
                hint = ("" if n or any(p.name in cited for p in self.pdfs) else
                        "\n\nNone of your PDFs has the name of a document this preset quotes, so nothing could be "
                        "checked. The preset quotes:\n" + "\n".join(cited) +
                        "\nAdd the client's PDF under its own file name.")
                info(self, "Preset checked", f"Checked the preset's quotes against {len(self.pdfs)} PDF(s): "
                                             f"{n} values verified. No value was changed.{hint}")
            elif self.config and self.config.effective_api_key() and installed("anthropic"):
                self.propose()
            else:                                # no key (operator 2026-10-13): the client's patterns, offline
                self.find_in_pdfs()

    def find_in_pdfs(self):
        """Fill the sheet from the listed PDFs with the client's patterns (core/spec_rules): no Claude, no key.
        A density already typed on the sheet is kept and applied. Nothing is saved until Save spec."""
        if self.store is None or not self.pdfs or self._task is not None:
            return
        client = self.sheet.client if self.sheet is not None else self.store.load()["client"]
        if not spec_rules.taught(client):
            info(self, "Find in PDFs", f"Find in PDFs is not taught {client}'s wording yet, so the sheet is left as it "
                                       f"is. Use the Client spec dropdown, or type the values.")
            return
        density = ""
        r = self.row_of("density")
        if r >= 0 and self.table.item(r, C_VALUE) is not None:
            density = self.table.item(r, C_VALUE).text().strip().lower()
        self.busy_line.start(f"Finding the rules in {len(self.pdfs)} PDF{'s' if len(self.pdfs) != 1 else ''}\u2026")
        try:
            found = spec_rules.find(list(self.pdfs), client)
        finally:
            self.busy_line.stop()
        self._sync_read_ticks()
        sheet = build_sheet(client, list(self.pdfs), found.statements, found.extras).with_operator_extras(self.sheet).with_hard_pon_rule(self.sheet)
        if density in ("high", "low"):
            sheet.set_operator("density", density, "entered in the Plan Stages dock")
            sheet.apply_density(density)
        self.sheet = sheet
        self._fill()
        self._not_from_preset()
        req = required_keys()
        got = [k for k in req if sheet.entries[k].status in ("proposed", "conflict") or k == "density" and density]
        missing = [k for k in req if k not in got]
        info(self, "Found in the PDFs",
             f"Found {len(got)} of {len(req)} planning values and {sum(1 for x in sheet.extras if not is_operator(x))} extra details in "
             f"{len(self.pdfs)} PDF(s), with no API key.\n\n"
             + ("" if density in ("high", "low") else "Type the site's density (high or low) in the density row: "
                "the split ratios then follow that section of the spec.\n")
             + (f"Not stated in the documents, type them: {', '.join(k for k in missing if k != 'density')}.\n"
                if [k for k in missing if k != "density"] else "")
             + "Check every row, tick what is right, then Save spec."
             + (f"\n\n{found.note}" if found.note else ""))
        self.refresh()

    def remove_selected_pdf(self):
        row = self.files.currentRow()
        if row < 0 or row >= len(self.pdfs):
            return
        del self.pdfs[row]
        self._fill_files_only(); self.refresh()

    def _clear_spec_dialog(self):
        if self.store is None or self.locked:
            return
        st = self.store.load()
        if not ask_yes_no(self, "Clear spec?", f"Remove every saved spec revision of site {st['site']} (sheets and "
                          f"imported PDFs) and empty the sheet, so a new spec can be imported or typed? Every "
                          f"started stage goes stale until a new revision is saved. This cannot be undone."):
            return
        self.clear_spec()

    def clear_spec(self):
        from ..core import approval
        approval.clear_spec(self.store)
        self.pdfs, self.sheet = [], Sheet.blank(self.store.load()["client"])
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()

    def _fill_files_only(self):
        """File names, full path in the tooltip; an empty list says what it is for (spec 8.4)."""
        from qgis.PyQt.QtWidgets import QListWidgetItem
        self.files.clear()
        for p in self.pdfs:
            it = QListWidgetItem(p.name); it.setToolTip(str(p)); self.files.addItem(it)
        if not self.pdfs:
            it = QListWidgetItem("No PDFs yet. Add the client's design standard to check each rule against it.")
            it.setFlags(Qt.ItemFlag.NoItemFlags); self.files.addItem(it)
        self.files.setMaximumHeight(54 if not self.pdfs else 90)

    def install_anthropic(self):
        """pip install anthropic into QGIS's Python through the plugin's launcher, as a background task."""
        if self._task is not None or self.config is None:
            return
        try:
            launcher = envmod.command_for(self.config, stages.get("p5_crossings"), "adapters/p5_crossings.py")[0]
        except Exception as e:                           # noqa: BLE001 - no QGIS found / bad config
            warn(self, "Install anthropic", f"{type(e).__name__}: {e}")
            return
        cmd = deps.pip_install_cmd(launcher, *(deps.missing_packages() or ["anthropic"]))

        def work(task):
            import subprocess
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode, (r.stdout or "") + (r.stderr or ""))

        def done(exc, result=None):
            self._task = None
            self.busy_line.stop()
            _FOUND.clear()                               # look again: the install may have added a package
            if exc is not None or result is None:
                warn(self, "Install anthropic", f"pip did not run: {exc}")
            elif result[0] != 0:
                warn(self, "Install anthropic", f"pip exited {result[0]}:\n\n{result[1][-1500:]}")
            elif not deps.have_anthropic():
                warn(self, "Install anthropic", "pip reported success, but the package is not importable yet. "
                                                 "Restart QGIS, then try Propose again.")
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: pip install anthropic", work, on_finished=done)
        self.busy_line.start("Installing the PDF reader into QGIS's Python\u2026 this can take a minute.")
        QgsApplication.taskManager().addTask(self._task)
        self.refresh()

    def propose(self):
        if not (self.config and self.config.effective_api_key()) or not self.pdfs or self._task is not None:
            return
        pdfs, client, key = list(self.pdfs), self.store.load()["client"], self.config.effective_api_key()

        def work(task):
            return propose_sheet(pdfs, client, key)

        def done(exception, result=None):
            self._task = None
            self.busy_line.stop()
            self._busy_changed()
            if exception is not None:
                kind = "refused" if isinstance(exception, ProposalRefused) else \
                    "failed" if isinstance(exception, ProposalFailed) else f"error ({type(exception).__name__})"
                warn(self, f"Proposal {kind}", str(exception))
            elif result is not None:
                self._sync_read_ticks(); self.sheet = result.with_operator_extras(self.sheet).with_hard_pon_rule(self.sheet)
                self._fill(); self._not_from_preset()
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: propose spec sheet", work, on_finished=done)
        self.busy_line.start(f"Claude is reading {len(pdfs)} PDF{'s' if len(pdfs) != 1 else ''}\u2026 this can take a "
                             f"minute; you can keep working.")
        self._busy_changed()
        QgsApplication.taskManager().addTask(self._task)

    # ---------------- copy (rollout 2026-10-12) ----------------
    def copy_sources(self) -> list[tuple[str, Path]]:
        return spec_sources(self.store.site_dir.parent, exclude_site=self.store.site) if self.store is not None else []

    def _copy_dialog(self):
        src = self.copy_sources()
        if not src:
            info(self, "Copy spec", "No other site with a saved spec was found.")
            return
        label, ok = QInputDialog.getItem(self, "Copy spec from", "Fill this site's sheet from:", [s[0] for s in src], 0, False)
        if ok and label:
            self.copy_from(label, dict(src)[label])
            info(self, "Spec copied", f"Filled from {label}.\nReview every value (edit or untick any that do not apply "
                                      f"to this site), then press Save spec. Nothing is saved until you do.")

    def copy_from(self, label: str, path: Path) -> None:
        """Replace the unsaved table with a copy of the sheet at `path` (marked with its source); this site's own
        details stay. Not saved."""
        self._sync_read_ticks()
        self.sheet = copy_sheet(Sheet.load(path), self.store.load()["client"], label).with_operator_extras(self.sheet)
        self._fill()
        self._not_from_preset()

    # ---------------- save ----------------
    def _sheet_from_table(self) -> Sheet:
        st = self.store.load()
        out = Sheet(self.sheet.client if self.sheet is not None else st["client"], "", {})
        out.extras = [{**x, "read": ticked} for x, ticked in zip(self.sheet.extras, self._read_ticks())]
        out.op_seq = self.sheet.op_seq
        for t, r in [(t, r) for t in self._value_tables() for r in range(t.rowCount())]:
            k = t.item(r, C_KEY).data(Qt.ItemDataRole.UserRole)
            e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
            text = (t.item(r, C_VALUE).text() if t.item(r, C_VALUE) else "").strip()
            ticked = t.item(r, C_CONFIRM).checkState() == Qt.CheckState.Checked
            entry = SheetEntry(**{**e.__dict__})
            out.entries[k] = entry
            if not ticked:
                if entry.status == "confirmed":
                    entry.status = "proposed"            # un-ticking withdraws the confirmation
                continue
            if text.lower() in NA_WORDS:
                out.mark_not_applicable(k)
            elif not text:
                continue                                 # ticked but empty: stays unresolved
            elif text == _show(e.value) and e.status in ("proposed", "confirmed") and e.check in BLOCKING:
                # the plugin could not find Claude's quote (or the value in it) in the PDF: ticking it makes the
                # value the operator's own statement, never a cited document value
                out.set_operator(k, e.value, f"{e.check_note or e.check}: quote not found in the PDF; "
                                             f"value stated by the operator in the Plan Stages dock")
            elif text == _show(e.value) and e.status in ("proposed", "confirmed"):
                entry.status = "confirmed"
            else:
                out.set_operator(k, _parse(text), "entered in the Plan Stages dock")
        # entries with no row in the table (HeroTel 14's pon_cap_hard) come across as they are: dropping them here
        # planned Deneysville as plain HeroTel (walk 2026-11-02)
        for k, e in self.sheet.entries.items() if self.sheet is not None else ():
            if k not in out.entries:
                out.entries[k] = SheetEntry(**{**e.__dict__})
        return out

    def save_quietly(self) -> str | None:
        """Use this wayleave with no revision saved (2026-10-20): save the sheet on show and return the line the
        Wayleave box shows, with the extras Approve will ask about; None when the sheet lacks a required value."""
        rev = self.save_revision(announce=False)
        if not rev:
            return None
        summary = _extras_summary(self.sheet.extras) if self.sheet is not None else ""
        return (f"spec {rev} saved from the sheet on the Spec tab (no revision was saved yet)"
                + (f"; {summary}" if summary else ""))

    def save_revision(self, announce: bool = True) -> str | None:
        """Write spec/rev-NNN/{docs,sheet.json}; mark every non-pending stage stale. Returns the rev or None.
        announce=False: Use this wayleave saved it (2026-10-20) and says so in its own report."""
        from .words import rule_name, stage_label
        sheet = self._sheet_from_table()
        missing = sheet.unresolved(required_keys())
        if missing:
            warn(self, "Spec not complete", "Still needed: " + ", ".join(rule_name(k) for k in missing) + ".",
                 "Unresolved keys: " + ", ".join(missing))
            if missing[0] in set(self.planning_keys()):
                self.select_key(missing[0])
            return None
        started = [sid for sid in stages.order() if sid != "wayleave" and sid in self.store.started_stages()]
        if announce and started and not ask_yes_no(
                self, "Save spec?", f"Saving these rules makes {', '.join(stage_label(s).split(' ')[0] for s in started)} "
                                    f"out of date. They will need to be made again.\n\nSave spec?"):
            return None
        base = self.store.site_dir / "spec"
        base.mkdir(parents=True, exist_ok=True)
        existing = sorted(p.name for p in base.glob("rev-*") if p.is_dir())
        rev = f"rev-{(int(existing[-1][4:]) + 1 if existing else 1):03d}"
        rd = base / rev
        (rd / "docs").mkdir(parents=True)
        sheet.rev = rev
        try:
            sheet.save(rd / "sheet.json", required_keys())
        except SheetIncomplete as e:
            shutil.rmtree(rd, ignore_errors=True)
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(e.keys))
            return None
        for p in self.pdfs:
            if p.exists():
                shutil.copy2(p, rd / "docs" / p.name)
        self.store.save_spec_revision(rev)
        if self.pending_preset is not None:
            self.store.set_client_preset(sheet.client, self.pending_preset or None)
            self.pending_preset = None
        summary = _extras_summary(sheet.extras)
        self.set_site(self.store, self.config, self.locked)
        if announce:                                     # spec 8.5: a quiet line, not a box to dismiss
            from .theme import is_dark, tone
            self.saved_line.setText(f"\u2713 Spec {int(rev[4:])} saved." + (f" {summary}." if summary else ""))
            self.saved_line.setStyleSheet(f"color: {tone('ok', is_dark(self))};")
            self.saved_line.show()
        self.changed.emit()
        return rev
