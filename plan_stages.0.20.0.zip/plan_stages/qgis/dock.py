"""The Plan Stages dock: site selector, config dialog, site lock, and the Spec / Plan / Help tabs. The Plan tab starts
with the Wayleave box (the project's wayleave layers, snapshotted as the approved input), then gate0 and P1 to P7."""
from __future__ import annotations
import re
from dataclasses import fields
from pathlib import Path
from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QTabWidget,
                                 QLabel, QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QInputDialog, QScrollArea,
                                 QFrame, QToolButton, QMenu, QMessageBox)
from ..config import PluginConfig, default_config_path
from ..core import stages, presets
from ..core.controller import StageController
from ..core.store import SiteStore, LockHeld, MigrationBlocked
from ..core.sitecrs import lo_zone
from .sitecrs_qgis import project_longitude
from .spec_tab import SpecTab
from qgis.core import QgsProject
from . import layers
from .stage_tab import StageTab
from .wayleave_box import WayleaveBox
from . import help_tab
from .help_tab import HelpTab
from .ui import ask_yes_no, warn
from . import words
from .theme import is_dark, tone, card
from .stage_strip import StageStrip



_SETTING_LABELS = {"plan_root": "Where sites are saved", "qgis_root": "QGIS install folder",
                   "wayleave_root": "Where wayleaves are kept", "gdal_python": "GDAL Python (advanced)",
                   "pyqgis_python": "QGIS Python (advanced)", "anthropic_api_key": "Claude API key (optional)"}


def ask_save(parent, site: str, can_cancel: bool = True) -> str:
    """'save' | 'discard' | 'cancel'. Tests replace this function."""
    box = QMessageBox(QMessageBox.Icon.Question, "Save your work?",
                      f"Save your work on {site}? Work that is not saved is cleared the next time the site opens.",
                      parent=parent)
    save = box.addButton("Save", QMessageBox.ButtonRole.AcceptRole)
    box.addButton("Don't save", QMessageBox.ButtonRole.DestructiveRole)
    cancel = box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole) if can_cancel else None
    box.setDefaultButton(save)
    box.exec()
    clicked = box.clickedButton()
    return "save" if clicked is save else ("cancel" if cancel is not None and clicked is cancel else "discard")


def client_mismatch(store) -> str | None:
    """Spec 9.3: the site's client, the saved rules' client and the preset's client must agree. Returns the plain
    message when they do not (Generate refuses until it is fixed), else None."""
    try:
        st = store.load()
        site_client = st.get("client")
        others = []
        if st.get("spec_preset"):
            others.append(presets.get(st["spec_preset"]).client)
        if st.get("spec_rev"):
            from ..core.specsheet import Sheet
            sheet = store.site_dir / "spec" / st["spec_rev"] / "sheet.json"
            if sheet.exists():
                others.append(Sheet.load(sheet).client)
    except Exception:                                     # noqa: BLE001 - an unreadable spec is the Spec tab's message
        return None
    wrong = next((c for c in others if c and site_client and c != site_client), None)
    if wrong is None:
        return None
    return (f"This site is {site_client} but the saved rules are {wrong}. Pick the {site_client} rules on the Spec tab "
            f"and save them.")


def _wayleave_counts(store) -> list[str]:
    """"56 PONs", "5,948 homes", "2,233 poles" from the approved wayleave's run.log first lines (written by the
    Wayleave box: "pons: 56 features from ...")."""
    import re as _re
    try:
        w = store.load()["stages"]["wayleave"]
        rev = w.get("approved_rev") or w.get("current_rev")
        log = store.rev_dir("wayleave", rev) / "run.log" if rev else None
        text = log.read_text(encoding="utf-8", errors="replace") if log is not None and log.exists() else ""
    except Exception:                                     # noqa: BLE001
        return []
    got = dict((m[1], int(m[2])) for m in _re.finditer(r"^(\w+): (\d+) features", text, _re.M))
    out = []
    for key, word in (("pons", "PONs"), ("demand_points", "homes"), ("poles", "poles")):
        if key in got:
            out.append(f"{got[key]:,} {word}")
    return out


class NewSiteDialog(QDialog):
    def __init__(self, parent, zone, plist, existing: set):
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QSpinBox
        self.setWindowTitle("New site")
        self._plist, self._existing = plist, existing
        form = QFormLayout(self)
        self.name = QLineEdit(); self.name.setPlaceholderText("e.g. Itsoseng")
        self.name_hint = QLabel("Letters, numbers, - and _ only."); self.name_hint.setWordWrap(True)
        self.client = QComboBox(); self.client.addItem("Choose\u2026", None)
        for p in plist:
            self.client.addItem(p.label, p.id)
        self.epsg = QSpinBox(); self.epsg.setRange(1024, 999999); self.epsg.setValue(zone[0] if zone else 2052)
        self.zone_hint = QLabel(f"Lo{zone[1]} \u00b7 EPSG:{zone[0]}, from your project's layers" if zone else
                                "No layers to suggest from: load the wayleave first, or type the Lo zone's EPSG "
                                "(Lo19 2048, Lo25 2051, Lo27 2052, Lo29 2053).")
        self.zone_hint.setWordWrap(True)
        form.addRow("Site name", self.name); form.addRow("", self.name_hint)
        form.addRow("Client rules", self.client)
        form.addRow("Map zone (EPSG)", self.epsg); form.addRow("", self.zone_hint)
        self.bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.bb.button(QDialogButtonBox.StandardButton.Ok).setText("Make the site")
        self.bb.accepted.connect(self.accept); self.bb.rejected.connect(self.reject)
        form.addRow(self.bb)
        self.name.textChanged.connect(lambda _t: self._validate()); self.client.currentIndexChanged.connect(lambda _i: self._validate())
        self._validate()

    def problem(self) -> str:
        n = self.name.text().strip()
        if not n:
            return "Type a site name."
        if not re.fullmatch(r"[A-Za-z0-9_\-]+", n):
            return "Letters, numbers, - and _ only (no spaces)."
        if n in self._existing:
            return f"{n} already exists. Pick it in the site list instead."
        if self.client.currentData() is None:
            return "Choose the client's rules."
        return ""

    def _validate(self):
        why = self.problem()
        self.bb.button(QDialogButtonBox.StandardButton.Ok).setEnabled(not why)
        self.name_hint.setText(why or "\u2713 Ready.")

    def values(self):
        return self.name.text().strip(), int(self.epsg.value()), self.client.currentData()


PON_LAB_KEY = "plan_stages/ui/pon_lab_url"
_ADVANCED = ("qgis_root", "wayleave_root", "gdal_python", "pyqgis_python")


def pon_lab_url(site: str, pon) -> str | None:
    """Spec 12: the PON Lab address for a PON, from the template in Settings ({site}, {pon}); None when not set."""
    from qgis.core import QgsSettings
    from urllib.parse import quote
    tpl = (QgsSettings().value(PON_LAB_KEY, "", type=str) or "").strip()
    if not tpl or pon is None:
        return None
    return tpl.replace("{site}", quote(str(site))).replace("{pon}", quote(str(pon)))


class ConfigDialog(QDialog):
    """Spec 2: plain labels; the four launcher / checkout folders under a closed Advanced section, with the PON Lab
    address (kept in QgsSettings, not the config file). Same PluginConfig fields."""
    def __init__(self, config: PluginConfig, parent=None):
        super().__init__(parent)
        from qgis.core import QgsSettings
        self.setWindowTitle("Plan Stages settings")
        lay = QVBoxLayout(self)
        form = QFormLayout(); adv_form = QFormLayout()
        self.edits: dict[str, QLineEdit] = {}
        for f in fields(PluginConfig):
            e = QLineEdit(str(getattr(config, f.name)))
            if f.name == "anthropic_api_key":
                e.setEchoMode(QLineEdit.EchoMode.Password)
                e.setPlaceholderText("Only needed to read PDFs with Claude")
            label = _SETTING_LABELS.get(f.name, f.name)
            (adv_form if f.name in _ADVANCED else form).addRow(label, e); self.edits[f.name] = e
            e.setToolTip(f.name)
            if f.name in _ADVANCED:
                e.setPlaceholderText("Found automatically")
        self.pon_lab = QLineEdit(QgsSettings().value(PON_LAB_KEY, "", type=str) or "")
        self.pon_lab.setPlaceholderText("e.g. https://…/lab?site={site}&pon={pon}")
        self.pon_lab.setToolTip("Address of PON Lab. {site} and {pon} are filled in. Empty: no PON Lab links.")
        adv_form.addRow("PON Lab address", self.pon_lab)
        lay.addLayout(form)
        self.adv_btn = QToolButton(); self.adv_btn.setText("\u25b8 Advanced"); self.adv_btn.setCheckable(True)
        self.adv_btn.setAutoRaise(True)
        self.adv = QWidget(); self.adv.setLayout(adv_form); self.adv.hide()
        self.adv_btn.toggled.connect(lambda on: (self.adv.setVisible(on),
                                                 self.adv_btn.setText(("\u25be" if on else "\u25b8") + " Advanced"),
                                                 self.adjustSize()))
        lay.addWidget(self.adv_btn); lay.addWidget(self.adv)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.setMinimumWidth(420)

    def value(self) -> PluginConfig:
        return PluginConfig(**{k: e.text().strip() for k, e in self.edits.items()})

    def save_ui_settings(self) -> None:
        from qgis.core import QgsSettings
        QgsSettings().setValue(PON_LAB_KEY, self.pon_lab.text().strip())


class PlanStagesDock(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Plan Stages", parent or iface.mainWindow())
        self.iface = iface
        self.setObjectName("PlanStagesDock")
        self.config = PluginConfig.load(default_config_path())
        self.store: SiteStore | None = None
        self.controller: StageController | None = None
        self.has_lock = False
        self.locked = False
        self._build()
        self.reload_sites()
        # A project opened or cleared in QGIS gives the dock a fresh slate (ruling 2026-10-07).
        prj = QgsProject.instance()
        self._prj_conns = [(prj.readProject, lambda _doc: self._project_changed()),
                           (prj.cleared, self._project_changed)]
        for sig, fn in self._prj_conns:
            sig.connect(fn)

    # ---------------- layout ----------------
    def _build(self):
        body = QWidget(); lay = QVBoxLayout(body)
        # Frontend spec 2: site · client badge · Save chip · •••, then one line of facts. Fits a 420 px dock.
        top = QHBoxLayout(); top.setSpacing(6)
        self.site_combo = QComboBox(); self.site_combo.setMinimumWidth(90)
        self.site_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.site_combo.setMinimumContentsLength(8)
        self.site_combo.setPlaceholderText("Choose a site")
        self.site_combo.activated.connect(lambda _i: self.select_site(self.site_combo.currentText()))
        self.client_badge = QToolButton(); self.client_badge.setAutoRaise(True); self.client_badge.hide()
        self.client_badge.clicked.connect(lambda: self.tabs.setCurrentWidget(self.spec_tab))
        self.save_btn = QPushButton("Save"); self.save_btn.clicked.connect(self.save_progress)
        self.save_btn.setToolTip("Keep this site's planning work. Work that is not saved is cleared the next time "
                                 "the site is opened.")
        self.more_btn = QToolButton(); self.more_btn.setText("\u2022\u2022\u2022"); self.more_btn.setAutoRaise(True)
        self.more_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.more_btn.setStyleSheet("QToolButton::menu-indicator { image: none; width: 0; }")
        self.more_btn.setToolTip("New site, start over, settings")
        menu = QMenu(self.more_btn); self.more_btn.setMenu(menu)
        self.new_btn = menu.addAction("New site…"); self.new_btn.triggered.connect(self._new_site_dialog)
        self.folder_btn = menu.addAction("Open site folder"); self.folder_btn.triggered.connect(self._open_site_folder)
        menu.addSeparator()
        self.reset_btn = menu.addAction("Start over…"); self.reset_btn.triggered.connect(self._start_over_dialog)
        self.reset_btn.setToolTip("Delete this site's plan work (every stage back to not started); keeps the spec")
        menu.addSeparator()
        self.report_btn = menu.addAction("Plan report…"); self.report_btn.triggered.connect(lambda: self.show_report())
        menu.addSeparator()
        self.cfg_btn = menu.addAction("Settings…"); self.cfg_btn.triggered.connect(self._config_dialog)
        top.addWidget(self.site_combo, 1); top.addWidget(self.client_badge); top.addWidget(self.save_btn)
        top.addWidget(self.more_btn)
        lay.addLayout(top)
        self.facts = QLabel(""); self.facts.setWordWrap(True); self.facts.hide()
        lay.addWidget(self.facts)
        self.strip = StageStrip(); self.strip.hide()
        self.strip.picked.connect(self._strip_picked)
        lay.addWidget(self.strip)
        self.lock_label = QLabel(""); self.lock_label.setWordWrap(True); self.lock_label.hide()
        lay.addWidget(self.lock_label)
        self.saved_label = QLabel(""); self.saved_label.setWordWrap(True); self.saved_label.hide()
        lay.addWidget(self.saved_label)
        from .ui import BusyLine
        self.busy_line = BusyLine(); lay.addWidget(self.busy_line)    # spec 4: opening a site says so
        self.tabs = QTabWidget()
        self.spec_tab = SpecTab(on_busy=self.set_global_busy)
        plan = QWidget(); pl = QVBoxLayout(plan)
        self.wayleave_box = WayleaveBox(self.iface)
        self.plan_reason = QLabel(""); self.plan_reason.setWordWrap(True)
        rows = [s.id for s in stages.REGISTRY if s.phase in ("gate", "plan")]
        self.plan_tab = StageTab(self.iface, rows, on_busy=self.set_global_busy)
        self.wayleave_box.ensure_spec = self.spec_tab.save_quietly
        self.plan_tab.wayleave_layer = lambda name: self.wayleave_box.chosen().get(name)
        self.plan_tab.wayleave_chosen = lambda: self.wayleave_box.chosen()
        self.wayleave_box.stage_tab = self.plan_tab          # 0.16.0: the Scan window's chain runs on the plan tab
        from .auto_run import AutoBar
        self.auto_bar = AutoBar()                          # spec 3.2 / 5: one press runs every stage still to do
        self.auto_bar.set_context(self.plan_tab, self.wayleave_box, self)
        self.auto_bar.report_requested.connect(self.show_report)
        self.auto_bar.show_issues.connect(self._show_stage_issues)
        pl.addWidget(self.wayleave_box); pl.addWidget(self.auto_bar); pl.addWidget(self.plan_reason)
        pl.addWidget(self.plan_tab, 1)
        self.plan_index = self.tabs.addTab(plan, "Plan")
        self.tabs.addTab(self.spec_tab, "Spec")
        self.help_tab = HelpTab()
        self.help_index = self.tabs.addTab(self.help_tab, "Help")
        if not help_tab.help_seen():          # the very first time the plugin is opened, show what it needs
            self.tabs.setCurrentIndex(self.help_index)
            help_tab.mark_help_seen()
        for t in (self.spec_tab, self.wayleave_box, self.plan_tab):
            t.changed.connect(self.refresh)
        self.plan_tab.approved.connect(self._after_approve)
        self.plan_tab.herotel_block = self._herotel_block
        lay.addWidget(self.tabs, 1)
        # The dock must shrink to whatever width the operator drags it to: the body scrolls instead of
        # imposing its natural width (eight layer rows + seven button rows) on the QGIS window.
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(body)
        self.setWidget(scroll)
        self.setMinimumWidth(240)

    # ---------------- sites ----------------
    def site_names(self) -> list[str]:
        root = Path(self.config.plan_root)
        return sorted(p.name for p in root.iterdir() if (p / "site.json").exists()) if root.is_dir() else []

    def reload_sites(self):
        current = self.store.site if self.store else None
        self.site_combo.blockSignals(True)
        self.site_combo.clear()
        self.site_combo.addItems(self.site_names())
        if current:
            self.site_combo.setCurrentText(current)
        else:
            self.site_combo.setCurrentIndex(-1)
        self.site_combo.blockSignals(False)
        self.refresh()

    def _new_site_dialog(self):
        """Spec 2 + 9.3: one dialog instead of three. The name is checked as it is typed, the client rules start on
        "Choose…" (no default: a Fibertime site never starts on HeroTel's rules by accident), the map zone is filled
        from the project. create_site() is called unchanged."""
        zone = lo_zone(project_longitude(QgsProject.instance()))
        dlg = NewSiteDialog(self, zone, presets.list_presets(), set(self.site_names()))
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        name, epsg, preset_id = dlg.values()
        self.create_site(name, epsg, preset_id)

    def create_site(self, name: str, epsg: int, preset_id: str) -> bool:
        """The new-site code path (the dialog only collects these three values). Selects the new site; its sheet
        starts from the chosen client spec preset, unsaved (2026-10-16)."""
        if not re.fullmatch(r"[A-Za-z0-9_\-]+", name):
            warn(self, "New site", "Use letters, digits, '_' or '-' only for the site name.")
            return False
        store = SiteStore(Path(self.config.plan_root), name)
        if (store.site_dir / "site.json").exists():
            warn(self, "New site", f"Site {name} already exists; selecting it.")
        else:
            p = presets.get(preset_id)
            store.create_site(int(epsg), p.client, preset=preset_id)
        self.select_site(name)
        self.reload_sites()
        return True

    def _start_over_dialog(self):
        if self.store is None or self.locked:
            return
        started = [sid for sid, s in self.store.load()["stages"].items() if s["status"] != "pending"]
        names = ", ".join(stages.get(s).name for s in started) or "(nothing started yet)"
        if not ask_yes_no(self, f"Start over on {self.store.site}?",
                          f"Delete every stage revision of site {self.store.site} from disk and its layers from "
                          f"the project, and put every stage back to pending? The spec is kept.\n\n"
                          f"Started stages: {names}\n\nThis cannot be undone."):
            return
        self.start_over()

    def _discard_unsaved(self):
        """Ruling 2026-10-07: a site opened with unsaved progress starts clean; only saved progress persists."""
        self.plan_tab.cancel_tasks()
        if not self.store.is_saved() and self.store.started_stages():
            layers.unload_all(self.store.site)       # release the GeoPackage locks before the revisions are deleted
        try:
            wiped = self.controller.discard_unsaved()
        except Exception as e:                       # noqa: BLE001 - a locked file must not leave the dock siteless
            warn(self, "Plan Stages", f"Could not discard unsaved progress of {self.store.site}: "
                                      f"{type(e).__name__}: {e}" + "\n\nClose whatever holds the file and pick the site again.")
            wiped = []
        if wiped:
            self.saved_label.setStyleSheet(f"color: {tone('warn', is_dark(self))};")
            self.saved_label.setText(f"Work on {self.store.site} that was not saved last time was cleared "
                                     f"({', '.join(words.stage_label(s) for s in wiped)}). Press Save to keep your work.")
            self.saved_label.show()
        else:
            self.saved_label.hide()

    def save_progress(self):
        if self.store is None or self.locked:
            return
        self.controller.save_progress()
        self.refresh()

    def start_over(self):
        """Ruling 2026-10-07: the same site planned again from the Wayleave box."""
        self.plan_tab.cancel_tasks()
        for sid in stages.order():
            layers.unload_stage(self.store.site, stages.get(sid)); layers.unload_issues(self.store.site, stages.get(sid))
        self.controller.reset_site()
        self.select_site(self.store.site)

    def _project_changed(self):
        """QGIS opened or cleared a project: a fresh slate against the new project (sites re-read, Wayleave rows
        re-matched, reports cleared). An exception escaping a PyQt slot aborts QGIS, so swallow everything."""
        try:
            self.ask_before_leaving(can_cancel=False)     # the project already changed: Save or Don't save only
            self.reload_sites()
            if self.store is not None:
                self.select_site(self.store.site)
        except Exception:                        # noqa: BLE001
            pass

    def _spec_path(self) -> Path | None:
        rev = self.store.load().get("spec_rev") if self.store else None
        return self.store.site_dir / "spec" / rev / "sheet.json" if rev else None

    def select_site(self, name: str):
        """Open a site fresh from disk: state re-read, Wayleave rows re-matched against the open project, old
        reports and logs cleared. Choosing the site already open does the same (ruling 2026-10-07); the lock
        is kept, not re-taken."""
        if not name:
            return
        same = self.store is not None and self.store.site == name and self.has_lock
        if not same and not self.ask_before_leaving():
            self.site_combo.blockSignals(True); self.site_combo.setCurrentText(self.store.site)
            self.site_combo.blockSignals(False)
            return
        self.busy_line.start(f"Opening {name}\u2026")
        try:
            self._open_site(name, same)
        finally:
            self.busy_line.stop()

    def _open_site(self, name: str, same: bool):
        if not same:
            self._release()
            self.store = SiteStore(Path(self.config.plan_root), name)
            self.controller = StageController(self.config, self.store, self._spec_path)
            self._acquire()
            if self.has_lock:
                self._discard_unsaved()
        if self.has_lock:                      # a project saved with old stage layers opens clean; wayleave layers stay
            layers.unload_stale(self.store.site, self.store.load()["stages"])
        self.spec_tab.set_site(self.store, self.config, self.locked)
        # set_site refreshes each row; a stage whose current revision is not in the project (e.g. after a
        # restart) gets a Load button there, which loads it editable unless approved. Nothing auto-loads.
        self.plan_tab.set_site(self.controller, self.store, self.locked)
        self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.refresh()

    # ---------------- lock ----------------
    def _acquire(self):
        self.has_lock = self.locked = False
        try:
            self.store.acquire_lock()
            self.has_lock = True
            self.lock_label.hide()
        except LockHeld as e:
            self.locked = True
            self.lock_label.setStyleSheet(f"color: {tone('error', is_dark(self))};")
            self.lock_label.setText(f"{self.store.site} is open in another QGIS window (since {e.when}). You can look, "
                                    f"not change. Close it there, then pick the site again here.")
            self.lock_label.setToolTip(f"pid {e.pid}")
            self.lock_label.show()
            return
        self._move_old_layout()

    def _move_old_layout(self):
        """A site made with 0.10.0: its old plan work moves to old-layout/ now, before anything else reads or wipes
        it (final review 2026-10-21). Its layers leave the project first, or Windows refuses to move their files.
        Refused: nothing moved, nothing deleted, the site shown read-only until the operator picks it again."""
        try:
            if not self.store.old_layout():
                return
            layers.unload_old_layout(self.store.site)
            self.store.load()                    # the lock holder's first read moves the old folders aside
        except MigrationBlocked as e:
            self._release()
            self.locked = True
            msg = (f"Site {self.store.site} was planned with an older Plan Stages. Its old plan work could not be "
                   f"moved to the old-layout folder ({e}). Close the old plan layers (or the other QGIS that has this "
                   f"site open) and pick the site again. Nothing was moved or deleted. Read-only until then.")
            self.lock_label.setStyleSheet(f"color: {tone('error', is_dark(self))};")
            self.lock_label.setText(msg); self.lock_label.setWordWrap(True); self.lock_label.show()
            warn(self, "Plan Stages", msg)

    def _release(self):
        if self.store is not None and self.has_lock:
            try:
                self.store.release_lock()
            except OSError:
                pass
        self.has_lock = False

    def plan_blocked_reason(self) -> str | None:
        """Why the Plan tab's stage rows are disabled; None when gate0 to P7 may run."""
        if self.store is None:
            return "Select or create a site."
        st = self.store.load()
        w = st["stages"]["wayleave"]       # 2026-10-20: no saved spec is not its own stop; Use this wayleave saves one
        if w["status"] != "approved":
            if w["status"] == "stale":
                return "The rules changed after the wayleave snapshot. Press Use this wayleave again."
            return "Start here: check the wayleave layers above, then press Use this wayleave."
        return None

    def plan_enabled(self) -> bool:
        return self.plan_blocked_reason() is None

    def refresh(self):
        self.plan_tab.locked = self.locked
        if self.plan_tab.controller is not None:
            self.plan_tab.refresh()
        self.wayleave_box.locked = self.locked
        self.wayleave_box.refresh()
        self.spec_tab.locked = self.locked
        self.spec_tab.refresh()
        why = self.plan_blocked_reason()
        self.plan_reason.setText(why or ""); self.plan_reason.setVisible(why is not None)
        # Spec 9.5: a next step is blue, an out-of-date state amber; red is only for errors. The list stays readable
        # (spec 3.3): rows say "Waiting for the wayleave" and offer no button until it is approved.
        stale = self.store is not None and self.store.load()["stages"]["wayleave"]["status"] == "stale"
        self.plan_reason.setStyleSheet(f"color: {tone('warn' if stale else 'info', is_dark(self))};")
        self.plan_tab.setEnabled(True)
        if self.store is not None:
            saved = self.store.is_saved() or not self.store.started_stages()
            self.save_btn.setEnabled(not self.locked and not saved)
            self.save_btn.setText("Saved" if saved else "\u25cf Not saved \u00b7 Save")
            self.save_btn.setFlat(saved)
            self.save_btn.setStyleSheet("" if saved else f"QPushButton {{ color: {tone('warn', is_dark(self))}; font-weight: 600; }}")
        else:
            self.save_btn.setEnabled(False); self.save_btn.setText("Save"); self.save_btn.setFlat(True)
            self.save_btn.setStyleSheet("")
        self.reset_btn.setEnabled(self.store is not None and not self.locked and not self.plan_tab.busy)
        self.report_btn.setEnabled(self.store is not None)
        self.auto_bar.refresh()
        self.folder_btn.setEnabled(self.store is not None)
        self._refresh_badge_and_facts()

    def _refresh_badge_and_facts(self):
        """Client badge (spec 2, 9.3) and the facts line: counts from the approved wayleave, spec number, n of 8."""
        if self.store is None:
            self.client_badge.hide(); self.facts.hide(); self.strip.hide(); return
        st = self.store.load()
        client = st.get("client") or "No client"
        label = client
        try:
            if st.get("spec_preset"):
                label = presets.get(st["spec_preset"]).label
        except Exception:                                     # noqa: BLE001 - an unknown preset id still shows the client
            pass
        dark = is_dark(self)
        colour = {"Fibertime": tone("ready", dark), "HeroTel": "#e65100" if not dark else "#ffab40"}.get(client, tone("idle", dark))
        self.client_badge.setText(label.split(" (")[0])        # "Fibertime · Formal"; the full name is in the tooltip
        self.client_badge.setToolTip(f"Rules: {label}" + (f", spec {st['spec_rev'].split('-')[-1].lstrip('0')}"
                                                          if st.get("spec_rev") else ", no spec saved yet")
                                     + ". Click to open the Spec tab.")
        mismatch = client_mismatch(self.store)
        self.plan_tab.blocked_reason = mismatch
        if mismatch:                                      # spec 9.3: red, with "!", and the reason in words
            colour = tone("error", dark)
            self.client_badge.setText("! " + self.client_badge.text())
            self.client_badge.setToolTip(mismatch + " Click to open the Spec tab.")
            self.plan_reason.setText(mismatch); self.plan_reason.setStyleSheet(f"color: {colour};")
            self.plan_reason.show()
        if not mismatch and self.plan_reason.isHidden():
            todo = self.spec_tab.herotel_unacked() if self.spec_tab.sheet is not None else []
            if todo:
                from .words import rule_name
                self.plan_reason.setText(f"{len(todo)} rule{'s use' if len(todo) != 1 else ' uses'} a HeroTel value "
                                         f"({', '.join(rule_name(k) for k in todo)}). Keep or change "
                                         f"{'them' if len(todo) != 1 else 'it'} on the Spec tab.")
                self.plan_reason.setStyleSheet(f"color: {tone('warn', dark)};"); self.plan_reason.show()
        self.client_badge.setStyleSheet(f"QToolButton {{ color: {colour}; border: 1px solid {colour}; border-radius: 9px;"
                                        f" padding: 1px 8px; font-weight: 600; }}")
        self.client_badge.show()
        plan = [s.id for s in stages.REGISTRY if s.phase in ("gate", "plan")]
        done = sum(1 for s in plan if st["stages"].get(s, {}).get("status") == "approved")
        bits = _wayleave_counts(self.store)
        if st.get("spec_rev"):
            bits.append(f"spec {st['spec_rev'].split('-')[-1].lstrip('0') or '0'}")
        bits.append(f"{done} of {len(plan)} approved")
        self.facts.setText(" \u00b7 ".join(bits))
        self.facts.setStyleSheet(f"color: {tone('idle', dark)}; font-size: 8.5pt;")
        self.facts.show()
        self.strip.set_stages([(s, st["stages"].get(s, {}).get("status", "pending")) for s in plan])
        self.strip.show()

    def _herotel_block(self, stage_id: str) -> str | None:
        """Spec 9.3.4: why this stage waits (it reads a HeroTel value on another client's site that is not kept
        yet), else None."""
        from .words import rule_name
        try:
            todo = [k for k in self.spec_tab.herotel_unacked() if k in stages.get(stage_id).spec_keys]
        except Exception:                                 # noqa: BLE001 - never blocks on its own error
            return None
        if not todo:
            return None
        names = ", ".join(rule_name(k) for k in todo)
        return (f"{names}: the value is HeroTel's, because {self.spec_tab.sheet.client} gives none. On the Spec tab, "
                f"keep it or type the client's value first.")

    def show_report(self):
        """Spec 6: the plan report, from what is on disk (and the last Auto run's times when there was one)."""
        if self.store is None:
            return None
        from .run_report import RunReportDialog
        run = getattr(self.auto_bar, "run", None)
        times = run.times if run is not None and run.store is self.store else None
        line = run.result[1] if run is not None and run.result and run.store is self.store else ""
        self._report = RunReportDialog(self.store, times, line, self)
        self._report.show()
        return self._report

    def _show_stage_issues(self, sid: str):
        self.tabs.setCurrentIndex(self.plan_index)
        if sid in self.plan_tab.rows:
            self.plan_tab.rows[sid]["radio"].setChecked(True)
            self.plan_tab.show_pane("issues")

    def _strip_picked(self, sid: str):
        self.tabs.setCurrentIndex(self.plan_index)
        if sid in self.plan_tab.rows:
            self.plan_tab.rows[sid]["radio"].setChecked(True)

    def _open_site_folder(self):
        if self.store is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.store.site_dir)))

    def _after_approve(self, _stage_id: str):
        """Spec 9.1: auto-save after every approval (setting plan_stages/ui/autosave_after_approve, default on)."""
        from qgis.core import QgsSettings
        if QgsSettings().value("plan_stages/ui/autosave_after_approve", True, type=bool):
            self.save_progress()

    def _unsaved(self) -> bool:
        return self.store is not None and not self.locked and self.has_lock and not self.store.is_saved() \
            and bool(self.store.started_stages())

    def ask_before_leaving(self, can_cancel: bool = True) -> bool:
        """Spec 9.1: Save / Don't save (/ Cancel) when unsaved work would be cleared. False = stay. Only asks when the
        dock is on screen (a hidden dock, or a test, never blocks)."""
        if not self._unsaved() or not self.isVisible():
            return True
        answer = ask_save(self, self.store.site, can_cancel)
        if answer == "save":
            self.save_progress()
        return answer != "cancel"

    def set_global_busy(self):
        """While any tab runs a task, the site, config, spec-save and wayleave controls are frozen."""
        busy = self.plan_tab.busy or self.spec_tab.proposing
        for w in (self.site_combo, self.new_btn, self.cfg_btn):
            w.setEnabled(not busy)
        self.spec_tab.external_busy = self.plan_tab.busy
        self.spec_tab.refresh()
        self.wayleave_box.external_busy = self.plan_tab.busy
        self.wayleave_box.refresh()

    # ---------------- config ----------------
    def _config_dialog(self):
        dlg = ConfigDialog(self.config, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new = dlg.value()
        dlg.save_ui_settings()
        new.save(default_config_path())
        root_changed = new.plan_root != self.config.plan_root
        self.config = new
        if root_changed:
            self._release()
            self.store = self.controller = None
            self.plan_tab.set_site(None, None, False)
            self.wayleave_box.set_site(None, None, False)
            self.spec_tab.set_site(None, new, False)
        elif self.store is not None:
            self.controller = StageController(self.config, self.store, self._spec_path)
            self.spec_tab.set_site(self.store, self.config, self.locked)
            self.plan_tab.set_site(self.controller, self.store, self.locked)
            self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.reload_sites()

    # ---------------- lifecycle ----------------
    def showEvent(self, event):
        if self.store is not None and not self.has_lock:      # re-take the lock after a close / reopen
            self._acquire()
            self.select_site_tabs()
        super().showEvent(event)

    def select_site_tabs(self):
        self.plan_tab.set_site(self.controller, self.store, self.locked)
        self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.spec_tab.set_site(self.store, self.config, self.locked)
        self.refresh()

    def closeEvent(self, event):
        if not self.ask_before_leaving():
            event.ignore()
            return
        self._release()
        super().closeEvent(event)

    def shutdown(self):
        """Called by the plugin's unload: cancel running stage tasks and release the site lock."""
        self.plan_tab.cancel_tasks()
        self.wayleave_box.shutdown()
        for sig, fn in getattr(self, "_prj_conns", []):
            try:
                sig.disconnect(fn)
            except (TypeError, RuntimeError):
                pass
        self._prj_conns = []
        self._release()
