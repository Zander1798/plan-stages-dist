"""Run report (frontend spec 6): what the plan holds, built from what is on disk, so it works for a hand-run plan as
well as after Auto. Shown in a window with Save as HTML and Copy summary. Reads only; writes nothing in the site."""
from __future__ import annotations

import html
import json
from pathlib import Path

from qgis.PyQt.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
)

from ..core import stages
from ..core.checks import ChecksReport
from . import words

PLAN = [s.id for s in stages.REGISTRY if s.phase in ("gate", "plan")]


def _json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def stage_rows(store, times: dict | None = None) -> list[dict]:
    """One dict per stage: name, status words, errors / warnings / hidden, how approved, own layer, time."""
    from ..core import dismiss
    st = store.load()["stages"]
    out = []
    for sid in ["wayleave"] + PLAN:
        s = st.get(sid, {})
        row = {"id": sid, "name": "Wayleave" if sid == "wayleave" else words.stage_label(sid),
               "status": words.status_label(s.get("status", "pending")), "errors": 0, "warnings": 0, "hidden": 0,
               "how": "", "own": False, "time": (times or {}).get(sid)}
        rev = store.rev_dir(sid, s["current_rev"]) if s.get("current_rev") else None
        if rev is not None:
            row["own"] = (rev / "takeover.json").exists()
            cj = rev / "checks.json"
            if cj.exists():
                try:
                    report = ChecksReport.load(cj)
                    shown, removed, _fixed = dismiss.split_how(report, rev)
                    row["errors"] = sum(1 for i in shown if i.severity == "error")
                    row["warnings"] = sum(1 for i in shown if i.severity != "error")
                    row["hidden"] = len(removed)
                except Exception:                        # noqa: BLE001 - one bad file never hides the report
                    pass
            ap = _json(rev / "approval.json")
            if ap:
                note = ap.get("note") or ""
                row["how"] = ("approved with errors" if ap.get("overridden_checks") else
                              "Auto" if note.startswith("Auto run") else "you")
                row["note"] = note
                row["overridden"] = ap.get("overridden_checks") or []
        if s.get("status") == "generated" and row["errors"]:
            row["status"] = "Needs fixes"                  # same words as the stage row (spec 3.3)
        out.append(row)
    return out


def totals(store) -> list[str]:
    """Totals from P7's metrics, else from P4's result block."""
    st = store.load()["stages"]
    d = st.get("p8_delivery", {})
    if d.get("current_rev"):
        from .stage_tab import _delivery_facts
        facts, _ = _delivery_facts(store.rev_dir("p8_delivery", d["current_rev"]))
        if facts:
            return facts
    p4 = st.get("p4_drops", {})
    if p4.get("current_rev"):
        log = store.rev_dir("p4_drops", p4["current_rev"]) / "run.log"
        if log.exists():
            text = log.read_text(encoding="utf-8", errors="replace")
            block = text.rsplit("--- Step 4 result ---", 1)
            if len(block) == 2:
                return [l.strip() for l in block[1].splitlines() if l.strip()][:8]
    return []


def open_errors(store, most: int = 60) -> list[tuple[str, str]]:
    """(stage, message) of every open error in the current revisions, worst stage first."""
    from ..core import dismiss
    st = store.load()["stages"]
    out = []
    for sid in PLAN:
        s = st.get(sid, {})
        if not s.get("current_rev"):
            continue
        rev = store.rev_dir(sid, s["current_rev"])
        cj = rev / "checks.json"
        if not cj.exists():
            continue
        try:
            shown, _r, _f = dismiss.split_how(ChecksReport.load(cj), rev)
        except Exception:                                # noqa: BLE001
            continue
        out += [(words.stage_label(sid).split(" ")[0], i.message) for i in shown if i.severity == "error"]
    return out[:most]


def build_html(store, times: dict | None = None, run_line: str = "") -> str:
    from .dock import _wayleave_counts
    st = store.load()
    e = html.escape
    rows = stage_rows(store, times)
    approved = sum(1 for r in rows[1:] if r["status"].startswith("Approved"))
    parts = [f"<h2>{e(store.site)} — plan report</h2>",
             f"<p>{e(st.get('client') or '')} rules"
             + (f" · spec {int(st['spec_rev'][4:])}" if st.get("spec_rev") else "") + " · "
             + " · ".join(e(x) for x in _wayleave_counts(store)) + f" · {approved} of {len(PLAN)} approved</p>"]
    if run_line:
        parts.append(f"<p><b>{e(run_line)}</b></p>")
    tot = totals(store)
    if tot:
        parts.append("<h3>Totals</h3><ul>" + "".join(f"<li>{e(t)}</li>" for t in tot) + "</ul>")
    parts.append("<h3>Stages</h3><table border=0 cellspacing=0 cellpadding=3>"
                 "<tr><th align=left>Stage</th><th align=left>State</th><th>Errors</th><th>Warnings</th>"
                 "<th>Hidden</th><th align=left>Approved by</th><th align=left>Time</th></tr>")
    from . import progress
    for r in rows:
        parts.append(f"<tr><td>{e(r['name'])}{' (your layer)' if r['own'] else ''}</td><td>{e(r['status'])}</td>"
                     f"<td align=center>{r['errors'] or ''}</td><td align=center>{r['warnings'] or ''}</td>"
                     f"<td align=center>{r['hidden'] or ''}</td><td>{e(r['how'])}</td>"
                     f"<td>{progress.clock(r['time']) if r['time'] else ''}</td></tr>")
    parts.append("</table>")
    errs = open_errors(store)
    if errs:
        parts.append(f"<h3>Needs a person ({len(errs)})</h3><ul>" +
                     "".join(f"<li>{e(s)} · {e(m)}</li>" for s, m in errs) + "</ul>")
    dec = [(r["name"], r.get("note", ""), r.get("overridden", [])) for r in rows if r.get("overridden")]
    hidden = [(r["name"], r["hidden"]) for r in rows if r["hidden"]]
    if dec or hidden:
        parts.append("<h3>Decisions on record</h3><ul>")
        for name, note, checks in dec:
            parts.append(f"<li>{e(name)}: approved over {len(checks)} failed check(s) — “{e(note)}”</li>")
        for name, n in hidden:
            parts.append(f"<li>{e(name)}: {n} issue(s) marked Not a problem</li>")
        parts.append("</ul>")
    return "\n".join(parts)


def summary_text(store, run_line: str = "") -> str:
    rows = stage_rows(store)
    lines = [f"{store.site}: " + (run_line or "plan report")]
    lines += [f"{r['name']}: {r['status']}" + (f", {r['errors']} errors" if r["errors"] else "")
              + (f", {r['warnings']} warnings" if r["warnings"] else "") for r in rows]
    lines += totals(store)
    return "\n".join(lines)


class RunReportDialog(QDialog):
    def __init__(self, store, times: dict | None = None, run_line: str = "", parent=None):
        super().__init__(parent)
        self.store = store
        self.setWindowTitle(f"Plan report · {store.site}")
        lay = QVBoxLayout(self)
        self.view = QTextBrowser(); self.view.setOpenExternalLinks(True)
        self.html = build_html(store, times, run_line)
        self.view.setHtml(self.html)
        self._summary = summary_text(store, run_line)
        lay.addWidget(self.view, 1)
        bar = QHBoxLayout()
        self.save_btn = QPushButton("Save as HTML…"); self.save_btn.clicked.connect(self.save_html)
        self.copy_btn = QPushButton("Copy summary"); self.copy_btn.clicked.connect(
            lambda: QApplication.clipboard().setText(self._summary))
        close = QPushButton("Close"); close.clicked.connect(self.accept)
        bar.addWidget(self.save_btn); bar.addWidget(self.copy_btn); bar.addStretch(1); bar.addWidget(close)
        lay.addLayout(bar)
        self.resize(620, 700)

    def save_html(self, path: str | None = None) -> str | None:
        if path is None:
            path, _ = QFileDialog.getSaveFileName(self, "Save the report", f"{self.store.site}_plan_report.html",
                                                  "HTML (*.html)")
        if not path:
            return None
        Path(path).write_text(f"<html><meta charset='utf-8'><body>{self.html}</body></html>", encoding="utf-8")
        return path
