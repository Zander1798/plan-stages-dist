"""What one stage row shows (frontend spec 3.3): state dot, status line, ONE main button and a ⋯ menu.

Pure Python (no Qt), so the state table is tested without QGIS. The inputs are facts the tab already reads:
the stage's state in site.json, controller.next_enabled(), the current revision's checks and approval record.
A button that cannot be pressed is never shown; the status line says what the stage waits for instead.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .words import stage_label

# tone -> (dot glyph). Shape AND colour carry the state, so it reads without colour too.
DOTS = {"ok": "●", "ready": "◕", "info": "◑", "warn": "◐", "error": "✕", "idle": "○",
        "run": "◔", "back": "↩"}


@dataclass
class RowFacts:
    stage_id: str
    status: str                                   # site.json status ("pending", "generated", ...)
    enabled: dict = field(default_factory=dict)   # controller.next_enabled(stage_id)
    deps_waiting: list = field(default_factory=list)   # dependency ids not approved yet, in order
    wayleave_ok: bool = True
    running: bool = False                         # a task of this tab is running this stage
    busy: bool = False                            # some task runs (other rows show no button)
    locked: bool = False
    has_checks: bool = False                      # checks.json exists for the current revision
    errors: int = 0                               # blocking issues still shown (after "Not a problem")
    warnings: int = 0
    taken_over: bool = False                      # takeover.json: the planner's own layer
    overridden: int = 0                           # approved over N failed checks
    hidden: int = 0                               # issues marked "Not a problem"
    approved_when: str = ""                       # "09:31" or "20 Nov"
    stale_reasons: list = field(default_factory=list)   # plain reasons from words.explain_reasons(can_approve)
    load_needed: bool = False                     # current revision not on the map
    drawn_names: str = ""                         # own drawn layer offered for this step ("" = none)
    note: str = ""                                # reject note, failure line
    progress_text: str = ""                       # "Running · Reading roads · 3:12 · about 9 min left"
    stopped: bool = False                         # the planner pressed Stop on the last run


@dataclass
class RowView:
    tone: str
    dot: str
    status: str
    main: str | None = None                       # action name: generate/check/approve/use_drawn/load/stop
    main_label: str = ""
    menu: list = field(default_factory=list)      # [(action, label)], only actions that can run now


def short_name(stage_id: str) -> str:
    """'P3', 'Gate 0', 'Wayleave': the name a status line uses for another stage."""
    label = stage_label(stage_id)
    return label.split(' · ')[0] if not label.startswith('P') else label.split(' ')[0]


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def view(f: RowFacts) -> RowView:
    en = f.enabled if not (f.locked or f.busy) else {}
    menu: list[tuple[str, str]] = []

    def offer(action: str, label: str):
        if en.get(action):
            menu.append((action, label))

    if f.running:
        return RowView("run", DOTS["run"], f.progress_text or "Running", "stop", "Stop", [("log", "Show log")])
    if f.stopped and f.status == "failed":
        offer("remove", "Delete the unfinished version…")
        main = "generate" if en.get("generate") else None
        return RowView("idle", DOTS["idle"], "Stopped by you", main, "Generate" if main else "", menu + [("log", "Show log")])

    st = f.status
    if st in ("pending", "-", "", None):
        if f.drawn_names and en.get("generate"):
            return RowView("info", DOTS["info"], f"Found in your project: {f.drawn_names}", "use_drawn", "Use my layer",
                           [("generate", "Draw it for me instead")])
        if not f.wayleave_ok:
            return RowView("idle", DOTS["idle"], "Waiting for the wayleave")
        if f.deps_waiting:
            return RowView("idle", DOTS["idle"], f"Waiting for {', '.join(short_name(d) for d in f.deps_waiting[-2:])}")
        if en.get("generate"):
            return RowView("idle", DOTS["idle"], "Ready", "generate", "Generate")
        return RowView("idle", DOTS["idle"], "Not started")

    if st == "generating":
        return RowView("run", DOTS["run"], "Running in another window" if not f.running else "Running")

    if st == "failed":
        line = "Failed" + (f" · {f.note}" if f.note else "")
        offer("remove", "Delete this version…")
        main = "generate" if en.get("generate") else None
        return RowView("error", DOTS["error"], line, main, "Try again" if main else "", menu + [("log", "Show log")])

    if st == "rejected":
        offer("remove", "Delete this version…")
        main = "generate" if en.get("generate") else None
        return RowView("idle", DOTS["back"], "Sent back" + (f" · “{f.note}”" if f.note else ""), main,
                       "Generate again" if main else "", menu)

    if st == "stale":
        why = f.stale_reasons[0].rstrip(".") if f.stale_reasons else "an earlier step changed"
        offer("check", "Check only"); offer("remove", "Delete this version…")
        main = "generate" if en.get("generate") else None
        return RowView("warn", DOTS["warn"], f"Out of date · {why}", main, "Redo" if main else "", menu)

    if st == "approved":
        bits = ["Approved" + (f" · {f.approved_when}" if f.approved_when else "")]
        if f.taken_over:
            bits.append("your own layer")
        if f.overridden:
            bits.append(f"approved with {_plural(f.overridden, 'failed check')}")
        if f.hidden:
            bits.append(f"{f.hidden} hidden")
        offer("revise", "Edit this stage"); offer("remove", "Delete this version…")
        main = None
        if f.load_needed and en:
            main = "load"
        return RowView("ok", DOTS["ok"], " · ".join(bits), main, "Put on map" if main else "", menu)

    if st == "checked":
        warn = f" · {_plural(f.warnings, 'warning')}" if f.warnings else ""
        offer("generate", "Generate again"); offer("reject", "Send back…"); offer("remove", "Delete this version…")
        main = "approve" if en.get("approve") else None
        if main is None and f.load_needed and en:
            main = "load"
        elif f.load_needed and en:                       # Approve is the button; Put on map is still one click away
            menu.append(("load", "Put on map"))
        return RowView("ready", DOTS["ready"], "Checked · ready" + warn, main,
                       {"approve": "Approve", "load": "Put on map"}.get(main or "", ""), menu)

    # generated
    if f.has_checks and f.errors:
        line = f"Needs fixes · {_plural(f.errors, 'error')}" + (f", {_plural(f.warnings, 'warning')}" if f.warnings else "")
        offer("approve", "Approve anyway…"); offer("generate", "Generate again"); offer("reject", "Send back…")
        offer("remove", "Delete this version…")
        main = "check" if en.get("check") else None
        return RowView("error", DOTS["error"], line, main, "Check again" if main else "", menu)
    if f.has_checks:            # checks ran, nothing blocking left (all marked "Not a problem"): approve is next
        offer("check", "Check again"); offer("generate", "Generate again"); offer("remove", "Delete this version…")
        main = "approve" if en.get("approve") else None
        return RowView("ready", DOTS["ready"], "Checked · ready" + (f" · {_plural(f.warnings, 'warning')}" if f.warnings else ""),
                       main, "Approve" if main else "", menu)
    offer("generate", "Generate again"); offer("remove", "Delete this version…")
    main = "check" if en.get("check") else ("load" if f.load_needed and en else None)
    return RowView("info", DOTS["info"], "Drawn · check it", main,
                   {"check": "Check", "load": "Put on map"}.get(main or "", ""), menu)
