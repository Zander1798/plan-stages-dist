"""One tab of stage rows (Generate / Check / Approve / Reject / Revise, plus Load after a restart) and the
selected stage's logs and issues."""
from __future__ import annotations

import html
import json
import re
import time
from pathlib import Path

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QFontDatabase
from qgis.PyQt.QtWidgets import (
    QApplication,
    QButtonGroup,
    QHBoxLayout,
    QLabel,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QRadioButton,
    QStackedWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..core import approval, dismiss, stages
from ..core.checks import ChecksReport, Issue
from ..core.scan import SCANNED
from . import layers, progress, words
from .details_dialogs import confirm_details
from .issue_list import IssueList
from .row_view import RowFacts
from .row_view import view as row_view
from .runner import SubprocessTask
from .stage_row import StageRow
from .ui import ask_note, ask_yes_no, tail, warn

BUTTONS = ("generate", "check", "approve", "reject", "revise", "remove")
LOGS = ("run.log", "check.log")          # generator output, then the last Check's output


def assign_cp_ids(grp, working_gpkg: Path) -> list[str]:
    """2026-10-14: P4's Check gives a hand-drawn collection point the next free cp_id, through the loaded layer when
    it is on screen (so the screen and the file agree), else in the file."""
    from ..core import fixups
    lyr = next((l for l in layers.group_layers(grp) if l.name() == "collection_points"), None)
    if lyr is None:
        return fixups.assign_missing_cp_ids(working_gpkg)
    idx = lyr.fields().indexOf("cp_id")
    if idx < 0:
        return []
    todo = fixups.next_ids([(f.id(), None if f["cp_id"] is None or str(f["cp_id"]) == "NULL" else f["cp_id"])
                            for f in lyr.getFeatures()])
    if todo:
        lyr.dataProvider().changeAttributeValues({fid: {idx: n} for fid, n in todo})
        lyr.reload(); lyr.triggerRepaint()
    return [f"cp_id {n} given to collection point fid {fid}" for fid, n in todo]


def write_step_snapshot(path: Path, stage_id: str, chosen: dict, epsg: int, log: list | None = None) -> dict:
    """0.16.0 Scan: a step's project layers copied into its plan layers, exactly as a takeover writes them (and as a
    rescan writes them again to compare): the snapshot outputs, and for distribution `link` 1 on every line of a layer
    named as a link layer (final review M1: any other layer keeps the operator's own link value; fill makes a null 0).
    One-part multi geometries are written single (final review C1: every line shapefile reads as MultiLineString)."""
    from ..core.layermatch import is_link_layer
    from ..core.scan import snapshot_outputs
    from . import wayleave_box
    flag = (lambda l: 1 if is_link_layer(l.name()) else None) if stage_id == "p3_distribution" else None
    return wayleave_box.write_snapshot(path, chosen, epsg, log, outputs=snapshot_outputs(stage_id), link_flag=flag,
                                       single_parts=True, int_labels=True)   # "PON 047" -> 47 (walk 2026-10-29)


# Plain names of the plan layers, for messages (2026-11-12).
_PLAIN = {"feeder": "feeder", "splitters_1to16": "1:16 splitters", "distribution": "distribution",
          "collection_points": "collection points", "drops": "drops", "road_crossings": "road crossings",
          "splitters_8way": "8-way splitters", "dome_joints": "dome joints"}


def _default_note() -> str:
    """'Approved by JJ, 23 Nov 09:31' (Windows user name)."""
    import datetime as _dt
    import getpass
    try:
        who = getpass.getuser()
    except Exception:                                   # noqa: BLE001
        who = "planner"
    now = _dt.datetime.now()
    return f"Approved by {who}, {now.day} {now:%b %H:%M}"


def _summary(rev: Path) -> str:
    """Plain facts for the Summary pane (spec 3.4), read from files the stage already wrote."""
    lines = []
    tk = rev / "takeover.json"
    if tk.exists():
        try:
            names = [x["name"] for ls in json.loads(tk.read_text(encoding="utf-8"))["layers"].values() for x in ls]
            lines.append(f"Your own layer: {', '.join(dict.fromkeys(names))}, taken over as this stage.")
        except (OSError, ValueError, KeyError, TypeError):
            lines.append("Your own layer, taken over as this stage.")
    log = rev / "run.log"
    if log.exists():
        text = log.read_text(encoding="utf-8", errors="replace")
        block = text.rsplit("--- Step", 1)
        tail_lines = (("--- Step" + block[1]) if len(block) == 2 else text).splitlines()
        keep = [l.strip() for l in tail_lines if l.strip() and not l.startswith(("Traceback", "  File", "    "))]
        lines += keep[-8:]
    ap = rev / "approval.json"
    if ap.exists():
        try:
            rec = json.loads(ap.read_text(encoding="utf-8"))
            lines.append(f"Approved {_when(rec.get('when', ''))}" + (f": \u201c{rec['note']}\u201d" if rec.get("note") else ""))
        except (OSError, ValueError, TypeError):
            pass
    return "\n".join(lines) if lines else "No summary for this version yet."


def _delivery_facts(rev: Path) -> tuple[list[str], list[tuple[str, Path, str]]]:
    """P7 Delivery (spec 3.4 / 6): the totals its metrics files hold and the files it made, with Open actions.
    ([fact lines], [(button label, path, tooltip)]); empty when the revision has none of them."""
    facts, actions = [], []
    m = {}
    for rel in ("step3/step3_metrics.json", "step4/step4_metrics.json", "step567/step567_metrics.json"):
        try:
            m.update(json.loads((rev / rel).read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
    for key, words_ in (("feeder_m", "m of feeder"), ("distribution_m", "m of distribution"), ("drops", "drops"),
                        ("total_drop_m", "m of drop cable"), ("collection_points", "collection points"),
                        ("crossings", "road crossings"), ("poles_total", "poles"), ("dome_joints", "dome joints")):
        if isinstance(m.get(key), (int, float)):
            facts.append(f"{int(m[key]):,} {words_}")
    projects = sorted((rev / "qgis").glob("*.qgz")) if (rev / "qgis").is_dir() else []
    pngs = sorted((rev / "render").glob("*.png")) if (rev / "render").is_dir() else []
    if projects:
        facts.append(f"Project: {projects[0].name}")
        actions.append(("Open project", projects[0], "Opens the delivery project in a new QGIS window; "
                                                     "this project stays open here"))
    if pngs:
        facts.append(f"{len(pngs)} map image{'s' if len(pngs) != 1 else ''}")
        actions.append(("Open map images", rev / "render", "Opens the folder with the map images"))
    return facts, actions


def _stale_reasons(reasons: list[str]) -> list[str]:
    """Why a stage is out of date, short enough for the status line: "P2 changed", "rules changed"."""
    import re as _re

    from .row_view import short_name
    out = []
    for r in reasons:
        m = _re.match(r"dependency (\w+) (re-approved|has no approved)", r)
        if m:
            out.append(f"{short_name(m[1])} changed")
        elif r.startswith("spec changed"):
            out.append("rules changed")
        elif r.startswith("built on "):
            out.append("made by an older Plan Stages")
    return list(dict.fromkeys(out)) or ["an earlier step changed"]


def _chip_style(tone_name: str, widget) -> str:
    """A filter chip: outlined in its severity colour when on, dashed and grey when off."""
    from .theme import is_dark, tone
    c, off = tone(tone_name, is_dark(widget)), tone("idle", is_dark(widget))
    return (f"QToolButton {{ border: 1px dashed {off}; border-radius: 9px; padding: 1px 8px; color: {off}; }}"
            f"QToolButton:checked {{ border: 1px solid {c}; color: {c}; font-weight: 600; }}")


def _when(stamp: str) -> str:
    """'2026-11-20T09:31:00' -> '09:31' today, else '20 Nov'."""
    import datetime as _dt
    try:
        d = _dt.datetime.strptime(stamp[:19], "%Y-%m-%dT%H:%M:%S")
    except ValueError:
        return ""
    return d.strftime("%H:%M") if d.date() == _dt.date.today() else f"{d.day} {d.strftime('%b')}"


class StageTab(QWidget):
    changed = pyqtSignal()          # any flow finished: the dock re-evaluates every tab
    approved = pyqtSignal(str)      # a stage was approved (the dock auto-saves, frontend spec 9.1)

    def __init__(self, iface, stage_ids: list[str], on_busy=None, parent=None):
        super().__init__(parent)
        self.iface, self.stage_ids, self.on_busy = iface, list(stage_ids), on_busy
        self.controller = self.store = None
        self.wayleave_layer = None       # set by the dock: name -> the project's wayleave layer the operator chose
        self.wayleave_chosen = None      # set by the dock: () -> {name: the project's wayleave layer} (2026-10-14)
        self.locked, self.busy = False, False
        self._saving_for = None          # stage whose edits the tab itself is committing (Check/Approve): no auto re-check
        self._tasks: list = []           # keep QgsTasks alive until finished
        self._running = None             # stage whose task runs now (its row shows Stop)
        self.blocked_reason = None       # set by the dock: a client / rules mismatch refuses Generate (spec 9.3)
        self.herotel_block = None        # set by the dock: stage id -> why it waits on a HeroTel value, or None
        self.auto_sink = None            # a list while Auto runs: messages are collected instead of shown
        self._stopped: set = set()       # stages whose last run the planner stopped (spec 4: "Stopped by you")
        self._tick = QTimer(self); self._tick.setInterval(1000); self._tick.timeout.connect(self._on_tick)
        self._log_shown = 0              # lines of the running task already in the Log pane
        self.selected = self.stage_ids[0] if self.stage_ids else None
        self._build()

    # ---------------- layout ----------------
    def _build(self):
        outer = QVBoxLayout(self)
        rows = QWidget(); col = QVBoxLayout(rows); col.setContentsMargins(0, 0, 0, 0); col.setSpacing(0)
        self.sel_group = QButtonGroup(self); self.sel_group.setExclusive(True)
        self.rows: dict[str, dict] = {}
        n = len(self.stage_ids)
        for r, sid in enumerate(self.stage_ids):
            # Frontend spec 3.3: one timeline row per stage; the row is the click target. The radio stays (hidden) so
            # the QButtonGroup keeps exactly one stage selected, as before.
            radio = QRadioButton(words.stage_label(sid, stages.get(sid).name)); radio.setChecked(sid == self.selected)
            radio.toggled.connect(lambda on, s=sid: on and self.select(s))
            radio.hide()
            self.sel_group.addButton(radio)
            line = StageRow(words.stage_label(sid, stages.get(sid).name), first=(r == 0), last=(r == n - 1))
            line.clicked.connect(lambda rb=radio: rb.setChecked(True))
            line.menu_action.connect(lambda action, s=sid: self._row_action(s, action))
            badge = QLabel("-"); badge.hide()                  # kept for support tooltips; the status line replaces it
            row = {"radio": radio, "badge": badge, "line": line}
            for name in BUTTONS:
                b = QPushButton(name.capitalize()); b.setEnabled(False); b.hide()
                b.clicked.connect(lambda _=False, s=sid, n=name: getattr(self, n)(s))
                row[name] = b; line.add_button(b)
            if sid in SCANNED:                    # 0.16.0: a step Scan found drawn, offered as the row's main button
                use = QPushButton("Use my layer"); use.hide()
                use.setToolTip("Take over the layer you drew for this step (picked in Scan) as its approved "
                               "version; its Check still runs and lists issues")
                use.clicked.connect(lambda _=False, s=sid: self.use_drawn(s))
                row["use_drawn"] = use; line.add_button(use)
            load = QPushButton("Put on map"); load.setToolTip("Load this stage's current version into the project")
            load.clicked.connect(lambda _=False, s=sid: self.load(s)); load.hide()
            row["load"] = load; line.add_button(load)
            stop = QPushButton("Stop"); stop.hide(); stop.clicked.connect(self.cancel_tasks)
            row["stop"] = stop; line.add_button(stop)
            col.addWidget(line)
            self.rows[sid] = row
        self.timeline = rows
        self.stale_bar = QWidget(); self.stale_bar.setObjectName("staleBar")
        self.stale_bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True); sb = QHBoxLayout(self.stale_bar); sb.setContentsMargins(6, 4, 6, 4)
        self.stale_text = QLabel(""); self.stale_text.setWordWrap(True)
        self.stale_btn = QPushButton("Redo"); self.stale_btn.clicked.connect(self._redo_first_stale)
        sb.addWidget(self.stale_text, 1); sb.addWidget(self.stale_btn); self.stale_bar.hide()
        outer.addWidget(self.stale_bar)
        outer.addWidget(rows)
        # the operator's own details for the selected stage (2026-10-14): ticked at Approve
        self.details_label = QLabel(""); self.details_label.setWordWrap(True); self.details_label.hide()
        self.details_label.setStyleSheet("QLabel { background: #fff8e1; border: 1px solid #f9a825; padding: 4px; }")
        outer.addWidget(self.details_label)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setPlaceholderText("run.log and check.log of the selected stage")
        self.issues = IssueList(self.iface, self._resolve_issue)
        self.issues.pon_lookup = self._pon_at
        self.issues.toggle_issue = lambda: self.remove_btn.isEnabled() and self._remove_toggle()
        self.issues.pon_lab = self._pon_lab_url
        self._pon_cache = None                            # (gpkg path, mtime, epsg, [(geometry, pon)], index)
        # 0.8.1 (operator walk 2026-10-15): the operator decides whether an issue is a real problem (errors too: 2026-10-16)
        box = QWidget(); bl = QVBoxLayout(box); bl.setContentsMargins(0, 0, 0, 0)
        self.remove_btn = QPushButton("Not a problem"); self.remove_btn.setEnabled(False)
        self.remove_btn.setToolTip("Remove an issue you judge is not a real problem (a warning or an error). It stays "
                                   "off the list, and Approve records it.")
        self.remove_btn.clicked.connect(self._remove_toggle)
        self.issues.currentItemChanged.connect(lambda *_: self._update_remove())
        self.issues.marked.connect(self._update_remove)
        # spec 7: counts in words, Previous / Next through the issues (keys P / N), Not a problem
        nav = QHBoxLayout(); nav.setSpacing(4)
        self.issue_head = QLabel(""); self.issue_head.setWordWrap(True)
        self.prev_btn = QToolButton(); self.prev_btn.setText("\u2039 Previous"); self.prev_btn.setAutoRaise(True)
        self.next_btn = QToolButton(); self.next_btn.setText("Next \u203a"); self.next_btn.setAutoRaise(True)
        self.prev_btn.setToolTip("Previous issue (P)"); self.next_btn.setToolTip("Next issue (N)")
        self.prev_btn.clicked.connect(lambda: self.issues.step(-1)); self.next_btn.clicked.connect(lambda: self.issues.step(1))
        nav.addWidget(self.issue_head, 1); nav.addWidget(self.prev_btn); nav.addWidget(self.next_btn)
        bl.addLayout(nav)
        # spec 7: severity chips with counts, and By check / By PON
        chips = QHBoxLayout(); chips.setSpacing(4)
        self.chip_btns = {}
        for kind, label in (("error", "\u00d7 Errors"), ("warn", "! Warnings"), ("hidden", "Hidden")):
            b = QToolButton(); b.setText(label); b.setCheckable(True); b.setChecked(True)
            b.setToolTip(f"Show or hide {label.split(' ')[-1].lower()} in the list")
            b.toggled.connect(lambda _on: self._chips_changed())
            chips.addWidget(b); self.chip_btns[kind] = b
        chips.addStretch(1)
        self.group_btns = {}
        for how, label in (("type", "By check"), ("pon", "By PON")):
            b = QToolButton(); b.setText(label); b.setCheckable(True); b.setAutoExclusive(True)
            b.setChecked(how == "type")
            b.setToolTip("Group the issues by kind of check" if how == "type" else
                         "Group the issues by the PON they are in, worst first")
            b.clicked.connect(lambda _=False, h=how: self.issues.set_group_by(h))
            chips.addWidget(b); self.group_btns[how] = b
        bl.addLayout(chips)
        self.issues.shown_changed.connect(self._update_nav)
        # spec 7 empty states: a calm message with the one thing to do, instead of a blank box
        self.issue_empty = QWidget(); el = QVBoxLayout(self.issue_empty); el.addStretch(1)
        self.empty_text = QLabel(""); self.empty_text.setWordWrap(True)
        self.empty_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_btn = QPushButton("Check"); self.empty_btn.hide()
        self.empty_btn.clicked.connect(lambda: self.selected and self.check(self.selected))
        el.addWidget(self.empty_text); el.addWidget(self.empty_btn, 0, Qt.AlignmentFlag.AlignHCenter); el.addStretch(2)
        self.issue_stack = QStackedWidget(); self.issue_stack.addWidget(self.issues); self.issue_stack.addWidget(self.issue_empty)
        self.remove_why = QLabel(""); self.remove_why.setWordWrap(True)
        foot = QHBoxLayout(); foot.addWidget(self.remove_btn); foot.addWidget(self.remove_why, 1)
        bl.addWidget(self.issues.why_window); bl.addWidget(self.issue_stack, 1); bl.addLayout(foot)
        # Frontend spec 3.4: issues first; the log is one click away
        self.summary = QLabel(""); self.summary.setWordWrap(True); self.summary.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.summary.setContentsMargins(4, 4, 4, 4)
        # spec 3.4: the Summary pane says what the stage made, and opens the files it made (P7's dead end fixed)
        sumbox = QWidget(); sl = QVBoxLayout(sumbox); sl.setContentsMargins(0, 0, 0, 0)
        self.summary_btns = QHBoxLayout(); self.summary_btns.setSpacing(6)
        self._summary_actions: list[QPushButton] = []
        self.share_btn = QPushButton("Save to SharePoint…"); self.share_btn.hide()
        self.share_btn.setToolTip("Choose a folder (SharePoint or anywhere): the project, all its layers in one "
                                  "GeoPackage and the map images are saved there, so it opens on any laptop")
        self.share_btn.clicked.connect(lambda: self._share_rev is not None and self._save_delivery(self._share_rev))
        self._share_rev = None
        self.share_line = QLabel(""); self.share_line.setWordWrap(True)
        self.share_line.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        sl.addWidget(self.summary); sl.addLayout(self.summary_btns); sl.addWidget(self.share_btn); sl.addWidget(self.share_line); sl.addStretch(1)
        mono = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont); self.log.setFont(mono)
        # Log pane: the text plus Copy and Open folder (spec 3.4)
        logbox = QWidget(); ll = QVBoxLayout(logbox); ll.setContentsMargins(0, 0, 0, 0)
        lbar = QHBoxLayout(); lbar.addStretch(1)
        self.copy_log_btn = QToolButton(); self.copy_log_btn.setText("Copy"); self.copy_log_btn.setAutoRaise(True)
        self.copy_log_btn.setToolTip("Copy the log, for support")
        self.copy_log_btn.clicked.connect(lambda: QApplication.clipboard().setText(self.log.toPlainText()))
        self.folder_log_btn = QToolButton(); self.folder_log_btn.setText("Open folder"); self.folder_log_btn.setAutoRaise(True)
        self.folder_log_btn.setToolTip("Open this version's folder (logs, checks, layers)")
        self.folder_log_btn.clicked.connect(self._open_rev_folder)
        lbar.addWidget(self.copy_log_btn); lbar.addWidget(self.folder_log_btn)
        ll.addLayout(lbar); ll.addWidget(self.log, 1)
        self.pane = QStackedWidget(); self.pane.addWidget(box); self.pane.addWidget(sumbox); self.pane.addWidget(logbox)
        self.pane.setMinimumHeight(160)
        seg = QHBoxLayout(); seg.setSpacing(0)
        self.pane_btns = {}
        for i, (key, label) in enumerate((("issues", "Issues"), ("summary", "Summary"), ("log", "Log"))):
            b = QToolButton(); b.setText(label); b.setCheckable(True); b.setAutoExclusive(True)
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
            b.clicked.connect(lambda _=False, k=key: self.show_pane(k))
            seg.addWidget(b); self.pane_btns[key] = b
        seg.addStretch(1)
        self.pane_btns["issues"].setChecked(True)
        for b in self.pane_btns.values():
            b.setAutoRaise(True)
            b.setStyleSheet("QToolButton { padding: 3px 10px; border: none; border-bottom: 2px solid transparent; }"
                            "QToolButton:checked { border-bottom: 2px solid palette(highlight); font-weight: 600; }")
        outer.addLayout(seg)
        outer.addWidget(self.pane, 1)

    # ---------------- state ----------------
    def set_site(self, controller, store, locked: bool):
        self.controller, self.store, self.locked = controller, store, locked
        self.busy = False
        self.refresh()

    def refresh(self):
        """Every row's dot, status line and ONE main button come from row_view.view(); the buttons themselves keep
        their old enabled rule (controller.next_enabled), so nothing can be pressed that could not be before."""
        usable = self.controller is not None and not self.locked and not self.busy
        state = self.store.load()["stages"] if self.controller is not None else {}
        for sid, row in self.rows.items():
            s = state.get(sid, {})
            status = s.get("status", "-")
            try:                                           # one bad row must never freeze the whole tab
                en = self.controller.next_enabled(sid) if usable else {}
            except Exception as e:                         # noqa: BLE001
                en = {}
                row["badge"].setToolTip(f"status: {status}\n{type(e).__name__}: {e}")
            for name in BUTTONS:
                row[name].setEnabled(bool(en.get(name)))
            try:
                self._update_load(sid, row, s, usable)
            except Exception:                              # noqa: BLE001
                row["load"].setEnabled(False)
            try:
                self._update_use_drawn(sid, row, state, usable)
            except Exception:                              # noqa: BLE001
                if "use_drawn" in row:
                    row["use_drawn"].setEnabled(False)
            try:
                facts = self._row_facts(sid, s, state, en)
                v = row_view(facts)
            except Exception as e:                         # noqa: BLE001
                from .row_view import RowView
                v = RowView("error", "\u2715", f"Could not read this stage ({type(e).__name__})")
            row["badge"].setText(words.status_label(status))
            self._show_main(row, v)
            row["line"].show_view(v, status)
            row["line"].set_progress(None if (self.busy and self._running == sid) else -1)
            row["line"].set_selected(sid == self.selected)
        self._update_stale_bar(state, usable)
        try:
            self._show_selected()
        except Exception as e:                             # noqa: BLE001
            self.log.setPlainText(f"could not show the selected stage: {type(e).__name__}: {e}")

    def _update_stale_bar(self, state: dict, usable: bool):
        """Spec 9.4: one banner when any stage is out of date, naming the cause, with Redo from the first one."""
        stale = [s for s in self.stage_ids if state.get(s, {}).get("status") == "stale"]
        if not stale:
            self.stale_bar.hide(); return
        first = stale[0]
        why = []
        try:
            why = _stale_reasons(approval.can_approve(self.store, first))
        except Exception:                                  # noqa: BLE001
            pass
        names = [words.stage_label(s).split(" ")[0] for s in stale]
        cause = why[0].replace(" changed", "") if why and why[0].endswith(" changed") else ""
        verb = "is" if len(names) == 1 else "are"
        self.stale_text.setText(f"{' and '.join([', '.join(names[:-1]), names[-1]] if len(names) > 1 else names)} {verb} out of date"
                                + (f" because {cause} changed." if cause else "."))
        from .theme import is_dark, tone
        c = tone("warn", is_dark(self))
        self.stale_bar.setStyleSheet(f"#staleBar {{ border: 1px solid {c}; border-radius: 6px; }}")
        self.stale_text.setStyleSheet(f"color: {c};")
        self.stale_btn.setText(f"Redo from {names[0]}")
        try:
            can = usable and bool(self.controller.next_enabled(first).get("generate"))
        except Exception:                                  # noqa: BLE001
            can = False
        self.stale_btn.setVisible(can)
        self._first_stale = first
        self.stale_bar.show()

    def _redo_first_stale(self):
        if getattr(self, "_first_stale", None):
            self.generate(self._first_stale)

    def _show_main(self, row: dict, v):
        """Exactly one button in the row's slot is visible: the view's main action, relabelled."""
        for key in (*BUTTONS, "use_drawn", "load", "stop"):
            b = row.get(key)
            if b is None:
                continue
            on = key == v.main
            b.setVisible(on)
            if on:
                from .theme import is_dark, primary_button, quiet_button
                dark = is_dark(self)
                b.setStyleSheet(quiet_button(dark, "error") if key == "stop" else
                                quiet_button(dark, "idle") if key == "load" else primary_button(dark))
                if v.main_label:
                    b.setText(v.main_label if key != "use_drawn" else b.text())
                if key == "stop":
                    b.setEnabled(True)

    def _row_facts(self, sid: str, s: dict, state: dict, en: dict) -> RowFacts:
        rev = self.store.rev_dir(sid, s["current_rev"]) if self.store is not None and s.get("current_rev") else None
        f = RowFacts(stage_id=sid, status=s.get("status", "-"), enabled=en, locked=self.locked, busy=self.busy,
                     wayleave_ok=state.get("wayleave", {}).get("status") == "approved")
        f.deps_waiting = [d for d in stages.get(sid).deps if state.get(d, {}).get("status") != "approved"]
        f.running = self.busy and self._running == sid
        f.stopped = sid in self._stopped
        if f.running:
            task = self._running_task()
            if task is not None:
                f.progress_text = progress.running_line(sid, time.time() - task.started, getattr(self, "_history", []),
                                                        task.lines)
        f.load_needed = bool(self.rows[sid]["load"].isEnabled())
        use = self.rows[sid].get("use_drawn")
        if use is not None and use.isEnabled():
            f.drawn_names = use.text().split("(", 1)[-1].rstrip(")") if "(" in use.text() else ""
        if rev is None:
            return f
        f.taken_over = (rev / "takeover.json").exists()
        cj = rev / "checks.json"
        if cj.exists():
            f.has_checks = True
            report = ChecksReport.load(cj)
            shown, removed, _fixed = dismiss.split_how(report, rev)
            f.hidden = len(removed)
            from ..core.issues import group_report
            from .issue_list import tally
            n_err, f.warnings = tally(group_report(ChecksReport(report.checks, shown, report.dropped)))
            if self._has_blocking(sid, s):
                f.errors = max(1, n_err)                  # the same count as the issue pane and its chips
        ap = rev / "approval.json"
        if ap.exists():
            try:
                rec = json.loads(ap.read_text(encoding="utf-8"))
                f.overridden = len(rec.get("overridden_checks") or [])
                f.hidden = len(rec.get("issues_removed") or []) or f.hidden
                f.approved_when = _when(rec.get("when", ""))
            except (OSError, ValueError, TypeError):
                pass
        if f.status == "stale":
            f.stale_reasons = _stale_reasons(approval.can_approve(self.store, sid))
        if f.status in ("failed", "rejected"):
            f.note = s.get("note") or ""
            if f.status == "failed" and (rev / "run.log").exists():
                f.note = re.sub(r"^\w+(Error|Exception|Refusal): ", "", words.last_useful_line(
                    (rev / "run.log").read_text(encoding="utf-8", errors="replace")))[:90]
        return f

    def _running_task(self):
        return next((t for t in self._tasks if getattr(t, "stage_id", None) == self._running), None)

    def _on_tick(self):
        """Once a second while a stage runs: its row's status line, and the Log pane follows the log live."""
        task = self._running_task()
        if task is None or self._running not in self.rows:
            return
        text = progress.running_line(self._running, time.time() - task.started, getattr(self, "_history", []), task.lines)
        row = self.rows[self._running]
        row["line"].status.setText(text)
        row["line"].set_progress(task.progress() or None)
        if self.selected == self._running and self.pane.currentIndex() == 2:
            new = task.lines[self._log_shown:]
            if new:
                self.log.appendPlainText("\n".join(new)); self._log_shown += len(new)

    def show_pane(self, key: str):
        idx = {"issues": 0, "summary": 1, "log": 2}[key]
        self.pane.setCurrentIndex(idx)
        self.pane_btns[key].setChecked(True)

    def _row_action(self, sid: str, action: str):
        """A ⋯ menu pick: the same handler the old button called, or the log view."""
        if action == "log":
            self.select(sid); self.rows[sid]["radio"].setChecked(True)
            self.show_pane("log")
            return
        getattr(self, action)(sid)

    def _update_load(self, sid: str, row: dict, s: dict, usable: bool):
        """After a restart the project may not hold a stage's current revision: offer Load (never auto-load). Never for
        a taken-over revision: the operator's own layer is the one on the map (operator 2026-11-06, no double layers)."""
        rev = self.store.rev_dir(sid, s["current_rev"]) if self.store is not None and s.get("current_rev") else None
        need = (rev is not None and (rev / "working.gpkg").exists() and not (rev / "takeover.json").exists()
                and layers.find_stage_group(self.store.site, stages.get(sid), rev.name) is None)
        row["load"].setVisible(bool(need))
        row["load"].setEnabled(bool(need) and usable)

    def load(self, stage_id: str):
        stage, store = stages.get(stage_id), self.store
        rev = self._rev(stage_id)
        if rev is None:
            return
        editable = store.stage_state(stage_id)["status"] != "approved"
        self._complete(stage_id, f"{stage.name}: load",
                       lambda: self._load_layers(stage_id, store.site, stage, rev, editable=editable))

    def _load_layers(self, stage_id: str, site: str, stage, rev: Path, editable: bool):
        grp = layers.load_stage(self.iface, site, stage, rev, editable=editable)
        layers.on_commit(layers.group_layers(grp), lambda s=stage_id: self._saved(s))
        return grp

    def _saved(self, stage_id: str):
        """A stage layer was saved by the operator: re-run its Check so fixed errors disappear and the fresh
        checks make Approve available (ruling 2026-10-08). Not when the tab itself is saving for Check/Approve."""
        if self._saving_for == stage_id or self.busy or self.locked or self.controller is None:
            return
        if self.store.stage_state(stage_id)["status"] in ("approved", "pending"):
            return
        QTimer.singleShot(0, lambda: None if self.busy else self.check(stage_id))

    def select(self, stage_id: str):
        self.selected = stage_id
        for sid, row in self.rows.items():
            row["line"].set_selected(sid == stage_id)
        self._show_selected()

    def _rev(self, stage_id: str, store=None) -> Path | None:
        store = store or self.store
        if store is None:
            return None
        cur = store.stage_state(stage_id)["current_rev"]
        return store.rev_dir(stage_id, cur) if cur else None

    def _group(self, stage_id: str, store=None):
        store = store or self.store
        rev = self._rev(stage_id, store)
        return layers.find_stage_group(store.site, stages.get(stage_id), rev.name) if rev else None

    def _show_details(self):
        details = approval.stage_details(self.store, self.selected) if self.store is not None and self.selected else []
        self.details_label.setVisible(bool(details))
        self.details_label.setText(f"<b>Operator details for this stage ({len(details)})</b>: each is ticked as "
                                   f"checked against the plan at Approve.<br>" +
                                   "<br>".join(f"• {html.escape(x['detail'])}" for x in details))

    def _empty(self, text: str, button: str = ""):
        """Spec 7: the issue pane's empty state, with at most one button (only when it can be pressed)."""
        from .theme import is_dark, primary_button, tone
        self.empty_text.setText(text)
        self.empty_text.setStyleSheet(f"color: {tone('idle', is_dark(self))};")
        self.empty_btn.setVisible(bool(button))
        if button:
            self.empty_btn.setText(button); self.empty_btn.setStyleSheet(primary_button(is_dark(self)))
        self.issue_stack.setCurrentIndex(1)
        for b in (*self.chip_btns.values(), *self.group_btns.values(), self.prev_btn, self.next_btn):
            b.setVisible(False)

    def _pon_lab_url(self, pon):
        from .dock import pon_lab_url
        return pon_lab_url(self.store.site, pon) if self.store is not None else None

    def _chips_changed(self):
        self.issues.set_filter([k for k, b in self.chip_btns.items() if b.isChecked()])

    def _update_nav(self):
        has = bool(self.issues.issue_rows())
        self.prev_btn.setEnabled(has); self.next_btn.setEnabled(has)

    def _pon_at(self, issue):
        """Spec 7 Group by PON, last resort: the PON whose area holds the issue's point, from the approved wayleave
        snapshot's pons layer (field pon_num, site coordinates). Read once per snapshot file."""
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsGeometry,
            QgsPointXY,
            QgsProject,
            QgsSpatialIndex,
            QgsVectorLayer,
        )
        if self.store is None or issue.x is None or issue.y is None:
            return None
        gpkg = self.store.approved_gpkg("wayleave")
        if gpkg is None or not gpkg.exists():
            return None
        epsg = int(self.store.load()["epsg"])
        key = (str(gpkg), gpkg.stat().st_mtime, epsg)
        if self._pon_cache is None or self._pon_cache[0] != key:
            lyr = QgsVectorLayer(f"{gpkg}|layername=pons", "pons", "ogr")
            polys, index = {}, QgsSpatialIndex()
            if lyr.isValid() and lyr.fields().indexOf("pon_num") >= 0:
                for f in lyr.getFeatures():
                    try:
                        polys[f.id()] = (QgsGeometry(f.geometry()), int(f["pon_num"]))
                    except (TypeError, ValueError):
                        continue
                    index.addFeature(f)
            self._pon_cache = (key, polys, index)
        _key, polys, index = self._pon_cache
        pt = QgsPointXY(issue.x, issue.y)
        if issue.epsg and int(issue.epsg) != epsg:
            tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem(f"EPSG:{int(issue.epsg)}"),
                                        QgsCoordinateReferenceSystem(f"EPSG:{epsg}"), QgsProject.instance())
            pt = tr.transform(pt)
        g = QgsGeometry.fromPointXY(pt)
        for fid in index.intersects(g.boundingBox()):
            if fid in polys and polys[fid][0].contains(g):
                return polys[fid][1]
        return None

    def _show_selected(self):
        self._show_details()
        self.log.clear(); self.issues.clear(); self.issues.why_window.hide()
        self.summary.setText("Nothing made yet for this stage.")
        for b in self._summary_actions:
            self.summary_btns.removeWidget(b); b.hide(); b.setParent(None); b.deleteLater()
        self._summary_actions = []
        self.issue_head.setText(""); self.remove_why.setText("")
        self.prev_btn.setEnabled(False); self.next_btn.setEnabled(False)
        self.pane_btns["issues"].setText("Issues")
        rev = self._rev(self.selected) if self.selected else None
        if rev is None:
            self._empty("Nothing made yet for this stage." if self.selected else "Pick a stage above.")
            return
        parts = [f"===== {n} =====\n" + (rev / n).read_text(encoding="utf-8", errors="replace")
                 for n in LOGS if (rev / n).exists()]
        tk = rev / "takeover.json"                        # 0.16.0: say where a taken-over layer came from
        if tk.exists():
            try:
                names = [x["name"] for ls in json.loads(tk.read_text(encoding="utf-8"))["layers"].values() for x in ls]
                parts.insert(0, f"Drawn by hand (layer {', '.join(names)}), taken over by Scan\n")
            except (OSError, ValueError, KeyError, TypeError):
                parts.insert(0, "Drawn by hand, taken over by Scan\n")
        self.log.setPlainText("\n".join(parts) if parts else "(no run.log or check.log)")
        self._show_summary(rev)
        cj = rev / "checks.json"
        if not cj.exists():
            try:
                can = bool(self.controller.next_enabled(self.selected).get("check")) and not self.busy and not self.locked
            except Exception:                            # noqa: BLE001
                can = False
            running = self.busy and self._running == self.selected
            st_now = self.store.stage_state(self.selected).get("status") if self.store is not None else None
            self._empty("Checking\u2026 the issues appear here when it finishes." if running else
                        "No check results are saved for this version." if st_now in ("checked", "approved") else
                        "Not checked yet." + (" Press Check to find what needs fixing." if can else ""),
                        "Check" if can and not running else "")
            return
        self.issue_stack.setCurrentIndex(0)
        self.prev_btn.setVisible(True); self.next_btn.setVisible(True)
        try:
            report = ChecksReport.load(cj)
        except Exception as e:                           # noqa: BLE001 - a bad file must not break the tab
            self.issues.addItem(QListWidgetItem(f"checks.json unreadable: {type(e).__name__}: {e}"))
            return
        shown, removed, fixed = dismiss.split_how(report, rev)
        self.issues.set_report(ChecksReport(report.checks, shown, report.dropped), removed=removed, fixed=fixed)
        self.pane_btns["issues"].setText(f"Issues ({len(shown)})")
        err, warn_n = self.issues.counts()
        parts = [f"{err} error{'s' if err != 1 else ''}"] if err else []
        parts += [f"{warn_n} warning{'s' if warn_n != 1 else ''}"] if warn_n else []
        import datetime as _dt
        when = _dt.datetime.fromtimestamp(cj.stat().st_mtime)
        self.issue_head.setText(f"{words.stage_label(self.selected)} \u00b7 " + (" \u00b7 ".join(parts) or "no issues")
                                + f" \u00b7 checked {when:%H:%M}" + ("" if when.date() == _dt.date.today() else f" {when.day} {when:%b}"))
        n_hidden = len(self.issues.removed)
        for kind, label, n in (("error", "\u00d7 Errors", err), ("warn", "! Warnings", warn_n), ("hidden", "Hidden", n_hidden)):
            b = self.chip_btns[kind]; b.setText(f"{label} {n}"); b.setVisible(n > 0)
            b.setStyleSheet(_chip_style({'error': 'error', 'warn': 'warn'}.get(kind, 'idle'), self))
        any_issue = bool(err or warn_n)
        for b in self.group_btns.values():
            b.setVisible(any_issue)
        self._chips_changed()
        self._update_nav()
        self._update_remove()

    def _show_summary(self, rev: Path):
        """Plain facts, then Open buttons for what the stage made (Delivery: the project and the map images)."""
        for b in self._summary_actions:
            self.summary_btns.removeWidget(b); b.hide(); b.setParent(None); b.deleteLater()
        self._summary_actions = []
        self.share_line.setText(""); self.share_btn.hide(); self._share_rev = None
        text = _summary(rev)
        if self.selected == "p8_delivery":
            facts, actions = _delivery_facts(rev)
            if facts:
                text = "\n".join(facts) + ("\n\n" + text if text != "No summary for this version yet." else "")
            for label, path, tip in actions:
                b = QPushButton(label); b.setToolTip(tip)
                b.clicked.connect(lambda _=False, pth=path: self._open_path(pth))
                self.summary_btns.addWidget(b); self._summary_actions.append(b)
            if any(a[0] == "Open project" for a in actions):
                from .theme import is_dark, primary_button
                self._share_rev = rev
                self.share_btn.setStyleSheet(primary_button(is_dark(self))); self.share_btn.show()
        b = QPushButton("Open folder"); b.setToolTip("Open this version's folder")
        b.clicked.connect(self._open_rev_folder)
        self.summary_btns.addWidget(b); self._summary_actions.append(b)
        self.summary.setText(text)

    def _save_delivery(self, rev: Path):
        """JJ 2026-11-26: pick a folder in File Explorer; the delivery is packaged there (qgis/delivery_package)."""
        from qgis.core import QgsSettings
        from qgis.PyQt.QtWidgets import QFileDialog

        from .delivery_package import package_delivery
        key = "plan_stages/ui/delivery_save_dir"
        start = QgsSettings().value(key, "", type=str) or ""
        if not start or not Path(start).is_dir():
            org = [d for d in Path.home().iterdir() if d.is_dir() and "." in d.name and not d.name.startswith(".")]                 if Path.home().is_dir() else []
            start = str(org[0] if org else Path.home())
        parent = QFileDialog.getExistingDirectory(self, "Choose where to save the delivery", start)
        if not parent:
            return
        QgsSettings().setValue(key, parent)

        def step(i, n, name):
            self.share_line.setText(f"Saving {i} of {n}: {name}…")
            QApplication.processEvents()
        self.share_line.setText("Saving…"); QApplication.processEvents()
        try:
            out, skipped = package_delivery(rev, Path(parent), self.store.site, on_step=step)
        except Exception as e:                           # noqa: BLE001 - say it, never crash the dock
            self.share_line.setText("")
            self._say("Save the delivery", f"Could not save the delivery: {e}")
            return
        line = f"✓ Saved to {out}"
        if skipped:
            line += "\nLeft as they were: " + "; ".join(skipped)
        self.share_line.setText(line)
        self._open_path(out)

    def _open_path(self, path: Path):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _open_rev_folder(self):
        rev = self._rev(self.selected) if self.selected else None
        if rev is not None:
            self._open_path(rev)

    def _update_remove(self):
        """Remove is offered on a shown issue with a fingerprint (a warning or an error); Restore on a removed row. Never on an approved
        stage (its record is closed: Revise first), nor while locked or busy."""
        issue, removed = self.issues.current()
        st = self.store.stage_state(self.selected)["status"] if self.store is not None and self.selected else None
        edited = self.issues.current_edited()
        ok = (issue is not None and not self.locked and not self.busy and st not in (None, "approved") and not edited
              and (removed or bool(issue.geom_hash)))
        self.remove_btn.setEnabled(bool(ok))
        self.remove_btn.setText("Bring back" if removed else "Not a problem")
        self.remove_why.setText("You edited this. Check again first." if edited and issue is not None else "")
        self.remove_btn.setToolTip("You edited this feature: Check again first. If the Check still finds the issue it "
                                   "stays crossed out as fixed by you." if edited else
                                   "Remove an issue you judge is not a real problem (a warning or an error). It stays "
                                   "off the list, and Approve records it.")

    def _remove_toggle(self):
        issue, removed = self.issues.current()
        rev = self._rev(self.selected)
        if issue is None or rev is None:
            return
        try:
            (dismiss.restore if removed else dismiss.add)(rev, issue)
        except ValueError as e:
            self._say("Remove issue", str(e)); return
        self._show_selected()
        self.refresh()                                   # a failed check whose issues are all removed no longer stops Approve

    def _resolve_issue(self, issue: Issue):
        """The loaded layer an issue of the selected stage lives in: this stage's group for source "working", else
        the loaded group of the dependency stage it names; a wayleave issue falls back to the project layer the
        operator chose in the Wayleave box."""
        if self.store is None or self.selected is None:
            return None
        if issue.source == "working":
            grp = self._group(self.selected)
        else:
            grp = layers.find_stage_group(self.store.site, stages.get(issue.source)) if issue.source in stages.order() else None
        if grp is not None:
            for child in grp.findLayers():
                if child.layer() is not None and child.layer().name() == issue.layer:
                    return child.layer()
        if issue.source == "wayleave" and self.wayleave_layer is not None:
            return self.wayleave_layer(issue.layer)
        return None

    def _say(self, title: str, text: str, details: str = ""):
        """Every message of the stage flows. While Auto runs (auto_sink set) it is collected, not shown in a box: the
        run reads it and stops with it (spec 5). Otherwise the usual warning box."""
        if self.auto_sink is not None:
            self.auto_sink.append((title, text, details))
            return
        warn(self, title, text, details)

    def _set_busy(self, busy: bool):
        self.busy = busy
        try:
            self.refresh()
        finally:
            if self.on_busy is not None:
                self.on_busy()

    def _has_blocking(self, stage_id: str, s: dict) -> bool:
        """A drawn stage whose last check has blocking failures reads "Needs fixes", not "Drawn · check it"."""
        if s.get("status") != "generated" or not s.get("current_rev") or self.store is None:
            return False
        try:
            cj = self.store.rev_dir(stage_id, s["current_rev"]) / "checks.json"
            return cj.exists() and any(c.status == "failed" for c in ChecksReport.load(cj).blocking())
        except Exception:                                  # noqa: BLE001 - a badge never breaks the tab
            return False

    def _flow_done(self, stage_id: str):
        self.selected = stage_id
        try:
            self.rows[stage_id]["radio"].setChecked(True)
        finally:
            try:
                self._set_busy(False)
            finally:
                self.changed.emit()

    def _complete(self, stage_id: str, title: str, body):
        """Run a completion body; any exception is shown and the tab always recovers."""
        try:
            body()
        except Exception as e:                           # noqa: BLE001 - never leave the tab wedged
            self._say(title, words.explain_exception(e), f"{type(e).__name__}: {e}")
        finally:
            self._flow_done(stage_id)

    def _launch(self, desc, cmd, env, log_path, on_done, stage_id=None):
        task = None
        self._running = stage_id
        if stage_id:
            self._stopped.discard(stage_id)

        def done(rc, text):
            self._running = None
            self._tick.stop()
            if task is not None and stage_id:
                if task.stopped_by_user:
                    self._stopped.add(stage_id)
                elif rc == 0 and "generate" in desc:
                    progress.remember(stage_id, time.time() - task.started)
            if task in self._tasks:
                self._tasks.remove(task)
            on_done(rc, text)
        task = SubprocessTask(desc, cmd, env, log_path, done, stage_id=stage_id)
        self._tasks.append(task)
        self._log_shown = 0
        if stage_id:
            self._history = progress.history(stage_id) if "generate" in desc else []
            self._tick.start()
        self._set_busy(True)
        QgsApplication.taskManager().addTask(task)

    def cancel_tasks(self):
        for task in list(self._tasks):
            task.cancel()

    # ---------------- Generate ----------------
    def wayleave_changes(self) -> list[str]:
        """Differences between the wayleave on screen and the approved snapshot (2026-10-14, D-PS.8); [] when the
        same, or when there is nothing to compare (no approved wayleave, or no Wayleave box wired)."""
        import tempfile

        from ..core import wayleave_diff
        from .wayleave_box import write_snapshot
        ap = self.store.approved_gpkg("wayleave") if self.store is not None else None
        if ap is None or not ap.exists() or self.wayleave_chosen is None:
            return []
        chosen = self.wayleave_chosen()
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            screen = Path(d) / "screen.gpkg"
            write_snapshot(screen, chosen, self.store.load()["epsg"])
            return wayleave_diff.diff(ap, screen, set(chosen))

    def generate(self, stage_id: str):
        stage = stages.get(stage_id)
        if self.blocked_reason:
            self._say(f"{stage.name}: generate", self.blocked_reason)
            return
        why = self.herotel_block(stage_id) if self.herotel_block is not None else None
        if why:                                           # spec 9.3.4: a borrowed value is kept or changed first
            self._say(f"{stage.name}: generate", why)
            return
        ctl, store = self.controller, self.store          # completions bind to the site that launched them
        # Operator 2026-11-12: a step whose layer the operator already has in the project never gets a second one.
        # Their layer stays, is taken over as the step's approved version, and the plan moves on to the next step.
        if stage_id in SCANNED:
            drawn = self.drawn_layers(stage_id)
            if drawn:
                names = ", ".join(dict.fromkeys(l.name() for ls in drawn.values() for l in ls))
                self.use_drawn(stage_id, why=f"Your layer ({names}) is this step's layer, so nothing new is drawn: "
                                             f"it stays as it is and is taken over as {stage.name}'s approved "
                                             f"version (its Check still runs).")
                return
            found = self.existing_layers(stage_id)
            if found:
                self._say(f"{stage.name}: generate",
                     f"Your project already has {', '.join(found)} for this step, so Generate would add a second "
                     f"layer beside it. Press Use what I've drawn… in the Wayleave box: keep it ticked to use "
                     f"your layer for this step" + self._missing_text(stage_id) + ", or untick it there to have the "
                     "plugin draw this step.")
                return
        try:
            changes = self.wayleave_changes()
        except Exception as e:                            # noqa: BLE001 - a broken comparison must not pass silently
            changes = [f"could not compare the wayleave on screen: {type(e).__name__}: {e}"]
        if changes:
            self._say(f"{stage.name}: generate", "The wayleave on screen differs from the approved snapshot:\n\n" +
                 "\n".join(changes) + "\n\nFirst check the Wayleave box shows the layers the snapshot was taken "
                 "from. Only if you really changed the wayleave, press Use this wayleave again (every started "
                 "stage goes stale), then Generate.")
            return
        if stage.generator is None:                       # a manual re-generate copies the saved drawing
            grp = self._group(stage_id)
            if grp is not None and layers.has_unsaved_edits(grp):
                self._say(f"{stage.name}: generate", "The layers have unsaved edits. Save or discard them first.")
                return
            if not self._flush(stage_id, "generate"):
                return
        try:
            rev, cmd, env = ctl.begin_generate(stage_id)
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            self._say(f"{stage.name}: generate", words.explain_exception(e), f"{type(e).__name__}: {e}")
            self.refresh()
            return
        if cmd is None:                                   # manual stage: editable layers (seeded after rev 1)
            self._complete(stage_id, f"{stage.name}: generate",
                           lambda: self._load_layers(stage_id, store.site, stage, rev, editable=True))
            return
        self._launch(f"{store.site}: generate {stage.name}", cmd, env, rev / "run.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: generate",
                                                     lambda: self._generate_result(ctl, store, stage_id, rev, rc, text)),
                     stage_id=stage_id)

    def _generate_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str):
        stage = stages.get(stage_id)
        if ctl.finish_generate(stage_id, rev, rc, log):
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        elif stage_id in self._stopped:                   # spec 4: the planner pressed Stop; not a failure to report
            return
        else:
            last = words.last_useful_line(log)
            self._say(f"{stage.name}: generate failed",
                 f"{words.stage_label(stage_id, stage.name)} could not finish." + (f"\n\n{last}" if last else "") +
                 "\n\nPress Generate to try again. If it fails twice, send Show details to support.",
                 f"rc={rc}\n\n{tail(log)}")

    # ---------------- Check ----------------
    def check(self, stage_id: str):
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        grp = self._group(stage_id)
        if grp is not None and not layers.save_all_edits(grp):
            self._say(f"{stage.name}: check", "Saving the layer edits failed; fix the edits and Check again.")
            return
        if not self._flush(stage_id, "check"):
            return
        assigned = []
        if stage_id == "p4_drops":                        # 2026-10-14: number hand-drawn collection points first
            rev_now = self._rev(stage_id)
            if rev_now is not None and (rev_now / "working.gpkg").exists():
                assigned = assign_cp_ids(grp, rev_now / "working.gpkg")
                self._flush(stage_id, "check")
        try:
            rev, cmd, env = ctl.begin_check(stage_id)     # hashes working.gpkg as the Check starts
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            self._say(f"{stage.name}: check", words.explain_exception(e), f"{type(e).__name__}: {e}")
            return
        start = ctl.check_start.get(stage_id)
        cj = rev / "checks.json"                          # never let an old report stand in for this run
        if cj.exists():
            cj.unlink()
        store.set_stage(stage_id, checked_hash=None)
        self._launch(f"{store.site}: check {stage.name}", cmd, env, rev / "check.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: check",
                                                     lambda: self._check_result(ctl, store, stage_id, rev, rc, text,
                                                                                start, assigned)),
                     stage_id=stage_id)

    def _check_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str, start: str | None = None,
                      assigned: list | None = None):
        stage = stages.get(stage_id)
        if assigned:
            lg = rev / "check.log"
            old = lg.read_text(encoding="utf-8", errors="replace") if lg.exists() else ""
            lg.write_text("\n".join(assigned) + "\n" + old, encoding="utf-8")
        cj = rev / "checks.json"
        # rc != 0 with blocking checks in checks.json is a normal failing check (checks/common.main exits 1).
        # rc != 0 with no report, or with a report claiming success, is a crashed check: never trust it.
        report = ChecksReport.load(cj) if cj.exists() else None
        if rc != 0 and (report is None or report.ok()):
            if cj.exists():
                cj.unlink()
            self._say(f"{stage.name}: check failed",
                 f"The check for {words.stage_label(stage_id, stage.name)} stopped before it finished. Press Check "
                 f"again. If it happens twice, send Show details to support.",
                 f"The check exited rc={rc} without a usable checks.json.\n\n{tail(log)}")
            return
        report = ctl.finish_check(stage_id, rev, rc, log, start_hash=start)
        if report is None:                               # no checks.json: the check itself failed
            self._say(f"{stage.name}: check failed",
                 f"The check for {words.stage_label(stage_id, stage.name)} left no result. Press Check again.",
                 f"The check wrote no checks.json (rc={rc}).\n\n{tail(log)}")
            return
        if ctl.last_warning:
            self._say(f"{stage.name}: check", words.explain_one(ctl.last_warning), ctl.last_warning)
        layers.load_issues(self.iface, store.site, stage, rev)

    def _flush(self, stage_id: str, what: str) -> bool:
        rev = self._rev(stage_id)
        if rev is None or layers.flush_wal(rev / "working.gpkg"):
            return True
        self._say(f"{stages.get(stage_id).name}: {what}",
             "The layer is still being saved. Wait a moment and try again.",
             "Could not checkpoint working.gpkg (another program is writing it).")
        return False

    # ---------------- Approve / Reject ----------------
    def approve(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            later = [words.stage_label(d).split(" ")[0] for d in stages.downstream_of(stage_id)
                     if self.store.stage_state(d)["status"] not in ("pending",)]
            if later and not ask_yes_no(self, f"Approve {stage.name}?",
                                        f"Approving {words.stage_label(stage_id)} again makes {', '.join(later)} out of "
                                        f"date. They will need to be made again.\n\nApprove?"):
                return
            note = _default_note()                       # spec 3.3: no forced typing; a reason is asked only to override
        if not note.strip():
            self._say(f"Approve {stage.name}", "An approval note is required.")
            return
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            self._say(f"Approve {stage.name}", "The layers have unsaved edits. Check again (it saves them) first.")
            return
        if not self._flush(stage_id, "approve"):
            return
        details = approval.stage_details(self.store, stage_id)
        checked = []
        if details:
            checked = confirm_details(self, stage.name, details)
            if checked is None:
                return

        def body():
            refusals = self.controller.approve(stage_id, note.strip(), details_checked=checked)
            if refusals:
                checks, hard = self.controller.approve_blockers(stage_id)
                if hard or not checks:
                    self._say(f"Approve {stage.name} refused", "\n".join(words.explain_reasons(refusals)),
                         "\n".join(refusals))
                    return
                # Operator ruling 2026-10-07: failed checks ask, they do not block. The override is recorded.
                # Spec 10: the typed reason is required here: it is the override on record.
                reason = ask_note(self, f"Approve {stage.name} with failed checks?",
                                  "These checks fail:\n\n" + "\n".join(words.explain_reasons(checks)) +
                                  "\n\nWhy is this OK? Your reason is kept on record.")
                if reason is None or not reason.strip():
                    return
                # a new name: assigning `note` here would make it local to body() (UnboundLocalError above)
                on_record = f"{note.strip()} \u2014 {reason.strip()}" if note.strip() != reason.strip() else note.strip()
                refusals = self.controller.approve(stage_id, on_record, override=reason.strip(), details_checked=checked)
                if refusals:
                    self._say(f"Approve {stage.name} refused", "\n".join(words.explain_reasons(refusals)),
                         "\n".join(refusals))
                    return
            grp_now = self._group(stage_id)
            if grp_now is not None:                       # approved layers are a record; Revise to change them
                layers.set_group_readonly(grp_now, True)
            self.approved.emit(stage_id)
        self._complete(stage_id, f"Approve {stage.name}", body)

    # ---------------- Revise ----------------
    def revise(self, stage_id: str):
        """Rev N+1 = an editable copy of the latest approved layer (else the current working layer). A step taken over
        from the operator's own layer is never copied onto the map (2026-11-12, no double layers): Revise takes their
        layer over again, as it is now."""
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        rev_now = self._rev(stage_id)
        if stage_id in SCANNED and rev_now is not None and (rev_now / "takeover.json").exists():
            if self.drawn_layers(stage_id):
                self.use_drawn(stage_id, why=f"{stage.name} is your own layer: edit it in your project, and Revise "
                                             f"takes it over again as it is now (no copy is added to the map).")
            else:
                self._say(f"Revise {stage.name}", "This step is your own layer, taken over by Scan, and the layer you "
                                                   "picked is no longer in the project or has no features. Add it back "
                                                   "and Scan again, or Remove this revision to have the plugin draw "
                                                   "the step.")
            return
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            self._say(f"Revise {stage.name}", "The layers have unsaved edits. Save or discard them first.")
            return
        if not self._flush(stage_id, "revise"):
            return

        def body():
            rev = ctl.begin_revise(stage_id)
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        self._complete(stage_id, f"Revise {stage.name}", body)

    # ---------------- Remove ----------------
    def remove(self, stage_id: str, confirmed: bool = False):
        """Operator ruling 2026-10-07: delete the stage's current revision and its layers from the project.
        The stage falls back to its previous revision, or to pending; downstream built on it goes stale."""
        stage, store = stages.get(stage_id), self.store
        s = store.stage_state(stage_id)
        cur = s.get("current_rev")
        if not cur:
            return
        remaining = sorted(p.name for p in (store.site_dir / stage_id).glob("rev-*") if p.is_dir() and p.name != cur)
        after = (f"The stage goes back to {remaining[-1]}." if remaining else "The stage goes back to pending.")
        downstream = [stages.get(d).name for d in stages.downstream_of(stage_id)
                      if store.stage_state(d)["status"] != "pending"]
        extra = ("\n\nThis revision is the approved one; these stages were built on it and become stale:\n"
                 + "\n".join(downstream)) if s.get("approved_rev") == cur and downstream else ""
        if not confirmed and not ask_yes_no(self, f"Remove {stage.name} {cur}?",
                                            f"Delete {stage.name} {cur} from disk and its layers from the project? "
                                            f"This cannot be undone. {after}{extra}"):
            return

        def body():
            layers.unload_stage(store.site, stage)
            self.controller.remove(stage_id)
        self._complete(stage_id, f"Remove {stage.name}", body)

    # ---------------- Scan: take hand-drawn layers over (0.16.0) ----------------
    def drawn_layers(self, stage_id: str) -> dict:
        """{plan layer: [project layers]} the saved scan picks name for this stage, only those with features; {} when
        the picks do not cover every layer the step needs."""
        from ..core import scan
        from .wayleave_box import project_layers
        if self.store is None or stage_id not in scan.SCANNED:
            return {}
        picks = self.store.scan_picks()
        out = {}
        for spec in scan.snapshot_outputs(stage_id):
            names = picks.get(spec.name) or []
            cands = project_layers(self.store, self.controller, spec.geom)
            # final review M2: every project layer of that name and geometry, as the Scan window ticks them all
            hit = [l for n in dict.fromkeys(names) for l in cands if l.name() == n and l.featureCount() > 0]
            if hit:
                out[spec.name] = hit
        return out if all(k in out for k in scan.NEEDED[stage_id]) else {}

    def existing_layers(self, stage_id: str) -> list[str]:
        """Names of the operator's project layers, with features, that hold one of this step's plan layers: the Scan
        picks for a plan layer Scan has saved (unticked there = the operator wants it drawn), else the layers Scan
        would tick by name. Generate never draws a step one of these is already (2026-11-12)."""
        from ..core import scan
        from ..core.layermatch import match_plan_layers
        from .wayleave_box import project_layers
        if self.store is None or stage_id not in scan.SCANNED:
            return []
        saved, out = self.store.scan_picks(), []
        for spec in scan.snapshot_outputs(stage_id):
            names = [l.name() for l in project_layers(self.store, self.controller, spec.geom) if l.featureCount() > 0]
            if spec.name in saved:
                out += [n for n in names if n in saved[spec.name]]
            else:
                out += [names[i] for i in match_plan_layers(spec.name, names)]
        return list(dict.fromkeys(out))

    def _missing_text(self, stage_id: str) -> str:
        """' (it also needs a layer for ...)' when the step needs a plan layer Scan has nothing for (P6 needs both an
        8-way splitter and a dome joint layer), else ''."""
        from ..core import scan
        from ..core.layermatch import match_plan_layers
        from .wayleave_box import project_layers
        saved, missing = self.store.scan_picks(), []
        geom = {o.name: o.geom for o in stages.get(stage_id).outputs}
        for name in scan.NEEDED.get(stage_id, ()):
            names = [l.name() for l in project_layers(self.store, self.controller, geom[name]) if l.featureCount() > 0]
            hit = [n for n in names if n in saved[name]] if name in saved else \
                [names[i] for i in match_plan_layers(name, names)]
            if not hit:
                missing.append(_PLAIN.get(name, name.replace("_", " ")))
        return f" (this step also needs a layer of {' and '.join(missing)}: draw it first)" if missing else ""

    def _update_use_drawn(self, sid: str, row: dict, state: dict, usable: bool):
        """Spec "When a hand-drawn step's turn comes": a found layer that had to wait is offered beside Generate
        once every step it depends on is approved."""
        btn = row.get("use_drawn")
        if btn is None:
            return
        s = state.get(sid, {})
        turn = (s.get("status") != "approved"
                and all(state.get(d, {}).get("status") == "approved" for d in stages.get(sid).deps))
        drawn = self.drawn_layers(sid) if turn else {}
        names = ", ".join(l.name() for ls in drawn.values() for l in ls)
        btn.setText(f"Use my layer ({names})")
        btn.setVisible(bool(drawn))
        btn.setEnabled(bool(drawn) and usable)

    def use_drawn(self, stage_id: str, note: str | None = None, why: str = ""):
        """The same takeover Scan does, for this one stage: note asked as at Approve, details ticked as at Approve.
        `why`: shown above the note when Generate or Revise sent the operator here (2026-11-12)."""
        stage = stages.get(stage_id)
        if not self.drawn_layers(stage_id):
            self._say(f"{stage.name}: use my drawn layer", "The layers you picked in Scan are no longer in the "
                                                           "project or have no features. Scan again.")
            return
        if note is None:
            note = ask_note(self, f"Use my drawn layer for {stage.name}",
                            (why + "\n\n" if why else "") + "Approval note (required):")
            if note is None:
                return
        if not note.strip():
            self._say(f"Use my drawn layer for {stage.name}", "An approval note is required.")
            return
        details = approval.stage_details(self.store, stage_id)
        checked = []
        if details:
            checked = confirm_details(self, stage.name, details)
            if checked is None:
                return

        def done(taken, stopped, msg):
            if stopped:
                self._say(f"{stage.name}: use my drawn layer", msg)
        self.take_over([stage_id], self.drawn_layers, note.strip(), {stage_id: checked}, on_done=done)

    def take_over(self, stage_ids: list[str], layers_for, note: str, details: dict, on_step=None, on_done=None):
        """Take each stage over in order (spec "Continue from these"): snapshot the project layers as they are now,
        fill the plan fields, run its Check in the background, then approve (over failed checks, recorded). The
        chain stops at the first step that is not approved (a crashed Check, an unticked detail, a refusal), and
        that message goes on the step's run.log. on_step(sid, None, "") as each step starts, on_step(sid, ok, msg)
        after it; on_done(taken, stopped, msg) once at the end, after the tab has refreshed. Each approved step is
        loaded read-only like any approved stage (final review I2)."""
        ctl, store = self.controller, self.store
        todo, taken = list(stage_ids), []

        def finish(stopped=None, msg=""):
            try:
                self._flow_done(stopped or (taken[-1] if taken else (stage_ids[0] if stage_ids else self.selected)))
            finally:
                if on_done is not None:
                    on_done(taken, stopped, msg)

        def stop(sid, msg, rev=None):
            if rev is not None:
                try:
                    with open(rev / "run.log", "a", encoding="utf-8") as f:
                        f.write(f"\nScan takeover stopped here: {msg}\n")
                except OSError:
                    pass
            if on_step is not None:
                on_step(sid, False, msg)
            finish(sid, msg)

        def result(sid, rev, start, rc, text):
            try:
                ok, msg = ctl.finish_takeover(sid, rev, rc, text, start, note, details.get(sid, ()))
                if ok:                                   # operator 2026-11-06: no copy on the map; old group gone
                    try:
                        layers.unload_stage(store.site, stages.get(sid))
                    except Exception as e:               # noqa: BLE001 - approved all the same; say why it stayed
                        with open(rev / "run.log", "a", encoding="utf-8") as f:
                            f.write(f"\ncould not remove the stage's old layers: {type(e).__name__}: {e}\n")
                if (rev / "checks.json").exists():
                    layers.load_issues(self.iface, store.site, stages.get(sid), rev)
            except Exception as e:                       # noqa: BLE001 - never leave the tab wedged
                ok, msg = False, f"{type(e).__name__}: {e}"
            if not ok:
                stop(sid, msg, rev)
                return
            taken.append(sid)
            if on_step is not None:
                on_step(sid, True, msg)
            step()

        def step():
            if not todo:
                finish()
                return
            sid = todo.pop(0)
            made: list[Path] = []                        # the revision begin_takeover made, once it exists
            if on_step is not None:                      # final review I3: the window names the step being taken
                on_step(sid, None, "")
            try:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                try:                                     # final review I3: export + snapshot + fill block the UI
                    rev, start, cmd, env = self._takeover_start(ctl, store, sid, layers_for(sid), made)
                finally:
                    QApplication.restoreOverrideCursor()
                self._launch(f"{store.site}: take over {stages.get(sid).name}", cmd, env, rev / "check.log",
                             lambda rc, text: result(sid, rev, start, rc, text))
            except Exception as e:                       # noqa: BLE001 - never leave the tab busy
                msg = f"{type(e).__name__}: {e}"
                if made:                                 # fix round T6: a half-made rev is no work to keep
                    try:
                        ctl.takeover_failed(sid, made[0], e)
                    except Exception:                    # noqa: BLE001
                        pass
                stop(sid, msg)

        self._set_busy(True)
        step()

    def _takeover_start(self, ctl, store, sid: str, chosen: dict, made: list):
        """begin_takeover, the snapshot of the layers as they are now (its fingerprint hash recorded in takeover.json
        before any field is filled), the field fill, P4's collection point ids and begin_check. Returns (rev, start
        hash, cmd, env); the new revision is appended to `made` as soon as it exists."""
        import datetime

        from ..core import wayleave_diff
        if not chosen:
            raise ValueError("no project layer picked for this step")
        source = {"layers": {pl: [{"name": l.name(), "source": l.source(), "features": l.featureCount()}
                                  for l in ls] for pl, ls in chosen.items()},
                  "when": datetime.datetime.now().isoformat(timespec="seconds")}
        rev = ctl.begin_takeover(sid, source)
        made.append(rev)
        log: list[str] = []
        counts = write_step_snapshot(rev / "working.gpkg", sid, chosen, store.load()["epsg"], log)
        source["snapshot_hash"] = wayleave_diff.fingerprint_hash(rev / "working.gpkg")   # the raw copy, as drawn
        (rev / "takeover.json").write_text(json.dumps(source, indent=2), encoding="utf-8")
        (rev / "run.log").write_text("drawn by hand, taken over by Scan: snapshot of project layers\n" + "".join(
            f"{n}: {c} features from {', '.join(l.name() for l in chosen[n])}\n" for n, c in counts.items())
            + "".join(line + "\n" for line in log), encoding="utf-8")
        ctl.after_snapshot(sid, rev)
        if sid == "p4_drops":                             # numbered as P4's Check numbers hand-drawn points
            assigned = assign_cp_ids(None, rev / "working.gpkg")
            if assigned:
                with open(rev / "run.log", "a", encoding="utf-8") as f:
                    f.write("\n".join(assigned) + "\n")
        rev2, cmd, env = ctl.begin_check(sid)
        start = ctl.check_start.get(sid)
        cj = rev2 / "checks.json"                         # never let an old report stand in for this run
        if cj.exists():
            cj.unlink()
        store.set_stage(sid, checked_hash=None)
        return rev2, start, cmd, env

    def reject(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            note = ask_note(self, f"Reject {stage.name}", "Rejection note:")
            if note is None:
                return
        self._complete(stage_id, f"Reject {stage.name}", lambda: self.controller.reject(stage_id, note))

