"""Colours for the dock that read on QGIS's light AND dark themes (frontend spec 13, accessibility).

Every tone has a light-theme and a dark-theme text colour; both pass 4.5:1 against that theme's panel
background (tests/test_row_view.py measures them). The theme is read from the widget's own palette, so the
dock follows whatever QGIS theme is active and never hard-codes a background.
"""
from __future__ import annotations

# tone -> (on a light panel, on a dark panel)
TONES = {
    "ok": ("#1b5e20", "#81c784"),
    "ready": ("#00574b", "#4db6ac"),
    "info": ("#0d47a1", "#64b5f6"),
    "warn": ("#6d4c00", "#ffd54f"),
    "error": ("#b71c1c", "#ef9a9a"),
    "idle": ("#555555", "#a8a8a8"),
    "run": ("#283593", "#9fa8da"),
}
# the panel backgrounds the tones are measured against (QGIS default light, QGIS "Night Mapping" / Blend of Gray)
LIGHT_BG, DARK_BG = "#efefef", "#2e2e2e"


def is_dark(widget=None) -> bool:
    """QGIS sets its theme on the application palette; a widget not yet shown may still hold a default palette,
    so the application's palette decides."""
    try:
        from qgis.PyQt.QtWidgets import QApplication
        return QApplication.palette().window().color().lightness() < 128
    except Exception:                                   # noqa: BLE001 - no application (pure tests): light
        return False


def tone(name: str, dark: bool) -> str:
    light_c, dark_c = TONES.get(name, TONES["idle"])
    return dark_c if dark else light_c


# The one accent: the next thing to press. Filled, so the eye lands on it; white text passes 4.5:1 on both fills.
ACCENT = ("#1565c0", "#1e6fd1")
ACCENT_HOVER = ("#0d47a1", "#2b7fe6")


def primary_button(dark: bool) -> str:
    a, h = ACCENT[1 if dark else 0], ACCENT_HOVER[1 if dark else 0]
    return (f"QPushButton {{ background: {a}; color: #ffffff; border: 1px solid {a}; border-radius: 5px;"
            f" padding: 3px 12px; font-weight: 600; }}"
            f"QPushButton:hover {{ background: {h}; border-color: {h}; }}"
            f"QPushButton:pressed {{ background: {a}; padding-top: 4px; padding-bottom: 2px; }}"
            f"QPushButton:disabled {{ background: transparent; color: palette(mid); border-color: palette(mid); }}")


def quiet_button(dark: bool, name: str = "idle") -> str:
    c = tone(name, dark)
    return (f"QPushButton {{ background: transparent; color: {c}; border: 1px solid {c}; border-radius: 5px;"
            f" padding: 3px 12px; font-weight: 600; }}"
            f"QPushButton:hover {{ background: palette(midlight); }}")


def card(dark: bool, object_name: str) -> str:
    border = "#4a4a4a" if dark else "#d4d4d4"
    fill = "rgba(255,255,255,0.03)" if dark else "rgba(255,255,255,0.65)"
    return f"#{object_name} {{ border: 1px solid {border}; border-radius: 8px; background: {fill}; }}"
