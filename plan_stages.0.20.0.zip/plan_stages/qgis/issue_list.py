"""The clickable issues list under a stage (and in the Wayleave box): one header row per check (or per PON) with
something to say, its located issues indented under it, and a footer for what the cap dropped. Clicking an issue
takes the operator to that feature (zoom, select, activate the layer, flash); clicking a header selects every
located feature of that group at once.

Frontend spec 7: severity filter (errors / warnings / hidden by you), group by check type or by PON, and the Why
of an issue shown inline under the list instead of in a separate window."""
from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QFrame,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QVBoxLayout,
)

from ..core.checks import ChecksReport, Issue
from ..core.issues import group_report
from . import locate, words
from .theme import is_dark, tone

ROLE = Qt.ItemDataRole.UserRole
KIND = ROLE + 2                  # "error" | "warn" | "hidden" | "" (notices): what the severity filter acts on
KINDS = ("error", "warn", "hidden")


class WhyPanel(QFrame):
    """Why the step did not make something (operator 2026-10-19), shown inline under the list (spec 7). The owner
    places it in its layout; it stays hidden until an issue with a reason is clicked. Same API as the old window:
    show_issue(), text(), hide()."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("whyPanel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._label = QLabel(); self._label.setWordWrap(True)
        self._label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay = QVBoxLayout(self); lay.setContentsMargins(8, 6, 8, 6); lay.addWidget(self._label)
        self.hide()

    def show_issue(self, issue: Issue) -> None:
        todo = words.check_todo(issue.code)
        self._label.setText(f"{issue.message}\n\nWhy: {issue.why}" + (f"\n\nWhat to do: {todo}" if todo else ""))
        c = tone("info", is_dark(self))
        self.setStyleSheet(f"#whyPanel {{ border: 1px solid {c}; border-radius: 6px; }}")
        self.show()

    def text(self) -> str:
        return self._label.text()


WhyWindow = WhyPanel             # old name, kept for anything that imported it


@dataclass
class PonGroup:
    """A group-by-PON header: the same fields _go_group and counts() read from a check group."""
    pon: int | None
    issues: list = field(default_factory=list)
    blocking: bool = False
    code: str = ""

    @property
    def title(self) -> str:
        return f"PON {self.pon}" if self.pon is not None else "No PON"


_PON_IN_TEXT = re.compile(r"\bPON\s*0*(\d+)", re.IGNORECASE)


def pon_from_issue(issue: Issue) -> int | None:
    """The PON an issue belongs to from its own data: `match` "pon_num=23", else "PON 23" in the message."""
    m = re.match(r"pon_num=0*(\d+)$", issue.match or "")
    if m:
        return int(m[1])
    m = _PON_IN_TEXT.search(issue.message or "")
    return int(m[1]) if m else None


def tally(groups) -> tuple[int, int]:
    """(errors, warnings) the planner sees, counted one way everywhere (row, pane header, chips): an issue of a
    blocking check or of severity error is an error; a blocking check that failed with no located issue counts one."""
    err = warn = 0
    for g in groups:
        for i in g.issues:
            if g.blocking or i.severity == "error":
                err += 1
            else:
                warn += 1
        if not g.issues:
            err += 1 if g.blocking else 0
    return err, warn


class IssueList(QListWidget):
    marked = pyqtSignal()           # a row's live edit mark was set or cleared (0.8.1: Remove re-evaluates)
    shown_changed = pyqtSignal()    # the filter or grouping changed (the owner refreshes Previous / Next)

    def __init__(self, iface, resolve: Callable[[Issue], object | None], parent=None):
        """`resolve(issue)` returns the loaded QgsVectorLayer the issue lives in, or None. `pon_lookup(issue)`
        (set by the owner, optional) gives the PON an issue's point falls in, for Group by PON."""
        super().__init__(parent)
        self.iface, self.resolve = iface, resolve
        self.pon_lookup: Callable[[Issue], int | None] | None = None
        self.groups = []
        self.type_groups = []            # always the check groups, whatever is displayed (counts, blocking)
        self.removed: list = []          # issues the operator removed (0.8.1), shown last
        self._n_fixed = 0                # the first _n_fixed of `removed` were fixed by an edit (2026-10-16)
        self._selected: list = []        # layers the last click selected on; cleared before the next click
        self._watched: list = []         # (layer, signal, slot) connected for live edit marking
        self._rows: dict = {}            # (layer id, fid) -> [QListWidgetItem]
        self._report: ChecksReport | None = None
        self.group_by = "type"           # "type" | "pon"
        self.filter: set = set(KINDS)    # kinds shown
        self.setWordWrap(True)                         # long messages wrap instead of running off the dock
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.itemClicked.connect(self._clicked)
        self.pon_lab = None              # set by the owner: pon -> address, or None when no PON Lab is set up
        self.toggle_issue = None         # set by the owner: () -> None, the Not a problem / Bring back action
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)
        self.why_window = WhyPanel()     # the owner adds it to its layout (StageTab puts it under the list)
        self.setToolTip("Click an issue to go to it on the map; click a header to select every feature it flags")

    # ---------------- content ----------------
    def set_report(self, report: ChecksReport | None, removed=(), fixed=()) -> None:
        """`removed`: issues the operator removed (0.8.1), listed last and greyed; `fixed`: issues on a feature the
        operator edited that the Check still finds (2026-10-16: "fixes should remain crossed out"), listed last and
        crossed out. Both can be restored. `report` holds the shown ones."""
        self._report = report
        self.removed = list(fixed) + list(removed); self._n_fixed = len(list(fixed))
        self.type_groups = group_report(report) if report is not None else []
        self._render()

    def set_group_by(self, how: str) -> None:
        if how != self.group_by:
            self.group_by = how
            self._render()
            self.shown_changed.emit()

    def set_filter(self, kinds) -> None:
        self.filter = set(kinds)
        self._apply_filter()
        self.shown_changed.emit()

    def _is_error(self, issue: Issue) -> bool:
        blocking = {g.code for g in self.type_groups if g.blocking}
        return issue.severity == "error" or issue.code in blocking

    def _pon_groups(self) -> list:
        """Spec 7: one group per PON, worst first (most errors, then most issues); "No PON" last."""
        by: dict = {}
        for g in self.type_groups:
            for i in g.issues:
                pon = pon_from_issue(i)
                if pon is None and self.pon_lookup is not None:
                    try:
                        pon = self.pon_lookup(i)
                    except Exception:                    # noqa: BLE001 - a lookup never breaks the list
                        pon = None
                grp = by.setdefault(pon, PonGroup(pon))
                grp.issues.append(i)
        for grp in by.values():
            grp.blocking = any(self._is_error(i) for i in grp.issues)
        key = lambda g: (g.pon is None, -sum(1 for i in g.issues if self._is_error(i)), -len(g.issues), g.pon or 0)
        return sorted(by.values(), key=key)

    def _render(self) -> None:
        self._unwatch()
        self.clear(); self._rows = {}
        self.why_window.hide()
        report = self._report
        if report is None:
            self.groups = []
            return
        bold = QFont(); bold.setBold(True)
        dark = is_dark(self)
        self.groups = self._pon_groups() if self.group_by == "pon" else self.type_groups
        for gi, g in enumerate(self.groups):
            if self.group_by == "pon":
                n_err = sum(1 for i in g.issues if self._is_error(i)); n_warn = len(g.issues) - n_err
                bits = ([f"{n_err} error{'s' if n_err != 1 else ''}"] if n_err else []) + \
                       ([f"{n_warn} warning{'s' if n_warn != 1 else ''}"] if n_warn else [])
                error = n_err > 0
                mark = "×" if error else "!"
                title = f"{mark}  {g.title} · {', '.join(bits)}"
                tip = f"{g.title}: {', '.join(bits)}\nClick to select them all on the map"
            else:
                n_fx = sum(1 for i in self.removed[:self._n_fixed] if i.code == g.code)
                n_rm = sum(1 for i in self.removed[self._n_fixed:] if i.code == g.code)
                how = "fixed or hidden" if n_fx and n_rm else "fixed" if n_fx else "hidden"
                error = g.blocking or any(i.severity == "error" for i in g.issues)
                count = f" · {len(g.issues)}" if g.issues else ""
                mark = "×" if error else "!"
                title = f"{mark}  {words.check_title(g.code)}{count}" + (
                    f" — all {n_fx + n_rm} {how} by you" if n_fx + n_rm and not g.issues else "")
                todo = words.check_todo(g.code)
                tip = g.title + (f"\nWhat to do: {todo}" if todo else "") + \
                    (f"\n{len(g.issues)} on the map: click to select them all" if g.issues else "")
            h = QListWidgetItem(title); h.setFont(bold); h.setData(ROLE, ("group", gi))
            h.setData(KIND, "error" if error else "warn")
            h.setForeground(QColor(tone("error" if error else "warn", dark)))
            h.setToolTip(tip)
            self.addItem(h)
            for ii, i in enumerate(g.issues):
                lead = f"{words.check_title(i.code)}: " if self.group_by == "pon" else ""
                it = QListWidgetItem(f"    {lead}{i.message}" + ("  ›" if i.why else "") +
                                     (" (still found after your edit)" if i.after_edit else ""))
                it.setData(ROLE, ("issue", gi, ii))
                it.setData(KIND, "error" if self._is_error(i) else "warn")
                it.setToolTip(f"{i.severity} {i.code} · {i.layer or 'no layer'} fid {i.fid}" +
                              (f" ({i.source})" if i.source != "working" else "") + ("\nClick to read why" if i.why else ""))
                self.addItem(it)
                self._index(i, it)
        if report.dropped:
            self.addItem(QListWidgetItem(f"{report.dropped} more not shown — fix some and check again"))
        if not self.groups and not self.removed:
            ok = QListWidgetItem("✓  No issues"); ok.setForeground(QColor(tone("ok", dark)))
            self.addItem(ok)
        for start, stop, what, tip in ((0, self._n_fixed, "fixed",
                                        "Issues on features you edited: check again to confirm. Select one to bring it back."),
                                       (self._n_fixed, len(self.removed), "hidden",
                                        "Issues you marked Not a problem. Select one to bring it back.")):
            if stop <= start:
                continue
            h = QListWidgetItem(f"{what.capitalize()} by you ({stop - start})"); h.setFont(bold); h.setToolTip(tip)
            h.setData(KIND, "hidden")
            self.addItem(h)
            for k in range(start, stop):
                i = self.removed[k]
                lead = "✓ " if what == "fixed" else ""
                tail = " — fixed, check again to confirm" if what == "fixed" else " (hidden by you)"
                it = QListWidgetItem(f"    {lead}{i.message}{tail}")
                it.setToolTip(f"{i.severity} {i.code}")
                it.setData(ROLE, ("removed", k)); it.setData(KIND, "hidden"); it.setForeground(QColor("#8a8a8a"))
                if what == "fixed":
                    f = it.font(); f.setStrikeOut(True); it.setFont(f)
                self.addItem(it)
        self._apply_filter()

    def _apply_filter(self) -> None:
        """Hide rows of unticked kinds; a header whose rows are all hidden hides with them. Notices always show."""
        header = None
        any_child = False
        for r in range(self.count()):
            it = self.item(r)
            data = it.data(ROLE) or ("",)
            kind = it.data(KIND) or ""
            if data[0] == "group" or (kind == "hidden" and not data[0]):
                if header is not None:
                    header.setHidden(not any_child and header.data(KIND) not in self.filter)
                header, any_child = it, False
                it.setHidden(False)
                continue
            if kind:
                hide = kind not in self.filter
                it.setHidden(hide)
                any_child = any_child or not hide
            else:
                it.setHidden(False)
        if header is not None:
            header.setHidden(not any_child and header.data(KIND) not in self.filter)

    def current_edited(self) -> bool:
        """The current row's feature was edited since the last Check (review I-1: a removal now would hold the old
        geometry and come back at the next Check)."""
        it = self.currentItem()
        return bool(it is not None and it.data(ROLE + 1))

    def current(self):
        """(issue, removed) under the current row; (None, False) on a header, footer or notice."""
        it = self.currentItem()
        data = it.data(ROLE) if it is not None else None
        if data and data[0] == "issue":
            return self.groups[data[1]].issues[data[2]], False
        if data and data[0] == "removed":
            return self.removed[data[1]], True
        return None, False

    # ---------------- live edit marking (operator ruling 2026-10-08: fixed errors disappear) ----------------
    def _index(self, issue: Issue, item) -> None:
        """Remember which row belongs to which loaded feature, and watch that layer's edit buffer. The row is
        marked the moment the operator edits or deletes the feature; the save re-check then removes it for real."""
        if issue.fid is None or issue.fid < 0:
            return
        layer = self.resolve(issue)
        if layer is None:
            return
        self._rows.setdefault((layer.id(), int(issue.fid)), []).append(item)
        if not any(l is layer for l, _, _ in self._watched):
            for sig, slot in (("geometryChanged", lambda fid, _g, l=layer: self._mark(l, fid, "edited")),
                              ("featureDeleted", lambda fid, l=layer: self._mark(l, fid, "deleted")),
                              ("afterRollBack", lambda l=layer: self._unmark(l))):
                getattr(layer, sig).connect(slot); self._watched.append((layer, sig, slot))

    def _unwatch(self) -> None:
        for layer, sig, slot in self._watched:
            try:
                getattr(layer, sig).disconnect(slot)
            except (TypeError, RuntimeError):            # layer removed from the project meanwhile
                pass
        self._watched = []

    def _mark(self, layer, fid: int, what: str) -> None:
        for it in self._rows.get((layer.id(), int(fid)), []):
            base = it.data(ROLE + 1) or it.text()
            it.setData(ROLE + 1, base)
            it.setText(f"{base}   (fixed by you)" if what == "edited" else f"{base}   ({what})")   # stays crossed out (2026-10-16)
            f = it.font(); f.setStrikeOut(True); it.setFont(f); it.setForeground(QColor("#8a8a8a"))
        self.marked.emit()

    def _unmark(self, layer) -> None:
        for (lid, _fid), items in self._rows.items():
            if lid != layer.id():
                continue
            for it in items:
                base = it.data(ROLE + 1)
                if base:
                    it.setText(base); f = it.font(); f.setStrikeOut(False); it.setFont(f); it.setData(ROLE + 1, None)
                    it.setForeground(QColor())
        self.marked.emit()

    # ---------------- right-click (spec 7 row actions, spec 12) ----------------
    def menu_actions(self, item) -> list[tuple[str, object]]:
        """[(label, callable)] for a row: Not a problem / Bring back, Open PON n in PON Lab, Copy text."""
        from qgis.PyQt.QtWidgets import QApplication
        out = []
        if item is None:
            return out
        self.setCurrentItem(item)
        issue, removed = self.current()
        if issue is not None and self.toggle_issue is not None:
            out.append(("Bring back" if removed else "Not a problem", self.toggle_issue))
        data = item.data(ROLE) or ("",)
        pon = None
        if issue is not None:
            pon = pon_from_issue(issue)
            if pon is None and self.pon_lookup is not None:
                try:
                    pon = self.pon_lookup(issue)
                except Exception:                        # noqa: BLE001
                    pon = None
        elif data[0] == "group" and self.group_by == "pon":
            pon = self.groups[data[1]].pon
        url = self.pon_lab(pon) if (self.pon_lab is not None and pon is not None) else None
        if url:
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtGui import QDesktopServices
            out.append((f"Open PON {pon} in PON Lab", lambda u=url: QDesktopServices.openUrl(QUrl(u))))
        out.append(("Copy text", lambda t=item.text().strip(): QApplication.clipboard().setText(t)))
        return out

    def _menu(self, pos):
        from qgis.PyQt.QtWidgets import QMenu
        acts = self.menu_actions(self.itemAt(pos))
        if not acts:
            return
        m = QMenu(self)
        for label, fn in acts:
            m.addAction(label).triggered.connect(lambda _=False, f=fn: f())
        m.exec(self.viewport().mapToGlobal(pos))

    # ---------------- Next / Previous (spec 7) ----------------
    def issue_rows(self) -> list[int]:
        """Rows of issues the filter shows, in list order."""
        return [r for r in range(self.count())
                if (self.item(r).data(ROLE) or ("",))[0] == "issue" and not self.item(r).isHidden()]

    def step(self, direction: int) -> None:
        """Go to the next (+1) or previous (-1) issue row and take the map there."""
        rows = self.issue_rows()
        if not rows:
            return
        cur = self.currentRow()
        later = [r for r in rows if (r > cur if direction > 0 else r < cur)]
        target = (later[0] if direction > 0 else later[-1]) if later else (rows[0] if direction > 0 else rows[-1])
        self.setCurrentRow(target)
        self._clicked(self.item(target))

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key.Key_N, Qt.Key.Key_P) and not e.modifiers():
            self.step(1 if e.key() == Qt.Key.Key_N else -1); return
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.currentItem() is not None:
            self._clicked(self.currentItem()); return
        super().keyPressEvent(e)

    def counts(self) -> tuple[int, int]:
        """(errors, warnings) shown, for the pane header: always counted by check, whatever the grouping."""
        return tally(self.type_groups)

    def prepend(self, text: str) -> None:
        """An inert notice row at the top (approval refused, override recorded, ...)."""
        self.insertItem(0, QListWidgetItem(text))

    # ---------------- navigation ----------------
    def _clear_previous_selection(self) -> None:
        """What the previous click selected stays yellow on the map until it is cleared (operator, 2026-10-08)."""
        for layer in self._selected:
            try:
                layer.removeSelection()
            except RuntimeError:                         # layer gone
                pass
        self._selected = []

    def _clicked(self, item):
        data = item.data(ROLE)
        if not data:
            return
        self._clear_previous_selection()
        issue = (self.groups[data[1]].issues[data[2]] if data[0] == "issue" else
                 self.removed[data[1]] if data[0] == "removed" else None)
        if issue is not None and issue.why:
            self.why_window.show_issue(issue)
        else:
            self.why_window.hide()
        if data[0] == "issue":
            self._go_issue(self.groups[data[1]].issues[data[2]])
        elif data[0] == "removed":
            self._go_issue(self.removed[data[1]])
        elif data[0] == "group":
            self._go_group(self.groups[data[1]])

    def _go_issue(self, issue: Issue):
        layer = self.resolve(issue)
        f = locate.find_feature(layer, issue) if layer is not None else None
        if f is not None:
            locate.go_to(self.iface, layer, [f.id()], None); self._selected.append(layer)
        else:
            dest = self.iface.mapCanvas().mapSettings().destinationCrs()
            locate.go_to(self.iface, None, [], locate.issue_point(issue, dest))

    def _go_group(self, group):
        found: dict = {}                                 # layer id -> (layer, [fids])
        for i in group.issues:
            layer = self.resolve(i)
            f = locate.find_feature(layer, i) if layer is not None else None
            if f is not None:
                found.setdefault(layer.id(), (layer, []))[1].append(f.id())
        if not found:
            if group.issues:
                self._go_issue(group.issues[0])
            return
        layer, fids = max(found.values(), key=lambda v: len(v[1]))   # one layer gets the selection and the view
        for other, ofids in found.values():
            if other is not layer and not locate.is_polygon(other):   # a selected polygon hides its contents
                other.selectByIds(ofids); self._selected.append(other)
        locate.go_to(self.iface, layer, sorted(set(fids)), None); self._selected.append(layer)
