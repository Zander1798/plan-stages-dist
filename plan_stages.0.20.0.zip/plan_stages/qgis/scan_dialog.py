"""Scan current wayleave state (0.16.0, spec 2026-10-29): the window that lists, per plan step, the project layers
the operator already drew for it, and takes the covered steps over in chain order ("Continue from these").

One row per scan.SCANNED step: its state and note, a tick list of project layers (of the right geometry type, never
the plugin's own) for each plan layer, a "keep the plugin's version" tick on approved and started rows, and the
operator's Spec-tab details for each step about to be taken over. The chain itself runs on the stage tab
(StageTab.take_over), one background Check at a time; the press is the operator's approval of every step it takes."""
from __future__ import annotations
import tempfile
from collections import Counter
from pathlib import Path
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QApplication, QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, QListWidget,
                                 QListWidgetItem, QCheckBox, QLineEdit, QPushButton, QScrollArea, QWidget, QFrame,
                                 QProgressBar, QToolButton)
from qgis.core import QgsProject
from ..core import approval, scan, stages
from ..core.layermatch import match_plan_layers
from .ui import warn
from .stage_tab import write_step_snapshot
from .wayleave_box import project_layers

_ID, _NAME = Qt.ItemDataRole.UserRole, Qt.ItemDataRole.UserRole + 1
CHANGED = "your layer changed since it was taken over"
# final review T7b: a takeover is unsaved progress like any other (ruling 2026-10-07: wiped on the next open)
SAVE_LINE = "Press Save to keep the takeover (unsaved progress is wiped when the site is next opened)."


_outputs = scan.snapshot_outputs


def _short(sid: str) -> str:
    return stages.get(sid).name.split(" ")[0]                                         # "P1 Feeder" -> "P1"


def _sentence(text: str) -> str:
    """The text ending in a full stop (or the ? / ! it already has)."""
    text = text.rstrip()
    return text if not text or text[-1] in ".?!" else text + "."


PROMISE = ("Your layers are taken over, not changed. The plugin keeps a copy as each step's approved version; "
           "your layers stay exactly as you drew them and no second layer is added to the map.")
_PLAIN = {"feeder": "Feeder", "splitters_1to16": "1:16 splitters", "distribution": "Distribution",
          "collection_points": "Collection points", "drops": "Drops", "road_crossings": "Road crossings",
          "splitters_8way": "8-way splitters", "dome_joints": "Dome joints"}


def _default_note() -> str:
    import datetime as _dt
    d = _dt.date.today()
    return f"My own layers, {d.day} {d:%b}"


def _taken_over(store, sid: str) -> bool:
    s = store.stage_state(sid)
    return bool(s.get("approved_rev")) and (store.rev_dir(sid, s["approved_rev"]) / "takeover.json").exists()


class ScanDialog(QDialog):
    def __init__(self, iface, controller, store, stage_tab, parent=None, on_done=None):
        super().__init__(parent)
        self.iface, self.controller, self.store, self.stage_tab, self.on_done = (iface, controller, store, stage_tab,
                                                                                 on_done)
        self.setWindowTitle(f"Use what I've drawn \u00b7 {store.site}")
        self._building = True
        self.lists: dict[str, QListWidget] = {}          # plan layer -> tick list of project layers
        self._picks_ui: dict[str, tuple] = {}            # plan layer -> (summary label, Change button, list)
        self._progress = (0, 0)                          # (done, total) while a chain runs
        self.ui: dict[str, dict] = {}                    # stage id -> its widgets
        self._msg: dict[str, str] = {}                   # stage id -> the message the last chain left on it
        self._seen: dict[str, str] = {}                  # stage id -> state shown, to reset "keep" when it changes
        self._build()
        self._building = False
        self._rescan()
        self._preview()

    # ---------------- layout ----------------
    def _build(self):
        from .theme import is_dark, tone, card
        dark = is_dark(self)
        self.setStyleSheet(card(dark, "stepCard") + card(dark, "promise"))
        lay = QVBoxLayout(self)
        promise = QFrame(); promise.setObjectName("promise"); pl = QVBoxLayout(promise); pl.setContentsMargins(10, 8, 10, 8)
        self.promise = QLabel(PROMISE); self.promise.setWordWrap(True)
        self.promise.setStyleSheet(f"color: {tone('info', dark)};")
        pl.addWidget(self.promise); lay.addWidget(promise)
        body = QWidget(); bl = QVBoxLayout(body); bl.setSpacing(6)
        saved = self.store.scan_picks()
        for sid in scan.SCANNED:
            box = QFrame(); box.setObjectName("stepCard"); v = QVBoxLayout(box); v.setContentsMargins(10, 6, 10, 6)
            v.setSpacing(2)
            head = QHBoxLayout()
            name = QLabel(f"<b>{stages.get(sid).name}</b>")
            tag = QLabel(""); tag.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            head.addWidget(name, 1); head.addWidget(tag)
            v.addLayout(head)
            state = QLabel(""); state.setWordWrap(True); state.setStyleSheet(f"color: {tone('idle', dark)};")
            note = QLabel(""); note.setWordWrap(True); note.setStyleSheet(f"color: {tone('warn', dark)};")
            keep = QCheckBox("keep the plugin's version"); keep.setChecked(True); keep.hide()
            keep.toggled.connect(lambda _on: self._preview())
            v.addWidget(state); v.addWidget(note); v.addWidget(keep)
            for spec in _outputs(sid):
                plain = _PLAIN.get(spec.name, spec.name.replace("_", " ").capitalize())
                optional = spec.name in scan.OPTIONAL.get(sid, ())
                line = QHBoxLayout(); line.setSpacing(4)
                pick = QLabel(""); pick.setWordWrap(True)
                change = QToolButton(); change.setText("Change"); change.setAutoRaise(True); change.setCheckable(True)
                change.setToolTip("Pick other layers for this")
                line.addWidget(pick, 1); line.addWidget(change)
                v.addLayout(line)
                lst = QListWidget(); lst.setMaximumHeight(72)
                lst.setProperty("plain", plain + (" (optional: worked out from your drops when none)" if optional else ""))
                cands = sorted(project_layers(self.store, self.controller, spec.geom), key=lambda l: l.name().lower())
                names = [l.name() for l in cands]
                pre = set(n for n in saved[spec.name] if n in names) if spec.name in saved else \
                    {names[i] for i in match_plan_layers(spec.name, names)}
                for l in cands:
                    it = QListWidgetItem(f"{l.name()} ({l.featureCount():,})")
                    it.setData(_ID, l.id()); it.setData(_NAME, l.name())
                    it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    it.setCheckState(Qt.CheckState.Checked if l.name() in pre else Qt.CheckState.Unchecked)
                    lst.addItem(it)
                if not cands:
                    lst.setMaximumHeight(24)
                lst.itemChanged.connect(lambda _it: self._preview())
                change.toggled.connect(lambda on, l=lst: l.setVisible(on))
                v.addWidget(lst); self.lists[spec.name] = lst
                self._picks_ui[spec.name] = (pick, change, lst)
            det = QWidget(); dl = QVBoxLayout(det); dl.setContentsMargins(0, 0, 0, 0)
            ticks = []
            details = approval.stage_details(self.store, sid)
            if details:
                dl.addWidget(QLabel(f"<b>Your details for this step ({len(details)})</b>: tick each as checked "
                                    f"against your layer"))
            for x in details:
                cb = QCheckBox(x["detail"]); cb.setProperty("detail_id", x["id"]); ticks.append(cb); dl.addWidget(cb)
            det.hide(); v.addWidget(det)
            self.ui[sid] = {"state": state, "note": note, "keep": keep, "details": det, "ticks": ticks, "tag": tag}
            bl.addWidget(box)
        bl.addStretch(1)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)
        self.summary = QLabel(""); self.summary.setWordWrap(True)
        lay.addWidget(self.summary)
        self.busy_bar = QProgressBar(); self.busy_bar.setRange(0, 0); self.busy_bar.setTextVisible(False)
        self.busy_bar.setMaximumHeight(6); self.busy_bar.hide()
        lay.addWidget(self.busy_bar)
        # the note sits behind a link, filled with a sensible default (spec 11)
        self.note = QLineEdit(_default_note()); self.note.setPlaceholderText("approval note (required)")
        self.note.hide()
        self.note_link = QToolButton(); self.note_link.setText("Add a note"); self.note_link.setAutoRaise(True)
        self.note_link.setToolTip(f"The approval note on record: \u201c{_default_note()}\u201d unless you change it")
        self.note_link.clicked.connect(lambda: (self.note.show(), self.note.setFocus(), self.note.selectAll(),
                                                self.note_link.hide()))
        lay.addWidget(self.note)
        bar = QHBoxLayout()
        self.continue_btn = QPushButton("Take these over")
        self.continue_btn.setToolTip("Take over the steps marked so, in order; this press approves each of them")
        from .theme import primary_button
        self.continue_btn.setStyleSheet(primary_button(dark))
        self.continue_btn.clicked.connect(lambda _=False: self.continue_from_these())
        self.close_btn = QPushButton("Close"); self.close_btn.clicked.connect(self.close)
        bar.addWidget(self.note_link); bar.addStretch(1); bar.addWidget(self.continue_btn); bar.addWidget(self.close_btn)
        lay.addLayout(bar)
        self.resize(520, 640)

    # ---------------- what the window shows ----------------
    def offered(self, plan_layer: str) -> list[str]:
        lst = self.lists[plan_layer]
        return [lst.item(i).data(_NAME) for i in range(lst.count())]

    def ticked(self, plan_layer: str) -> list[str]:
        lst = self.lists[plan_layer]
        return [lst.item(i).data(_NAME) for i in range(lst.count())
                if lst.item(i).checkState() == Qt.CheckState.Checked]

    def picks(self) -> dict[str, list[str]]:
        return {pl: self.ticked(pl) for pl in self.lists}

    def _ticked_layers(self, plan_layer: str) -> list:
        lst, prj = self.lists[plan_layer], QgsProject.instance()
        out = [prj.mapLayer(lst.item(i).data(_ID)) for i in range(lst.count())
               if lst.item(i).checkState() == Qt.CheckState.Checked]
        return [l for l in out if l is not None]

    def _counts(self) -> dict[str, int]:
        """Feature counts of the ticked layers as they are now (a layer removed from the project counts 0)."""
        out: dict[str, int] = {}
        for pl in self.lists:
            for l in self._ticked_layers(pl):
                out[l.name()] = max(out.get(l.name(), 0), l.featureCount())
        return out

    def layers_for(self, sid: str) -> dict:
        """{plan layer: [project layers]} ticked for this step, those with features, read at the moment of the call."""
        out = {}
        for spec in _outputs(sid):
            ls = [l for l in self._ticked_layers(spec.name) if l.featureCount() > 0]
            if ls:
                out[spec.name] = ls
        return out

    def scan_rows(self) -> list:
        return scan.rows(self.store, self.picks(), self._counts())

    def replace(self) -> set[str]:
        return {sid for sid, w in self.ui.items() if not w["keep"].isHidden() and not w["keep"].isChecked()}

    def keeps(self, sid: str) -> bool:
        return self.ui[sid]["keep"].isChecked()

    def row_note(self, sid: str) -> str:
        return self.ui[sid]["note"].text()

    def detail_ids(self, sid: str) -> list[str]:
        return [cb.property("detail_id") for cb in self.ui[sid]["ticks"]]

    def tick_detail(self, sid: str, detail_id: str, on: bool = True):
        for cb in self.ui[sid]["ticks"]:
            if cb.property("detail_id") == detail_id:
                cb.setChecked(on)

    def _ticked_details(self, sid: str) -> list[str]:
        return [cb.property("detail_id") for cb in self.ui[sid]["ticks"] if cb.isChecked()]

    # ---------------- rescan: a taken-over layer changed since ----------------
    def _changed_since_takeover(self, sid: str) -> bool:
        """The ticked layers, snapshotted now exactly as the takeover wrote them, against the takeover's recorded
        snapshot_hash (geometry and attributes, before any field was filled). A takeover with no recorded hash
        falls back to geometry only against approved.gpkg (the fill adds fields and P4's worked-out collection
        points the drawn layers never had), per layer the snapshot holds."""
        import json
        from ..core import wayleave_diff
        chosen = self.layers_for(sid)
        if not chosen or not _taken_over(self.store, sid):
            return False
        ap = self.store.approved_gpkg(sid)
        try:
            recorded = json.loads((ap.parent / "takeover.json").read_text(encoding="utf-8")).get("snapshot_hash")
        except (OSError, ValueError, AttributeError):
            recorded = None
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
            now = Path(d) / "now.gpkg"
            write_step_snapshot(now, sid, chosen, self.store.load()["epsg"])
            if recorded:
                return wayleave_diff.fingerprint_hash(now) != recorded
            a, b = wayleave_diff.fingerprint(ap), wayleave_diff.fingerprint(now)
        geoms = lambda c: Counter({w: n for (w, _attrs), n in c.items()})        # noqa: E731
        return any(geoms(a.get(name, Counter())) != geoms(b[name]) for name in b)

    def _rescan(self):
        self._status("Comparing your layers with the taken-over ones...")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)    # final review I3: snapshots on the main thread
        try:
            self._rescan_rows()
        finally:
            QApplication.restoreOverrideCursor()
            self._status("")

    def _status(self, text: str):
        """A line under the steps naming the slow work under way, painted at once (final review I3)."""
        self.summary.setText(text)
        QApplication.processEvents()

    def _rescan_rows(self):
        for sid in scan.SCANNED:
            try:
                changed = self._changed_since_takeover(sid)
            except Exception as e:                       # noqa: BLE001 - a broken comparison must not hide the row
                self._msg[sid] = f"could not compare with the taken-over layer: {type(e).__name__}: {e}"
                continue
            if changed:
                self.ui[sid]["keep"].setChecked(False)
                self._msg[sid] = CHANGED

    # ---------------- the preview (what Continue would do) ----------------
    def _preview(self):
        if self._building:
            return
        rows = self.scan_rows()
        try:
            take, stop, why = scan.walk(self.store, rows, self.replace())
        except Exception as e:                           # noqa: BLE001
            take, stop, why = [], None, f"{type(e).__name__}: {e}"
        for row in rows:
            w = self.ui[row.stage_id]
            if self._seen.get(row.stage_id) not in (None, row.state):
                w["keep"].setChecked(True)               # newly approved / started: keep it unless unticked again
            self._seen[row.stage_id] = row.state
            w["keep"].setVisible(row.state in ("approved", "in_progress"))
            label = scan.label(row)
            for old, new in (("Found", "Found in your project"), ("Outstanding", "Not drawn yet")):   # spec 1 words
                if label.startswith(old) and not label.startswith(new):
                    label = new + label[len(old):]
            taken = row.state == "approved" and _taken_over(self.store, row.stage_id)
            again = taken and row.stage_id in take              # "again" only for a step Scan took over before
            changed = again and self._msg.get(row.stage_id) == CHANGED
            if taken:
                label = "Already done: drawn by hand, taken over by Scan"
            if changed:                                         # walk 2026-10-29: was "Already done ... Will be taken over."
                label = "Changed since it was taken over"
            if row.state in ("found", "approved", "in_progress") and row.layers:
                label += ": " + "; ".join(f"{_PLAIN.get(pl, pl)} from {', '.join(ns)}" for pl, ns in row.layers.items())
            if again:
                label += ". Will be taken over again."
            elif row.stage_id in take:
                label += ". Will be taken over."
            elif row.stage_id == stop:
                label += f". Stops here: {why}."
            w["state"].setText(label)
            msg = self._msg.get(row.stage_id) or row.note
            if changed:                                         # the state already says so: not twice
                msg = row.note
            if msg and msg.lower()[:14] in label.lower():      # already said in the state line: not twice
                msg = ""
            w["note"].setText(msg); w["note"].setVisible(bool(msg))
            w["details"].setVisible(row.stage_id in take and bool(w["ticks"]))
            self._tag(row.stage_id, "taken over again" if again else
                      "will be taken over" if row.stage_id in take else
                      "stops here" if row.stage_id == stop else
                      "done" if taken else
                      "kept" if row.state in ("approved", "in_progress") and w["keep"].isChecked() else "")
        self._refresh_picks()
        busy = self.stage_tab is None or self.stage_tab.busy
        self.continue_btn.setEnabled(not busy)
        self.continue_btn.setVisible(bool(take) or busy)
        if not take and not busy and not self.summary.text():
            self.summary.setText(f"Nothing to take over yet: {why}." if why else "Nothing to take over yet.")

    _TAG_TONE = {"will be taken over": "info", "taken over again": "warn", "stops here": "warn", "done": "ok",
                 "kept": "idle", "taken over \u2713": "ok", "taking over\u2026": "run"}

    def _tag(self, sid: str, text: str):
        """The coloured outcome at the right of a step (spec 11), in words, never colour alone."""
        from .theme import is_dark, tone
        tag = self.ui[sid]["tag"]
        tag.setText(text)
        c = tone(self._TAG_TONE.get(text, "idle"), is_dark(self))
        tag.setStyleSheet(f"QLabel {{ color: {c}; border: 1px solid {c}; border-radius: 8px; padding: 0px 7px; }}")
        tag.setVisible(bool(text))

    def _refresh_picks(self):
        """One line per plan layer: "✓ Feeder Cable (1,204)"; the tick list opens only to change the pick, or when
        there is nothing (or more than one candidate) to choose from."""
        from .theme import is_dark, tone
        for name, (pick, change, lst) in self._picks_ui.items():
            ticked = [lst.item(i).text() for i in range(lst.count()) if lst.item(i).checkState() == Qt.CheckState.Checked]
            plain = lst.property("plain")
            if lst.count() == 0:
                pick.setText(f"{plain}: no layer of this kind in your project")
                pick.setStyleSheet(f"color: {tone('idle', is_dark(self))};")
                change.hide(); lst.hide(); continue
            pick.setText(f"{plain}: \u2713 {', '.join(ticked)}" if ticked else f"{plain}: not picked \u2014 the plugin draws it")
            pick.setStyleSheet("" if ticked else f"color: {tone('idle', is_dark(self))};")
            open_list = change.isChecked() or (not ticked and lst.count() > 1)
            change.setVisible(True)
            lst.setVisible(open_list)

    # ---------------- Continue from these ----------------
    def continue_from_these(self):
        if self.stage_tab is None or self.stage_tab.busy:
            return
        if self.stage_tab.store is not self.store:        # the dock moved on: never write into the wrong site
            warn(self, "Scan current wayleave state", f"The Plan tab is now on another site, not {self.store.site}. "
                                                      "Close this window and scan again from the Wayleave box.")
            return
        note = self.note.text().strip()
        if not note:
            warn(self, "Scan current wayleave state", "An approval note is required.")
            return
        self.store.set_scan_picks(self.picks())
        rows = self.scan_rows()
        take, stop, why = scan.walk(self.store, rows, self.replace())
        self._msg = {k: v for k, v in self._msg.items() if v == CHANGED and k not in take}
        details, unticked = {}, None
        for i, sid in enumerate(take):                   # spec: a step with a detail left unticked is not taken over
            ids, got = self.detail_ids(sid), self._ticked_details(sid)
            if set(ids) - set(got):
                self._msg[sid] = (f"tick every one of your details for this step first "
                                  f"({len(set(ids) - set(got))} not ticked); it was not taken over")
                take, unticked = take[:i], sid
                break
            details[sid] = got
        self._walk_stop = (unticked, "") if unticked else (stop, why)
        if not take:
            self._chain_done([], None, "")
            return
        self.continue_btn.setEnabled(False)
        self._progress = (0, len(take))
        self.busy_bar.show()
        self.stage_tab.take_over(take, self.layers_for, note, details, on_step=self._step_done,
                                 on_done=self._chain_done)

    def _step_done(self, sid: str, ok, msg: str):
        done, total = self._progress
        if ok is None:                                   # the step is starting (final review I3)
            self._tag(sid, "taking over\u2026")
            self._status(f"Taking over {stages.get(sid).name} \u00b7 {done + 1} of {total}\u2026")
        elif not ok:
            self._msg[sid] = msg
            self._tag(sid, "stops here")
        else:
            self._progress = (done + 1, total)
            self._tag(sid, "taken over \u2713")

    def _chain_done(self, taken: list[str], stopped: str | None, msg: str):
        self.busy_bar.hide()
        for s in taken:                                  # taken now: a second press keeps it unless unticked again
            self.ui[s]["keep"].setChecked(True)
        try:
            head = f"Taken over: {', '.join(_short(s) for s in taken)}." if taken else "Nothing taken over."
            if stopped:
                first = (msg or "").strip().splitlines()[0] if (msg or "").strip() else "stopped"
                line, at = f"{head} Stopped at {stages.get(stopped).name}: {first}", stopped
            else:
                at, why = self._walk_stop
                if at is None:
                    line, at = f"{head} Next: {stages.get('p8_delivery').name}: Generate", "p8_delivery"
                elif why.startswith("run Gate 0"):
                    line, at = f"{head} Next: {why}.", "gate0"
                elif at in self._msg and not why:            # an unticked detail
                    line = f"{head} Stopped at {stages.get(at).name}: {self._msg[at]}"
                else:
                    state = next((r.state for r in self.scan_rows() if r.stage_id == at), "outstanding")
                    action = "Generate" if state == "outstanding" else why
                    line = f"{head} Next: {stages.get(at).name}: {action}"
            line = _sentence(line)                       # walk 2026-10-29: "...: Generate Press Save" had no full stop
            self.summary.setText(f"{line} {SAVE_LINE}" if taken else line)
            tab = self.stage_tab
            if tab is not None and at in getattr(tab, "rows", {}):
                tab.rows[at]["radio"].setChecked(True)
                tab.select(at)
        finally:
            self._preview()
            if self.on_done is not None:
                self.on_done()
