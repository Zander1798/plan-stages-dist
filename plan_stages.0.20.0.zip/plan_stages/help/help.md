# Plan Stages help

This page is always here on the **Help** tab. The other two tabs are **Spec** (the client's rules) and **Plan**
(the wayleave and the stages).

## 1. What Plan Stages does

Plan Stages plans a fibre network on a **wayleave you already have**. It never draws the wayleave itself.

The work goes in order, and nothing moves on until the step before it is approved:

1. **Wayleave**: a snapshot of the wayleave layers in your QGIS project.
2. **Gate 0**: checks that the wayleave can be planned at all.
3. **P1** feeder, from the POP to every PON. It follows the roads and runs beside them, as one line parallel to
   the road: 2 m inside the property line, or 6.5 m off the road line where no erf is near. It keeps off paths
   through properties. You fix it and approve it before anything is built on it.
4. **P2** 1:16 splitters, one per PON, on your approved feeder
5. **P3** distribution, the span split per PON, with the 1:16s joined to it
6. **P4** collection points and drops
7. **P5** road crossings (each one ends once the cable is off the road; up to 30 m is a Drill, longer a Trench)
8. **P6** 8-way splitters and dome joints, hung on your wayleave poles
9. **P7** delivery (a QGIS project and map images)

The poles are yours: the plan uses the poles in your wayleave exactly as drawn and never adds one. Where a
collection point or a 1:16 has none of your poles under it, its Check says so; draw the pole in your poles layer
and press **Use this wayleave** again. A poles layer with no points in it is accepted: Gate 0 warns, every
collection point stands on the cable, and each one's Check asks for a pole.

For every stage you press **Generate**, look at the result and fix anything on the map, press **Check**, then
**Approve**.

## 2. Before you start

You need:

- **QGIS 3.40 or later, or QGIS 4, on Windows.** On QGIS 3 the spec PDF page opens in your PDF viewer instead of inside QGIS.
- **The wayleave loaded in your QGIS project**: the layers in the table in section 3.
- **The client's spec values** (drop cap, span cap, and so on). Either the client's specification PDFs (the plugin
  reads HeroTel's by itself), HeroTel's ready-made template, or the values to hand to type.
- **No API key is needed.** An Anthropic API key is optional: with one, Claude reads the spec PDFs instead of the
  plugin's own reader.

## 3. The wayleave layers

Load these into your project before you set up the site. Each row in the Wayleave box (top of the Plan tab) fills
itself when your layer has one of the names below (capitals, spaces, `_` and `-` do not matter). If your layer has
another name, pick it in the row by hand: for example **PON Zones HT2** in the `pons` row. A layer with no features
is passed over when another layer of that name has some, and a required row is left for you to pick rather than
given an empty layer (a client package's empty POP layer, say) while any other layer of the row's type (points,
lines or polygons) has features.

| Row | Required? | Type | Filled automatically when your layer is called |
|---|---|---|---|
| `span` | yes | lines | span, spans, cable span, wayleave span, wayleave |
| `pons` | yes | polygons | pon, pons, pond, ponds, pon zones, pon zone, pon test |
| `demand_points` | yes | points | demand point, demand points, demandpoints, dp, dps, homes, demand unit, demand units |
| `pop` | yes | points | pop, pops, olt, olts, exchange |
| `roads` | yes | lines | road, roads, road osm, osm roads, streets |
| `poles` | yes | points | pole, poles |
| `erven` | no | polygons | erf, erven, ervan, erfs, stands, parcels |
| `aoi` | no | polygons | aoi, area of interest, boundary, site boundary |
| `buildings` | no | polygons | building, buildings, footprints, building footprints, structures, open buildings |

**Fields the plugin reads.** Everything else on your layers is ignored. A field is found by its own name, or else
by the first of these other names your layer has:

| Layer | Field | Also accepted |
|---|---|---|
| `pons` | `pon_num` (the PON number) | pon, pon_id, pon_no, number, id |
| `pons` | `homes` (homes in the PON) | units, stands, home_count, homes_count, count |
| `pop` | `name` | label, title, site |
| `poles` | `role` | type, class |
| `erven` | `erf_id` | id, erf, erf_no, parcel_id, stand_no |

A number field here must hold a number: text such as **P001** is left empty. (Only the plan layers Scan takes over
read text that ends in the number, such as **PON 047** as 47; see section 7.)

**What Gate 0 refuses.** Fix these in your layers, then press **Use this wayleave** again:

- **The span is not one network.** At least 99% of the span's metres must join up. Line ends must meet within
  **0.75 m** of each other to count as joined.
- **The POP is too far from the span.** It must be within **25 m** of the span, on the main network.
- **A PON cannot be fed.** Every PON must contain some span and be reachable along the span from the POP.
- **The CRS is wrong.** The site must use the Hartebeesthoek94 Lo zone of the area (section 5).

Your wayleave is taken as drawn. Demand points further from the span than the drop cap, poles off the span and
overlapping span features are counted for your information in the Check's log ("info …" lines); they are never
issues and never stop Approve.

## 4. Building footprints (optional)

Footprints let P1 keep the feeder off the land between houses (the midblock test). Without them P1 still runs, the
test is off, and the run log says so.

Any footprint layer works. Load it and pick it in the `buildings` row:

- **Google Open Buildings**: <https://sites.research.google/open-buildings/>
- **Microsoft building footprints**: <https://github.com/microsoft/GlobalMLBuildingFootprints>
- **OpenStreetMap buildings** through the QuickOSM plugin (key `building`).

## 5. Setting up a site

1. **Load the wayleave first**, then press **New site…** at the top of the dock. Give the site a name (letters,
   digits, `_` or `-`). The plugin suggests the Lo zone from your layers; accept it unless you know better. Then
   pick the **client spec** (the same list as the Spec tab's dropdown, below): the site's sheet starts from it.

   | Lo zone | EPSG |
   |---|---|
   | Lo15 | 2046 |
   | Lo17 | 2047 |
   | Lo19 | 2048 |
   | Lo21 | 2049 |
   | Lo23 | 2050 |
   | Lo25 | 2051 |
   | Lo27 | 2052 |
   | Lo29 | 2053 |
   | Lo31 | 2054 |
   | Lo33 | 2055 |

   Examples: Malmesbury Lo19 (2048), Cradock Lo25 (2051), Ventersdorp Lo27 (2052).

2. **Fill the spec.** Either:
   - **Client spec** (the dropdown at the top of the Spec tab): HeroTel; HeroTel 14 (at most 14 collection points
     and 112 demand points per PON); Vuma Reach (mid-block), Core (road front)
     or Key (informal); Fibertime Informal (1:8 then 1:16) or Formal (1:16 then 1:8); MetroFibre free-standing
     houses (1:4 then 1:16). The spec loads ready to plan: every value shows the document, page and sentence it
     comes from and is already accepted (untick or retype any you disagree with). A drop cap, span cap or
     cross-span cap the client does not state takes HeroTel's value, marked "HeroTel value used". Where the
     documents allow more than one value, the row asks you to pick one; any other value the documents do not
     state is empty: type it. The client's rules that change how a plan is
     drawn are in the extra details block. Add the client's PDF and the plugin checks each quote against it; no
     value changes. Nothing is kept until you press Save spec. For a client other than HeroTel the planning
     steps still plan HeroTel's way; that client's rules are in the details. Or
   - **Spec tab > Copy from…** another site you planned before, or
   - **Add PDF…** for the client's spec documents. The plugin finds the values in them by itself (**Find in
     PDFs**: no API key, no internet), using what it has been taught about that client's documents (HeroTel so
     far). Then **type the site's density** (high or low) in the density row: the splitter ratios follow that part
     of the spec. Type anything the documents do not state (for HeroTel, the drop cap). If an Anthropic API key is
     set under **Settings**, Claude reads the PDFs instead; the checks below are the same either way.

     Find in PDFs (and Copy from…) **replace what is on the sheet**; only a density already typed is kept. So
     read the PDFs first, then type or change values. On a client spec other than HeroTel, adding a PDF checks
     the spec's quotes instead, and Find in PDFs leaves the sheet alone (it only knows HeroTel's wording).

   The values the plan needs are at the top, and the line above the table says how many are settled
   ("Ready to plan: 9 of 11"). The **check** column shows:
   - **✓ verified p.N**: the sentence is on that page of the PDF, with that value in it. Tick it to accept.
   - **⚠ quote not in PDF** or **⚠ value not in quote**: the plugin could not find it. Read the document yourself;
     if you tick it anyway, it is recorded as your own value, not the document's.
   - **⚠ documents disagree**: the documents state different values. Select the row, pick the statement that
     applies to this site and press **Use this statement**, or type your own value.
   - **could not check**: the page is a scan with no text. Check it by eye.

   Hover over a check to see where it was found. **PON cap** and **fan cap** may say *worked out from the feeder
   split* or *from the distribution split*: a 1:16 feeder dome feeds 16 collection points, a 1:8 distribution
   splitter 8 homes.

   Under the planning values, the **Extra details** block holds what else the PDFs say that a
   planner should know: the other values (span typical, PON target, pole pitch …) and other details (cable sizes,
   stay rules, clearances, labelling …), each with its check. The plugin's own reader lists up to 100 sentences on
   planning topics that state a number or a rule ("drops must never cross a road diagonally"), rules first, as
   written in the PDF; Claude (with a key) writes a one-line summary of each instead. The plan does not use them.
   Tick **read** on each one you have looked at; unread details never stop you saving. They come only from the
   PDFs you add for this site, or with a client spec: Copy from… and a typed spec bring none of them.

   **Your own details.** Press **Add a detail…** under the extra details to write something this site needs that
   no document says, for example "No poles on the east side of Main Road". Tick the stages it affects (Gate 0, P1
   to P7), pick a topic and write the detail. Your rows say "operator" in the check column and list their stages.
   Select one of your rows to **Edit…** or **Remove** it; rows from the PDFs cannot be changed. Your details stay
   when you press Find in PDFs or Copy from…; Clear spec… removes them. Save spec keeps them with the spec and,
   like any spec change, makes every stage already started stale. The planning steps do not read your text: you
   check each detail yourself when you approve the stages it affects (section 6).

   Select any row to see its quote below the table; **Open page** shows that page of the PDF with the sentence
   highlighted. Change what is different for this site, then press **Save spec**. Nothing is kept until you do.
3. **Plan tab, Wayleave box**: check each row shows the right layer and count. Pick any row that stayed empty by
   hand (for example **PON Zones HT2** in `pons`). Then press **Use this wayleave**. Scrolling the panel over a row
   never changes it; click the row first if you want to use the mouse wheel in it. The plugin's own issue and stage
   layers are never offered.

## 6. Running the stages

Each stage is one row: a dot, its name, a line saying where it stands, and **one** button for the next thing to
do. Everything else is in the row's **•••** menu. A button that cannot be pressed is not shown; the line says what
the stage is waiting for ("Waiting for P3, P4").

| Button | What it does |
|---|---|
| **Generate** | Makes the stage from the approved stages above it. The result loads on the map, ready to edit. While it runs the row shows what it is doing, the time so far and an estimate from earlier runs; **Stop** ends it. |
| **Check** / **Check again** | Checks the stage as it is now, including your edits. Errors (×) block; warnings (!) do not. |
| **Approve** | Accepts the stage so the next one can start, and records "Approved by you" with the time. If errors are still listed, **Approve anyway…** in the ••• menu asks why it is OK and keeps your reason on record. |
| **Redo** | The stage is out of date (a stage above it, the rules or the wayleave changed): make it again. |
| **Try again** | The last run failed: run it again. **Show log** in the ••• menu says why it failed. |
| **Send back…** (•••) | Sends the stage back, with a note. |
| **Edit this stage** (•••) | Opens an approved stage again for editing. |
| **Delete this version…** (•••) | Deletes the stage's latest attempt. |
| **Put on map** | Puts a stage back on the map, for example after QGIS restarted. |
| **Save to SharePoint…** | On P7 Delivery's Summary. Opens File Explorer so you choose a folder (your SharePoint site folder, or anywhere). It saves the delivery project, all its layers in one GeoPackage and the map images in a new folder there, so it opens on anyone's laptop. It never overwrites an earlier save. |
| **▶ Auto from wayleave** | Above the stages. Draws and checks each stage still to do, one after another. After each clean check it stops, selects the stage and waits for you: look at it and press **Approve**, and Auto goes on to the next stage. It never approves anything itself. It stops on errors, where you chose **Pause after**, or when you send a stage back. **Stop** ends it after this stage or at once. |

Under the stages, **Issues · Summary · Log** show the selected stage. Issues come first: the chips at the top
(**× Errors**, **! Warnings**, **Hidden**) show or hide each kind, **By check** / **By PON** group them, and
**Previous** / **Next** (keys P and N) step through them on the map. An issue with a reason (›) shows it above
the list when you click it, with what to do.

**P1, P2 and P3 in detail.**

- **P1 Feeder.** Generate draws the feeder from the POP to every PON, beside the road. With an AOI in the wayleave,
  the feeder uses only the roads inside it and never leaves it. Move it where you want it,
  then Check and Approve. Check warns about feeder points away from the road (midblock) and gives an error for a
  PON that the feeder does not reach: no feeder point within 25 m of that PON's span.
- **P2 1:16 splitters.** Generate puts one 1:16 in each PON, on the feeder you approved. It stands where P1 aimed
  it if your feeder still passes there (within 2 m); if you moved the feeder away from that spot, it stands on the
  point of your feeder nearest that PON's span. A 1:16 is never placed off the feeder. A PON your feeder does not
  reach gets none: click it in the list and the **Why** window says why. Check wants exactly one 1:16 per PON.
  A 1:16 does not have to stand inside its PON, it only has to run into one: one outside every PON belongs to the
  PON its `pon` field names, else to the nearest PON.
- **P3 Distribution.** Generate splits the span per PON. If you moved a 1:16 off the span, or it stands outside its
  PON, P3 adds one straight link from it into its PON's span (that piece is marked `link` = 1). Check wants every 1:16
  to join the distribution (within 2 m).

**An older site.** A site made before version 0.11.0 opens with its wayleave, Gate 0 and spec kept. Every plan
stage starts again from P1, because the stages are cut differently now. The old plan work is not deleted: it is
moved to the site's `old-layout` folder. A site opened with unsaved progress is still wiped, as below.

**Click an issue** in the list and the map zooms to it, selects it and makes its layer active, so you can fix it
straight away. When the step left something out on purpose (a PON with no 1:16, say), the click also opens a
small **Why** window that says why, and what to fix. Click a **bold heading** to select everything that check found. When you save your edits, the check
runs again and fixed items disappear.

**Your details at Approve.** A stage with your own details (section 5) shows them in a yellow box above its log.
When you press **Approve**, a window lists them: tick each one once you have checked the plan against it. Approve
stays refused until every one is ticked, and this cannot be overridden. The ticked details are written into the
stage's `approval.json`.

**Every step builds on what you corrected.** Check works from what is drawn on the map, not from numbers the
plugin wrote: a drop you add counts towards the fan cap; a drop you draw across a road is an error in P4's Check;
a 1:16 counts for the PON it stands in (outside every PON: the one its `pon` field names, else the nearest). A collection point you draw yourself gets the next free number when you
press Check (the check log lists it). When you Approve, the next Generate builds on exactly what you approved: P5
on your cable and collection points, and P6 hangs the splitters and domes on your wayleave poles.

**Your fixes stay crossed out.** When you edit a feature an issue points at, its row is crossed out: "fixed by
you". When you press Check, an issue that is gone disappears; one that the Check still finds on the feature you
edited stays crossed out under "fixed by you" at the bottom of the list. It does not come back on later Checks.

**Removing an issue.** If you judge an issue (a warning or an error) is not a real problem for this plan, select it
and press **Not a problem** (under the issues list). It moves to "Hidden by you" at the bottom. Only that issue is removed: other issues on the same feature (another pole gap on the
same cable, another vertex of the same feeder), and any new issue found there later, stay on the list.

Fixed and removed issues stay off the list through every Check and every new Generate of the stage (a regenerated
feature with the same shape). Select one at the bottom and press **Bring back** to bring it back. When every
issue of a failed check is fixed or removed, Approve no longer counts that check as failed. Approve records each one
in the stage's `approval.json`. An approved stage keeps them as approved: use **Edit this stage** to change them.

**P4 follows your cable.** P4 puts collection points only on wayleave poles that stand on your approved P3
distribution cable (within 2 m); a pole your corrected cable no longer passes is not used. Where your cable runs
with no wayleave pole within 31.5 m, P4 puts the collection point on the cable itself, and P4's Check warns
"collection point … m from the nearest wayleave pole: draw a pole here in the wayleave, or move the collection
point onto one". Nothing adds that pole for you. P2's Check warns the same way for a 1:16 with none of your poles
within 2 m. P6 hangs the splitters and domes on your poles. P4's Check still warns for a
collection point you drag more than 2 m off your cable.

**No drop is longer than the spec's drop cap.** P4 never draws a drop longer than the drop cap on your Spec tab
(70 m for HeroTel). A home no collection point can reach within the cap gets no drop, and P4's Check lists it as an
error that says why: the nearest collection point is too far, the ones in reach are full, or every one in reach is
across a road. Click the row to go to the home, then add or move a collection point, or remove the issue. A drop
you draw yourself is never deleted.

**No drop crosses a road.** On every spec, P4 never draws a drop across a road. A home whose only collection points
in reach are across the road is served from one on its own side (P4 opens one there if it can); when there is none,
the home gets no drop and an error row that says every collection point in reach is across a road. A drop you draw
across a road yourself is an error in P4's Check. P4 needs the Roads layer for this: with no roads in the wayleave,
the wayleave check says so.

**HeroTel 14.** With the HeroTel 14 spec, a PON of 112 demand points or fewer never gets more than 14 collection
points: homes that no longer fit get no drop and an error row, and a collection point you placed yourself is never
removed (a 15th one you place is an error in P4's Check). A PON with more than 112 demand points is still planned,
with the collection points it needs: the wayleave check lists it as an error (fix the PON boundary, or carry on) and
P4's Check warns. Find in PDFs keeps HeroTel 14's 14 and 112. To use it on an existing site, pick HeroTel 14 on its
Spec tab and press Save spec. A site set to HeroTel 14 on version 0.17.0 saved its sheet without this rule: pick
HeroTel, then HeroTel 14 again, press Save spec, and Generate P4 again.

**Generate checks the wayleave first.** If you edited the wayleave layers in the project after **Use this
wayleave**, Generate stops and lists what changed (for example "span: 1 added, 1 removed"). Press **Use this
wayleave** again, then Generate.

**Press Save** (top of the dock) to keep your progress. Progress that was not saved is wiped the next time the
site is opened.

## 7. Your wayleave already has part of the plan

Some wayleaves come with part of the plan already drawn: the feeder, the 1:16s, the distribution, the drops. You
do not have to generate those again. Press **Use what I've drawn…** (in the Wayleave box, under Use this
wayleave; it works once the wayleave is used) and the plugin carries on from the layers you have. The scan can list
your layers straight away, but it takes steps over only once Gate 0 is approved: until then it says "run Gate 0
first".

**The scan window** has one row per plan step, P1 to P6, in order. Each row says one of:

- **Found**: your layer for that step, with how many features it has. It will be taken over.
- **Outstanding**: no layer found. You generate this step as usual.
- **Started in the plugin, not yet approved**: the plugin's own attempt. It is kept (**keep the plugin's version**
  is ticked) and the scan stops there for you to finish it.
- **Already done in the plugin**: approved already. It is kept too, so a new scan never replaces work by itself.
  Untick **keep the plugin's version** and tick your layer if you want your layer instead; the steps after it then
  go stale, as with any new approval.
- **Approved in the plugin, now stale (an earlier step or the spec changed)**: approved once, but what it was built
  on changed. The scan stops there: generate it again, or untick **keep the plugin's version** to take your layer.

Each row lists your project layers with ticks. The plugin ticks the ones whose names fit (for example Feeder Fibre,
Feeder Joints, DC Fibre 12F Aerial, Drop Fibre). Change the ticks if it guessed wrong. **Tick several layers for
one step** when you drew it across several layers: DC Fibre 12F Aerial, DC Fibre 24F Aerial and Link Fibre are
merged into one distribution, and the lines from Link Fibre are marked as links. Link Joints belong to no step. P4
needs only your drops: when you have no collection-point layer, the plugin puts one collection point where your
drops end together. P6 needs both an 8-way splitter layer and a dome joint layer; with only one of them it stays
outstanding and P6 generates both.

**Take these over.** Type a short note and press **Take these over**. That press approves every step it
takes over, the way Use this wayleave approves the wayleave. If a step has your own details from the Spec tab, they
are listed under it in the window: tick each one first, or that step is not taken over and the scan stops there.

- The steps are taken over **in order**: P1, then P2, then P3 and so on. A step is taken over only when every step
  before it is approved. If your feeder is missing but your distribution is drawn, the feeder is generated first and
  your distribution waits its turn.
- A step you **keep** that is built on a step taken over in the same press goes stale when that step is approved,
  so the scan stops there: generate it again, or untick **keep the plugin's version**.
- A step taken over is **marked drawn by hand**: its tab says "Drawn by hand (layer ...), taken over by Scan".
- **No second layer is added.** Your own layer stays the one on the map, and nothing ever adds a copy of it: not the
  scan, not Generate, not Revise. Clicking
  an issue on a step taken over zooms to the spot; it does not select the feature.
- A number field of your layer may hold text that ends in the number: **PON 047** is read as 47. A value that cannot
  be read is left empty, and the step's run log names the field and how many values were left.
- Its **Check still runs**, with the same rules as always, and its **issues are still listed**, clickable, to fix or
  Remove. A failed check never stops the takeover; the approval records that the step went in with open issues.
  Only a Check that crashes stops the scan at that step: press Check, then Approve.
- **The first missing step generates from your layers**: press Generate on it, and it builds on the steps you drew.

Press **Save** to keep the takeover (unsaved progress is wiped when the site is next opened).

**Use my drawn layer.** A layer found for a step that had to wait (an earlier step was missing) is not lost. When
you reach that step, its tab shows **Use my drawn layer (name)** next to Generate. It takes your layer over the
same way, and so does **Generate** on that step: it never draws a second layer beside yours, it takes yours over and
the plan moves on to the next step. **Revise** on a step taken over takes your layer over again as it is now (edit
your own layer, not a copy). To have the plugin draw a step instead, untick your layer in the scan window.

**Generate never adds a second layer.** If you have not scanned and your project already holds a layer for a step
(one the scan would tick by its name, such as Feeder Cable or 1 to 16 Splitter), Generate on that step draws
nothing and asks you to scan first: keep the layer ticked to use it, or untick it to have the plugin draw the step.

**Rescan after edits.** The scan shows your layers as they are when you open it. If you change a layer that was
already taken over, scan again: the row says "Changed since it was taken over ... Will be taken over again", and
Take these over takes the new version over.

**Nothing in your project layers changes.** The plugin copies your layers; it never edits, moves or deletes what
you drew. Fields the next steps need (the PON of a 1:16, the length of a drop, and so on) are filled in on the copy
only, worked out from where things are drawn.

## 8. Greyed out, or something went wrong

- **"Use this wayleave" is greyed out.** The line under it says why: a required row is empty, or a layer has no
  coordinate system.
  No saved spec is not a reason: pressing it saves the sheet on the Spec tab first (a new site's client preset) and
  stops only if that sheet is missing a required value, naming it.
- **Gate 0 warns about the span** (in pieces, the POP off it, a PON with no span or not reachable). These are
  information about your wayleave and never stop you: P1's Check names any PON the feeder does not reach, P2's
  any PON left without a 1:16, and P3's any 1:16 the distribution does not join.
- **Save spec says the spec is not complete.** The line above the rules says what is still needed, and the first
  missing rule is selected: tick it, type a value, or type `n/a`.
- **Find in PDFs found little or nothing.** The plugin has not been taught that client's documents yet (it says
  so), or the PDF is a scan with no text. Type the values, and send the PDFs so the client can be added.
- **The split rows say documents disagree.** Press **High** or **Low** density above the rules first.
- **The Spec tab shows an amber "HeroTel value" banner.** The client's documents give no value for that rule, so
  HeroTel's is in its place. Press **Keep** if it is right for this site, or **Change** and type the client's value.
  Until you do, the stages that read that rule wait.
- **Edit… / Remove under the extra details are greyed out.** Select one of your own rows; rows from the PDFs
  cannot be edited.
- **Approve says an operator detail is not checked.** Press Approve again and tick every detail in the window.
- **Generate says the wayleave on screen differs.** You (or a tool) changed a wayleave layer after Use this
  wayleave, or a row in the Wayleave box is no longer picked. Press **Use this wayleave** again (every started
  stage goes stale), or undo the edit.
- **"Read the PDFs with Claude" is greyed out.** It needs a Claude API key under **Settings** (the ••• menu at
  the top of the dock). Without a key, use **Find the rules in the PDFs** (Spec tab, **More**).
- **The stages show no buttons.** The blue line above them says why: press Use this wayleave (again, if the spec
  changed). The rows stay readable meanwhile.
- **A stage says out of date.** Something above it changed; the row says what ("P2 changed", "rules changed").
  Press **Redo**, or **Redo from P3** in the banner above the list.
- **I reopened a site and my work is gone.** It was not saved. The top of the dock says **● Not saved · Save**
  when there is work to keep, and the dock asks before you switch site or close it. Approving a stage saves too.
- **"Site … is open in another QGIS".** Only one QGIS can work on a site. Close the other one. After a crash,
  delete the `lock` file in the site folder, once you are sure no other QGIS is using it.
- **Gate 0 fails on the CRS.** The site's EPSG is not the Lo zone of your data. Make a new site with the right zone
  (section 5).
- **The wayleave check says a layer is nowhere near the AOI.** None of that layer's features is within 1 km of the
  AOI, almost always because its coordinate system is missing or wrong in the project (a GeoPackage can carry none
  of its own). In the Layers panel right-click the layer, **Layer CRS > Set Layer CRS…**, pick the one the data is
  in (usually WGS 84, EPSG:4326), then press **Use this wayleave** again. It never stops you starting.
- **P4's Check says no drops were drawn.** The wayleave has demand points but P4 found none inside the PONs, so it
  drew nothing. Look at the wayleave check first (a layer nowhere near the AOI), fix the demand points or the PONs,
  press Use this wayleave again and Generate P4 again.
- **Odd errors right after updating the plugin.** Save, then restart QGIS.

## 9. Updating the plugin, and where files are kept

**Updating.** When a new version is out, a pop-up says so each time you open the Plan Stages panel, with what is
new in it. **Update** installs it (it offers to Save an unsaved site first); **Skip for now** closes it until the
next time you open the panel. Restart QGIS after updating. You can also update from Plugins > Manage and Install
Plugins > **Upgradeable** > Plan Stages > Upgrade: press **Save** in the dock first.

**Installing on a new PC.** Plugins > Manage and Install Plugins > Settings > Add…, and enter
<https://raw.githubusercontent.com/Zander1798/plan-stages-dist/main/plugins.xml>. Then search **Plan Stages** on
the All tab and press Install.

**Where files are kept.**

- Sites: `Documents\PlanStages\<site>` (change it with "Where sites are saved" under **Settings**). Each stage has a folder with
  one `rev-NNN` folder per attempt; nothing is overwritten.
- Settings: `plan_stages.toml` in your QGIS profile folder
  (`%APPDATA%\QGIS\QGIS4\profiles\default`, the same folder on QGIS 3 and QGIS 4).
