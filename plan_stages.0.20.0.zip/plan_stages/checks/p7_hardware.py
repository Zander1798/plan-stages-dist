import sys
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.checks.common import main, open_layer, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

ON_POLE_M = 0.5


def extra(report, rev):
    ds, spl = open_layer(str(rev / "working.gpkg"), "splitters_8way")
    ds2, dome = open_layer(str(rev / "working.gpkg"), "dome_joints")
    _one_per_cp(report, spl, dome)
    _on_poles(report, spl, dome)


def _on_poles(report, spl, dome):
    """2026-10-14: hardware hangs on a pole: each 8-way splitter and dome joint within ON_POLE_M of an approved
    wayleave pole (0.13.0: the operator's poles; P6 Pole reconciliation is gone). A warning: Generate leaves hardware
    whose collection point has no pole within 2 m where it is."""
    poles_gpkg = P.approved_path("wayleave")
    pds = ogr.Open(poles_gpkg) if poles_gpkg else None
    pl = pds.GetLayerByName("poles") if pds is not None else None
    if spl is None or dome is None or pl is None:
        report.checks.append(CheckResult("hardware_on_pole", False, "skipped", "hardware layers or approved wayleave poles missing"))
        return
    tree = cKDTree(P.points_site(pl)) if pl.GetFeatureCount() else None
    n = 0
    for name, lyr in (("splitters_8way", spl), ("dome_joints", dome)):
        lyr.ResetReading(); t = P.to_site(P.layer_epsg(lyr))
        for f in lyr:
            g = f.GetGeometryRef()
            if g is None:
                continue
            d = tree.query(t.TransformPoint(g.GetX(), g.GetY())[:2])[0] if tree is not None else float("inf")
            if d > ON_POLE_M:
                n += 1; add_issue(report, lyr, f, "hardware_on_pole", "warn", f"{name} not on a wayleave pole ({d:.1f} m)")
    report.checks.append(CheckResult("hardware_on_pole", False, "passed" if n == 0 else "failed",
                                     f"{n} splitters/domes not on a wayleave pole"))


def _one_per_cp(report, spl, dome):
    drops_gpkg = P.approved_path("p4_drops")
    if spl is None or dome is None or drops_gpkg is None:
        report.checks.append(CheckResult("one_per_cp", True, "skipped", "hardware layers or approved P4 missing"))
        return
    pds = ogr.Open(drops_gpkg); cps = pds.GetLayerByName("collection_points")
    cp_feats = list(cps)
    want = sorted(f.GetField("cp_id") for f in cp_feats); wset = set(want)
    bad = []; per_cp: dict = {}                            # cp_id -> ["dome_joints 2", ...] (one row per CP, ruling 2026-10-08)
    for name, lyr in (("splitters_8way", spl), ("dome_joints", dome)):
        have = {}
        for f in lyr:
            have[f.GetField("cp_id")] = have.get(f.GetField("cp_id"), 0) + 1
        miss = [c for c in want if have.get(c, 0) != 1]
        unknown = [c for c in have if c not in wset]
        if miss or unknown:
            bad.append(f"{name}: {len(miss)} collection points without exactly one, {len(unknown)} unknown cp_id")
        for cp in miss:
            per_cp.setdefault(cp, []).append(f"{name} {have.get(cp, 0)}")
        for f in lyr:                                    # hardware whose cp_id matches no collection point
            if f.GetField("cp_id") in unknown:
                add_issue(report, lyr, f, "one_per_cp", "error", f"{name}: unknown cp_id {f.GetField('cp_id')}")
    for f in cp_feats:                                   # located on the approved P4 collection point
        cp = f.GetField("cp_id")
        if cp in per_cp:
            add_issue(report, cps, f, "one_per_cp", "error", f"cp {cp}: {', '.join(per_cp[cp])} (want 1 each)", source="p4_drops")
    report.checks.append(CheckResult("one_per_cp", True, "passed" if not bad else "failed",
                                     "; ".join(bad) if bad else f"{len(want)} collection points, one 8-way and one dome each"))


if __name__ == "__main__":
    sys.exit(main(extra))
