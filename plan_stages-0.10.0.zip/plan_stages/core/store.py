from __future__ import annotations
import hashlib, json, os, time
from pathlib import Path
from . import stages


class LockHeld(Exception):
    def __init__(self, pid: int, when: str):
        super().__init__(f"site locked by pid {pid} since {when}")
        self.pid, self.when = pid, when


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _blank_stage() -> dict:
    return {"status": "pending", "current_rev": None, "approved_rev": None,
            "generated_from": {}, "spec_rev": None, "checked_hash": None, "approved_hash": None}


class SiteStore:
    def __init__(self, plan_root: Path, site: str):
        self.site = site
        self.site_dir = Path(plan_root) / site
        self._state_path = self.site_dir / "site.json"
        self._lock_path = self.site_dir / "lock"

    # ---- state ----
    def create_site(self, epsg: int, client: str, preset: str | None = None) -> None:
        self.site_dir.mkdir(parents=True, exist_ok=True)
        if not self._state_path.exists():
            self.save({"site": self.site, "epsg": epsg, "client": client, "spec_preset": preset, "spec_rev": None,
                       "stages": {sid: _blank_stage() for sid in stages.order()}})

    def load(self) -> dict:
        st = json.loads(self._state_path.read_text(encoding="utf-8"))
        for sid in stages.order():         # a site made before a registry change has no row for a new stage
            st["stages"].setdefault(sid, _blank_stage())
        return st

    def save(self, state: dict) -> None:
        tmp = self._state_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
        os.replace(tmp, self._state_path)

    def stage_state(self, stage_id: str) -> dict:
        return self.load()["stages"][stage_id]

    # ---- saved progress (operator ruling 2026-10-07) ----
    # Planning progress persists only when the operator presses Save; a site opened with unsaved progress
    # starts clean. The spec is saved by its own Save revision and is never part of this.
    def is_saved(self) -> bool:
        return bool(self.load().get("saved", False))

    def mark_saved(self, saved: bool = True) -> None:
        st = self.load(); st["saved"] = saved; self.save(st)

    def started_stages(self) -> list[str]:
        return [sid for sid, s in self.load()["stages"].items() if s["status"] != "pending" or s["current_rev"]]

    def set_stage(self, stage_id: str, **fields) -> None:
        st = self.load()
        st["stages"][stage_id].update(fields)
        self.save(st)

    # ---- revisions ----
    def rev_dir(self, stage_id: str, rev: str) -> Path:
        return self.site_dir / stage_id / rev

    def new_revision(self, stage_id: str) -> Path:
        base = self.site_dir / stage_id
        base.mkdir(parents=True, exist_ok=True)
        existing = sorted(p.name for p in base.glob("rev-*") if p.is_dir())
        n = int(existing[-1][4:]) + 1 if existing else 1
        rev = f"rev-{n:03d}"
        (base / rev).mkdir()
        # A new revision starts clean: nothing checked, nothing generated from yet. Leaving the previous
        # revision's checked_hash here made can_approve hash a working.gpkg that may never be written.
        self.set_stage(stage_id, current_rev=rev, checked_hash=None, generated_from={}, status="generating")
        self.mark_saved(False)                  # new work: unsaved until the operator presses Save
        return base / rev

    def latest_layer(self, stage_id: str) -> Path | None:
        """What a revise or a manual re-generate starts from: the latest approved.gpkg, else the current
        revision's working.gpkg; None when neither exists."""
        ap = self.approved_gpkg(stage_id)
        if ap is not None and ap.exists():
            return ap
        cur = self.stage_state(stage_id)["current_rev"]
        wk = self.rev_dir(stage_id, cur) / "working.gpkg" if cur else None
        return wk if wk is not None and wk.exists() else None

    def set_client_preset(self, client: str, preset_id: str | None) -> None:
        """The client and preset the site's spec was built from (2026-10-16); written at Save revision."""
        st = self.load()
        st["client"] = client
        st["spec_preset"] = preset_id
        self.save(st)

    def save_spec_revision(self, rev_id: str) -> None:
        """A new confirmed spec revision: record it and mark every stage already started stale."""
        st = self.load()
        st["spec_rev"] = rev_id
        for s in st["stages"].values():
            if s["status"] != "pending":
                s["status"] = "stale"
        self.save(st)

    def approved_gpkg(self, stage_id: str) -> Path | None:
        s = self.stage_state(stage_id)
        if not s["approved_rev"]:
            return None
        return self.rev_dir(stage_id, s["approved_rev"]) / "approved.gpkg"

    def mark_failed(self, stage_id: str, rev: Path, log_text: str) -> None:
        for part in rev.glob("generated.gpkg*"):
            part.unlink()
        with open(rev / "run.log", "a", encoding="utf-8") as f:
            f.write(log_text)
        self.set_stage(stage_id, status="failed")

    # ---- lock ----
    def acquire_lock(self) -> None:
        if self._lock_path.exists():
            try:
                d = json.loads(self._lock_path.read_text())
            except Exception:
                d = {"pid": -1, "when": "?"}
            if _pid_alive(d["pid"]):
                raise LockHeld(d["pid"], d["when"])
        self._lock_path.write_text(json.dumps({"pid": os.getpid(), "when": time.strftime("%Y-%m-%d %H:%M:%S")}))

    def release_lock(self) -> None:
        if self._lock_path.exists():
            self._lock_path.unlink()


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
        return False
    except Exception:
        return True   # cannot tell: be safe and treat as alive
