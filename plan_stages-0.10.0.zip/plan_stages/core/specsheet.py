from __future__ import annotations
import json
from dataclasses import dataclass, asdict, field, fields
from pathlib import Path

SPEC_KEYS: tuple[str, ...] = (
    "density", "drop_cap_m", "span_cap_m", "span_typical_m", "cable_span_rating_m", "cross_span_m",
    "fan_cap", "pon_cap", "feeder_split", "dist_split", "pon_target", "pon_max",
    "pole_midblock_m", "pole_crossing_m", "pole_feeder_m", "pole_boundary_setback_m", "pole_pitch_m",
    "direction_change_stay_deg", "aerial",
)
UNITS = {"drop_cap_m": "m", "span_cap_m": "m", "span_typical_m": "m", "cable_span_rating_m": "m", "cross_span_m": "m",
         "pole_midblock_m": "m", "pole_crossing_m": "m", "pole_feeder_m": "m", "pole_boundary_setback_m": "m",
         "pole_pitch_m": "m", "direction_change_stay_deg": "deg"}
# conflict: the documents state different values; the operator picks one (Sheet.pick) or types their own
STATUSES = ("proposed", "confirmed", "operator_stated", "not_found", "not_applicable", "conflict")
OPERATOR = "operator"      # Sheet.extras rows the operator wrote (2026-10-14); a row without "source" is from a PDF


def is_operator(x: dict) -> bool:
    return x.get("source") == OPERATOR


def detail_stage_ids() -> tuple[str, ...]:
    """The stages an operator detail may affect: the Plan tab's. Not the wayleave, approved in its own box."""
    from . import stages
    return tuple(s.id for s in stages.REGISTRY if s.phase != "source")


class SheetIncomplete(Exception):
    def __init__(self, keys: list[str]):
        super().__init__("unresolved: " + ", ".join(keys)); self.keys = keys


@dataclass
class SheetEntry:
    key: str
    value: object = None
    unit: str = ""
    status: str = "not_found"
    document: str = ""
    page: int | None = None
    quoted_text: str = ""
    note: str = ""
    check: str = ""          # the plugin's own check of the quote (core/spec_verify); "" = not from a PDF
    check_note: str = ""
    candidates: list = field(default_factory=list)   # every statement of this key found in the PDFs (dicts)


@dataclass
class Sheet:
    client: str
    rev: str = ""
    entries: dict[str, SheetEntry] = field(default_factory=dict)
    # other details a planner should see: from the PDFs submitted for this site (operator 2026-10-13; dicts with
    # topic, detail, document, page, quoted_text, check, check_note, read) and the operator's own (2026-10-14:
    # source "operator", id, stages). Never read by the step scripts; the operator's are ticked at Approve.
    extras: list = field(default_factory=list)
    op_seq: int = 0            # last operator detail number handed out; ids are never reused

    @classmethod
    def blank(cls, client: str) -> "Sheet":
        return cls(client, "", {k: SheetEntry(k, unit=UNITS.get(k, "")) for k in SPEC_KEYS})

    def confirm(self, key: str) -> None:
        from .spec_verify import BLOCKING
        e = self.entries[key]
        if e.status not in ("proposed", "operator_stated"):
            raise ValueError(f"{key} has nothing to confirm (status {e.status})")
        if e.status == "proposed" and e.check in BLOCKING:
            raise ValueError(f"{key}: {e.check_note or e.check}; type the value yourself if you know it")
        if e.status == "proposed":
            e.status = "confirmed"

    def pick(self, key: str, index: int) -> None:
        """Take statement `index` of the key's candidates as its proposed value (documents that disagree)."""
        e = self.entries[key]
        c = e.candidates[index]
        self.entries[key] = SheetEntry(key, c["value"], c.get("unit") or UNITS.get(key, ""), "proposed",
                                       c.get("document", ""), c.get("page"), c.get("quoted_text", ""), e.note,
                                       c.get("check", ""), c.get("check_note", ""), list(e.candidates))

    def apply_density(self, density: str | None) -> None:
        """The operator chose the site's density (or cleared it): rows whose statements sit in density sections (the
        split ratios, and the caps worked out from them) keep only that section's statements. Nothing is lost:
        every statement stays on the row, so changing density brings the others back."""
        for k, e in list(self.entries.items()):
            if any(c.get("regime") for c in e.candidates):
                self.entries[k] = entry_from_candidates(k, e.candidates, density)

    def set_operator(self, key: str, value, note: str) -> None:
        self.entries[key] = SheetEntry(key, value, UNITS.get(key, ""), "operator_stated", "operator-stated", None, "", note)

    def operator_details(self, stage_id: str | None = None) -> list[dict]:
        return [x for x in self.extras if is_operator(x) and (stage_id is None or stage_id in x.get("stages", ()))]

    def add_detail(self, stage_ids, topic: str, detail: str) -> dict:
        x = _operator_row(stage_ids, topic, detail)
        self.op_seq += 1
        x = {"id": f"op-{self.op_seq:03d}", **x}
        self.extras.append(x)
        return x

    def edit_detail(self, detail_id: str, stage_ids, topic: str, detail: str) -> dict:
        i = self._detail_index(detail_id)
        x = {"id": detail_id, **_operator_row(stage_ids, topic, detail)}
        self.extras[i] = x
        return x

    def remove_detail(self, detail_id: str) -> None:
        del self.extras[self._detail_index(detail_id)]

    def _detail_index(self, detail_id: str) -> int:
        for i, x in enumerate(self.extras):
            if is_operator(x) and x.get("id") == detail_id:
                return i
        raise KeyError(detail_id)

    def with_operator_extras(self, old: "Sheet | None") -> "Sheet":
        """This sheet (just found in the PDFs, proposed or copied) with `old`'s operator details after its own PDF
        rows: the operator's details belong to the site, not to a document. Any operator rows already here go."""
        if old is None:
            return self
        self.extras = [x for x in self.extras if not is_operator(x)] + [dict(x) for x in old.operator_details()]
        self.op_seq = max(self.op_seq, old.op_seq)
        return self

    def mark_not_applicable(self, key: str) -> None:
        self.entries[key] = SheetEntry(key, None, UNITS.get(key, ""), "not_applicable")

    def unresolved(self, required: tuple[str, ...]) -> list[str]:
        return [k for k in required if self.entries.get(k, SheetEntry(k)).status not in
                ("confirmed", "operator_stated", "not_applicable")]

    def save(self, path: Path, required: tuple[str, ...]) -> None:
        missing = self.unresolved(required)
        if missing:
            raise SheetIncomplete(missing)
        out = {"client": self.client, "rev": self.rev,
               "entries": {k: _export(e) for k, e in self.entries.items()}, "extras": list(self.extras),
               "op_seq": self.op_seq}
        Path(path).write_text(json.dumps(out, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "Sheet":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        known = {f.name for f in fields(SheetEntry)}      # a sheet written by a newer plugin still loads
        return cls(d["client"], d.get("rev", ""),
                   {k: SheetEntry(**{f: x for f, x in v.items() if f in known}) for k, v in d["entries"].items()},
                   list(d.get("extras") or []), int(d.get("op_seq") or 0))


def _export(e: SheetEntry) -> dict:
    d = asdict(e)
    if e.status == "operator_stated":
        d["status"] = "confirmed"; d["note"] = (e.note + " [operator-stated]").strip()
    return d


def _operator_row(stage_ids, topic: str, detail: str) -> dict:
    from .spec_claude import TOPICS
    allowed = detail_stage_ids()
    asked = list(stage_ids or ())
    bad = [s for s in asked if s not in allowed]
    if bad:
        raise ValueError(f"not a stage a detail can affect: {', '.join(bad)}")
    if not asked:
        raise ValueError("tick at least one stage the detail affects")
    if topic not in TOPICS:
        raise ValueError(f"unknown topic {topic!r}")
    text = (detail or "").strip()
    if not text:
        raise ValueError("the detail is empty")
    return {"source": OPERATOR, "stages": [s for s in allowed if s in asked], "topic": topic, "detail": text,
            "document": "", "page": None, "quoted_text": "", "check": OPERATOR,
            "check_note": "added by the operator in the Plan Stages dock", "read": True}


def entry_from_candidates(key: str, cands: list[dict], density: str | None = None) -> SheetEntry:
    """One sheet row from every statement of `key`: the documents agree (one plausible value) -> proposed, the
    best-checked statement chosen; they disagree -> conflict, the operator picks. Implausible values never vote.
    A statement from a density section other than `density` does not vote either; with no density chosen, the
    statements of both sections do (so the split ratios wait for the operator's choice)."""
    from . import spec_verify as sv
    rank = {sv.VERIFIED: 0, sv.UNREADABLE: 1, sv.VALUE_NOT_IN_QUOTE: 2, sv.QUOTE_NOT_FOUND: 3, sv.BAD_VALUE: 4}
    cands = sorted(cands, key=lambda c: rank.get(c.get("check", ""), 5))
    pool = [c for c in cands if density is None or not c.get("regime") or c.get("regime") == density]
    plausible = [c for c in pool if c.get("check") != sv.BAD_VALUE]
    # statements found in the PDF decide; only when none was found do the unconfirmed ones count
    trusted = [c for c in plausible if c.get("check") in (sv.VERIFIED, sv.UNREADABLE)] or plausible
    if not trusted:
        return SheetEntry(key, None, UNITS.get(key, ""), "not_found", candidates=cands,
                          check_note=f"nothing stated for {density} density" if density else "")
    e = SheetEntry(key, None, UNITS.get(key, ""), "conflict", candidates=cands)
    if len({json.dumps(c["value"]) for c in trusted}) > 1:
        e.check_note = "the documents state different values: pick one" + \
                       ("" if density else " (or choose the site's density first)" if any(c.get("regime") for c in trusted) else "")
        return e
    s = Sheet("", "", {key: e}); s.pick(key, cands.index(trusted[0]))
    return s.entries[key]


def required_keys() -> tuple[str, ...]:
    from . import stages
    keys = {"density"}
    for s in stages.REGISTRY:
        keys.update(s.spec_keys)
    return tuple(k for k in SPEC_KEYS if k in keys)


TEMPLATES = Path(__file__).resolve().parents[1] / "templates"


def spec_sources(plan_root: Path, exclude_site: str) -> list[tuple[str, Path]]:
    """Sheets a new site can copy (rollout 2026-10-12): every other site under plan_root with a saved spec revision.
    (label, sheet.json path). The shipped templates are the Client spec dropdown's (core/presets, 2026-10-16)."""
    out = []
    root = Path(plan_root)
    for sj in sorted(root.glob("*/site.json")) if root.is_dir() else []:
        site = sj.parent.name
        if site == exclude_site:
            continue
        try:
            st = json.loads(sj.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        rev = st.get("spec_rev")
        sheet = sj.parent / "spec" / str(rev) / "sheet.json"
        if rev and sheet.exists():
            out.append((f"Site: {site} ({st.get('client', '?')}, {rev})", sheet))
    return out


def copy_sheet(src: Sheet, client: str, source_label: str) -> Sheet:
    """A copy of `src` for another site: every resolved value comes across marked with where it came from (still
    unsaved -- the operator reviews it and presses Save revision); anything unresolved in the source stays
    unresolved here. Nothing is defaulted. Neither kind of extra detail comes across (the PDFs' or the operator's):
    they belong to the PDFs submitted for, and the operator of, the other site (operator 2026-10-13)."""
    out = Sheet.blank(client)
    for k, e in src.entries.items():
        if e.status == "not_applicable":
            out.mark_not_applicable(k)
        elif e.status in ("confirmed", "operator_stated") and e.value is not None:
            out.entries[k] = SheetEntry(k, e.value, e.unit or UNITS.get(k, ""), "confirmed", e.document, e.page,
                                        e.quoted_text, (f"copied from {source_label}; " + e.note).strip("; "))
    return out
