import json
import sys
import numpy as np
from scipy.spatial import cKDTree
from osgeo import ogr
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

FEEDER_ROAD_WARN_M = 20.0
FEEDER_ROAD_HARD_M = 40.0
EDGE_M = 2.0               # a 1:16 this close to a PON (on its edge) belongs to it


def why_no_1to16(rev, pon: int) -> str:
    """Why PON `pon` has no 1:16, from what P1's Generate recorded (<rev>/step3/step3_metrics.json); "" when it
    recorded nothing (an older run, or the layers came from elsewhere)."""
    try:
        m = json.loads((rev / "step3" / "step3_metrics.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    if "no_1to16" not in m:
        return ""
    if str(pon) not in m["no_1to16"]:
        return ("P1 placed a 1:16 for this PON at Generate, but none stands inside this PON or within 2 m of its edge "
                "now: it was deleted or moved since, or P1 placed it just outside the edge. Put one inside the PON or on "
                "its edge, or Remove this issue if it stands where it should.")
    gap = m["no_1to16"][str(pon)]
    if gap is None:
        return ("P1 did not place a 1:16 here: no span runs inside this PON, and the 1:16 stands on the span. Check "
                "the span and the PON outline in the wayleave.")
    cap = float(m.get("connector_max_m", 25))
    return (f"P1 did not place a 1:16 here. A 1:16 goes where the feeder can reach it: along roads (or span beside a "
            f"road) from the POP, then at most {cap:.0f} m off the road to the PON's span. The nearest road the feeder "
            f"can reach is {gap:,.0f} m from this PON's span, so this PON's streets are not joined to the POP's road "
            f"network in the Roads layer (a gap, or a street that is not mapped). Join them in Roads, then press Use "
            f"this wayleave and Generate P1 again. Or place the 1:16 and draw the feeder to it by hand.")


def extra(report, rev):
    ds, feeder = open_layer(str(rev / "working.gpkg"), "feeder")
    ds2, spl = open_layer(str(rev / "working.gpkg"), "splitters_1to16")
    road = P.export_dir() / "road.shp"
    if feeder is None or not road.exists():
        for c in ("feeder_not_midblock", "feeder_midblock_hard"):
            report.checks.append(CheckResult(c, c == "feeder_midblock_hard", "skipped", "feeder layer or road.shp missing"))
    else:
        rds = ogr.Open(str(road)); rl = rds.GetLayer(0)
        tree = cKDTree(P.densify(P.lines_site(rl)))
        warn = hard = total = 0; worst = 0.0
        for fid, ln in P.lines_site_fids(feeder):
            d, _ = tree.query(ln)
            total += len(ln); worst = max(worst, float(d.max()))
            for k in np.nonzero(d > FEEDER_ROAD_WARN_M)[0]:
                is_hard = d[k] > FEEDER_ROAD_HARD_M
                hard += is_hard; warn += not is_hard
                add_issue(report, feeder, None, "feeder_midblock_hard" if is_hard else "feeder_not_midblock",
                          "error" if is_hard else "warn", f"feeder vertex {d[k]:.0f} m from a road",
                          xy=P.back_to_layer(feeder, *ln[k]), fid=fid)
        report.checks.append(CheckResult("feeder_not_midblock", False, "passed" if warn + hard == 0 else "failed",
                                         f"{warn + hard} of {total} feeder vertices more than {FEEDER_ROAD_WARN_M:.0f} m from a road (worst {worst:.0f} m)"))
        report.checks.append(CheckResult("feeder_midblock_hard", True, "passed" if hard == 0 else "failed",
                                         f"{hard} feeder vertices more than {FEEDER_ROAD_HARD_M:.0f} m from a road"))
    pons = P.export_dir() / "Pons.shp"
    if spl is None or not pons.exists():
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "splitters or Pons.shp missing"))
        return
    pds = ogr.Open(str(pons)); pl = pds.GetLayer(0)
    names = [pl.GetLayerDefn().GetFieldDefn(i).GetName() for i in range(pl.GetLayerDefn().GetFieldCount())]
    key = next((n for n in ("pon_num", "PON", "label", "Label") if n in names), None)
    if key is None:
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "no PON number field on Pons.shp"))
        return
    want = {int(f.GetField(key)) for f in pl if f.GetField(key) is not None}
    pl.ResetReading()
    # 2026-10-14: a 1:16 belongs to the PON polygon it stands in, not to its `pon` attribute (stale after a move)
    have, of = {}, {}
    sepsg = P.layer_epsg(spl)
    tp = P.to_site(P.layer_epsg(pl)); ts = P.to_site(sepsg); polys = []
    for pf in pl:
        pg = pf.GetGeometryRef()
        if pg is not None and pf.GetField(key) is not None:
            pg = pg.Clone(); pg.Transform(tp); polys.append((int(pf.GetField(key)), pg))
    pl.ResetReading()
    for f in spl:
        g = f.GetGeometryRef()
        poly = P.polygon_containing(pl, g, sepsg) if g is not None else None
        k = int(poly.GetField(key)) if poly is not None and poly.GetField(key) is not None else None
        if k is None and g is not None:
            # final review 2026-10-14: the operator puts 1:16s ON the PON edge (Botshabelo 33 of 47): a PON within
            # EDGE_M counts, the one the `pon` attribute names first, else the nearest
            q = g.Clone(); q.Transform(ts)
            near = sorted((pg.Distance(q), num) for num, pg in polys if pg.Distance(q) <= EDGE_M)
            named = f.GetField("pon") if spl.GetLayerDefn().GetFieldIndex("pon") >= 0 else None
            k = next((num for _d, num in near if named is not None and str(num) == str(named)), near[0][1] if near else None)
        of[f.GetFID()] = k
        if k is None:
            add_issue(report, spl, f, "one_1to16_per_pon", "error", "1:16 stands outside every PON")
        else:
            have[k] = have.get(k, 0) + 1
    spl.ResetReading()
    missing = sorted(want - set(have)); dup = sorted(k for k, v in have.items() if v > 1)
    outside = sum(1 for v in of.values() if v is None)
    for f in pl:                                         # a PON without a 1:16: located on the approved wayleave pons
        k = f.GetField(key)
        if k is not None and int(k) in missing and f.GetGeometryRef() is not None:
            add_issue(report, pl, None, "one_1to16_per_pon", "error", f"PON {int(k)} has no 1:16", layer="pons",
                      source="wayleave", xy=inside_xy(f.GetGeometryRef()), match=f"pon_num={int(k)}",
                      why=why_no_1to16(rev, int(k)))
    for f in spl:
        if of.get(f.GetFID()) in dup:
            n = have[of[f.GetFID()]]
            add_issue(report, spl, f, "one_1to16_per_pon", "error", f"PON {of[f.GetFID()]} has a duplicate 1:16 ({n})")
    report.checks.append(CheckResult("one_1to16_per_pon", True, "passed" if not missing and not dup and not outside else "failed",
                                     f"{len(want)} PONs, {len(have)} with a 1:16; missing {missing[:10]}, duplicated {dup[:10]}, "
                                     f"{outside} outside every PON"))


if __name__ == "__main__":
    sys.exit(main(extra))
