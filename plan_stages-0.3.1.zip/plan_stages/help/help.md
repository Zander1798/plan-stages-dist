# Plan Stages help

This page is always here on the **Help** tab. The other two tabs are **Spec** (the client's rules) and **Plan**
(the wayleave and the stages).

## 1. What Plan Stages does

Plan Stages plans a fibre network on a **wayleave you already have**. It never draws the wayleave itself.

The work goes in order, and nothing moves on until the step before it is approved:

1. **Wayleave**: a snapshot of the wayleave layers in your QGIS project.
2. **Gate 0**: checks that the wayleave can be planned at all.
3. **P1** feeder, distribution and 1:16 splitters
4. **P2** collection points and drops
5. **P3** road crossings
6. **P4** poles
7. **P5** 8-way splitters and dome joints
8. **P6** delivery (a QGIS project and map images)

For every stage you press **Generate**, look at the result and fix anything on the map, press **Check**, then
**Approve**.

## 2. Before you start

You need:

- **QGIS 4 on Windows.**
- **The wayleave loaded in your QGIS project**: the layers in the table in section 3.
- **The client's spec values** (drop cap, span cap, and so on). For HeroTel there is a ready-made template; for
  other clients, have their specification PDF or the values to hand.
- An Anthropic API key is **optional**. It is only used to read a spec PDF for you. Without it, type the values.

## 3. The wayleave layers

Load these into your project before you set up the site. Each row in the Wayleave box (top of the Plan tab) fills
itself when your layer has one of the names below (capitals, spaces, `_` and `-` do not matter). If your layer has
another name, pick it in the row by hand: for example **PON Zones HT2** in the `pons` row.

| Row | Required? | Type | Filled automatically when your layer is called |
|---|---|---|---|
| `span` | yes | lines | span, spans, cable span, wayleave span, wayleave |
| `pons` | yes | polygons | pon, pons, pond, ponds, pon zones, pon zone, pon test |
| `demand_points` | yes | points | demand point, demand points, demandpoints, dp, dps, homes |
| `pop` | yes | points | pop, pops, olt, olts, exchange |
| `roads` | yes | lines | road, roads, road osm, osm roads, streets |
| `poles` | no | points | pole, poles |
| `erven` | no | polygons | erf, erven, ervan, erfs, stands, parcels |
| `aoi` | no | polygons | aoi, area of interest, boundary, site boundary |
| `buildings` | no | polygons | building, buildings, footprints, building footprints, structures, open buildings |

**Fields the plugin reads.** Everything else on your layers is ignored. A field is found by its own name, or else
by the first of these other names your layer has:

| Layer | Field | Also accepted |
|---|---|---|
| `pons` | `pon_num` (the PON number) | pon, pon_id, pon_no, number, id |
| `pons` | `homes` (homes in the PON) | units, stands, home_count, homes_count, count |
| `pop` | `name` | label, title, site |
| `poles` | `role` | type, class |
| `erven` | `erf_id` | id, erf, erf_no, parcel_id, stand_no |

**What Gate 0 refuses.** Fix these in your layers, then press **Use this wayleave** again:

- **The span is not one network.** At least 99% of the span's metres must join up. Line ends must meet within
  **0.75 m** of each other to count as joined.
- **The POP is too far from the span.** It must be within **25 m** of the span, on the main network.
- **A PON cannot be fed.** Every PON must contain some span and be reachable along the span from the POP.
- **The CRS is wrong.** The site must use the Hartebeesthoek94 Lo zone of the area (section 5).

Demand points further from the span than the drop cap, and poles off the span, are warnings: they are listed, and
you decide.

## 4. Building footprints (optional)

Footprints let P1 keep the feeder off the land between houses (the midblock test). Without them P1 still runs, the
test is off, and the run log says so.

Any footprint layer works. Load it and pick it in the `buildings` row:

- **Google Open Buildings**: <https://sites.research.google/open-buildings/>
- **Microsoft building footprints**: <https://github.com/microsoft/GlobalMLBuildingFootprints>
- **OpenStreetMap buildings** through the QuickOSM plugin (key `building`).

## 5. Setting up a site

1. **Load the wayleave first**, then press **New site…** at the top of the dock. Give the site a name (letters,
   digits, `_` or `-`). The plugin suggests the Lo zone from your layers; accept it unless you know better.

   | Lo zone | EPSG |
   |---|---|
   | Lo15 | 2046 |
   | Lo17 | 2047 |
   | Lo19 | 2048 |
   | Lo21 | 2049 |
   | Lo23 | 2050 |
   | Lo25 | 2051 |
   | Lo27 | 2052 |
   | Lo29 | 2053 |
   | Lo31 | 2054 |
   | Lo33 | 2055 |

   Examples: Malmesbury Lo19 (2048), Cradock Lo25 (2051), Ventersdorp Lo27 (2052).

2. **Spec tab > Copy from… > Template: HeroTel** (or another site you planned before). Check the values, change
   what is different for this site, then press **Save revision**. Nothing is kept until you do.
3. **Plan tab, Wayleave box**: check each row shows the right layer and count. Pick any row that stayed empty by
   hand (for example **PON Zones HT2** in `pons`). Then press **Use this wayleave**.

## 6. Running the stages

| Button | What it does |
|---|---|
| **Generate** | Makes the stage from the approved stages above it. The result loads on the map, ready to edit. |
| **Check** | Checks the stage as it is now, including your edits. Red items block; amber items are warnings. |
| **Approve** | Accepts the stage so the next one can start. If something red is still listed, it asks "Approve anyway?" and records your note. |
| **Reject** | Sends the stage back, with a note. |
| **Revise** | Opens an approved stage again for editing. |
| **Remove** | Deletes the stage's latest attempt. |
| **Load** | Puts a stage back on the map, for example after QGIS restarted. |

**Click an issue** in the list and the map zooms to it, selects it and makes its layer active, so you can fix it
straight away. Click a **bold heading** to select everything that check found. When you save your edits, the check
runs again and fixed items disappear.

**Press Save** (top of the dock) to keep your progress. Progress that was not saved is wiped the next time the
site is opened.

## 7. Greyed out, or something went wrong

- **"Use this wayleave" is greyed out.** Hover over it to see why. Usually: no spec revision saved yet, a required
  row is empty, or a layer has no CRS.
- **The stage rows are greyed out.** The red line above them says why: save a spec revision, or press Use this
  wayleave (again, if the spec changed).
- **A stage says stale.** Something above it changed. Generate it again (or at least Check it) before approving.
- **I reopened a site and my work is gone.** It was not saved. Press **Save** before you close QGIS or switch site.
- **"Site … is open in another QGIS".** Only one QGIS can work on a site. Close the other one. After a crash,
  delete the `lock` file in the site folder, once you are sure no other QGIS is using it.
- **Gate 0 fails on the CRS.** The site's EPSG is not the Lo zone of your data. Make a new site with the right zone
  (section 5).
- **Odd errors right after updating the plugin.** Save, then restart QGIS.

## 8. Updating the plugin, and where files are kept

**Updating.** Plugins > Manage and Install Plugins > **Upgradeable** > Plan Stages > Upgrade. Press **Save** in the
dock first, and restart QGIS afterwards.

**Installing on a new PC.** Plugins > Manage and Install Plugins > Settings > Add…, and enter
<https://raw.githubusercontent.com/Zander1798/plan-stages-dist/main/plugins.xml>. Then search **Plan Stages** on
the All tab and press Install.

**Where files are kept.**

- Sites: `Documents\PlanStages\<site>` (change it with `plan_root` under **Config…**). Each stage has a folder with
  one `rev-NNN` folder per attempt; nothing is overwritten.
- Settings: `plan_stages.toml` in your QGIS profile folder
  (`%APPDATA%\QGIS\QGIS4\profiles\default`).
