"""Gate 0 check: the Step 0 verdict (wayleave_<site>.json) as check rows, plus the findings Step 0 only counts,
located feature by feature on the approved wayleave so the dock can take the operator to them:
demand points beyond the drop cap, poles off the span, span features overlapping another (the slivers)."""
import json, os, sys
from scipy.spatial import cKDTree
from osgeo import ogr
from plan_stages.checks.common import main, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

POLE_ON_SPAN_M = 2.0          # step0_wayleave: a pole "on the span" is within 2 m of it
SEG_M, STITCH_M = 0.5, 0.75   # step0's noding tolerances; overlap closer than STITCH_M is what it drops as slivers
SLIVER_MIN_M = 1.0


def step0_verdict(report, rev):
    j = rev / f"wayleave_{os.environ.get('PS_SITE', '')}.json"
    if not j.is_file():
        report.checks.append(CheckResult("step0_verdict", True, "skipped", f"{j.name} missing: Generate did not run Step 0"))
        return
    d = json.loads(j.read_text(encoding="utf-8"))
    for msg in d.get("fail", []):
        report.checks.append(CheckResult("step0_fail", True, "failed", msg))
    for msg in d.get("warn", []):
        report.checks.append(CheckResult("step0_warn", False, "failed", msg))
    nf, nw = len(d.get("fail", [])), len(d.get("warn", []))
    report.checks.append(CheckResult("step0_verdict", True, "failed" if nf else "passed", f"{nf} fail, {nw} warn"))


def _near(report, ds, tree, layer, code, severity, limit, what):
    lyr = ds.GetLayerByName(layer)
    if lyr is None:
        return None
    feats = list(lyr); xy = P.points_site(lyr); n = 0
    if len(xy):
        d, _ = tree.query(xy)
        for f, dist in zip(feats, d):
            if dist > limit:
                n += 1
                add_issue(report, lyr, f, code, severity, f"{what} {dist:.0f} m from the span (limit {limit:g} m)", source="wayleave")
    report.checks.append(CheckResult(code, False, "passed" if n == 0 else "failed",
                                     f"{n} of {len(feats)} {layer} more than {limit:g} m from the span"))
    return n


def extra(report, rev):
    step0_verdict(report, rev)
    wl = P.approved_path("wayleave")
    ds = ogr.Open(wl) if wl else None
    span = ds.GetLayerByName("span") if ds else None
    if span is None:
        report.checks.append(CheckResult("dp_beyond_cap", False, "skipped", "approved wayleave span missing"))
        return
    parts = P.lines_site_fids(span)
    pts = P.densify([ln for _, ln in parts], 2.0)
    if not len(pts):
        report.checks.append(CheckResult("dp_beyond_cap", False, "skipped", "span has no line geometry"))
        return
    tree = cKDTree(pts)
    cap = P.spec_limit("drop_cap_m")
    if cap is None:
        report.checks.append(CheckResult("dp_beyond_cap", False, "skipped", "drop_cap_m missing"))
    else:
        _near(report, ds, tree, "demand_points", "dp_beyond_cap", "error", cap, "demand point")
    _near(report, ds, tree, "poles", "pole_off_span", "warn", POLE_ON_SPAN_M, "pole")
    # Slivers: metres of a span feature that run within STITCH_M of ANOTHER feature are welded away by Step 0.
    dense = [(fid, P.densify([ln], SEG_M)) for fid, ln in parts]
    allpts = [p for _, d in dense for p in d]; owner = [fid for fid, d in dense for _ in d]
    t2 = cKDTree(allpts); n_sliver = 0; total = 0.0
    for fid, d in dense:
        hits = t2.query_ball_point(d, STITCH_M)
        over = [any(owner[j] != fid for j in h) for h in hits]
        m = sum(SEG_M for a, b in zip(over[:-1], over[1:]) if a and b)
        if m >= SLIVER_MIN_M:
            n_sliver += 1; total += m
            add_issue(report, span, None, "span_overlap", "warn", f"{m:.0f} m of this span feature overlaps another",
                      xy=P.back_to_layer(span, *d[over.index(True)]), source="wayleave", fid=fid)
    report.checks.append(CheckResult("span_overlap", False, "passed" if n_sliver == 0 else "failed",
                                     f"{n_sliver} span features overlap another ({total:.0f} m, dropped by Step 0 as slivers)"))


if __name__ == "__main__":
    sys.exit(main(extra))
