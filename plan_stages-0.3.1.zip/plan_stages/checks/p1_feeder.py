import sys
import numpy as np
from scipy.spatial import cKDTree
from osgeo import ogr
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

FEEDER_ROAD_WARN_M = 20.0
FEEDER_ROAD_HARD_M = 40.0


def extra(report, rev):
    ds, feeder = open_layer(str(rev / "working.gpkg"), "feeder")
    ds2, spl = open_layer(str(rev / "working.gpkg"), "splitters_1to16")
    road = P.export_dir() / "road.shp"
    if feeder is None or not road.exists():
        for c in ("feeder_not_midblock", "feeder_midblock_hard"):
            report.checks.append(CheckResult(c, c == "feeder_midblock_hard", "skipped", "feeder layer or road.shp missing"))
    else:
        rds = ogr.Open(str(road)); rl = rds.GetLayer(0)
        tree = cKDTree(P.densify(P.lines_site(rl)))
        warn = hard = total = 0; worst = 0.0
        for fid, ln in P.lines_site_fids(feeder):
            d, _ = tree.query(ln)
            total += len(ln); worst = max(worst, float(d.max()))
            for k in np.nonzero(d > FEEDER_ROAD_WARN_M)[0]:
                is_hard = d[k] > FEEDER_ROAD_HARD_M
                hard += is_hard; warn += not is_hard
                add_issue(report, feeder, None, "feeder_midblock_hard" if is_hard else "feeder_not_midblock",
                          "error" if is_hard else "warn", f"feeder vertex {d[k]:.0f} m from a road",
                          xy=P.back_to_layer(feeder, *ln[k]), fid=fid)
        report.checks.append(CheckResult("feeder_not_midblock", False, "passed" if warn + hard == 0 else "failed",
                                         f"{warn + hard} of {total} feeder vertices more than {FEEDER_ROAD_WARN_M:.0f} m from a road (worst {worst:.0f} m)"))
        report.checks.append(CheckResult("feeder_midblock_hard", True, "passed" if hard == 0 else "failed",
                                         f"{hard} feeder vertices more than {FEEDER_ROAD_HARD_M:.0f} m from a road"))
    pons = P.export_dir() / "Pons.shp"
    if spl is None or not pons.exists():
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "splitters or Pons.shp missing"))
        return
    pds = ogr.Open(str(pons)); pl = pds.GetLayer(0)
    names = [pl.GetLayerDefn().GetFieldDefn(i).GetName() for i in range(pl.GetLayerDefn().GetFieldCount())]
    key = next((n for n in ("pon_num", "PON", "label", "Label") if n in names), None)
    if key is None:
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "no PON number field on Pons.shp"))
        return
    want = {int(f.GetField(key)) for f in pl if f.GetField(key) is not None}
    have = {}
    for f in spl:
        have[f.GetField("pon")] = have.get(f.GetField("pon"), 0) + 1
    missing = sorted(want - set(have)); dup = sorted(k for k, v in have.items() if v > 1)
    for f in pl:                                         # a PON without a 1:16: located on the approved wayleave pons
        k = f.GetField(key)
        if k is not None and int(k) in missing and f.GetGeometryRef() is not None:
            add_issue(report, pl, None, "one_1to16_per_pon", "error", f"PON {int(k)} has no 1:16", layer="pons",
                      source="wayleave", xy=inside_xy(f.GetGeometryRef()), match=f"pon_num={int(k)}")
    for f in spl:
        if f.GetField("pon") in dup:
            n = have[f.GetField("pon")]
            add_issue(report, spl, f, "one_1to16_per_pon", "error", f"PON {f.GetField('pon')} has a duplicate 1:16 ({n})")
    report.checks.append(CheckResult("one_1to16_per_pon", True, "passed" if not missing and not dup else "failed",
                                     f"{len(want)} PONs, {len(have)} with a 1:16; missing {missing[:10]}, duplicated {dup[:10]}"))


if __name__ == "__main__":
    sys.exit(main(extra))
