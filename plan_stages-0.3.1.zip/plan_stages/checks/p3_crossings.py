import sys
from plan_stages.checks.common import main, open_layer, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult


def extra(report, rev):
    ds, xs = open_layer(str(rev / "working.gpkg"), "road_crossings")
    hard, norm = P.spec_limit("span_cap_m"), P.spec_limit("cross_span_m")
    if xs is None or hard is None:
        report.checks.append(CheckResult("cross_span_hard", True, "skipped", "road_crossings layer or span_cap_m missing"))
    if xs is None or norm is None:
        report.checks.append(CheckResult("cross_span", False, "skipped", "road_crossings layer or cross_span_m missing"))
    if xs is None:
        return
    nh = nw = 0; worst = 0.0
    for f in xs:
        L = P.cap_length(xs, f); worst = max(worst, L)
        over_hard = hard is not None and L > hard + 1e-6
        over_norm = norm is not None and L > norm + 1e-6
        nh += over_hard; nw += over_norm and not over_hard
        if over_hard or over_norm:
            add_issue(report, xs, f, "cross_span_hard" if over_hard else "cross_span",
                      "error" if over_hard else "warn", f"crossing {L:.1f} m")
    if hard is not None:
        report.checks.append(CheckResult("cross_span_hard", True, "passed" if nh == 0 else "failed",
                                         f"{nh} crossings longer than the {hard} m hard cap (longest {worst:.1f} m)"))
    if norm is not None:
        report.checks.append(CheckResult("cross_span", False, "passed" if nh + nw == 0 else "failed",
                                         f"{nh + nw} crossings longer than the {norm} m design norm (longest {worst:.1f} m)"))


if __name__ == "__main__":
    sys.exit(main(extra))
