import sys
from osgeo import ogr
from plan_stages.checks.common import main, open_layer, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

ON_LINE_M = 1.0
POLE_ON_CABLE_M = 0.5


def _boxes(lines):
    return [(l[:, 0].min(), l[:, 0].max(), l[:, 1].min(), l[:, 1].max()) for l in lines]


def _dist_to_lines(pt, lines, boxes):
    best = float("inf")
    for ln, (x0, x1, y0, y1) in zip(lines, boxes):
        if x0 - best <= pt[0] <= x1 + best and y0 - best <= pt[1] <= y1 + best:
            best = min(best, P.project(ln, pt)[0])
    return best


def extra(report, rev):
    ds, poles = open_layer(str(rev / "working.gpkg"), "poles")
    p1 = P.approved_path("p1_feeder")
    if poles is None or p1 is None:
        for c in ("span_cap", "pole_on_cable"):
            report.checks.append(CheckResult(c, True, "skipped", "poles layer or approved P1 missing"))
        return
    pds = ogr.Open(p1); dist_lyr = pds.GetLayerByName("distribution")
    dist_f = P.lines_site_fids(dist_lyr); dist = [ln for _, ln in dist_f]
    feeder = P.lines_site(pds.GetLayerByName("feeder"))
    xy = P.points_site(poles)
    feats = list(poles); roles = [f.GetField("role") for f in feats]
    cap = P.spec_limit("span_cap_m")
    if cap is None:
        report.checks.append(CheckResult("span_cap", True, "skipped", "span_cap_m missing"))
    else:
        over = 0; worst = 0.0
        for (fid, ln), (x0, x1, y0, y1) in zip(dist_f, _boxes(dist)):
            m = ((xy[:, 0] >= x0 - ON_LINE_M) & (xy[:, 0] <= x1 + ON_LINE_M)
                 & (xy[:, 1] >= y0 - ON_LINE_M) & (xy[:, 1] <= y1 + ON_LINE_M))
            ch = sorted(c for d, c in (P.project(ln, p) for p in xy[m]) if d <= ON_LINE_M)
            for a, b in zip(ch[:-1], ch[1:]):
                worst = max(worst, b - a)
                if b - a > cap + 1e-6:
                    over += 1                            # located mid-gap on the approved P1 distribution line
                    add_issue(report, dist_lyr, None, "span_cap", "error", f"consecutive poles {b - a:.1f} m apart",
                              xy=P.back_to_layer(dist_lyr, *P.point_at(ln, (a + b) / 2)), source="p1_feeder", fid=fid)
        report.checks.append(CheckResult("span_cap", True, "passed" if over == 0 else "failed",
                                         f"{over} pole gaps over {cap} m along {len(dist)} distribution lines (largest {worst:.1f} m)"))
    allc = dist + feeder; bx = _boxes(allc); off = 0; untested = 0
    for p, role, f in zip(xy, roles, feats):
        if role == "wayleave":
            untested += 1
            continue
        if _dist_to_lines(p, allc, bx) > POLE_ON_CABLE_M:
            off += 1
            add_issue(report, poles, f, "pole_on_cable", "error", "pole more than 0.5 m from the cable")
    report.checks.append(CheckResult("pole_on_cable", True, "passed" if off == 0 else "failed",
                                     f"{off} poles more than {POLE_ON_CABLE_M} m from cable ({untested} wayleave-only poles not tested)"))


if __name__ == "__main__":
    sys.exit(main(extra))
