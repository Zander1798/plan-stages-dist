"""Checks every stage shares. Other check scripts call run_common() then append."""
from __future__ import annotations
import os, sys
from pathlib import Path
from osgeo import ogr
from plan_stages.core.checks import ChecksReport, CheckResult, Issue, MAX_ISSUES


def open_layer(gpkg: str, name: str):
    ds = ogr.Open(gpkg)
    return ds, (ds.GetLayerByName(name) if ds else None)


def epsg_of(layer) -> int:
    srs = layer.GetSpatialRef()
    return int(srs.GetAuthorityCode(None)) if srs and srs.GetAuthorityCode(None) else 0


def inside_xy(geom) -> tuple[float, float]:
    """A point ON the geometry, for an issue's location. Not the centroid: a C-shaped PON's centroid falls inside a
    neighbouring PON, and a click there (fid -1: the feature at the point) took the operator to the wrong PON
    (Ventersdorp PON 14, 2026-10-12)."""
    p = geom.PointOnSurface() if "POLYGON" in geom.GetGeometryName() else None
    if p is None or p.IsEmpty():                         # lines and points keep their centroid (a line's midpoint)
        p = geom.Centroid()
    return p.GetX(), p.GetY()


def add_issue(report: ChecksReport, lyr, f, code: str, severity: str, message: str,
              xy=None, source: str = "working", fid: int | None = None, layer: str | None = None,
              match: str = "") -> None:
    """Record an issue located on feature `f` of `lyr` (a point on it, or `xy` in the layer's CRS). `f` may be
    None when only a place is known (fid -1: the dock then finds the feature nearest x, y). Beyond MAX_ISSUES
    the issue is counted in report.dropped instead of listed."""
    if len(report.issues) >= MAX_ISSUES:
        report.dropped += 1
        return
    if xy is None:
        xy = inside_xy(f.GetGeometryRef())
    report.issues.append(Issue(float(xy[0]), float(xy[1]), epsg_of(lyr), code, severity, message,
                               layer=layer if layer is not None else lyr.GetName(), source=source,
                               fid=int(fid) if fid is not None else int(f.GetFID()) if f is not None else -1,
                               match=match))


def run_common(working_gpkg: str, expected_layers: list[str]) -> ChecksReport:
    ds = ogr.Open(working_gpkg)
    if ds is None:
        return ChecksReport([CheckResult("gpkg_opens", True, "failed", f"cannot open {working_gpkg}")], [])
    report = ChecksReport([], []); checks = report.checks
    for name in expected_layers:
        lyr = ds.GetLayerByName(name)
        if lyr is None:
            checks.append(CheckResult(f"layer_present:{name}", True, "failed", f"layer {name} missing"))
            continue
        checks.append(CheckResult(f"layer_present:{name}", True, "passed", ""))
        bad = empty = 0
        for f in lyr:
            g = f.GetGeometryRef()
            if g is None or g.IsEmpty():
                empty += 1
                continue
            if not g.IsValid():
                bad += 1
                add_issue(report, lyr, f, "geom_valid", "error", f"{name} fid {f.GetFID()} invalid")
        checks.append(CheckResult(f"geom_valid:{name}", True, "passed" if bad == 0 else "failed", f"{bad} invalid"))
        checks.append(CheckResult(f"geom_nonempty:{name}", True, "passed" if empty == 0 else "failed", f"{empty} empty"))
    return report


def stage_outputs(working_gpkg: str | None = None) -> list[str]:
    """The stage's output layers to check: every required one, plus each optional one the gpkg holds."""
    from plan_stages.core import stages
    ds = ogr.Open(working_gpkg) if working_gpkg else None
    present = {ds.GetLayer(i).GetName() for i in range(ds.GetLayerCount())} if ds else set()
    return [o.name for o in stages.get(os.environ["PS_STAGE"]).outputs if not o.optional or o.name in present]


def main(extra=None):
    rev = Path(os.environ["PS_REV_DIR"])
    report = run_common(str(rev / "working.gpkg"), stage_outputs(str(rev / "working.gpkg")))
    if extra is not None:
        extra(report, rev)
    report.save(rev / "checks.json")
    print(f"{len(report.blocking())} blocking")
    return 0 if report.ok() else 1


if __name__ == "__main__":
    sys.exit(main())
