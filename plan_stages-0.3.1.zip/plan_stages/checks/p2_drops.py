import sys
from scipy.spatial import cKDTree
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult


def _issue(report, lyr, f, code, msg):
    add_issue(report, lyr, f, code, "error", msg)


def _num(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 1 << 30


STRAY_M = 25.0                                           # step4_drops attaches a stray CP to the nearest PON within this


def _pon_of(pl, g, epsg):
    """The PON polygon holding collection point g, else the nearest one within STRAY_M (step4's own rule)."""
    poly = P.polygon_containing(pl, g, epsg)
    if poly is not None:
        return poly
    q = g.Clone(); q.Transform(P.to_site(epsg)); t = P.to_site(P.layer_epsg(pl))
    best, bd = None, STRAY_M
    for f in pl:
        pg = f.GetGeometryRef()
        if pg is None:
            continue
        pg = pg.Clone(); pg.Transform(t); d = pg.Distance(q)
        if d <= bd:
            best, bd = f, d
    pl.ResetReading()
    return best


def extra(report, rev):
    ds, drops = open_layer(str(rev / "working.gpkg"), "drops")
    ds2, cps = open_layer(str(rev / "working.gpkg"), "collection_points")
    cap, fan, pon = P.spec_limit("drop_cap_m"), P.spec_limit("fan_cap"), P.spec_limit("pon_cap")
    ds3, review = open_layer(str(rev / "working.gpkg"), "drop_review")
    if drops is None or cap is None or review is None:
        report.checks.append(CheckResult("drop_cap_escalated", True, "skipped", "drops, drop_review or drop_cap_m missing"))
        report.checks.append(CheckResult("drop_cap", False, "skipped", "drops layer or drop_cap_m missing"))
    else:
        t = P.to_site(P.layer_epsg(drops))
        rv = P.points_site(review)
        tree = cKDTree(rv) if len(rv) else None
        over = unesc = 0; worst = 0.0
        for f in drops:
            L = P.cap_length(drops, f); worst = max(worst, L)
            if L <= cap + 1e-6:
                continue
            over += 1
            g = f.GetGeometryRef()                       # DP -> collection point: the home end is vertex 0
            hx, hy = t.TransformPoint(g.GetX(0), g.GetY(0))[:2]
            if tree is None or tree.query([hx, hy])[0] > 1.0:
                unesc += 1; _issue(report, drops, f, "drop_cap_escalated", f"drop {L:.1f} m over cap {cap} m has no drop_review point at its home end")
            else:
                add_issue(report, drops, f, "drop_cap", "warn", f"drop {L:.1f} m over cap {cap} m (escalated)")
        report.checks.append(CheckResult("drop_cap_escalated", True, "passed" if unesc == 0 else "failed",
                                         f"{unesc} over-cap drops without a drop_review point (of {over} over cap)"))
        report.checks.append(CheckResult("drop_cap", False, "passed" if over == 0 else "failed",
                                         f"{over} drops longer than {cap} m (longest {worst:.1f} m)"))
    if cps is None or fan is None:
        report.checks.append(CheckResult("fan_cap", True, "skipped", "collection_points or fan_cap missing"))
    else:
        over = 0
        for f in cps:
            n = f.GetField("n_drops") or 0
            if n > fan:
                over += 1; _issue(report, cps, f, "fan_cap", f"{n} drops exceeds fan cap {fan}")
        report.checks.append(CheckResult("fan_cap", True, "passed" if over == 0 else "failed",
                                         f"{over} collection points serve more than {fan} drops"))
    if cps is None or pon is None:
        report.checks.append(CheckResult("pon_cap", False, "skipped", "collection_points or pon_cap missing"))
    else:
        # Count by the PON polygon that HOLDS each collection point, not by its `pon` attribute: on 2026-10-09 the
        # attribute was the polygon's file position (pon_num - 1), so every Ventersdorp row named and located the
        # wrong PON. The polygon is also what the operator changes when they move a collection point by hand.
        # Operator ruling 2026-10-12: a WARNING, not a block. The hard rules (no road-crossing drops, the drop cap,
        # collection points on poles) can force a PON past the cap; the operator decides (re-cut, accept, edit).
        # Operator ruling 2026-10-08: ONE row per thing to fix (the PON), located on the PON polygon of the approved
        # wayleave (site_export/Pons.shp); the first collection point of the PON when no polygon holds it.
        pds, pl, key = P.open_pons(P.export_dir() / "Pons.shp")
        epsg = P.layer_epsg(cps)
        groups = {}                                      # group -> [label, count, polygon feature or None, first CP]
        for f in cps:
            g = f.GetGeometryRef()
            poly = _pon_of(pl, g, epsg) if pl is not None and g is not None else None
            if poly is not None:
                gk = ("pons", poly.GetFID()); label = poly.GetField(key)
            else:
                gk = ("cp", f.GetField("pon")); label = None
            e = groups.setdefault(gk, [None, 0, poly, f])
            e[1] += 1
            if e[0] is None:
                e[0] = label if label is not None else f.GetField("pon")
        bad = sorted((e for e in groups.values() if e[1] > pon), key=lambda e: (_num(e[0]), str(e[0])))
        for label, n, poly, f in bad:
            msg = (f"PON {label} has {n} collection points but its 1:16 has only {pon} outputs "
                   f"({n - pon} 1:8 splitters without a feed)")
            if poly is not None:
                k = poly.GetField(key)
                add_issue(report, pl, None, "pon_cap", "warn", msg, xy=inside_xy(poly.GetGeometryRef()), source="wayleave",
                          layer="pons", match=f"pon_num={int(k)}" if _num(k) < 1 << 30 else "")
            else:                                        # no PON polygon holds it: the PON's first collection point
                add_issue(report, cps, f, "pon_cap", "warn", msg)
        report.checks.append(CheckResult("pon_cap", False, "passed" if not bad else "failed",
                                         f"{len(bad)} PONs exceed {pon} collection points: " + ", ".join(f"{e[0]} ({e[1]})" for e in bad)))

if __name__ == "__main__":
    sys.exit(main(extra))
