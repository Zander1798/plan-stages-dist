import sys
from osgeo import ogr
from plan_stages.checks.common import main, open_layer, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult


def extra(report, rev):
    ds, spl = open_layer(str(rev / "working.gpkg"), "splitters_8way")
    ds2, dome = open_layer(str(rev / "working.gpkg"), "dome_joints")
    p2 = P.approved_path("p2_drops")
    if spl is None or dome is None or p2 is None:
        report.checks.append(CheckResult("one_per_cp", True, "skipped", "hardware layers or approved P2 missing"))
        return
    pds = ogr.Open(p2); cps = pds.GetLayerByName("collection_points")
    cp_feats = list(cps)
    want = sorted(f.GetField("cp_id") for f in cp_feats); wset = set(want)
    bad = []; per_cp: dict = {}                            # cp_id -> ["dome_joints 2", ...] (one row per CP, ruling 2026-10-08)
    for name, lyr in (("splitters_8way", spl), ("dome_joints", dome)):
        have = {}
        for f in lyr:
            have[f.GetField("cp_id")] = have.get(f.GetField("cp_id"), 0) + 1
        miss = [c for c in want if have.get(c, 0) != 1]
        unknown = [c for c in have if c not in wset]
        if miss or unknown:
            bad.append(f"{name}: {len(miss)} collection points without exactly one, {len(unknown)} unknown cp_id")
        for cp in miss:
            per_cp.setdefault(cp, []).append(f"{name} {have.get(cp, 0)}")
        for f in lyr:                                    # hardware whose cp_id matches no collection point
            if f.GetField("cp_id") in unknown:
                add_issue(report, lyr, f, "one_per_cp", "error", f"{name}: unknown cp_id {f.GetField('cp_id')}")
    for f in cp_feats:                                   # located on the approved P2 collection point
        cp = f.GetField("cp_id")
        if cp in per_cp:
            add_issue(report, cps, f, "one_per_cp", "error", f"cp {cp}: {', '.join(per_cp[cp])} (want 1 each)", source="p2_drops")
    report.checks.append(CheckResult("one_per_cp", True, "passed" if not bad else "failed",
                                     "; ".join(bad) if bad else f"{len(want)} collection points, one 8-way and one dome each"))


if __name__ == "__main__":
    sys.exit(main(extra))
