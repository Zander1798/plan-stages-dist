"""Wayleave snapshot check: the project's wayleave layers, as the dock wrote them into working.gpkg.

checks/common covers every required layer (present, valid, non-empty geometry) and each optional layer the
snapshot holds; an optional layer the project did not have is skipped, never failed. Then:
crs_matches_site, pop_count, span_nonempty and demand_nonempty, all required. Operator ruling 2026-10-06:
geometry validity of pons, erven, aoi, poles (and buildings, 2026-10-12) only warns (the pipeline has consumed these layers as-is);
it stays required for span, demand_points, pop and roads."""
import os, sys
from plan_stages.checks.common import main, epsg_of
from plan_stages.core import stages
from plan_stages.core.checks import CheckResult
from osgeo import ogr

WARN_ONLY_VALIDITY = ("pons", "erven", "aoi", "poles", "buildings")   # footprints: rollout 2026-10-12


def extra(report, rev):
    for c in report.checks:
        layer = c.code.split(":", 1)[1] if c.code.startswith("geom_valid:") else None
        if layer in WARN_ONLY_VALIDITY:
            c.required = False
    for i in report.issues:
        if i.code == "geom_valid" and i.message.split(" ", 1)[0] in WARN_ONLY_VALIDITY:
            i.severity = "warn"
    ds = ogr.Open(str(rev / "working.gpkg"))
    site = int(os.environ["PS_EPSG"])
    counts, wrong = {}, []
    for spec in stages.get("wayleave").outputs:
        lyr = ds.GetLayerByName(spec.name) if ds else None
        if lyr is None:
            continue
        counts[spec.name] = lyr.GetFeatureCount()
        e = epsg_of(lyr)
        if e != site:
            wrong.append(f"{spec.name} EPSG:{e}")
    report.checks.append(CheckResult("crs_matches_site", True, "failed" if wrong or ds is None else "passed",
                                     ", ".join(wrong) if wrong else f"all layers EPSG:{site}"))
    for code, layer, least in (("pop_count", "pop", 1), ("span_nonempty", "span", 1),
                               ("demand_nonempty", "demand_points", 1)):
        n = counts.get(layer)
        if n is None:
            report.checks.append(CheckResult(code, True, "failed", f"layer {layer} missing"))
        else:
            report.checks.append(CheckResult(code, True, "passed" if n >= least else "failed", f"{n} {layer}"))
    report.checks.append(CheckResult("layer_counts", False, "passed",
                                     ", ".join(f"{k} {v}" for k, v in counts.items())))


if __name__ == "__main__":
    sys.exit(main(extra))
