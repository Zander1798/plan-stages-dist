"""Per-client planning limits, taken from the client's own spec sheet.

R4.7 and R0.11: **every numeric limit is a per-client value.** Not a default, not carried
over from another client, and never inferred from a reference plan. This module is the one
place those values live, so a run can be pointed at a client and inherit the right set.

    set CLIENT=herotel
    ... every step then uses that client's caps

Provenance is carried next to each value in `SOURCE`, as document + page, because a number
whose origin is forgotten becomes a number nobody dares change. Values marked
`operator-stated` came from Zander directly and are NOT in the spec sheets on disk --
those are the ones to confirm first.

⚠️ **The splitter architecture is not a constant even within one client.** HeroTel's own
standard makes it depend on density:

    high density / small erf : feeder dome 1:16, distribution 1:8  -> 16 joints x 8 = 128
    low density  / large erf : feeder dome 1:32, distribution 1:4  -> 32 joints x 4 = 128

Both reach 128 clients per PON by different routes, and they imply DIFFERENT values of
PON_CAP and FAN_CAP. Malmesbury is small-erf informal, so 1:16 / 1:8 is right there -- but
it is a per-SITE decision, not a property of the client. Set `DENSITY=low` to switch.
"""
import json
import os

CLIENT = os.environ.get("CLIENT", "herotel").strip().lower()
DENSITY = os.environ.get("DENSITY", "high").strip().lower()   # high|low -- erf size regime

# ---------------------------------------------------------------------------------------
# Each entry: the planning limits the pipeline actually consumes.
#   drop_cap_m    R4.6  longest drop cable to a home
#   span_cap_m    R5.4  longest pole-to-pole span
#   span_typical  design norm, not a cap -- useful as a sanity check, not a constraint
#   fan_cap       R4.2  drops per collection point  (= distribution splitter ratio)
#   pon_cap       R4.3  collection points per PON   (= feeder/entry splitter ratio)
#   pon_target    stands per PON the client wants planners to aim at
#   pon_max       hard client ceiling per PON
#   cross_span_m  longest span permitted across a road
# ---------------------------------------------------------------------------------------
SPECS = {
    "herotel": {
        "high": dict(fan_cap=8,  pon_cap=16, feeder_split="1:16", dist_split="1:8"),
        "low":  dict(fan_cap=4,  pon_cap=32, feeder_split="1:32", dist_split="1:4"),
        "_common": dict(
            drop_cap_m=50.0, span_cap_m=70.0, span_typical_m=50.0,
            cable_span_rating_m=75.0, cross_span_m=40.0,
            pon_target=96, pon_max=128,
            pole_midblock_m=(5.4, 6.0), pole_crossing_m=7.2, pole_feeder_m=7.0,
            pole_boundary_setback_m=1.0, direction_change_stay_deg=15.0,
            aerial=True,
        ),
    },
    # Fibertime inverts the cascade relative to HeroTel, and flips it by settlement type.
    "fibertime": {
        "high": dict(fan_cap=16, pon_cap=8,  feeder_split="1:8",  dist_split="1:16"),
        "low":  dict(fan_cap=8,  pon_cap=16, feeder_split="1:16", dist_split="1:8"),
        "_common": dict(
            drop_cap_m=50.0, span_cap_m=70.0, span_typical_m=None,
            cable_span_rating_m=None, cross_span_m=None,
            pon_target=None, pon_max=128,
            pole_midblock_m=(7.0,), pole_crossing_m=7.0, pole_feeder_m=9.0,
            pole_boundary_setback_m=None, direction_change_stay_deg=15.0,
            aerial=True,
        ),
    },
    # MetroFibre is a different shape entirely: 1:64 per PON port, DP clusters capped at ~56.
    "metrofibre": {
        "high": dict(fan_cap=16, pon_cap=4,  feeder_split="1:4",  dist_split="1:16"),
        "low":  dict(fan_cap=16, pon_cap=4,  feeder_split="1:4",  dist_split="1:16"),
        "_common": dict(
            drop_cap_m=None, span_cap_m=None, span_typical_m=None,
            cable_span_rating_m=None, cross_span_m=None,
            pon_target=56, pon_max=64,
            pole_midblock_m=None, pole_crossing_m=None, pole_feeder_m=None,
            pole_boundary_setback_m=None, direction_change_stay_deg=None,
            aerial=False,
        ),
    },
    "vuma": {
        "high": dict(fan_cap=32, pon_cap=4,  feeder_split="1:4",  dist_split="1:32"),
        "low":  dict(fan_cap=32, pon_cap=4,  feeder_split="1:4",  dist_split="1:32"),
        "_common": dict(
            # cross-client table, HeroTel_Client_Profile p4
            drop_cap_m=50.0, span_cap_m=70.0, span_typical_m=None,
            cable_span_rating_m=None, cross_span_m=None,
            pon_target=None, pon_max=128,
            pole_midblock_m=None, pole_crossing_m=None, pole_feeder_m=None,
            pole_boundary_setback_m=None, direction_change_stay_deg=None,
            aerial=False,
        ),
    },
}

# document + page for every value that came from a sheet. "operator-stated" means it did NOT.
SOURCE = {
    "herotel": {
        "span_cap_m": "2026_OPL_GPON_FTTH_Standard.pdf p2 -- 'Maximum span distance of 70m'",
        "cable_span_rating_m": "TSD_Fibre Aerial Deployment.pdf p3 -- 'Short Span Aerial cable "
                               "can accommodate 75m suspension distances'",
        "span_typical_m": "TSD p16 -- 'In midblock deployments span lengths are usually around 50m'",
        "fan_cap": "2026_OPL_GPON_FTTH_Standard.pdf p3 -- '1 pole to feed 8 homes, 4 directly "
                   "from the pole and 4 more from a tangent'; p2 splitting ratio 'Distribution: 1-8 x 16'",
        "pon_cap": "2026_OPL_GPON_FTTH_Standard.pdf p2 -- 'Feeder/Entry dome: 1-16'",
        "pon_target": "2026_OPL_GPON_FTTH_Standard.pdf p1 -- 'aim to reach a healthy stand count "
                      "per PON of approximately 96 stands'",
        "pon_max": "2026_OPL_GPON_FTTH_Standard.pdf p1 -- 'GPON reaches a maximum of 128 clients per PON'",
        "cross_span_m": "2026_OPL_GPON_FTTH_Standard.pdf p3 -- midblock-to-midblock road span "
                        "'only if the span distance is not exceeding 40m'",
        "pole_boundary_setback_m": "TSD p3 -- 'No street poles closer than 1-meter from a property boundary'",
        "direction_change_stay_deg": "HeroTel_Client_Profile p3 -- 'stays or struts are mandatory "
                                     "wherever the route changes direction by more than 15 degrees'",
        "drop_cap_m": "HeroTel_Client_Profile_2026-05-08.pdf p4, cross-client table: "
                      "'Max span 70 m (dist/feeder), 50 m (drops)' -> HeroTel column reads "
                      "'75 m (SSA), 50 m (drop)'. CONFIRMED 2026-08-24; previously recorded as "
                      "operator-stated only (D-4.6). NOTE their accepted Cradock plan exceeds "
                      "this 160 times, worst 160.2 m -- see PLANNING-LEARNINGS.md sec0.",
    },
    "fibertime": {
        "fan_cap/pon_cap": "CLAUDE_Fibertime_Project_Knowledge.pdf p4 -- 'Informal: (1x1:8)(8x1:16). "
                           "Established: (1x1:16)(8x1:8).' NOTE this is the INVERSE of HeroTel, "
                           "and it flips by settlement type.",
        "span_cap_m": "HeroTel_Client_Profile p4 cross-client table: 70 m (dist/feeder).",
        "drop_cap_m": "⚠️ CONFLICT, UNRESOLVED. CLAUDE_Fibertime_Project_Knowledge.pdf p4 says "
                      "'Drop spans max 50m. Float max 50m.'; HeroTel_Client_Profile p4 "
                      "cross-client table says 55 m for Fibertime. The value in SPECS is the "
                      "SAFER 50 m. Resolve with the operator before planning a Fibertime site.",
    },
    "metrofibre": {
        "pon_max": "MF_Optical Planning Design Requirements_V1.3.pdf p9 -- 'maximum splitting ratio "
                   "currently being used is 1:64 ... max 64 customers per PON port'",
        "pon_target": "same, p6 -- 'DP Cluster ... maxed to +-56 houses/units ... to have spare "
                      "output fibres available in case of property subdivision'",
        "fan_cap/pon_cap": "same, p7 -- two-tier 1:4Way at FDH + 1:16Way at DP = 1:64. Moving to "
                           "1:128 by adding 1:2Way at the POP (p9).",
    },
    "vuma": {
        "fan_cap/pon_cap": "HeroTel_Client_Profile p1 describes Vuma as a fixed 1:128 cascade; "
                           "Vuma PDR shows 1:4/1:8/1:16/1:32 joint options. ⚠️ NOT pinned down.",
        "planned_drop_average": "Vumatel National Specification VT_NAS-FTTH Ver_1.01 p24-25 -- "
                                "minimum planned drops per splitter (e.g. '3 drops per 1:4w', "
                                "'7 drops per 1:8w', '12 drops per 1:16w'). A FILL-RATE rule, "
                                "which no other client here states.",
    },
}


# Keys the SPEC_SHEET marks not_applicable: the only keys for which limit() may hand back its fallback while a
# sheet is in force. Filled by spec().
NOT_APPLICABLE = set()
SHEET_PATH = None     # the SPEC_SHEET spec() loaded, or None


def spec():
    """the merged limit set for CLIENT at DENSITY"""
    global SHEET_PATH
    sheet = SHEET_PATH = os.environ.get("SPEC_SHEET") or None
    NOT_APPLICABLE.clear()
    if sheet:
        with open(sheet, encoding="utf-8") as fh:
            d = json.load(fh)
        vals = {k: e["value"] for k, e in d["entries"].items() if e.get("status") == "confirmed"}
        NOT_APPLICABLE.update(k for k, e in d["entries"].items() if e.get("status") == "not_applicable")
        vals.setdefault("density", DENSITY)
        vals["client"] = CLIENT
        return vals
    if CLIENT not in SPECS:
        raise SystemExit(f"unknown CLIENT={CLIENT!r}; known: {', '.join(sorted(SPECS))}")
    c = SPECS[CLIENT]
    if DENSITY not in ("high", "low"):
        raise SystemExit(f"DENSITY must be 'high' or 'low', not {DENSITY!r}")
    out = dict(c["_common"])
    out.update(c[DENSITY])
    out["client"] = CLIENT
    out["density"] = DENSITY
    return out


SPEC = spec()


def limit(name, fallback=None, required=False):
    """a client limit, or the fallback. `required` refuses to guess.

    With SPEC_SHEET set, the operator's confirmed sheet is the only source: an absent key raises even when a
    fallback is given, unless the sheet marks that key not_applicable (then the fallback, if not required)."""
    v = SPEC.get(name)
    if v is None and SHEET_PATH:
        if name in NOT_APPLICABLE and not required:
            return fallback
        raise SystemExit(
            f"SPEC_SHEET {SHEET_PATH} has no confirmed value for {name!r} and does not mark it "
            f"not_applicable. Nothing may be defaulted: confirm it on the Spec tab.")
    if v is None:
        if required:
            raise SystemExit(
                f"{CLIENT} has no value on file for {name!r}. R4.7 forbids assuming one -- "
                f"get it from the client spec sheet before planning. See client-specs.md.")
        return fallback
    return v


def banner():
    s = SPEC
    lines = [f"CLIENT={s.get('client')}  DENSITY={s.get('density')}  "
             f"({s.get('feeder_split')} feeder -> {s.get('dist_split')} distribution)",
             f"  drop cap {s.get('drop_cap_m')} m | span cap {s.get('span_cap_m')} m | "
             f"fan {s.get('fan_cap')} | joints/PON {s.get('pon_cap')} | "
             f"PON target {s.get('pon_target')} max {s.get('pon_max')}"]
    unknown = [k for k in ("drop_cap_m", "span_cap_m", "fan_cap", "pon_cap") if s.get(k) is None]
    if unknown:
        lines.append(f"  *** NO SPEC VALUE ON FILE FOR: {', '.join(unknown)} -- "
                     f"R4.7 forbids assuming. Get the sheet. ***")
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    for cl in sorted(SPECS):
        for dens in ("high", "low"):
            os.environ["CLIENT"], os.environ["DENSITY"] = cl, dens
            CLIENT, DENSITY = cl, dens
            SPEC = spec()
            print(banner())
        print()
