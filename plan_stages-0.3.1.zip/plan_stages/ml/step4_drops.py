"""
Step 4 — drop cables and collection points.

Inputs (ground truth, so this step's error is isolated from Steps 1-3):
    Distribution Cable  +  Demand points  +  Pons
Output:
    collection points on the cable, one drop per demand point

R4.6 states the problem exactly: partition the demand points into groups of <= 8 and for
each group find a point ON the distribution cable within 50 m of every member. Capacitated
clustering with a radius constraint.

R3.5  the bot plans one PON at a time, so every PON is solved independently
R4.2  max 8 drops per collection point (hard; 9 requires escalation per Q4.2)
R4.6  drop <= 50 m, HeroTel (client-specific per R4.7)
R4.3  each collection point becomes a pole + dome joint + 1:8 splitter
      -> max 16 per PON, the 1:16 splitter's port count

Method: greedy capacitated cover gives a guaranteed-feasible baseline, then a
capacity-constrained Lloyd tries to beat it at a smaller collection-point count. The
Lloyd result is only accepted if it is feasible AND smaller, so the output can never be
worse than the baseline -- the same never-lose-to-the-baseline shape used in Step 2.

Scored against the reference run: 415 collection points, 2,848 drops, drop median 15.2 m /
p90 25.9 m. Per R4.8 the reference itself breaches 50 m ten times, so it is ground truth
for PATTERN, not for COMPLIANCE.

Usage:  step4_drops.py
"""
import os, json
import numpy as np
from scipy.spatial import cKDTree
from osgeo import ogr, osr
ogr.UseExceptions()

from client_spec import limit, banner as client_banner   # R4.7: limits are PER-CLIENT (F-35)
import cp_cover          # exact (max-flow) feasibility for the collection-point count

from site_crs import LOCAL_EPSG, check_layer   # EPSG:2048 is Malmesbury-only

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
from site_config import work_dir, SITE_DIR as D, have, ref, banner
from site_config import L as LYR   # NOT `L` -- step3 and step567 both use
                                   # a local `L` for a cable length in metres
OUT = work_dir("step4")

DROP_CAP_M = float(os.environ.get("DROP_CAP_M", limit("drop_cap_m", required=True)))  # R4.6
FAN_CAP = int(os.environ.get("FAN_CAP", limit("fan_cap", required=True)))       # R4.2
PON_CAP = int(os.environ.get("PON_CAP", limit("pon_cap", required=True)))      # R4.3
# Lloyd restart budget, split around PON_CAP -- see the comment in solve_pon().
SEEDS_TIGHT = int(os.environ.get("SEEDS_TIGHT", "40"))
SEEDS_LOOSE = int(os.environ.get("SEEDS_LOOSE", "6"))
# Prove the minimum collection-point count per PON rather than searching for it.
CP_EXACT = os.environ.get("CP_EXACT", "1") == "1"
CP_TIME_LIMIT = float(os.environ.get("CP_TIME_LIMIT", "45"))
# 🔴 RETIRED 2026-09-09. This let a drop cross a road to protect the 16-joint ceiling. The
# operator rejected the result on sight: "we don't do that at all". The road rule is hard
# again and the joint count gives way instead -- see solve_pon().
ROAD_TIER = False
# Price of one road-crossing drop, in the same units as the assignment tie-break (metres/1000),
# so a crossing is only taken when it actually buys a collection point.
ROAD_CROSS_COST = float(os.environ.get("ROAD_CROSS_COST", "50"))
CP_DEBUG = os.environ.get("CP_DEBUG", "0") == "1"
# 🔴 FILL EACH 1:8 TO EIGHT DROPS. Operator, 2026-09-10:
#   "For each individual 1:8 splitter, we want 8 drops going to a single 1:8 splitter as far
#    as you can ... We want about 14 1:8 splitters in a pond ... For the ponds that will not
#    have those, it's basically acceptable to then do 7, or maybe 4, 2, or 3. That runs
#    essentially when there's no other choice."
# So an under-filled splitter is a LAST RESORT, not a free choice, and the objective is to
# open as FEW splitters as the geometry allows -- which is the same thing as filling each to
# its 8-way capacity. `JOINT_COST_M` is what one splitter (plus its dome joint and pole) is
# worth in metres of drop cable; at 1,000 m it dominates, so the count is minimised first and
# drop length only breaks ties between equal-count answers.
#
# ⚠️ I had this at 40 m on 2026-09-09 -- a mild preference -- because a render showed wide
# drop fans and I read them as the "messy drops" defect. Measured afterwards, our fans are
# the same shape as the operator's own (spread 254 deg against their 244-248, 81% over 180
# deg against their 77-86%), so the fans were never the problem and the low joint cost was
# solving a defect that did not exist. sec8.2: do not conclude structure from a render.
JOINT_COST_M = float(os.environ.get("JOINT_COST_M", "40"))
# The number of 1:8s the operator expects in a healthy PON. 16 is the HARDWARE ceiling (one
# 1:16 feeder dome); 14 is what they want to see. Reported against, never forced.
SPLITTER_TARGET = int(os.environ.get("SPLITTER_TARGET", "14"))
# What a FULL 1:8 is worth, in metres of drop cable. This is the only term that separates
# 8+8+2 from 6+6+6 -- both open three splitters and serve the same homes, and the operator
# wants the first. Set well above a typical drop so filling a splitter beats shaving metres.
FULL_BONUS_M = float(os.environ.get("FULL_BONUS_M", "300"))
ROAD_TIER_STATS = []      # (homes, drops crossing, count before, count after) per PON
STEP_M = 2.0           # cable discretisation
# REACH EVERY PROPERTY (PLANNING-LEARNINGS sec0). The cap is respected wherever geometry
# allows; a home the capacitated cover cannot place is served anyway with an over-cap drop
# and REPORTED. Measured on Cradock: the accepted plan carries 160 over-cap drops (worst
# 160.2 m) to reach homes we abandoned as "unreachable".
REACH_ALL = os.environ.get("REACH_ALL", "1") == "1"
# THERE IS NO UPPER BOUND ON A DROP (operator, 2026-08-25 -- PLANNING-LEARNINGS sec0.5).
# 212 m is not an escalation; it is served. But an extreme drop is usually EVIDENCE that the
# demand point is not a dwelling -- a sports field or a community hall sits alone on a large
# parcel -- and the operator prunes those by hand. So we flag, never delete, and we flag with
# the two signals they named:
#   R2.4 parcel size    -- the same >5,000 m2 test step3_cable.py used for its C1 note
#   ISOLATION           -- "very, very far away from the rest of the demand points"
# Isolation is expressed as a MULTIPLE of this site's own median nearest-neighbour spacing,
# not as a fitted distance: "far from the others" only means anything relative to how far
# apart the others normally are, and that differs by an order of magnitude between a township
# and a smallholding belt. No new tuned constant enters the pipeline.
REVIEW_ERF_M2 = float(os.environ.get("REVIEW_ERF_M2", "5000"))   # R2.4, as in step3_cable.py
REVIEW_ISO_MULT = float(os.environ.get("REVIEW_ISO_MULT", "5"))  # x median NN spacing

wgs = osr.SpatialReference(); wgs.ImportFromEPSG(4326)
loc = osr.SpatialReference(); loc.ImportFromEPSG(LOCAL_EPSG)
for s in (wgs, loc): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
fwd = osr.CoordinateTransformation(wgs, loc)
rev = osr.CoordinateTransformation(loc, wgs)

def load(name):
    ds = ogr.Open(f"{D}/{name}.shp"); l = ds.GetLayer(); o = []
    for f in l:
        g = f.GetGeometryRef()
        if g is None: continue
        g = g.Clone(); g.FlattenTo2D(); g.Transform(fwd); o.append(g)
    return o

def lines(geoms):
    out = []
    for g in geoms:
        stack = [g]
        while stack:
            x = stack.pop()
            if x.GetGeometryName() == "LINESTRING":
                out.append(np.array([(x.GetX(i), x.GetY(i)) for i in range(x.GetPointCount())]))
            elif x.GetGeometryCount():
                stack += [x.GetGeometryRef(i) for i in range(x.GetGeometryCount())]
    return out

def densify(cs, step):
    pts = []
    for c in cs:
        for a, b in zip(c[:-1], c[1:]):
            n = max(int(float(np.hypot(*(b-a)))/step), 1)
            pts += [a + (b-a)*(k/n) for k in range(n)]
        pts.append(c[-1])
    return np.array(pts)

def P(g): return g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()

# CABLE=claude routes everything onto OUR OWN Step 3 cable instead of the
# operator's, which is the only way to test the pipeline end to end.
CABLE = os.environ.get("CABLE", "gt")
if CABLE == "claude":
    _p = os.path.join(work_dir("step3"), "claude_distribution_cable.gpkg")
    _ds = ogr.Open(_p); _l = _ds.GetLayer(); _g = []
    for _f in _l:
        _x = _f.GetGeometryRef()
        if _x is None: continue
        _x = _x.Clone(); _x.FlattenTo2D(); _x.Transform(fwd); _g.append(_x)
    dc = lines(_g)
    print(f"USING OUR OWN Step 3 cable: {len(dc)} segments")
else:
    if not have("ref_cable"):
        raise SystemExit("CABLE=gt needs the reference Distribution Cable layer, which "
                         "this site does not have. Use CABLE=claude to route on our own "
                         "Step 3 output.")
    dc = lines(load(LYR("ref_cable")))
DPSRC = os.environ.get("DPSRC", "gt")
if DPSRC == "claude":
    _dp = load(None) if False else None
    _ds2 = ogr.Open(os.path.join(work_dir("step2"), "claude_demand_points.gpkg"))
    _l2 = _ds2.GetLayer(); _pts = []
    for _f in _l2:
        _g = _f.GetGeometryRef()
        if _g is None: continue
        _g = _g.Clone(); _g.FlattenTo2D(); _g.Transform(fwd)
        _pts.append((P(_g).GetX(), P(_g).GetY()))
    DPS = np.array(_pts); print(f"USING OUR OWN Step 2 demand points: {len(DPS)}")
else:
    DPS = np.array([(P(g).GetX(), P(g).GetY()) for g in load(LYR("demand_points"))])
# WHERE MAY A COLLECTION POINT STAND? Every collection point carries a 1:8 splitter and a
# dome joint, so it must stand ON A POLE. Before the wayleave we had no pole layer at Step 4,
# so candidates were points densified along the cable and Step 5 planted a pole wherever the
# cover happened to land. The wayleave SUPPLIES the poles -- surveyed, permitted, already on
# the span (2,729 of 2,729 within 2 m of it on Ventersdorp) -- so the candidate set is now
# THEIR POLES, and a collection point can no longer ask for a pole that does not exist.
#
# Measured before the change (`work/_probes/pole_reconcile.py`): our free-floating collection
# points sat a median 9.2 m, max 21.9 m from the nearest operator pole. Every one of them was
# reachable, so this constrains the cover rather than breaking it.
#
# CANDSRC=cable restores the old behaviour for a site whose wayleave carries no poles.
CANDSRC = os.environ.get("CANDSRC", "poles" if have("poles") else "cable")
if CANDSRC == "poles":
    CAND = np.array([(P(g).GetX(), P(g).GetY()) for g in load(LYR("poles"))])
    print(f"CANDIDATES = the operator's {len(CAND):,} wayleave poles "
          f"(a collection point must stand on a pole)")
else:
    CAND = densify(dc, STEP_M)
    print(f"CANDIDATES = {len(CAND):,} points densified along the cable @{STEP_M} m "
          f"(no pole layer in this wayleave)")
# ---- COLLECTION POINTS THE OPERATOR PLACED BY HAND -----------------------------------
# The operator edits the plan in QGIS and expects those edits to survive. On 2026-09-10 they
# added two 1:8 splitters, two poles and ~47 m of distribution across two roads, to reach
# houses our plan was serving with over-long drops from far away:
#   "Get rid of the long drop cables that you added to those houses from other sections,
#    from other 1:8 splitters far away, and just use the new 1:8 splitters to do the drops
#    to those houses. It's going to make it look more tidy."
# A hand-added splitter is recognisable because ours all carry the `cp_id` of the step-4
# collection point they came from, and a drawn one has cp_id NULL.
# They are FORCED into the candidate set and pinned open, so the cover has to use them --
# otherwise the optimiser would simply re-derive its own answer and discard the operator's.
FORCED = []
_s5 = os.path.join(work_dir("step567"), "claude_step567.gpkg")
if os.environ.get("HONOUR_HAND_EDITS", "1") == "1" and os.path.exists(_s5):
    try:
        _ds5 = ogr.Open(_s5); _l5 = _ds5.GetLayerByName("claude_8way_splitters")
        for _f in _l5:
            if _f.GetField("cp_id") is not None:
                continue
            _g = _f.GetGeometryRef()
            if _g is None: continue
            _g = _g.Clone(); _g.FlattenTo2D(); _g.Transform(fwd)
            FORCED.append((P(_g).GetX(), P(_g).GetY()))
        _ds5 = None
    except Exception as _e:
        print(f"   (could not read hand-added splitters: {_e})")
if FORCED:
    _base = len(CAND)
    CAND = np.vstack([CAND, np.array(FORCED)])
    FORCED_IDX = list(range(_base, len(CAND)))
    print(f"OPERATOR HAND-PLACED {len(FORCED)} collection point(s) -- forced into the plan")
else:
    FORCED_IDX = []

PONS = load(LYR("pons"))
# The PON's own number, index-aligned with PONS (same null-geometry skip as load()). Everything written out
# carries THIS, never the polygon's file position: on 2026-10-09 the position (pon_num - 1) went into every
# collection point and the plugin's PON-cap rows named, counted and located the wrong PON. Same rule as step3.
def _pon_labels(name):
    ds = ogr.Open(f"{D}/{name}.shp"); l = ds.GetLayer(); o = []
    names = {l.GetLayerDefn().GetFieldDefn(i).GetName() for i in range(l.GetLayerDefn().GetFieldCount())}
    for f in l:
        if f.GetGeometryRef() is None: continue
        v = next((f.GetField(k) for k in ("pon_num", "label") if k in names and f.GetField(k) is not None), None)
        o.append(int(v) if v is not None and str(v).strip().lstrip("-").isdigit() else len(o) + 1)
    return o
PON_LABEL = _pon_labels(LYR("pons"))
check_layer(f"{D}/{LYR('pons')}.shp")   # loud if EPSG:2048 is wrong for this site
dc_len = sum(float(np.hypot(*(c[1:]-c[:-1]).T).sum()) for c in dc)
print(f"distribution cable {len(dc)} spans / {dc_len:,.0f} m")
print(f"demand points {len(DPS)}   PONs {len(PONS)}")

def pon_of(x, y):
    p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(float(x), float(y))
    for i, g in enumerate(PONS):
        if g.Contains(p): return i
    return -1
dp_pon = np.array([pon_of(*p) for p in DPS])
cand_pon = np.array([pon_of(*c) for c in CAND])

# A generated route can stray a metre or two outside the PON polygon it serves. Strict
# containment then rejects it and homes look "unserved" with cable 47 m away -- measured,
# 5 homes in PON 4. Attach any stray candidate to the PON whose boundary it is nearest.
stray = np.flatnonzero(cand_pon < 0)
if len(stray):
    fixed = 0
    for ci in stray:
        q = ogr.Geometry(ogr.wkbPoint); q.AddPoint_2D(float(CAND[ci][0]), float(CAND[ci][1]))
        best, bd = -1, 25.0
        for pi_, g_ in enumerate(PONS):
            d_ = g_.Distance(q)
            if d_ < bd: best, bd = pi_, d_
        if best >= 0: cand_pon[ci] = best; fixed += 1
    print(f"cable points outside every PON: {len(stray)} -> {fixed} re-attached to the nearest")

# Erven outside every PON are out of Step 0 scope (R3.5), not planning failures.
out_of_scope = int((dp_pon < 0).sum())
print(f"demand points outside every PON (out of scope, not unserved): {out_of_scope}")

tree = cKDTree(CAND)

# ---- DROPS MUST NOT CROSS A ROAD (PLANNING-LEARNINGS sec0.7, operator 2026-08-27) -------
# Loaded from Road.shp in the site inputs (or ROADS=). No layer -> unconstrained, as before.
# All geometry here is in the local metric CRS, so RoadBlocker gets `fwd` to match.
from roadblock import load_for_site as _load_blocker
BLOCKER = _load_blocker(D, fwd)
REACH_BLK_M = float(os.environ.get("REACH_MAX_M", "400"))
road_forced = 0
print("road layer: " + (f"{BLOCKER.segs.shape[0]:,} segments -- drops will NOT cross them"
                        if BLOCKER else "none -- drop-over-road rule not enforceable here"))


def dmat(dp_idx, cpos):
    return np.array([[float(np.hypot(*(CAND[c] - DPS[i]))) for c in cpos] for i in dp_idx])

def assign(dp_idx, cpos):
    """most-constrained demand point first, nearest collection point with a free port.
       -> {dp -> slot} or None if any demand point cannot be served"""
    dm = dmat(dp_idx, cpos); feas = dm <= DROP_CAP_M
    if BLOCKER is not None:
        for t, i in enumerate(dp_idx):
            feas[t] &= ~_blk(i, cpos)
    used = np.zeros(len(cpos), int); slot = {}
    todo = list(range(len(dp_idx)))
    while todo:
        avail = used < FAN_CAP
        nopt = [int((feas[t] & avail).sum()) for t in todo]
        t = todo[int(np.argmin(nopt))]
        c = np.flatnonzero(feas[t] & avail)
        if len(c) == 0: return None
        j = int(c[int(np.argmin(dm[t][c]))])
        slot[dp_idx[t]] = j; used[j] += 1; todo.remove(t)
    return slot

def _blk(i, cand_pos_idx, reach=None):
    """DROPS MUST NOT CROSS A ROAD (PLANNING-LEARNINGS sec0.7). (K,) bool for home i.
    Mirrors cover.Cover._blk -- the closed loop must optimise the same constraint.
    Default reach = the drop cap (longer pairs are infeasible anyway and pricing them
    costs 100x); serve_leftovers passes REACH_BLK_M for its over-cap drops."""
    if BLOCKER is None:
        return np.zeros(len(cand_pos_idx), bool)
    r = (DROP_CAP_M + 1.0) if reach is None else float(reach)
    return BLOCKER.blocked_from(DPS[int(i)], CAND[np.asarray(cand_pos_idx, int)], r)


def reposition(slot, cpos, cand_idx):
    """move each collection point to the cable position minimising its members' drops"""
    out = []
    for j in range(len(cpos)):
        mem = [i for i, s in slot.items() if s == j]
        if not mem: out.append(cpos[j]); continue
        tot = np.zeros(len(cand_idx)); bad = np.zeros(len(cand_idx), bool)
        for i in mem:
            d = np.hypot(*(CAND[cand_idx] - DPS[i]).T)
            tot += d; bad |= d > DROP_CAP_M
            if BLOCKER is not None:
                bad |= _blk(i, cand_idx)
        tot[bad] = np.inf
        out.append(cand_idx[int(tot.argmin())] if np.isfinite(tot).any() else cpos[j])
    return out

def greedy_pon(dp_idx, cand_idx):
    """always feasible: repeatedly open the position covering the most unserved homes"""
    unserved = set(int(i) for i in dp_idx); cpos = []; slot = {}
    while unserved:
        u = np.fromiter(unserved, int)
        best, bestn, bestmem = None, 0, None
        d_all = np.array([np.hypot(*(CAND[cand_idx] - DPS[i]).T) for i in u])
        within = d_all <= DROP_CAP_M
        if BLOCKER is not None:
            for t, i in enumerate(u):
                within[t] &= ~_blk(i, cand_idx)
        cnt = within.sum(axis=0)
        if cnt.max() == 0: break
        for c in np.flatnonzero(cnt == cnt.max()):
            mem = u[within[:, c]]
            mem = mem[np.argsort(d_all[within[:, c], c])][:FAN_CAP]
            if len(mem) > bestn: best, bestn, bestmem = c, len(mem), mem
        for i in bestmem: slot[int(i)] = len(cpos); unserved.discard(int(i))
        cpos.append(cand_idx[best])
    return cpos, slot

def lloyd_pon(dp_idx, cand_idx, K, seed, rounds=15):
    """capacity-constrained Lloyd at a FIXED collection-point count K"""
    rng = np.random.default_rng(seed)
    s = [int(rng.integers(len(dp_idx)))]
    while len(s) < K:
        d = np.min([np.hypot(*(DPS[dp_idx] - DPS[dp_idx[t]]).T) for t in s], axis=0)
        p = d**2
        s.append(int(rng.choice(len(dp_idx), p=p/p.sum())) if p.sum() > 0
                 else int(rng.integers(len(dp_idx))))
    cpos = []
    for t in s:
        d = np.hypot(*(CAND[cand_idx] - DPS[dp_idx[t]]).T)
        cpos.append(cand_idx[int(d.argmin())])
    best = None
    for _ in range(rounds):
        slot = assign(dp_idx, cpos)
        if slot is None: return best          # keep the last feasible one, if any
        best = (list(cpos), dict(slot))
        new = reposition(slot, cpos, cand_idx)
        if new == cpos: break
        cpos = new
    return best

def _reach_matrix(dp_idx, cand_idx, allow_road=False):
    """home x candidate reachability: within the drop cap, and (unless allow_road) not
    across a road."""
    reach = np.zeros((len(dp_idx), len(cand_idx)), dtype=bool)
    for t, i in enumerate(dp_idx):
        d = np.hypot(*(CAND[cand_idx] - DPS[i]).T)
        ok = d <= DROP_CAP_M
        if BLOCKER is not None and not allow_road and ok.any():
            ok &= ~_blk(i, cand_idx)
        reach[t] = ok
    return reach


def solve_pon(dp_idx, cand_idx):
    """Fewest collection points that serve every home. Never worse than greedy.

    THE COUNT IS A HARDWARE LIMIT (one 1:16 dome -> 16 x 1:8), so it is minimised with an
    EXACT feasibility test rather than a heuristic one. cp_cover checks a candidate set of
    poles by max flow -- capacity 8 per pole, each home only to poles in reach -- so the
    search only has to choose the SET, and can never claim a count it cannot deliver.

    This replaced capacity-constrained Lloyd, which left 43 of 82 Ventersdorp PONs above the
    16 ceiling while only 8 were genuinely forced there (`work/_probes/ceiling_bind.py`:
    capacity forced 0, coverage forced 8). Raising Lloyd's restarts 6 -> 40 changed nothing,
    which is what proved it was the wrong instrument: Lloyd moves centres, and the question
    is which subset of poles to open."""
    if len(dp_idx) and len(cand_idx):
        try:
            reach_all = _reach_matrix(dp_idx, cand_idx)
            # PLAN FOR THE HOMES THAT CAN BE SERVED, AND ESCALATE THE REST.
            # A home with no pole within the drop cap makes the covering problem INFEASIBLE,
            # because every home must be assigned. One such home was therefore sinking its
            # whole PON: the solver returned nothing, the run fell back to the weak greedy
            # path, and the count blew past the 16 ceiling. Measured 2026-09-09 with CP_DEBUG:
            # of the 12 PONs over the ceiling, NINE had unreachable homes (83/85, 106/107,
            # 112/113, 97/103, 88/96, 99/100, 91/92, 103/104, 90/91, 32/33) and only three
            # were genuinely constrained.
            # The unserved homes are still reported -- step4 counts and lists them as
            # escalations -- so nothing is hidden; they simply stop destroying the plan for
            # the 84 neighbours that CAN be served. Their cause is a wayleave data gap (no
            # pole near them), not a routing choice, and no solver can fix it.
            _ok = reach_all.any(axis=1)
            if not _ok.all():
                dp_idx = dp_idx[_ok]
                reach = reach_all[_ok]
                if CP_DEBUG:
                    print(f"   [cp] {int((~_ok).sum())} home(s) have no candidate within "
                          f"{DROP_CAP_M:.0f} m -- escalated, planning the remaining {len(dp_idx)}")
                if len(dp_idx) == 0:
                    raise ValueError("no reachable homes in this PON")
            else:
                reach = reach_all
            # EXACT first (MILP): one PON is small enough to prove the minimum, and the
            # difference matters -- the drop-and-repair heuristic got Ventersdorp from 43
            # PONs over the ceiling to 37 when the diagnosis said 8 were truly forced, and a
            # number in between cannot be told apart from a tired search. Fall back to the
            # heuristic only if the MILP cannot answer inside its time limit.
            # THE OBJECTIVE IS DROP LENGTH, UNDER A COUNT CEILING -- not the count itself.
            # Minimising the count produced 14 collection points per PON against the
            # operator's 15, and paid for it with long radiating drop fans: the "messy drop
            # cables" objection (F-52, F-56) is visible again in the render. Their own plans
            # sit just under the ceiling with SHORT drops, so the ceiling is a constraint and
            # the metres are the thing to minimise. `y_cost` stays as a mild per-joint charge
            # (hardware costs something) but no longer dominates.
            _dm = np.array([np.hypot(*(CAND[cand_idx] - DPS[i]).T) for i in dp_idx])

            def _try(R, xc=None, cap=None):
                g = (cp_cover.solve_exact(R, FAN_CAP, time_limit=CP_TIME_LIMIT, x_cost=xc,
                                          y_cost=JOINT_COST_M, max_open=cap,
                                          full_bonus=FULL_BONUS_M, force_open=_pin)
                     if CP_EXACT else None)
                if g is None:
                    g = cp_cover.solve(R, FAN_CAP, ceil=PON_CAP, rng=np.random.default_rng(0))
                return g if g and g[0] is not None else None

            # per-assignment cost: the drop's own length in metres, plus a road crossing
            # charge that only pays for itself when it saves a whole collection point.
            def _xcost(R_hard):
                return np.where(R_hard, 0.0, ROAD_CROSS_COST) + _dm

            # 🔴 A DROP MUST NEVER CROSS A ROAD. Operator, 2026-09-09, looking at the
            # plan: "we don't do that at all ... there's supposed to be a pull-over there
            # and a 1-to-8 splitter on the other side of the road to account for any demand
            # points that are there."
            # So the road rule is HARD and the JOINT COUNT is what gives way -- the opposite
            # of what this code did between 09:00 and 16:00 today. That earlier version
            # relaxed the road rule to protect the 16-joint ceiling, on the strength of
            # measuring the operator's own drops crossing roads 4.2-6.7% of the time. The
            # operator looked at the result and rejected it outright, so that measurement is
            # not evidence of a rule -- their crossings are something else (a road layer
            # artefact, or a case-by-case exception), and an aggregate that matched was
            # again hiding a structural error (F-59, F-61).
            # A PON that needs more than PON_CAP collection points to avoid crossing a road
            # is REPORTED as an escalation. That is a real, visible consequence for the
            # operator to rule on -- not something to be tuned away by crossing a road.
            # THE COUNT IS SET BY THE CAP, NOT BY PRICING A SPLITTER.
            # Measured on the operator's own HeroTel plans (WAYLEAVE-KNOWLEDGE.md sec5-6):
            # 13.7 / 14.0 / 14.0 / 14.1 / 14.6 / 16.3 splitters per PON, and a fill of
            # mean 5.7-7.8 with only 17-64% at a full 8. Matiko is the closest model --
            # 14.0 per PON, mean 6.48, 33% at 8.
            # So the fill is a CONSEQUENCE of capping the count: 94 homes over 14 splitters
            # is 6.7 each, which is their number. Pricing splitters at 1,000 m instead was
            # tried on 2026-09-10 and it stretched the worst drop from 198 m to 315 m while
            # barely moving the fill -- the operator's "don't overextend the drop span".
            # Within the cap, drop length is minimised, so drops stay short.
            # PRIORITISE A FULL 1:8. Operator, 2026-09-10: "we want to try to prioritize 8
            # drop cables going to a single 1-to-8 splitter. Later on, when we get to certain
            # PONs where that's not possible, it's fine. We can have 3 or 4 and split it up
            # that way within the immediate distance of that 1-to-8 splitter."
            # So the ladder starts at the CAPACITY FLOOR -- ceil(homes / 8), the fewest
            # splitters that could exist if every one were full -- and only loosens when that
            # is geometrically infeasible. The first feasible rung is taken, so the fill is
            # as close to 8 as this PON's geometry allows, and no looser.
            # Starting the ladder at 14 instead (tried first) let the solver spread 94 homes
            # evenly over 14 splitters at ~6.7 each when 12 full ones were available.
            # "Within the immediate distance" is the second half: within the chosen rung,
            # drop LENGTH is minimised, so a short-filled splitter still serves its own
            # neighbours rather than reaching across the block.
            # OPERATOR'S CHOICE, 2026-09-10: "fill to 8, but never fewer than 14".
            # 14 x 8 = 112 homes, and Ventersdorp's PONs hold 94 (median), so the two goals
            # cannot both hold on this site -- put to the operator, who chose to keep BOTH
            # the 14 splitters AND the 8-fill priority. That means the surplus splitters
            # carry the leftovers: a mix of full 8s and small ones, rather than an even 6.7
            # spread. `full_bonus` in the MILP is what produces that mix; the cap ladder
            # below never goes under SPLITTER_TARGET so the count stays at 14+.
            # A hand-placed splitter inside this PON is PINNED OPEN: the operator put it
            # there to serve specific houses, so the cover must build around it rather than
            # decide it is unnecessary.
            _pin = [int(np.flatnonzero(cand_idx == c)[0])
                    for c in FORCED_IDX
                    if c in set(cand_idx.tolist())]
            if _pin:
                print(f"   [hand] PON has {len(_pin)} operator-placed collection point(s) -- pinned open")
            _floor = max(-(-len(dp_idx) // FAN_CAP), 1)
            got = None
            for _cap in list(range(max(_floor, SPLITTER_TARGET), PON_CAP + 1)) + [None]:
                got = _try(reach, xc=_dm, cap=_cap)
                if got is not None:
                    break
            poles, slot_l = got if got else (None, None)
            if CP_DEBUG:
                _r = reach.any(axis=1)
                print(f"   [cp] PON homes={len(dp_idx)} cands={len(cand_idx)} "
                      f"reachable={int(_r.sum())}/{len(dp_idx)} "
                      f"-> {'None' if poles is None else len(poles)} CPs")
            if poles is not None:
                cpos = [int(cand_idx[p]) for p in poles]
                remap = {p: j for j, p in enumerate(poles)}
                slot = {int(dp_idx[h]): remap[p] for h, p in slot_l.items()}
                if len(slot) == len(dp_idx):
                    # polish positions at this count; the count itself is already minimal
                    for _ in range(10):
                        new = reposition(slot, cpos, cand_idx)
                        if new == cpos: break
                        s2 = assign(dp_idx, new)
                        if s2 is None: break
                        cpos, slot = new, s2
                    return cpos, slot, len(cpos), len(cpos)
        except Exception as _e:                 # never let the solver take the run down
            print(f"   cp_cover failed ({_e}); falling back to Lloyd for this PON")

    cpos, slot = greedy_pon(dp_idx, cand_idx)
    base = len(cpos)
    floor = max(-(-len(dp_idx)//FAN_CAP), 1)
    for K in range(floor, base):
        # THE 16 CEILING IS HARDWARE, NOT PREFERENCE (spec: one 1:16 feeder dome ->
        # 16 x 1:8 distribution), so it is worth real search to stay under it. Diagnosed
        # 2026-09-09 (`work/_probes/joint_fill.py`): at a perfect 8-home fill NO Ventersdorp
        # PON needs more than 15 collection points, and the fill needed to fit 16 is 5.91
        # homes/CP against the 5.82 we were achieving -- so the breaches were the SEARCH
        # falling just short, not the PON division being too big. Six seeds was the whole
        # budget at every K. Spend SEEDS_TIGHT at or below the ceiling and the cheap
        # SEEDS_LOOSE above it, where an extra joint is merely suboptimal, not illegal.
        seeds = SEEDS_TIGHT if K <= PON_CAP else SEEDS_LOOSE
        for seed in range(seeds):
            r = lloyd_pon(dp_idx, cand_idx, K, seed)
            if r and len(r[1]) == len(dp_idx):
                return r[0], r[1], base, K
    # polish the baseline's positions even when its count cannot be beaten
    for _ in range(10):
        new = reposition(slot, cpos, cand_idx)
        if new == cpos: break
        s2 = assign(dp_idx, new)
        if s2 is None: break
        cpos, slot = new, s2
    return cpos, slot, base, base

# The reference uses MORE collection points and LESS drop cable than a count-minimising
# solve. Neither dominates, so comparing totals is meaningless. MODE=match fixes K per PON
# to the reference's own count and minimises drop length instead -- the only fair test of
# whether our placement is as good as the human's.
MODE = os.environ.get("MODE", "min")
REF_K = {}
if MODE == "match":
    # Use the Dome Joints layer itself, NOT collection points recovered by clustering drop
    # endpoints -- that recovery returns 418 against the true 413 and inflates K.
    if not have("ref_dome_joints"):
        raise SystemExit("MODE=match needs the reference Dome Joints layer, which this "
                         "site does not have. MODE=match is a COMPARISON mode -- never "
                         "use it on a new site (leakage note, PLANNING-METHOD.md).")
    for g in load(LYR("ref_dome_joints")):
        p = P(g); pi = pon_of(p.GetX(), p.GetY())
        if pi >= 0: REF_K[pi] = REF_K.get(pi, 0) + 1
    print(f"MODE=match: reference collection points per PON loaded "
          f"({sum(REF_K.values())} total across {len(REF_K)} PONs)")

def solve_pon_at_K(dp_idx, cand_idx, K):
    """fixed K, minimise total drop length across restarts"""
    best = None
    for seed in range(8):
        r = lloyd_pon(dp_idx, cand_idx, K, seed)
        if not r or len(r[1]) != len(dp_idx): continue
        cpos, slot = r
        tot = sum(float(np.hypot(*(CAND[cpos[j]] - DPS[i]))) for i, j in slot.items())
        if best is None or tot < best[0]: best = (tot, cpos, slot)
    return (best[1], best[2]) if best else None

# MODE=sweep: for every PON, the whole cost curve -- total drop cable at each feasible
# collection-point count K, from the minimum possible up to the ceiling of 16. Written to
# disk so the joints-vs-cable trade-off can be calibrated afterwards without re-solving.
if MODE == "sweep":
    curve = {}
    # SWEEP_PONS=3,4,7 restricts the sweep to named PONs -- the whole-site sweep costs
    # hours and the question is usually about a handful of them (F-55).
    _only = os.environ.get("SWEEP_PONS", "")
    _only = set(int(x) for x in _only.replace(" ", "").split(",") if x) if _only else None
    for pi in range(len(PONS)):
        if _only is not None and pi not in _only: continue
        dp_idx = np.flatnonzero(dp_pon == pi)
        cand_idx = np.flatnonzero(cand_pon == pi)
        if len(dp_idx) == 0 or len(cand_idx) == 0: continue
        dp_idx = np.array([i for i in dp_idx if len(tree.query_ball_point(DPS[i], DROP_CAP_M))])
        if len(dp_idx) == 0: continue
        floor = max(-(-len(dp_idx)//FAN_CAP), 1)
        row = {}
        for K in range(floor, PON_CAP+1):
            r = solve_pon_at_K(dp_idx, cand_idx, K)
            if r is None: continue
            cpos, slot = r
            row[K] = round(sum(float(np.hypot(*(CAND[cpos[j]] - DPS[i])))
                               for i, j in slot.items()), 1)
        curve[pi] = {"homes": int(len(dp_idx)), "floor": floor, "cable_at_K": row}
        print(f"PON {pi:2d}: {len(dp_idx):3d} homes, K {floor}..{PON_CAP} -> "
              + "  ".join(f"{k}:{int(v)}" for k, v in sorted(row.items())))
    json.dump(curve, open(os.path.join(OUT, "step4_cost_curve.json"), "w"), indent=2)
    print(f"\nwrote {os.path.join(OUT, 'step4_cost_curve.json')}")
    raise SystemExit

def serve_leftovers(dp_idx, cand_idx, cpos, slot):
    """Serve anything the capacitated cover could not place, with an over-cap drop.

    Mirrors cover.Cover.serve_leftovers so the closed loop scores what Step 4 does. A home
    beyond the cap is a LONG DROP, not an unreachable property (PLANNING-LEARNINGS sec0)."""
    missing = [int(i) for i in dp_idx if int(i) not in slot]
    if not missing:
        return cpos, slot, 0
    used = {}
    for j in slot.values():
        used[j] = used.get(j, 0) + 1
    global road_forced
    over = 0
    for i in missing:
        # 🔴 CROSSING A ROAD IS THE WORST OUTCOME, not a mild penalty. Operator,
        # 2026-09-09: "we don't do that at all." This tier used to rank a road crossing
        # BELOW an over-cap drop (crossing = +1, over-cap = +2), so the solver would cross
        # a road rather than run a long drop -- which is why 62 crossings survived after
        # the cover itself was made strict. A long drop is a cable cost; a road crossing is
        # a build the operator says does not happen. Ranked accordingly: any crossing is
        # worse than any non-crossing.
        def tier(d, blocked):
            return (4 if blocked else 0) + (0 if d <= DROP_CAP_M else 1)
        blk_c = _blk(i, cpos, REACH_BLK_M) if BLOCKER is not None and cpos else None
        best = None                      # (tier, d, j)
        for j in range(len(cpos)):
            if used.get(j, 0) >= FAN_CAP:
                continue
            d = float(np.hypot(*(CAND[cpos[j]] - DPS[i])))
            b = bool(blk_c[j]) if blk_c is not None else False
            k = (tier(d, b), d, j)
            if best is None or k < best:
                best = k
        # MEASURED 2026-08-27: attach-only-unless-no-free-port left ~400 road-blocked
        # leftovers hanging off DISTANT free-port CPs (318 over-cap, 155 km of drops) while
        # an in-cap position across the road sat unused. So ALWAYS price the new-CP option
        # and take it when it reaches a strictly BETTER TIER than the best attach; on equal
        # tier keep the attach (no new joint for nothing).
        d = np.hypot(*(CAND[cand_idx] - DPS[i]).T)
        bd = (_blk(i, cand_idx, REACH_BLK_M) if BLOCKER is not None
              else np.zeros(len(cand_idx), bool))
        ks = [(tier(float(d[m]), bool(bd[m])), float(d[m]), m)
              for m in range(len(cand_idx))]
        nt, nd, nm = min(ks)
        if best is None or nt < best[0]:
            cpos = list(cpos) + [cand_idx[nm]]
            best = (nt, nd, len(cpos) - 1)
        t_, best_d, best_j = best
        slot[i] = best_j
        used[best_j] = used.get(best_j, 0) + 1
        if best_d > DROP_CAP_M:
            over += 1
        if t_ >= 4:                 # tier now encodes a crossing as >= 4
            road_forced += 1
    return cpos, slot, over


over_cap_forced = 0
assigned = np.full(len(DPS), -1); collections = []
escalate = []; improved = 0
for pi in range(len(PONS)):
    dp_idx = np.flatnonzero(dp_pon == pi)
    cand_idx = np.flatnonzero(cand_pon == pi)
    if len(dp_idx) == 0 or len(cand_idx) == 0: continue
    if not REACH_ALL:
        dp_idx = np.array([i for i in dp_idx
                           if len(tree.query_ball_point(DPS[i], DROP_CAP_M))])
    if len(dp_idx) == 0: continue
    if MODE == "match" and REF_K.get(pi):
        r = solve_pon_at_K(dp_idx, cand_idx, REF_K[pi])
        if r is None:
            cpos, slot, base, K = solve_pon(dp_idx, cand_idx)
        else:
            cpos, slot = r; base = K = len(cpos)
    else:
        cpos, slot, base, K = solve_pon(dp_idx, cand_idx)
    if REACH_ALL:
        cpos, slot, _ov = serve_leftovers(dp_idx, cand_idx, cpos, slot)
        over_cap_forced += _ov
    if K < base: improved += 1
    if len(cpos) > PON_CAP:
        escalate.append((pi, len(dp_idx), len(cpos)))
    b = len(collections); collections += list(cpos)
    for i, j in slot.items(): assigned[i] = b + j
collections = np.array(collections)

# ---- POST-PASS 0: REMOVE-AND-REPAIR SURPLUS JOINTS (F-55, 2026-09-04) ------------------
# Measured on Malmesbury: our solver opens 443 joints where the accepted plan uses 413, at
# the SAME road compliance (21 crossings vs their 16), the same drop cable (+0.6%) and
# better cap compliance. Handed the human's OWN cable it opens 448 -- so the excess is not
# the router, not the PON cut and not the caps. It is slack in `greedy_pon` + a 6-seed
# Lloyd, which solve each PON once and never revisit the joint COUNT afterwards.
#
# This pass revisits it. For each joint, try to empty it into the other joints of ITS OWN
# PON (R3.5) under the same three rules, and delete it when every member fits. It is
# never-lose-to-the-baseline -- the same shape Step 2 and solve_pon already use: a joint
# goes only when ALL of its drops are re-placed legally, so coverage cannot fall, no
# compliant drop is made non-compliant, and no drop gains a road crossing it did not have.
PRUNE = os.environ.get("PRUNE", "1") == "1"


def _prune():
    global collections, assigned
    alive = np.ones(len(collections), bool)
    fan = np.bincount(assigned[assigned >= 0], minlength=len(collections))
    pon_of_cp = cand_pon[collections]
    by_pon = {}
    for j in range(len(collections)):
        by_pon.setdefault(int(pon_of_cp[j]), []).append(j)
    removed = 0
    for _sweep in range(6):
        gone = 0
        for j in sorted(range(len(collections)), key=lambda x: fan[x]):
            if not alive[j]: continue
            if fan[j] == 0:                       # an empty joint is free to drop
                alive[j] = False; gone += 1; continue
            mem = [int(x) for x in np.flatnonzero(assigned == j)]
            others = [k for k in by_pon[int(pon_of_cp[j])]
                      if k != j and alive[k] and fan[k] < FAN_CAP]
            if not others: continue
            OK = np.array(others)
            OP = CAND[collections[OK]]
            opts = {}
            for i in mem:
                d = np.hypot(*(OP - DPS[i]).T)
                oldd = float(np.hypot(*(CAND[collections[j]] - DPS[i])))
                # never push a compliant drop over the cap; never lengthen an over-cap one
                lim = DROP_CAP_M if oldd <= DROP_CAP_M else oldd
                good = d <= lim
                if BLOCKER is not None and good.any():
                    # sec0.7 two-tier: a drop that already crosses may move anywhere legal
                    # by length; a clean drop may never ACQUIRE a crossing.
                    # REACH MUST COVER `lim`: blocked_from reports "not blocked" for any
                    # candidate beyond its reach, so the default (the cap) silently skipped
                    # the road test on over-cap drops -- measured, 1 new crossing each at
                    # Botshabelo and WUVS (F-55 addendum).
                    r_ = float(lim) + 1.0
                    if not bool(_blk(i, [collections[j]], r_)[0]):
                        good &= ~_blk(i, collections[OK], r_)
                opts[i] = (d, good)
            plan, tmp, ok = {}, {k: int(fan[k]) for k in others}, True
            for i in sorted(mem, key=lambda i: int(opts[i][1].sum())):   # most-constrained
                d, good = opts[i]
                pick = [(float(d[m]), others[m]) for m in np.flatnonzero(good)
                        if tmp[others[m]] < FAN_CAP]
                if not pick: ok = False; break
                _dd, k = min(pick)
                plan[i] = k; tmp[k] += 1
            if not ok: continue
            for i, k in plan.items():
                assigned[i] = k; fan[k] += 1
            fan[j] = 0; alive[j] = False; gone += 1
        removed += gone
        if gone == 0: break
    if removed:
        idx = np.flatnonzero(alive)
        remap = -np.ones(len(collections), int); remap[idx] = np.arange(len(idx))
        m = assigned >= 0
        assigned[m] = remap[assigned[m]]
        collections = collections[idx]
    return removed


def _repos():
    """After a prune the surviving joints carry members they were not placed for, so they
    sit where the OLD membership wanted them. Slide each one along its own PON's cable to
    the position minimising its members' drops, accepting only positions that keep every
    member at least as compliant as it is now (same rule as the prune). Pure win on cable:
    the current position is always in the candidate set, so this can never lengthen."""
    moved = 0; saved = 0.0
    pon_of_cp = cand_pon[collections]
    cidx = {}
    for j in range(len(collections)):
        p = int(pon_of_cp[j])
        if p not in cidx: cidx[p] = np.flatnonzero(cand_pon == p)
        mem = [int(x) for x in np.flatnonzero(assigned == j)]
        if not mem: continue
        ci = cidx[p]
        if not len(ci): continue
        tot = np.zeros(len(ci)); bad = np.zeros(len(ci), bool)
        cur = 0.0
        for i in mem:
            d = np.hypot(*(CAND[ci] - DPS[i]).T)
            oldd = float(np.hypot(*(CAND[collections[j]] - DPS[i])))
            cur += oldd
            tot += d
            lim = DROP_CAP_M if oldd <= DROP_CAP_M else oldd
            bad |= d > lim
            if BLOCKER is not None:
                r_ = float(lim) + 1.0      # reach must cover `lim` -- see _prune
                if not bool(_blk(i, [collections[j]], r_)[0]):
                    bad |= _blk(i, ci, r_)
        tot[bad] = np.inf
        if not np.isfinite(tot).any(): continue
        b = int(tot.argmin())
        if float(tot[b]) < cur - 1e-9:
            saved += cur - float(tot[b])
            collections[j] = ci[b]; moved += 1
    return moved, saved


if PRUNE:
    _before = len(collections)
    _pr = _prune()
    print(f"\npruned {_pr} surplus collection points (F-55 remove-and-repair): "
          f"{_before} -> {len(collections)}")
    if _pr:
        for _ in range(4):
            _mv, _sv = _repos()
            print(f"  repositioned {_mv} joints for their new members, "
                  f"-{_sv:,.0f} m of drop cable")
            if _mv == 0: break

# ---- POST-PASS 0b: SPACE THE JOINTS ALONG THE LANE (F-57, 2026-09-07) ------------------
# Operator, 2026-09-04: "you were forced to place three poles close to each other, and the
# drop cables just look all messy."
#
# F-55 fixed the joint COUNT (420 against the accepted plan's 414). SPACING is the same
# defect untouched: 6.4% of our joints have another within 15 m against their 1.0%. The
# cause is `_repos` directly above -- it slides every joint to the position minimising ITS
# members' drop cable, adjacent joints share members, so their optima converge and they
# drift together. Nothing ever pushed them apart.
#
# The consequence is not cosmetic. Measured on Malmesbury wave 9: of 79 row-continuity
# lanes (F-56), 72 were cut by trim_stubs because Step 4 left no joint on them -- median
# lane end 16.1 m from the nearest joint. trim_stubs is RIGHT to cut cable past the last
# joint; the accepted plan's lanes always end at a pole. The lanes have to EARN their
# joints, and that is this pass.
#
# Paid for in drop cable, which we can afford: Malmesbury wave 9 spends 43,951 m against
# the accepted plan's 45,266 m. The budget is exactly that headroom -- operator, 2026-09-07:
# "don't exceed the human's distribution ... we don't want to plan anything that is
# necessarily better than that said example." SPREAD=0 reverts.
SPREAD = os.environ.get("SPREAD", "1") == "1"
SPREAD_SEP_M = float(os.environ.get("SPREAD_SEP_M", "15"))   # F-56's clustering measure
# How far a moving joint keeps pushing. The accepted Malmesbury plan runs 18,234 m of cable
# over 414 joints = 44 m each; ours 17,091 over 420 = 41 m. The MEAN spacing already
# matches -- only the variance is wrong -- so this is the human's own density, not a
# tuned constant. At the old value (= SPREAD_SEP_M) every joint stopped dead at 15 m and
# no joint ever reached a row-continuity lane: measured, lane survival stuck at 7 of 79.
SPREAD_TARGET_M = float(os.environ.get("SPREAD_TARGET_M", "40"))

if SPREAD and len(collections):
    import joint_spread
    # The budget is the FINAL drop-cable headroom to the accepted plan, supplied per site by
    # rollout_full_site.ps1 (measured 2026-09-07, ours vs theirs: Malmesbury 43,951/45,266
    # -> 1,315 m; Botshabelo 102,769/123,652 -> 20,883; Middelburg 102,860/120,737 ->
    # 17,877; Cradock 154,821/158,652 -> 3,831; WUVS 193,649/225,881 -> 32,232).
    #
    # ⚠️ It is NOT derived from the drop total at this point in the pipeline. That was tried
    # and MEASURED WRONG on 2026-09-07: `_pullin` and `_uncross` run AFTER this pass and
    # shorten drops, so the mid-pipeline total sits above the final one and the subtraction
    # produced a budget of 0 -- the pass reported "spread 0 joints ... of a 0 m budget" and
    # the whole fix was silently a no-op. A budget must be measured on the same quantity it
    # bounds.
    _sbudget = float(os.environ.get("SPREAD_BUDGET_M", "inf"))

    _pon_of_cp = cand_pon[collections]
    _cidx, _ocache = {}, {}

    def _spread_options(j):
        """Legal positions for joint j and the drop cable its members pay at each.

        Same compliance rule as _prune/_repos, and scored against the joint's position at
        the START of this pass -- so no member may end up worse than it began, and a clean
        drop can never acquire a road crossing (sec0.7)."""
        if j in _ocache: return _ocache[j]
        p = int(_pon_of_cp[j])
        if p not in _cidx: _cidx[p] = np.flatnonzero(cand_pon == p)
        ci = _cidx[p]
        mem = np.flatnonzero(assigned == j)
        here = np.array([collections[j]])
        if not len(mem) or not len(ci):
            _ocache[j] = (here, np.zeros(1)); return _ocache[j]
        tot = np.zeros(len(ci)); bad = np.zeros(len(ci), bool)
        for i in mem:
            d = np.hypot(*(CAND[ci] - DPS[i]).T)
            oldd = float(np.hypot(*(CAND[collections[j]] - DPS[i])))
            tot += d
            lim = DROP_CAP_M if oldd <= DROP_CAP_M else oldd
            bad |= d > lim
            if BLOCKER is not None:
                r_ = float(lim) + 1.0        # reach must cover `lim` -- see _prune
                if not bool(_blk(i, [collections[j]], r_)[0]):
                    bad |= _blk(i, ci, r_)
        keep = (~bad) | (ci == collections[j])
        _ocache[j] = (ci[keep], tot[keep])
        return _ocache[j]

    _before_cl = np.hypot(*(CAND[collections][:, None, :]
                            - CAND[collections][None, :, :]).transpose(2, 0, 1))
    np.fill_diagonal(_before_cl, np.inf)
    _n_before = int((_before_cl.min(axis=1) < SPREAD_SEP_M).sum())
    collections, _smoved, _sadded = joint_spread.spread_joints(
        collections, CAND, _spread_options, min_sep=SPREAD_SEP_M, budget_m=_sbudget,
        target_sep=SPREAD_TARGET_M)
    _after_cl = np.hypot(*(CAND[collections][:, None, :]
                           - CAND[collections][None, :, :]).transpose(2, 0, 1))
    np.fill_diagonal(_after_cl, np.inf)
    _n_after = int((_after_cl.min(axis=1) < SPREAD_SEP_M).sum())
    print(f"\nspread {_smoved} joints along the cable (F-57 joint spacing): "
          f"clustered within {SPREAD_SEP_M:.0f} m {_n_before} -> {_n_after}, "
          f"+{_sadded:,.0f} m of drop cable"
          + (f" of a {_sbudget:,.0f} m budget" if np.isfinite(_sbudget) else ""))

# ---- POST-PASS 1: UN-STACK COLLECTION POINTS (defect D2, operator 2026-08-29) ----------
# The fan cap is enforced PER collection point, but two CPs can land within a couple of
# metres (typically across a PON boundary) -- physically one pole carrying 14-20 drops.
# Measured on WUVS: 107 pole-position clusters over 8, worst 20, vs the accepted plan's 5.
# Repair: for any pair of CPs within SEP_M whose combined fan exceeds FAN_CAP, slide the
# smaller CP along ITS OWN PON's cable to the nearest candidate >= SEP_M from every other
# CP that keeps all its members' drops feasible (cap tiering + road rule preserved).
SEP_M = float(os.environ.get("CP_SEP_M", "6"))
def _unstack():
    moved = 0
    CPxy = CAND[collections]
    fan_ = np.bincount(assigned[assigned >= 0], minlength=len(collections))
    t = cKDTree(CPxy)
    for k in range(len(collections)):
        js = [j for j in t.query_ball_point(CPxy[k], SEP_M) if j != k]
        if not js: continue
        if fan_[k] + sum(fan_[j] for j in js) <= FAN_CAP: continue
        # move the smallest-fan member of the cluster
        cl = sorted(js + [k], key=lambda j: fan_[j])
        mv = cl[0]
        pon = int(cand_pon[collections[mv]])
        mem = np.flatnonzero(assigned == mv)
        cand_idx = np.flatnonzero(cand_pon == pon)
        if len(cand_idx) == 0 or len(mem) == 0: continue
        best, bd = None, None
        dsum = np.zeros(len(cand_idx))
        ok_all = np.ones(len(cand_idx), bool)
        for i in mem:
            d = np.hypot(*(CAND[cand_idx] - DPS[i]).T)
            dsum += d
            was_over = np.hypot(*(CAND[collections[mv]] - DPS[i])) > DROP_CAP_M
            if not was_over:
                ok_all &= d <= DROP_CAP_M          # never push a compliant drop over cap
            if BLOCKER is not None:
                ok_all &= ~_blk(i, cand_idx)
        dcp = cKDTree(np.delete(CPxy, mv, axis=0)).query(CAND[cand_idx])[0]
        ok_all &= dcp >= SEP_M
        if not ok_all.any():
            # cannot MOVE any joint of this cluster -- REBALANCE instead (F-46 gate
            # measured: stacks are within-PON solver artefacts, not geometric pockets;
            # individual drops can usually reach another joint with a free port even
            # when no whole joint can legally move). Hand members away, farthest-first,
            # until the cluster's combined fan is within the cap.
            excess = fan_[k] + sum(fan_[j] for j in js) - FAN_CAP
            clset = set(cl)
            members = [i for i in np.flatnonzero(np.isin(assigned, cl))]
            members.sort(key=lambda i: -float(np.hypot(*(CPxy[assigned[i]] - DPS[i]))))
            for i in members:
                if excess <= 0: break
                oldd = float(np.hypot(*(CPxy[assigned[i]] - DPS[i])))
                best2 = None
                for j2 in np.flatnonzero(fan_ < FAN_CAP):
                    if j2 in clset: continue
                    d2 = float(np.hypot(*(CPxy[j2] - DPS[i])))
                    if d2 > DROP_CAP_M and oldd <= DROP_CAP_M: continue
                    if d2 > max(DROP_CAP_M, oldd): continue
                    # reach must cover d2, which may exceed the cap here (F-55)
                    if BLOCKER is not None and _blk(i, [collections[j2]],
                                                    max(DROP_CAP_M, d2) + 1.0)[0]: continue
                    if best2 is None or d2 < best2[0]: best2 = (d2, j2)
                if best2 is not None:
                    fan_[assigned[i]] -= 1; fan_[best2[1]] += 1
                    assigned[i] = best2[1]
                    excess -= 1; moved += 1
            continue
        pick = cand_idx[np.flatnonzero(ok_all)[np.argmin(dsum[ok_all])]]
        collections[mv] = pick
        CPxy[mv] = CAND[pick]
        moved += 1
    return moved
_mv = 0
for _it in range(6):          # one sweep cannot untangle 3+-deep stacks; loop to stillness
    _m = _unstack()
    _mv += _m
    if _m == 0: break
print(f"\nun-stacked {_mv} collection points (D2: pole-position fan cap)")
# whatever remains stacked had NO feasible road-legal, cap-legal position -- report it
_CPxy = CAND[collections]
_fan = np.bincount(assigned[assigned >= 0], minlength=len(collections))
_t = cKDTree(_CPxy)
_res = []
_seen = set()
for _k in range(len(collections)):
    if _k in _seen: continue
    _js = _t.query_ball_point(_CPxy[_k], 3.0)
    _seen.update(_js)
    if sum(_fan[_j] for _j in _js) > FAN_CAP:
        _res.append((int(sum(_fan[_j] for _j in _js)), int(cand_pon[collections[_k]])))
if _res:
    print(f"  {len(_res)} stack(s) could not be separated (no road-legal position) -- "
          f"worst {max(_res)[0]} drops, PONs {sorted(set(p for _, p in _res))[:10]}")

# ---- POST-PASS 1b: PULL EACH DROP IN TO ITS NEAREST POLE (operator 2026-09-03) ---------
# Operator, looking at Malmesbury: "the first four houses need to be connected via the first
# pole and then go out. The second four houses beneath that first row ... need to be
# connected to the second pole instead of having two of the drop cables going out to two of
# the top row houses."  Measured (drop_style_census C): a home takes its NEAREST pole in
# 67-74% of our drops vs 74-82% of theirs, and the misses reach 48-50 m -- right up against
# the drop cap -- while a pole sits 6-10 m away.
#
# Cause: `assign()` gives each home the nearest CP WITH A FREE PORT, and the un-stack
# rebalance hands members away the same way. Once a near pole is full the home walks to
# whatever is still open, and nothing afterwards revisits that choice.
#
# Repair, in worst-excess-first order, within a PON: MOVE the drop to a nearer pole that has
# a free port (and whose 3 m pole cluster stays within the fan cap -- never re-create D2), or
# SWAP with a member of that pole when the pair's total length strictly falls. A swap leaves
# every fan unchanged, so it cannot break D2 or the cap; and because it strictly shortens the
# pair it cannot introduce a crossing between the two (that is the same argument the uncross
# pass rests on). Both keep the road rule: a road-legal drop may not start crossing a road.
PULLIN_MIN = float(os.environ.get("PULLIN_MIN_M", "5"))


def _pullin():
    CPxy = CAND[collections]
    moved = swaps = 0
    for _round in range(4):
        changed = 0
        fan_ = np.bincount(assigned[assigned >= 0], minlength=len(collections))
        t = cKDTree(CPxy)
        # fan of the whole 3 m pole cluster a CP belongs to (D2's unit, not the CP's own fan)
        clus = [t.query_ball_point(CPxy[c], 3.0) for c in range(len(collections))]
        idxs = np.flatnonzero(assigned >= 0)
        cur = np.hypot(*(CPxy[assigned[idxs]] - DPS[idxs]).T)
        for pos in np.argsort(-cur):
            i = int(idxs[pos])
            ci = int(assigned[i])
            oi = float(np.hypot(*(CPxy[ci] - DPS[i])))
            if oi <= PULLIN_MIN: continue
            near = t.query_ball_point(DPS[i], oi - PULLIN_MIN)
            near.sort(key=lambda c: float(np.hypot(*(CPxy[c] - DPS[i]))))
            for cj in near:
                if cj == ci: continue
                if cand_pon[collections[cj]] != cand_pon[collections[ci]]: continue
                ni = float(np.hypot(*(CPxy[cj] - DPS[i])))
                if ni >= oi - PULLIN_MIN: continue
                _r = max(DROP_CAP_M, ni, oi) + 1.0    # reach must cover the pair (F-55)
                if BLOCKER is not None and _blk(i, [collections[cj]], _r)[0] \
                        and not _blk(i, [collections[ci]], _r)[0]:
                    continue
                # (a) free port, and the target's pole cluster stays within the cap
                if fan_[cj] < FAN_CAP and sum(fan_[c] for c in clus[cj]) < FAN_CAP:
                    assigned[i] = cj; fan_[ci] -= 1; fan_[cj] += 1
                    moved += 1; changed += 1; break
                # (b) swap with a member of that pole, if the pair strictly shortens
                best = None
                for j in np.flatnonzero(assigned == cj):
                    j = int(j)
                    oj = float(np.hypot(*(CPxy[cj] - DPS[j])))
                    nj = float(np.hypot(*(CPxy[ci] - DPS[j])))
                    if oj <= DROP_CAP_M and nj > DROP_CAP_M: continue
                    if ni + nj >= oi + oj - 0.5: continue
                    if BLOCKER is not None and _blk(j, [collections[ci]])[0] \
                            and not _blk(j, [collections[cj]])[0]:
                        continue
                    if best is None or ni + nj < best[0]: best = (ni + nj, j)
                if best is not None:
                    j = best[1]
                    assigned[i], assigned[j] = cj, ci
                    swaps += 1; changed += 1; break
        if changed == 0: break
    return moved, swaps


_pm, _ps = _pullin()
print(f"pulled in {_pm} drops to a nearer pole, {_ps} swapped (nearest-pole rule)")

# ---- POST-PASS 2: UNCROSS DROPS (defect D1) --------------------------------------------
# Two drops that cross can swap collection points; in the plane the swap strictly shortens
# both. Swap only within a PON, only when both new drops keep cap-compliance (an over-cap
# drop may stay over-cap but must not get longer past a compliant one) and the road rule.
# Measured on WUVS pre-fix: 246 crossing pairs vs the accepted plan's 52.
def _uncross():
    CPxy = CAND[collections]
    swaps = 0
    for _round in range(3):
        changed = 0
        P1 = DPS[assigned >= 0]; idxs = np.flatnonzero(assigned >= 0)
        mids = (DPS[idxs] + CPxy[assigned[idxs]]) / 2
        half = np.linalg.norm(DPS[idxs] - CPxy[assigned[idxs]], axis=1) / 2
        t = cKDTree(mids)
        hmax = half.max() if len(half) else 0
        for a_ in range(len(idxs)):
            i = idxs[a_]
            for b_ in t.query_ball_point(mids[a_], half[a_] + hmax + 0.1):
                if b_ <= a_: continue
                j = idxs[b_]
                ci, cj = assigned[i], assigned[j]
                if ci == cj: continue
                if cand_pon[collections[ci]] != cand_pon[collections[cj]]: continue
                p, q = DPS[i], CPxy[ci]; a2, b2 = DPS[j], CPxy[cj]
                qp = q - p; ba = b2 - a2      # explicit 2-D cross products (np.cross deprecated for 2-vectors)
                d1 = qp[0] * (a2 - p)[1] - qp[1] * (a2 - p)[0]
                d2 = qp[0] * (b2 - p)[1] - qp[1] * (b2 - p)[0]
                d3 = ba[0] * (p - a2)[1] - ba[1] * (p - a2)[0]
                d4 = ba[0] * (q - a2)[1] - ba[1] * (q - a2)[0]
                if not (d1 * d2 < 0 and d3 * d4 < 0): continue
                ni = float(np.hypot(*(CPxy[cj] - DPS[i])))
                nj = float(np.hypot(*(CPxy[ci] - DPS[j])))
                oi = float(np.hypot(*(CPxy[ci] - DPS[i])))
                oj = float(np.hypot(*(CPxy[cj] - DPS[j])))
                if (oi <= DROP_CAP_M and ni > DROP_CAP_M) or \
                   (oj <= DROP_CAP_M and nj > DROP_CAP_M): continue
                if BLOCKER is not None:
                    # like the cap rule above: a drop that ALREADY crosses a road may keep
                    # crossing after the swap (sec0.7 keeps it flagged), but a road-legal
                    # drop must not start crossing one.
                    # Reach must cover the pair being tested -- blocked_from reports "not
                    # blocked" past its reach, so the default (the cap) skips the test on
                    # over-cap drops entirely (F-55 addendum).
                    r_ = max(DROP_CAP_M, ni, nj, oi, oj) + 1.0
                    bi_new = _blk(i, [collections[cj]], r_)[0]
                    bj_new = _blk(j, [collections[ci]], r_)[0]
                    if bi_new or bj_new:
                        bi_old = _blk(i, [collections[ci]], r_)[0]
                        bj_old = _blk(j, [collections[cj]], r_)[0]
                        if (bi_new and not bi_old) or (bj_new and not bj_old):
                            continue
                assigned[i], assigned[j] = cj, ci
                changed += 1
        swaps += changed
        if changed == 0: break
    return swaps
_sw = _uncross()
print(f"uncrossed {_sw} drop pairs (D1)")

print(f"\nPONs where Lloyd beat the greedy baseline: {improved}/{len(PONS)}")
if escalate:
    print(f"PONs still over the {PON_CAP} ceiling -> ESCALATE (C1):")
    for pi, n, k in escalate: print(f"  PON {PON_LABEL[pi]}: {n} homes needs {k} collection points")
else:
    print(f"PONs over the {PON_CAP} ceiling: 0")

# ---- FINAL REPAIR: NO DROP MAY CROSS A ROAD ------------------------------------------
# Operator, 2026-09-09, on seeing drops strung over streets: "we don't do that at all ...
# there's supposed to be a pull-over there and a 1-to-8 splitter on the other side of the
# road to account for any demand points that are there."
#
# Making the cover strict took crossings 189 -> 62, and ranking a crossing below a long drop
# took 62 -> 54. Both helped and neither finished the job, because a dozen passes downstream
# of the cover (leftovers, un-stacking, joint spread, the D1 uncross) each move collection
# points for their own reasons and can re-introduce a crossing. Chasing them one at a time is
# how the last three attempts went; this instead enforces the rule at the END, on the final
# assignment, where it is simply true or not.
#
# For each home whose drop crosses a road: re-attach it to a collection point on ITS OWN side
# with a free port, and if none exists, OPEN ONE -- which is precisely the 1:8 on the other
# side of the road that the operator describes. Anything that still cannot be fixed is
# reported, never left silent.
def _fix_road_crossings():
    global collections, assigned
    if BLOCKER is None:
        return 0, 0
    fixed = opened = 0
    for _ in range(3):                      # a repair can itself fill a port; iterate
        CPx = CAND[collections]
        fan_n = np.bincount(assigned[assigned >= 0], minlength=len(collections))
        bad = [i for i in range(len(DPS))
               if assigned[i] >= 0
               and bool(_blk(i, [collections[assigned[i]]], REACH_BLK_M)[0])]
        print(f"   [repair] pass {_+1}: {len(bad)} crossing drop(s) found")
        if not bad:
            break
        for i in bad:
            pi = dp_pon[i]
            # candidates on this home's own side of the road, within the cap
            near = np.flatnonzero(np.hypot(*(CPx - DPS[i]).T) <= DROP_CAP_M)
            near = [j for j in near if fan_n[j] < FAN_CAP
                    and not bool(_blk(i, [collections[j]], REACH_BLK_M)[0])]
            if near:
                j = min(near, key=lambda j: float(np.hypot(*(CPx[j] - DPS[i]))))
                fan_n[assigned[i]] -= 1; assigned[i] = j; fan_n[j] += 1
                fixed += 1
                continue
            # no existing joint on this side -- open one (the operator's "pull-over")
            ci = np.flatnonzero(cand_pon == pi) if pi >= 0 else np.arange(len(CAND))
            if len(ci) == 0:
                continue
            d = np.hypot(*(CAND[ci] - DPS[i]).T)
            blk = _blk(i, ci, REACH_BLK_M)
            free = np.flatnonzero((d <= DROP_CAP_M) & ~blk)
            if len(free) == 0:
                continue
            m = int(ci[free[int(np.argmin(d[free]))]])
            collections = np.append(collections, m)
            fan_n = np.append(fan_n, 0)
            CPx = CAND[collections]
            fan_n[assigned[i]] -= 1; assigned[i] = len(collections) - 1; fan_n[-1] = 1
            opened += 1; fixed += 1
    return fixed, opened


_fx, _op = _fix_road_crossings()
_chk = sum(1 for i in range(len(DPS)) if assigned[i] >= 0
           and BLOCKER.blocked_from(DPS[i], CAND[collections[assigned[i]]][None, :],
                                    REACH_BLK_M)[0]) if BLOCKER is not None else 0
print(f"   [repair] crossings immediately after repair: {_chk}")
if _fx or _op:
    print(f"road-crossing repair: {_fx} drop(s) re-attached to their own side of the road, "
          f"{_op} new collection point(s) opened to do it (the operator's 'pull-over')")

CP = CAND[collections]
drop_len = np.array([float(np.hypot(*(CP[assigned[i]] - DPS[i]))) if assigned[i] >= 0
                     else np.nan for i in range(len(DPS))])
fan = np.bincount(assigned[assigned >= 0], minlength=len(collections))
ok = ~np.isnan(drop_len); q = lambda p: float(np.percentile(drop_len[ok], p))

print(f"\n--- Step 4 result ---")
print(f"COVERAGE               {ok.sum():>6} / {len(dp_pon[dp_pon>=0]):<6} properties in the PONs"
      f"   ({100*ok.sum()/max(1,(dp_pon>=0).sum()):.2f}%)")
print(f"  drops OVER the {DROP_CAP_M:.0f} m cap {int((drop_len[ok] > DROP_CAP_M).sum()):>5}"
      f"   <- flagged for operator acceptance, not failures")
print(f"collection points      {len(collections):>6}{ref('collection_points')}")
print(f"drops placed           {ok.sum():>6}{ref('drops_placed')}")
print(f"unserved demand points {(~ok).sum()-out_of_scope:>6}   (+{out_of_scope} out of PON scope)")
print(f"drop length  median {q(50):.1f} m   p90 {q(90):.1f} m   max {drop_len[ok].max():.1f} m"
      f"{ref('drop_median_m')}")
# NOT "must be 0" -- that was the old inverted objective, and it contradicted the COVERAGE
# line six rows above which already reports the same number as flagged, not failed (sec0).
print(f"drops over {DROP_CAP_M:.0f} m       {(drop_len[ok] > DROP_CAP_M).sum():>6}   "
      f"(flagged, all served{ref('over_cap_drops', '; reference has ', '')})")
print(f"fans over cap of {FAN_CAP}     {(fan > FAN_CAP).sum():>6}   (must be 0)")
if BLOCKER is not None:
    _rc = sum(1 for i in range(len(DPS)) if assigned[i] >= 0
              and BLOCKER.blocked_from(DPS[i], CP[assigned[i]][None, :], REACH_BLK_M)[0])
    print(f"drops CROSSING a road  {_rc:>6}   <- flagged for operator acceptance "
          f"(sec0.7 two-tier; the accepted Botshabelo plan carries 231)")
print(f"mean drops per collection point {fan.mean():.2f}{ref('mean_fan')}")
print("fan sizes: " + "  ".join(f"{v}:{int((fan==v).sum())}" for v in range(1, FAN_CAP+1)
                                if (fan == v).any()))

# ---- OVER-CAP DROP REVIEW (PLANNING-LEARNINGS sec0.5) --------------------------------
# Every one of these IS served. This list exists so the operator can spot the handful that
# are a sports field or a hall rather than a home, delete those demand points, and re-run.
review = []
_over_i = [i for i in range(len(DPS)) if ok[i] and drop_len[i] > DROP_CAP_M]
if _over_i:
    _nn = cKDTree(DPS).query(DPS, k=2)[0][:, 1]     # distance to the nearest OTHER home
    _med_nn = float(np.median(_nn))
    _iso_m = REVIEW_ISO_MULT * _med_nn
    ERVEN = load(LYR("erven")) if have("erven") else []
    _ec = cKDTree(np.array([[P(g).GetX(), P(g).GetY()] for g in ERVEN])) if ERVEN else None

    def _erf_area(xy):
        """area of the erf this demand point sits in; nearest centroid if none contains it"""
        if _ec is None: return None
        pt = ogr.Geometry(ogr.wkbPoint); pt.AddPoint_2D(float(xy[0]), float(xy[1]))
        for j in _ec.query(xy, k=min(10, len(ERVEN)))[1].ravel():
            if ERVEN[int(j)].Contains(pt): return float(ERVEN[int(j)].GetArea())
        return float(ERVEN[int(_ec.query(xy)[1])].GetArea())

    for i in _over_i:
        a = _erf_area(DPS[i]); iso = float(_nn[i])
        big = a is not None and a > REVIEW_ERF_M2
        far = iso > _iso_m
        note = ("likely NOT a dwelling -- large parcel AND isolated" if big and far else
                "large parcel -- check for a structure (R2.4)" if big else
                "isolated from the other demand points -- check" if far else
                "genuine long drop -- a real home the geometry cannot reach in 50 m")
        review.append({"dp": int(i), "pon": PON_LABEL[dp_pon[i]] if dp_pon[i] >= 0 else -1,
                       "x": float(DPS[i][0]), "y": float(DPS[i][1]),
                       "drop_m": round(float(drop_len[i]), 1),
                       "erf_area_m2": None if a is None else round(a, 0),
                       "isolation_m": round(iso, 1), "note": note})
    review.sort(key=lambda r: -r["drop_m"])
    _susp = [r for r in review if r["note"].startswith("likely NOT")]
    print(f"\n--- OVER-CAP DROP REVIEW --- {len(review)} drop(s) over {DROP_CAP_M:.0f} m, "
          f"ALL SERVED (no upper bound, sec0.5)")
    print(f"    isolation threshold {_iso_m:,.0f} m = {REVIEW_ISO_MULT:g} x this site's "
          f"median home spacing ({_med_nn:.1f} m);  large parcel > {REVIEW_ERF_M2:,.0f} m2")
    print(f"    {'PON':>4} {'drop m':>8} {'erf m2':>10} {'isolation m':>12}   note")
    for r in review[:25]:
        print(f"    {r['pon']:>4} {r['drop_m']:>8.1f} "
              f"{'-' if r['erf_area_m2'] is None else format(r['erf_area_m2'], ',.0f'):>10} "
              f"{r['isolation_m']:>12.1f}   {r['note']}")
    if len(review) > 25: print(f"    ... {len(review)-25} more in claude_drop_review")
    print(f"    {len(_susp)} of {len(review)} look like NON-DWELLINGS -> operator to delete "
          f"the demand point and re-run, per sec0.5. We do NOT delete them.")

# Scoring against a human plan is possible only where one exists. Everything below this
# block is a COMPARISON, so it is skipped on a virgin site; the outputs are written either
# way, further down.
if have("ref_drops"):
    gt_drops = lines(load(LYR("ref_drops")))
    gt_len = sum(float(np.hypot(*(c[1:]-c[:-1]).T).sum()) for c in gt_drops)
    print(f"\ntotal drop cable   ours {drop_len[ok].sum():,.0f} m   reference {gt_len:,.0f} m"
          f"   ({100*(drop_len[ok].sum()-gt_len)/gt_len:+.1f}%)")
    ends = np.array([c[-1] for c in gt_drops] + [c[0] for c in gt_drops])
    dd, _ = cKDTree(DPS).query(ends)
    cp_gt = ends[dd > 1.0]
    uniq = []
    for p in cp_gt:
        if not uniq or min(np.hypot(*(np.array(uniq)-p).T)) > 2.0: uniq.append(p)
    uniq = np.array(uniq)
    d2, _ = cKDTree(uniq).query(CP)
    print(f"our collection point -> nearest reference ({len(uniq)} recovered): "
          f"median {np.median(d2):.1f} m, p90 {np.percentile(d2,90):.1f} m")
else:
    print(f"\ntotal drop cable   ours {drop_len[ok].sum():,.0f} m   (no reference plan for this site)")
cnt = np.array([int(sum(1 for c in collections if cand_pon[c] == pi)) for pi in range(len(PONS))])
# `escalate` is filled inside the per-PON solve, BEFORE the post-passes, so it describes the
# solver's plan and not the one we ship (F-55: the prune removes joints it never saw). The
# shipped breach count is recomputed here, from the FINAL collections.
pons_over = [PON_LABEL[pi] for pi in range(len(PONS)) if cnt[pi] > PON_CAP]   # PON numbers, not positions
print(f"collection points per PON: median {np.median(cnt[cnt>0]):.0f}, max {cnt.max()} "
      f"(target {SPLITTER_TARGET}, hardware ceiling {PON_CAP})")
# HOW FULL IS EACH 1:8? The operator wants 8 drops on every splitter "as far as you can",
# and treats 7/4/3/2 as what you fall back to when there is no other choice -- so the shape
# of this distribution is the thing they are asking about, not the average.
_f = fan[fan > 0]
print(f"drops per 1:8 splitter: median {np.median(_f):.0f}  mean {_f.mean():.2f}  "
      f"(capacity {FAN_CAP})")
_hist = np.bincount(_f, minlength=FAN_CAP + 1)[1:FAN_CAP + 1]
print("   fill  " + "  ".join(f"{k}:{v}" for k, v in enumerate(_hist, 1)))
print(f"   FULL ({FAN_CAP} drops): {_hist[-1]:,} of {len(_f):,} splitters "
      f"({100 * _hist[-1] / len(_f):.0f}%)   under-filled: {len(_f) - _hist[-1]:,}")
if ROAD_TIER_STATS:
    _nc = sum(e[1] for e in ROAD_TIER_STATS)
    _saved = sum((e[2] or 99) - e[3] for e in ROAD_TIER_STATS)
    print(f"sec0.7 second tier: {len(ROAD_TIER_STATS)} PON(s) needed a road-crossing drop to "
          f"stay under the {PON_CAP}-joint ceiling")
    print(f"   {_nc} drops cross a road = {100*_nc/len(DPS):.1f}% of all drops "
          f"(the operator's own plans: 4.2-6.7%); saved {_saved} collection point(s)")
print(f"PONs over the {PON_CAP}-joint ceiling: {len(pons_over)} "
      f"(at solve time {len(escalate)}) {pons_over[:12]}")

TAG = os.environ.get("OUTTAG", "")
dst = os.path.join(OUT, f"claude_step4{TAG}.gpkg")
if os.path.exists(dst): ogr.GetDriverByName("GPKG").DeleteDataSource(dst)
ds = ogr.GetDriverByName("GPKG").CreateDataSource(dst)
lyr = ds.CreateLayer("claude_collection_points", wgs, ogr.wkbPoint)
for n_, t_ in (("cp_id", ogr.OFTInteger), ("n_drops", ogr.OFTInteger), ("pon", ogr.OFTInteger)):
    lyr.CreateField(ogr.FieldDefn(n_, t_))
for k, p in enumerate(CP):
    g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(float(p[0]), float(p[1])); g.Transform(rev)
    f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
    f.SetField("cp_id", k); f.SetField("n_drops", int(fan[k]))
    _pi = int(cand_pon[collections[k]])
    f.SetField("pon", PON_LABEL[_pi] if _pi >= 0 else -1); lyr.CreateFeature(f); f = None
lyr = ds.CreateLayer("claude_drops", wgs, ogr.wkbLineString)
# `crosses_road` is written so the operator can select these in QGIS rather than hunt for
# them. Each one is a home the wayleave leaves no pole for on its own side of the street.
for n_, t_ in (("cp_id", ogr.OFTInteger), ("length_m", ogr.OFTReal),
               ("crosses_road", ogr.OFTInteger)):
    lyr.CreateField(ogr.FieldDefn(n_, t_))
for i in range(len(DPS)):
    if assigned[i] < 0: continue
    g = ogr.Geometry(ogr.wkbLineString)
    g.AddPoint_2D(float(DPS[i][0]), float(DPS[i][1]))
    g.AddPoint_2D(float(CP[assigned[i]][0]), float(CP[assigned[i]][1])); g.Transform(rev)
    f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
    f.SetField("cp_id", int(assigned[i])); f.SetField("length_m", round(drop_len[i], 2))
    f.SetField("crosses_road", int(bool(BLOCKER is not None and _blk(i, [collections[assigned[i]]], REACH_BLK_M)[0])))
    lyr.CreateFeature(f); f = None
# The over-cap drops as a POINT layer the operator can load, sort by drop_m, and delete from.
# Points, not the drop lines, because what they are ruling on is the DEMAND POINT: is there a
# house here at all? (sec0.5)
lyr = ds.CreateLayer("claude_drop_review", wgs, ogr.wkbPoint)
for n_, t_ in (("pon", ogr.OFTInteger), ("drop_m", ogr.OFTReal),
               ("erf_area_m2", ogr.OFTReal), ("isolation_m", ogr.OFTReal),
               ("note", ogr.OFTString)):
    lyr.CreateField(ogr.FieldDefn(n_, t_))
for r in review:
    g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(r["x"], r["y"]); g.Transform(rev)
    f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
    f.SetField("pon", r["pon"]); f.SetField("drop_m", r["drop_m"])
    if r["erf_area_m2"] is not None: f.SetField("erf_area_m2", r["erf_area_m2"])
    f.SetField("isolation_m", r["isolation_m"]); f.SetField("note", r["note"])
    lyr.CreateFeature(f); f = None
ds = None
print(f"\nwrote {dst}")
json.dump({"collection_points": int(len(collections)), "drops": int(ok.sum()),
           "unserved": int((~ok).sum()), "drop_median_m": round(q(50), 2),
           "drop_p90_m": round(q(90), 2), "drop_max_m": round(float(drop_len[ok].max()), 2),
           "total_drop_m": round(float(drop_len[ok].sum())),
           # only exists where a human plan does -- gt_len is set inside the guarded
           # comparison block above, so it is absent on a virgin site (F-34 follow-up)
           "reference_total_drop_m": (round(gt_len) if "gt_len" in dir() else None),
           "over_cap_drops": int((drop_len[ok] > DROP_CAP_M).sum()),
           # served, flagged, and classified -- sec0.5. `suspect_non_dwelling` is a
           # RECOMMENDATION to the operator, never an action taken by the pipeline.
           "drop_review": review,
           "suspect_non_dwelling": sum(1 for r in review
                                       if r["note"].startswith("likely NOT")),
           "over_cap_fans": int((fan > FAN_CAP).sum()),
           # the SHIPPED plan's breaches (post-pass), not the solver's -- F-55
           "pons_over_ceiling": pons_over,
           "pons_over_ceiling_at_solve": [e[0] for e in escalate],
           "mean_fan": round(float(fan.mean()), 2)},
          open(os.path.join(OUT, "step4_metrics.json"), "w"), indent=2)
