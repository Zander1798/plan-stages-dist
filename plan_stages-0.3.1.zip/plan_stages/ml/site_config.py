"""Which site are we planning, where is its data, and is there a reference plan to compare to?

THE DEFECT THIS FIXES (found 2026-08-21, same audit that produced F-33). The pipeline could
not run on a new site at all, for three separate reasons, none of which one site could ever
reveal:

  1. **The data directory was hardcoded** to the Malmesbury shapefile folder in all four
     pipeline scripts.
  2. **Reference-only layers were loaded unconditionally.** Steps 4 and 7/5/6 read the human's
     `drops`, `Trenching` and `Distribution Cable` to score against. On a virgin site those do
     not exist and the run would crash — while *scoring against a reference* is exactly the
     thing a virgin site cannot do.
  3. **Reference numbers were printed as literals** — "(reference 113)", "(reference 798)".
     On another town those are not merely unavailable, they are WRONG, and they would sit in
     the output looking authoritative.

Item 2 is the interesting one. It encodes an assumption that a reference plan always exists,
which is true of every run this project has ever done and false of every run that matters.

    from site_config import SITE, SITE_DIR, have, ref

    erven = shp(L("erven"))                  # required input -> just load it
    if have("ref_drops"):                    # reference -> guard it
        ...compare...
    print(f"total poles {n}{ref('poles')}")  # prints "   (reference 798)" or nothing at all

Set `SITE=<name>` and `SITE_DIR=<path>` for a new site. Layer names are overrideable
individually via `LAYER_<KEY>` in case a client names them differently.
"""
import os

SITE = os.environ.get("SITE", "malmesbury")

_DEFAULT_DIR = (r"C:/Users/zande/Downloads/Malmsbury Herotel V2 sandbox Backup 2026-07-17 (2)"
                r"/Malmsbury Herotel V2 sandbox Backup 2026-07-17/Shapefiles")
SITE_DIR = os.environ.get("SITE_DIR", _DEFAULT_DIR)

# key -> shapefile basename. REQUIRED keys are the WAYLEAVE Step 0 (operator, 2026-09-09).
# REFERENCE keys exist only where a human has already planned the site.
#
# WHAT CHANGED, 2026-09-09. Until this date Step 0 handed us `Pons` AND `Feeder Joints` AND
# `feeder` -- the PON division and the 1:16 root of every tree. That is the skeleton, and
# F-61/sec0.24 established that being given it meant no plan we shipped demonstrated planning
# an open site. The wayleave replaces it: the operator supplies the SPAN (the route the fibre
# will follow), the POLES, the POP, the PONs, the demand points, the AOI and the roads --
# and the feeder and the 1:16 splitters become OUR OUTPUTS, not our inputs.
#
# Consequences encoded here:
#   * `span`, `pop`, `road` are new and REQUIRED -- the span is the routing graph now.
#   * `erven` is DEMOTED to optional. It was the routing graph; the span replaces it, which
#     also dissolves F-60 (a third of Ventersdorp has demand points but no cadastre).
#   * `feeder_joints` and `feeder` are NO LONGER INPUTS AT ALL. They stay in the table as
#     REFERENCE keys, because the five previously-planned sites ship them and they are the
#     answer key for grading the feeder/1:16 we now generate (sec0.24's standing rule).
_LAYERS = {
    # --- wayleave Step 0: required ---
    "span":          "Span",          # the route the operator has already chosen
    "pons":          "Pons",
    "demand_points": "Demand points",
    "pop":           "POP",
    "road":          "road",
    # --- wayleave Step 0: supplied where it exists, never required ---
    "poles":         "poles",         # operator's own pole placement, for reconciliation
    "erven":         "Erven",
    "aoi":           "AOI",
    # --- reference-only: a human plan to grade against, never an input ---
    "ref_feeder":        "feeder",           # was an INPUT before 2026-09-09; now the answer key
    "ref_feeder_joints": "Feeder Joints",    # ditto -- the operator's own 1:16 positions
    "ref_cable":         "Distribution Cable",
    "ref_drops":         "drops",
    "ref_dome_joints":   "Dome Joints",
    "ref_trenching":     "Trenching",
    "ref_poles":         "poles",
}
REQUIRED = ("span", "pons", "demand_points", "pop", "road")
OPTIONAL = ("poles", "erven", "aoi")
IS_REFERENCE = tuple(k for k in _LAYERS if k.startswith("ref_"))


def L(key):
    """layer basename, overrideable with LAYER_<KEY>"""
    return os.environ.get("LAYER_" + key.upper(), _LAYERS[key])


def path(key):
    return f"{SITE_DIR}/{L(key)}.shp"


def have(key):
    """does this layer actually exist for this site?"""
    return os.path.exists(path(key))


def missing_required():
    return [k for k in REQUIRED if not have(k)]


# Reference metrics, for the "(reference N)" annotations. Only defined for sites where a human
# plan exists. Absent -> ref() returns "" and the annotations simply do not appear, rather
# than printing another town's numbers as if they were this one's.
_REF = {
    "malmesbury": {
        "distribution_m": 18141.0, "drops_m": 45266.0, "total_m": 63407.0,
        "collection_points": 415, "drops_placed": "2,848",
        "drop_median_m": "15.2 / 25.9 / 84.0", "mean_fan": "6.86",
        "crossings": 113, "drill": 106, "trench": "7, incl. backhaul",
        "poles": 798, "poles_collection": 415, "poles_crossing": 197,
        "poles_span": "195; count is emergent, not a target",
        "span_stats": "22.8 / 42.7 / 70.0", "poles_on_erf": "99%",
        "splitters": 414, "dome_joints": 413,
        "mph_stats": "median 6.7, min 4.3, max 10.1",
        "crossing_stats": "drill median 10.1, max 24.0",
        "over_cap_drops": 10,
    },
}
REF = _REF.get(SITE, {})
HAS_REFERENCE = bool(REF)


def ref(key, prefix="   (reference ", suffix=")"):
    """annotation string, or empty when this site has no human plan to compare against"""
    v = REF.get(key)
    if v is None: return ""
    return f"{prefix}{v}{suffix}"


def banner():
    lines = [f"SITE={SITE}   dir={SITE_DIR}"]
    opt = [k for k in OPTIONAL if have(k)]
    lines.append("wayleave optional layers present: " + (", ".join(opt) if opt else "none"))
    miss = missing_required()
    if miss:
        lines.append("*** MISSING REQUIRED WAYLEAVE LAYERS: "
                     + ", ".join(f"{k} ({L(k)}.shp)" for k in miss) + " ***")
        lines.append("*** These are Step 0 blocking inputs. Override a name with "
                     "LAYER_<KEY>, e.g. LAYER_PONS='PON Zones HT2'. ***")
    if not HAS_REFERENCE:
        lines.append("no reference plan for this site: scoring against a human plan is skipped")
    return "\n".join(lines)


def work_dir(sub: str) -> str:
    """`PLAN_DIR/<sub>` when PLAN_DIR is set, else the shared scratch `work/<sub>`."""
    root = os.environ.get("PLAN_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), "work")
    d = os.path.join(root, sub)
    os.makedirs(d, exist_ok=True)
    return d
