"""The operator's wayleave SPAN, noded into a routing graph.

WHY THIS MODULE EXISTS. Under the wayleave Step 0 (operator, 2026-09-09) the route is no
longer ours to choose: the operator hands over `Span.shp`, the line the fibre will actually
follow, and planning becomes deciding which of that span is FEEDER and which is
DISTRIBUTION, then hanging the hardware on it. Every step downstream therefore reads the
same graph, and it has to be the right one.

THE DEFECT THIS FIXES, made and corrected on 2026-09-09. Asked whether the Ventersdorp span
was connected, the first attempt built the graph by snapping span VERTICES together and
reported "98 disconnected islands; the POP reaches 6 of 82 PONs". The operator said that
could not be right -- they could see the span running through every PON -- and they were
correct. Span lines meet MID-SEGMENT: T-junctions and crossings where neither line carries a
vertex at the meeting point. Vertex-snapping cannot see those. Noded properly, the same file
is ONE component, 86,075 m, all 82 PONs reachable from the POP.

That was not a rounding error; it was the opposite conclusion about whether the site could be
planned, reported to the operator as a measurement. Hence `test_span_graph.py`, and hence the
two-stage construction below:

  1. DENSIFY every polyline to `seg` metres, so a crossing point always has vertices near it.
  2. STITCH vertices within `stitch` metres into one node, so those near-vertices weld.

`seg` must be comfortably smaller than `stitch` or crossings are still missed -- at seg=5.0,
stitch=1.5 the Ventersdorp span still came apart (6.4% of nodes reachable).

The defaults are measured, on Ventersdorp's 371 features / 86,075 m:

    seg / stitch    nodes     components   PONs reachable   metres lost to slivers
    1.0  / 1.5       86k          1            82 / 82        1,016 m  (1.18%)
    0.5  / 1.0      171k          1            82 / 82          774 m  (0.90%)
    0.5  / 0.75     172k          1            82 / 82          500 m  (0.58%)   <- default
    0.25 / 0.5      344k          1            82 / 82          377 m  (0.44%)

Connectivity is the same at every setting, so "the span is one network" is a property of the
operator's data and not of the tuning. What the tolerance trades is METRES: a stitch welds
two points that are within tolerance, and where two span lines run parallel and close, the
edge between them collapses. Those metres are reported as `dropped_m` rather than quietly
absorbed -- every number this project produces is a length.

Edge weights are computed BEFORE contraction, from the original vertex positions, so noding
never inflates or shrinks the operator's metres. Every number this project reports is a
length, so that property is tested.

Pure stdlib -- no GDAL, no scipy -- so the logic is testable anywhere. `load_span()` is the
only GDAL-touching function and it imports osgeo lazily.

    from span_graph import build, load_span
    g = build(load_span(path, transform), seg=1.0, stitch=1.5)
    dist, par = g.dijkstra([g.nearest(pop_xy)])
"""
import math
import os

SEG_M = float(os.environ.get("SPAN_SEG_M", "0.5"))
STITCH_M = float(os.environ.get("SPAN_STITCH_M", "0.75"))


def densify(pts, seg):
    """Insert vertices so no gap exceeds `seg`, preserving every original vertex.

    Original vertices are kept exactly -- the operator's kinks are where poles stand
    (`pole_type='kink'` in their own pole layer), so they must not be smoothed away."""
    if seg <= 0 or len(pts) < 2:
        return list(pts)
    out = [tuple(pts[0])]
    for a, b in zip(pts, pts[1:]):
        d = math.dist(a, b)
        if d == 0:
            continue
        n = int(d // seg)
        for i in range(1, n + 1):
            t = (i * seg) / d
            if t >= 1.0:
                break
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
        out.append(tuple(b))
    return out


class _DSU:
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[ra] = rb


class Graph:
    """A noded span network. Nodes are ints; `coords` maps node -> (x, y) in site metres."""

    def __init__(self, adj, coords, dropped_m=0.0):
        self.adj = adj
        self.coords = coords
        self.dropped_m = dropped_m      # metres lost to degenerate slivers, reported not hidden
        self._cell, self._index = self._build_index()

    # ---- geometry ------------------------------------------------------------------
    def total_length(self):
        return sum(w for n, nbrs in self.adj.items() for m, w in nbrs if m > n)

    def _build_index(self):
        if not self.coords:
            return 1.0, {}
        xs = [p[0] for p in self.coords.values()]
        ys = [p[1] for p in self.coords.values()]
        span = max(max(xs) - min(xs), max(ys) - min(ys), 1.0)
        cell = max(span / max(math.isqrt(len(self.coords)), 1), 1e-6)
        idx = {}
        for n, (x, y) in self.coords.items():
            idx.setdefault((int(x // cell), int(y // cell)), []).append(n)
        return cell, idx

    def nearest(self, xy):
        """The graph node closest to an arbitrary point (the POP, a demand point, a 1:16)."""
        if not self.coords:
            return None
        cx, cy = int(xy[0] // self._cell), int(xy[1] // self._cell)
        best, bd = None, math.inf
        for r in range(0, 64):
            found = False
            for i in range(cx - r, cx + r + 1):
                for j in range(cy - r, cy + r + 1):
                    if r and max(abs(i - cx), abs(j - cy)) != r:
                        continue        # ring only; the interior was searched already
                    for n in self._index.get((i, j), ()):
                        d = math.dist(self.coords[n], xy)
                        found = True
                        if d < bd:
                            best, bd = n, d
            # one ring past the first hit guarantees correctness (a nearer point can hide
            # in the next ring when the hit sat in a far corner of its cell)
            if found and bd <= r * self._cell:
                return best
        if best is not None:
            return best
        return min(self.coords, key=lambda n: math.dist(self.coords[n], xy))

    # ---- topology ------------------------------------------------------------------
    def components(self):
        """Connected components, largest first. The measurement that was got wrong."""
        seen, out = set(), []
        for s in self.adj:
            if s in seen:
                continue
            comp, stack = set(), [s]
            seen.add(s)
            while stack:
                u = stack.pop()
                comp.add(u)
                for v, _ in self.adj[u]:
                    if v not in seen:
                        seen.add(v)
                        stack.append(v)
            out.append(comp)
        out.sort(key=len, reverse=True)
        return out

    def component_length(self, comp):
        c = set(comp)
        return sum(w for n in c for m, w in self.adj[n] if m > n and m in c)

    # ---- routing -------------------------------------------------------------------
    def dijkstra(self, sources, weight=None):
        """Least-cost tree from `sources`. `weight(u, v, w) -> cost` defaults to metres.

        The feeder needs a ROAD-WEIGHTED tree, not a shortest path (HeroTel: feeder runs
        roadside), so the cost function is a parameter rather than baked in."""
        import heapq
        wf = weight or (lambda u, v, w: w)
        dist = {n: math.inf for n in self.adj}
        par = {}
        h = []
        for s in sources:
            if s in dist:
                dist[s] = 0.0
                heapq.heappush(h, (0.0, s))
        while h:
            d, u = heapq.heappop(h)
            if d > dist[u] + 1e-9:
                continue
            for v, w in self.adj[u]:
                nd = d + wf(u, v, w)
                if nd < dist[v] - 1e-9:
                    dist[v] = nd
                    par[v] = u
                    heapq.heappush(h, (nd, v))
        return dist, par

    def path(self, node, par):
        """The route from the dijkstra source out to `node`, source first."""
        out = [node]
        while node in par:
            node = par[node]
            out.append(node)
        out.reverse()
        return out

    def edge_length(self, u, v):
        for m, w in self.adj[u]:
            if m == v:
                return w
        return math.dist(self.coords[u], self.coords[v])


def build(polylines, seg=None, stitch=None):
    """Node a list of polylines [[(x, y), ...], ...] into a Graph.

    `seg` must be well under `stitch` or mid-segment crossings are missed -- that is the
    F-62 failure. See the module docstring."""
    seg = SEG_M if seg is None else seg
    stitch = STITCH_M if stitch is None else stitch

    pts, edges, owner = [], [], []
    for lid, line in enumerate(polylines):
        d = densify(line, seg)
        base = len(pts)
        pts.extend(d)
        owner.extend((lid, i) for i in range(len(d)))
        for i in range(1, len(d)):
            edges.append((base + i - 1, base + i, math.dist(d[i - 1], d[i])))

    # Points that are NEIGHBOURS ALONG THE SAME LINE are always within `stitch` of each
    # other -- densification guarantees it -- so welding them would collapse every line to
    # a point. (It did: the first version returned a graph with zero edges.) Only weld
    # points that come from different lines, or from parts of one line far enough apart in
    # index to be a genuine self-crossing.
    apart = int(math.ceil(stitch / seg)) + 1 if seg > 0 else 1

    dsu = _DSU(len(pts))
    if stitch > 0 and pts:
        cell = stitch
        buckets = {}
        for i, (x, y) in enumerate(pts):
            buckets.setdefault((int(x // cell), int(y // cell)), []).append(i)
        s2 = stitch * stitch
        for (bx, by), members in buckets.items():
            near = []
            for i in range(bx - 1, bx + 2):
                for j in range(by - 1, by + 2):
                    near.extend(buckets.get((i, j), ()))
            for a in members:
                ax, ay = pts[a]
                la, pa = owner[a]
                for b in near:
                    if b <= a:
                        continue
                    lb, pb = owner[b]
                    if la == lb and abs(pa - pb) <= apart:
                        continue
                    dx, dy = pts[b][0] - ax, pts[b][1] - ay
                    if dx * dx + dy * dy <= s2:
                        dsu.union(a, b)

    # A welded node's position is the MEAN of the points welded into it, not the first
    # point's. Found 2026-09-09 on the feeder corridor (roads + roadside span stitched at
    # 3 m): with rep = first point, a chain through the reps of two parallel lines hops
    # between the lines' original points and the written geometry came out 40% longer than
    # the edge weights said. Averaging puts the node between the lines, where it belongs.
    acc, cnt = {}, {}
    for i, (x, y) in enumerate(pts):
        r = dsu.find(i)
        sx, sy = acc.get(r, (0.0, 0.0))
        acc[r] = (sx + x, sy + y); cnt[r] = cnt.get(r, 0) + 1

    coords, adj, dropped = {}, {}, 0.0
    for a, b, w in edges:
        ra, rb = dsu.find(a), dsu.find(b)
        if ra == rb:
            dropped += w                # a sliver shorter than the stitch tolerance
            continue
        for r in (ra, rb):
            if r not in coords:
                coords[r] = (acc[r][0] / cnt[r], acc[r][1] / cnt[r])
                adj[r] = []
        adj[ra].append((rb, w))
        adj[rb].append((ra, w))
    return Graph(adj, coords, dropped_m=dropped)


def load_span(path, transform=None):
    """Read a line layer into plain polylines, optionally reprojecting.

    Kept separate from `build` so the noding logic stays stdlib-testable."""
    from osgeo import ogr
    ogr.UseExceptions()
    ds = ogr.Open(path)
    if ds is None:
        raise SystemExit(f"cannot open {path}")
    layer = ds.GetLayer(0)
    out = []
    for f in layer:
        g = f.GetGeometryRef()
        if g is None:
            continue
        g = g.Clone()
        if transform is not None:
            g.Transform(transform)
        parts = ([g] if g.GetGeometryType() in (ogr.wkbLineString, ogr.wkbLineString25D)
                 else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())])
        for p in parts:
            pts = [p.GetPoint(i)[:2] for i in range(p.GetPointCount())]
            if len(pts) >= 2:
                out.append(pts)
    return out
