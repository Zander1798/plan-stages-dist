"""Choose collection points for one PON: fewest poles that serve every home.

THE PROBLEM. Each home must reach a collection point within the drop cap; each collection
point is a 1:8 splitter so it serves at most FAN homes; and the PON has one 1:16 feeder dome,
so it may hold at most CEIL collection points. Minimise the count.

WHY THIS EXISTS. Step 4 chose collection points with capacity-constrained Lloyd at a fixed K,
restarted from random seeds. On Ventersdorp that left 43 of 82 PONs above the 16 ceiling.
Diagnosed 2026-09-09 (`work/_probes/ceiling_bind.py`), and the cause was NOT what it looked
like:

    PONs where CAPACITY forces >16 (ceil(homes/8) > 16):            0
    PONs where COVERAGE forces >16 (greedy set cover, no capacity):  8
    PONs our solver actually put over 16:                           43

So ~35 PONs had a feasible 16 that the search never found. Raising the restart budget from 6
to 40 seeds changed nothing (43 -> 43), which is what confirmed it: Lloyd seeds K centres from
the demand points and snaps them to poles, so it explores placements, never *which subset of
poles* to open. That is a set-cover question, and Lloyd is the wrong instrument for it.

WHAT THIS DOES INSTEAD. Two separable halves:

  1. FEASIBILITY IS EXACT, not heuristic. For a FIXED set of poles, "can these serve every
     home within reach, at most FAN each?" is a bipartite b-matching -- solved here as a max
     flow (scipy.sparse.csgraph.maximum_flow). It answers yes/no with certainty and returns
     the assignment. No restart count can make a heuristic feasibility test exact.

  2. THE SEARCH ONLY CHOOSES THE SET. Start from the capacitated greedy cover, then repeatedly
     try to drop one pole and repair by swapping in a replacement, accepting any set that is
     still feasible. Each candidate set is checked by (1), so the descent can never report a
     count it cannot actually deliver.

The count is what the hardware ceiling is about, so the count is what is minimised. Drop
length is the tie-break among sets of equal size, not the objective -- Step 4 polishes
positions afterwards.

    from cp_cover import solve
    cpos, slot = solve(reach, fan=8, rng=...)   # reach[home, pole] bool
"""
import numpy as np


def feasible(reach, poles, fan):
    """Exact: can `poles` serve every home, <= fan each? Returns assignment or None.

    Max flow on  source -> home (1) -> allowed pole (1) -> sink (fan).  Integral capacities
    give an integral max flow, so a saturating flow IS a valid assignment."""
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import maximum_flow

    poles = list(poles)
    nh, np_ = reach.shape[0], len(poles)
    if nh == 0:
        return {}
    if np_ == 0:
        return None
    sub = reach[:, poles]
    if not sub.any(axis=1).all():
        return None                                   # a home reaches none of them
    if nh > np_ * fan:
        return None                                   # not enough capacity, cheap check

    # node ids: 0 = source, 1..nh = homes, nh+1..nh+np_ = poles, last = sink
    src, snk = 0, nh + np_ + 1
    rows, cols, data = [], [], []
    for h in range(nh):
        rows.append(src); cols.append(1 + h); data.append(1)
    hh, pp = np.nonzero(sub)
    for h, p in zip(hh, pp):
        rows.append(1 + int(h)); cols.append(1 + nh + int(p)); data.append(1)
    for p in range(np_):
        rows.append(1 + nh + p); cols.append(snk); data.append(fan)
    g = csr_matrix((np.array(data, dtype=np.int32),
                    (np.array(rows), np.array(cols))), shape=(snk + 1, snk + 1))
    res = maximum_flow(g, src, snk)
    if res.flow_value < nh:
        return None
    F = res.flow.toarray()
    slot = {}
    for h in range(nh):
        r = np.flatnonzero(F[1 + h, 1 + nh: 1 + nh + np_] > 0)
        if len(r) == 0:
            return None
        slot[h] = poles[int(r[0])]
    return slot


def greedy(reach, fan):
    """Capacitated greedy cover: open the pole serving the most unserved homes."""
    nh = reach.shape[0]
    un = set(range(nh))
    chosen = []
    while un:
        u = np.fromiter(un, int)
        cnt = reach[u].sum(axis=0)
        cnt[list(chosen)] = 0
        if cnt.max() == 0:
            break                                     # unreachable remainder
        c = int(cnt.argmax())
        members = u[reach[u, c]][:fan]
        for t in members:
            un.discard(int(t))
        chosen.append(c)
    return chosen


def solve_exact(reach, fan, time_limit=30.0, x_cost=None, y_cost=1000.0, max_open=None,
                full_bonus=0.0, force_open=None):
    """The PROVABLE minimum, by MILP. Returns (poles, {home: pole}) or None if it cannot.

    One PON is small -- ~100 homes over ~40 reachable poles -- so the exact problem is well
    within HiGHS. Formulated as capacitated set cover:

        minimise   sum_p y_p                         (open as few collection points as we can)
        subject to sum_p x_hp = 1     for each home h   (every home is served, exactly once)
                   sum_h x_hp <= fan * y_p  for each p  (a 1:8 serves at most `fan`, and only
                                                         if it is open -- this single row does
                                                         both, so no x_hp <= y_p rows needed)
                   x_hp defined only where reach[h, p]  (drop cap and no road crossed)

    Why exact and not another heuristic: the descent in solve() got Ventersdorp from 43 PONs
    over the ceiling to 37, while the diagnosis said only 8 are genuinely forced. A number
    between those two is indistinguishable from a search that is merely tired. The MILP
    settles which PONs are truly infeasible at 16, and those are a real escalation for the
    operator rather than something to tune away."""
    from scipy.optimize import milp, LinearConstraint, Bounds
    from scipy.sparse import csr_matrix

    nh, npole = reach.shape
    if nh == 0:
        return [], {}
    live = np.flatnonzero(reach.any(axis=0))
    if len(live) == 0 or not reach.any(axis=1).all():
        return None
    sub = reach[:, live]
    hh, pp = np.nonzero(sub)
    nx = len(hh)                                   # assignment variables
    npl = len(live)                                # open-pole variables
    if nx == 0:
        return None
    xcol = {(int(h), int(p)): k for k, (h, p) in enumerate(zip(hh, pp))}

    # OBJECTIVE. Opening a collection point costs `y_cost`; an individual home-to-pole
    # assignment may carry its own cost through `x_cost` (same shape as reach). With
    # y_cost >> any achievable assignment total, this is lexicographic: minimise the COUNT
    # first, then pick the cheapest assignment among the sets of that size.
    #
    # This matters because an unpriced relaxation overshoots. Letting drops cross roads
    # freely once the ceiling forced it took Ventersdorp from 36 PONs over to 12, but drove
    # road crossings to 9.9% against the operator's own 4.2-6.7% and added 14 km of drop
    # cable -- the solver had no reason to prefer the cheaper of two equal-count answers.
    cx = np.zeros(nx)
    if x_cost is not None:
        xc = np.asarray(x_cost, dtype=float)[:, live]
        cx = xc[hh, pp]
    c = np.concatenate([cx, np.full(npl, float(y_cost))])
    # FULL-SPLITTER REWARD. Operator, 2026-09-10: "we need to try to prioritize eight going
    # to a 1:8 splitter". Minimising the COUNT does not do this -- for a fixed number of
    # splitters, 8+8+8+2 and 6+6+7+7 cost exactly the same, and the operator wants the first.
    # So add a binary z_p per splitter, forced to 0 unless that splitter actually carries
    # `fan` drops, and pay a bonus for each one raised. That is the only term in this model
    # that distinguishes a FULL splitter from a merely-open one.
    #   z_p = 1  allowed only if  sum_h x_hp >= fan
    nz = npl if full_bonus > 0 else 0
    if nz:
        c = np.concatenate([c, np.full(nz, -float(full_bonus))])

    rows, cols, data = [], [], []
    # every home served exactly once
    for k, h in enumerate(hh):
        rows.append(int(h)); cols.append(k); data.append(1.0)
    # capacity, linked to the open decision:  sum_h x_hp - fan * y_p <= 0
    for k, p in enumerate(pp):
        rows.append(nh + int(p)); cols.append(k); data.append(1.0)
    for p in range(npl):
        rows.append(nh + p); cols.append(nx + p); data.append(-float(fan))
    nrow = nh + npl
    # OPTIONAL CEILING ROW: sum_p y_p <= max_open. With it, the count stops being the thing
    # to drive to zero and becomes a CONSTRAINT, which frees the objective to minimise drop
    # length instead. That is what the operator's own plans look like -- median 15 collection
    # points against a ceiling of 16, with SHORT drops -- where minimising the count gave us
    # 14 and long radiating fans (visible in work/compare/wayleave_*.png, and the "messy drop
    # cables" the operator has objected to since F-52).
    if max_open is not None:
        for p in range(npl):
            rows.append(nrow); cols.append(nx + p); data.append(1.0)
        nrow += 1
    if nz:
        # fan * z_p - sum_h x_hp <= 0   ->  z_p can only be 1 on a splitter carrying `fan`
        base = nrow
        for k, p in enumerate(pp):
            rows.append(base + int(p)); cols.append(k); data.append(-1.0)
        for p in range(npl):
            rows.append(base + p); cols.append(nx + npl + p); data.append(float(fan))
        nrow += npl
    # ⚠️ THE BOUND VECTORS MUST BE BUILT IN THE SAME ORDER THE ROWS WERE ADDED:
    #   homes (nh) | capacity (npl) | max_open (1) | full-splitter z (npl) | force_open (n)
    # Getting this wrong silently applies one constraint's bounds to another row, which the
    # solver will happily satisfy while producing nonsense.
    lb = np.concatenate([np.ones(nh), np.full(npl, -np.inf)])
    ub = np.concatenate([np.ones(nh), np.zeros(npl)])
    if max_open is not None:
        lb = np.append(lb, -np.inf); ub = np.append(ub, float(max_open))
    if nz:
        lb = np.concatenate([lb, np.full(npl, -np.inf)])
        ub = np.concatenate([ub, np.zeros(npl)])
    # FORCE_OPEN pins a splitter the operator placed by hand: y_p = 1, not the solver's call.
    forced_rows = 0
    if force_open:
        # NB: do not name the loop variable `c` -- that is the objective vector, and
        # shadowing it here silently replaced the whole objective with an integer.
        pos = {int(p): k for k, p in enumerate(live)}
        for _fc in force_open:
            k = pos.get(int(_fc))
            if k is None:
                continue
            rows.append(nrow + forced_rows); cols.append(nx + k); data.append(1.0)
            forced_rows += 1
        if forced_rows:
            lb = np.concatenate([lb, np.ones(forced_rows)])
            ub = np.concatenate([ub, np.ones(forced_rows)])
            nrow += forced_rows
    A = csr_matrix((data, (rows, cols)), shape=(nrow, nx + npl + nz))

    res = milp(c=c, constraints=LinearConstraint(A, lb, ub),
               integrality=np.ones(nx + npl + nz),
               bounds=Bounds(0, 1),
               options={"time_limit": time_limit, "presolve": True})
    # KEEP THE INCUMBENT ON TIMEOUT. HiGHS reports success=False when it hits the time limit
    # even though it usually holds a good feasible solution by then, and discarding that sent
    # the caller back to the weak heuristic: 12 Ventersdorp PONs were reported over the
    # 16-joint ceiling whose true minimum is 10-16. So take any x it returns and VALIDATE it
    # here rather than trusting the status flag -- an unproven-optimal answer that satisfies
    # every constraint is still a correct plan.
    if res.x is None:
        return None
    x = np.round(res.x).astype(int)
    slot = {}
    for (h, p), k in xcol.items():
        if x[k]:
            if h in slot:
                return None                        # a home assigned twice: not a valid plan
            slot[h] = int(live[p])
    if len(slot) != nh:
        return None
    load = {}
    for h, p in slot.items():
        if not reach[h, p]:
            return None                            # out of reach
        load[p] = load.get(p, 0) + 1
        if load[p] > fan:
            return None                            # over a 1:8's capacity
    return sorted(set(slot.values())), slot


def solve(reach, fan, ceil=None, rng=None, tries=60):
    """Fewest poles serving every home. Returns (poles, {home: pole}) or (None, None).

    `reach` is a boolean home x pole matrix. `ceil` only shapes effort: the descent keeps
    going below it, but a set at or under the ceiling is worth more search."""
    rng = rng or np.random.default_rng(0)
    nh, npole = reach.shape
    if nh == 0:
        return [], {}
    live = np.flatnonzero(reach.any(axis=0))          # poles that reach anything
    if len(live) == 0:
        return None, None

    cur = greedy(reach, fan)
    slot = feasible(reach, cur, fan)
    if slot is None:
        # greedy's own packing was not flow-feasible; fall back to its cover, unpacked
        cur = greedy(reach, nh)
        slot = feasible(reach, cur, fan)
        if slot is None:
            return None, None
    best = (list(cur), dict(slot))

    stall = 0
    while len(cur) > 1 and stall < tries:
        # try to drop the pole carrying the fewest homes first, then random ones
        load = {}
        for h, p in slot.items():
            load[p] = load.get(p, 0) + 1
        order = sorted(cur, key=lambda p: load.get(p, 0))
        if stall:
            order = list(rng.permutation(cur))
        found = None
        for drop in order[: max(3, len(order) // 2)]:
            trial = [p for p in cur if p != drop]
            s = feasible(reach, trial, fan)
            if s is not None:
                found = (trial, s); break
            # repair: swap in one pole not currently open
            pool = [int(p) for p in live if p not in trial]
            rng.shuffle(pool)
            for add in pool[:25]:
                s = feasible(reach, trial + [add], fan)
                if s is not None and len(trial) + 1 < len(cur):
                    found = (trial + [add], s); break
            if found: break
        if found is None:
            stall += 1
            continue
        cur, slot = found[0], found[1]
        if len(cur) < len(best[0]):
            best = (list(cur), dict(slot))
        stall = 0
    return best
