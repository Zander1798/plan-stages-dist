"""JOINT SPACING (F-57) -- space the joints ALONG the lane, the way the accepted plans do.

Operator, 2026-09-04: "you were forced to place three poles close to each other, and the
drop cables just look all messy."

F-55 fixed the joint COUNT: our solver opened 443 where the accepted plan used 413, and the
remove-and-repair prune closed that to 420 vs their 414. SPACING is the same defect and was
never touched. Measured on Malmesbury wave 9:

    collection points with another within 15 m    ours  6.4%   accepted plan  1.0%
    3+ within 15 m                                ours  5      accepted plan  0
    row-continuity lane ends carrying no joint     72 of 79  (median 16.1 m to the nearest)

WHY THEY CLUSTER: `_repos` slides every joint to the position that minimises ITS members'
drop cable. Adjacent joints share members, so their optima converge and they drift together.
Nothing in Step 4 ever pushes them apart, so a lane that runs the full block still gets its
joints piled at one end -- and `trim_stubs` then correctly cuts the cable beyond the last
one, which is how 72 of 79 lanes were lost.

WHAT IT COSTS: separation is bought with drop cable, and we can afford it -- Malmesbury
wave 9 spends 43,951 m of drops against the accepted plan's 45,266 m. The budget is that
headroom, the same rule the lane pass uses (operator, 2026-09-07: spend up to the human,
never past). `budget_m` is the only thing that limits the spend.

The cap and road rules do NOT live here. `options(j)` comes from step4 and yields only
positions joint j may legally occupy, so this pass cannot break the drop cap, cannot make a
clean drop cross a road, and cannot exceed the fan cap (s0.7, s0.1).
"""
import numpy as np


def spread_joints(collections, cand_xy, options, min_sep=15.0, budget_m=float("inf"),
                  sweeps=4, target_sep=None):
    """Move clustered joints onto under-used cable, best separation per metre first.

    collections : (J,) candidate index currently occupied by each joint.
    cand_xy     : (C, 2) coordinates of every candidate position.
    options(j)  : -> (ci, cost) legal candidate indices for joint j and the total drop
                  cable its members would pay at each. The joint's CURRENT position must be
                  among them, and `cost` is measured on the same scale for all candidates.
    min_sep     : joints closer than this to another joint are CLUSTERED, i.e. what makes a
                  joint eligible to move at all (F-56's own 15 m measure).
    target_sep  : how far a joint keeps pushing once it is moving; defaults to min_sep.
                  ⚠️ Measured 2026-09-07: with the reward capped at min_sep every joint
                  stopped at exactly 15 m and none ever travelled down a row-continuity
                  lane -- lane survival stayed at 7 of 79 while clustering fell 13.2% ->
                  2.1%. Separating joints and OCCUPYING the lane are not the same thing.
                  The accepted plan runs ~44 m of cable per joint against our ~41 m, so the
                  mean spacing is already right and only the variance is wrong.
    budget_m    : total extra drop cable this pass may spend across the whole site.

    Returns (collections, moved, added_m). Never returns a position `options` did not
    offer, so every step4 guarantee survives untouched.
    """
    out = np.asarray(collections).copy()
    P = np.asarray(cand_xy, float)
    reach = float(min_sep if target_sep is None else target_sep)
    moved = 0
    spent = 0.0

    def nearest_other(k, ci):
        """Distance from candidate `ci` to the closest joint that is not `k`."""
        others = np.delete(np.arange(len(out)), k)
        if len(others) == 0:
            return np.inf
        d = np.hypot(*(P[out[others]] - P[ci]).T)
        return float(d.min())

    for _sweep in range(sweeps):
        # worst cluster first: the joint with the closest neighbour has the most to gain
        sep_now = np.array([nearest_other(k, out[k]) for k in range(len(out))])
        order = [k for k in np.argsort(sep_now) if sep_now[k] < min_sep]
        if not order:
            break
        any_move = False
        for k in order:
            here = nearest_other(k, out[k])
            if here >= min_sep:
                continue
            ci, cost = options(k)
            ci = np.asarray(ci)
            cost = np.asarray(cost, float)
            if not len(ci):
                continue
            cur = np.flatnonzero(ci == out[k])
            if not len(cur):
                continue                      # step4 did not offer the current position
            cur_cost = float(cost[cur[0]])

            best = None
            for m, c in enumerate(ci):
                if c == out[k]:
                    continue
                if any(c == out[o] for o in range(len(out)) if o != k):
                    continue                  # never stack two joints on one position
                gain = nearest_other(k, c)
                if gain <= here:
                    continue                  # must actually separate
                delta = float(cost[m]) - cur_cost
                if delta < 0.0:
                    delta = 0.0               # a cheaper position is a bonus, not a credit
                if spent + delta > budget_m:
                    continue
                # rank: separation first (capped at `reach` -- past that, further is not
                # better), then the cheapest way to get it
                key = (-min(gain, reach), delta)
                if best is None or key < best[0]:
                    best = (key, m, c, delta)
            if best is None:
                continue
            _key, _m, c, delta = best
            out[k] = c
            spent += delta
            moved += 1
            any_move = True
        if not any_move:
            break
    return out, moved, spent
