"""Step 0 -- validate the operator's WAYLEAVE before anything is planned on it.

THE WAYLEAVE (operator, 2026-09-09) replaced the old Step 0. We are no longer given the PON
division plus the 1:16 root of every tree and asked to route between them; we are given the
SPAN -- the route the fibre will actually follow -- and asked to say which of it is FEEDER
and which is DISTRIBUTION, then hang the hardware on it. So the pipeline's first question is
no longer "did they give us a skeleton" but "is this span actually plannable".

WHY A GATE, AND WHY IT PRINTS RATHER THAN ASSUMES. On 2026-09-08 a Ventersdorp plan was
presented as "in style" because every SUMMARY STATISTIC of its synthesised PON cut matched
the operator's (F-61) -- the structure was a coin flip and the plan was rejected. On
2026-09-09 the span was reported as 98 disconnected islands because the graph was built by
snapping vertices instead of noding the lines (F-62); the operator knew it was wrong by
looking at it. Both failures were measurements presented without a check that could fail.
This gate is that check, and it refuses to pass rather than plan on a bad graph.

Checks, in order of what they would cost us later:
    1. CRS         -- every number below is a length in metres (site_crs).
    2. Layers      -- the required wayleave set is present.
    3. Span        -- nodes into ONE network; report every component and its metres.
    4. POP         -- sits on the span, in the main component.
    5. PONs        -- each contains span AND is reachable from the POP. A PON that is not
                      reachable cannot be fed, and no amount of routing fixes it.
    6. Demand pts  -- distance to the span, against the client drop cap. Reported against
                      THE OPERATOR'S OWN demand-point count, never a filtered denominator
                      (that error read 91.9% when the truth was 71.7%).
    7. Poles       -- how much of the operator's own pole layer lands on the span, and the
                      metres-per-pole their placement implies (sec0.20 is site-dependent).
    8. Roads       -- how much span is roadside, which is what the feeder must prefer.

Usage:  rungeo.bat step0_wayleave.py
        SITE=ventersdorp SITE_DIR=... SITE_EPSG=2052 LAYER_PONS="PON Zones HT2"
"""
import json
import math
import os
import sys

import numpy as np
from osgeo import ogr, osr
from scipy.spatial import cKDTree

ogr.UseExceptions()

from client_spec import limit
from site_crs import LOCAL_EPSG, check_layer
from site_config import work_dir, SITE, SITE_DIR, L as LYR, path as LPATH, have, banner, missing_required
from span_graph import build as build_graph, load_span, SEG_M, STITCH_M

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
OUT = work_dir("step0")

DROP_CAP_M = float(os.environ.get("DROP_CAP_M", limit("drop_cap_m", required=True)))
POP_SNAP_M = float(os.environ.get("POP_SNAP_M", "25"))     # how far off-span a POP may sit
MAIN_SHARE = float(os.environ.get("MAIN_SHARE", "0.99"))   # of span metres in one component

wgs = osr.SpatialReference(); wgs.ImportFromEPSG(4326)
loc = osr.SpatialReference(); loc.ImportFromEPSG(LOCAL_EPSG)
for s in (wgs, loc): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
FWD = osr.CoordinateTransformation(wgs, loc)

FAIL, WARN = [], []


def fail(msg): FAIL.append(msg); print("  FAIL  " + msg)
def warn(msg): WARN.append(msg); print("  warn  " + msg)
def ok(msg):   print("  ok    " + msg)


def load(key):
    """features of a layer, reprojected to site metres"""
    ds = ogr.Open(LPATH(key))
    if ds is None: raise SystemExit(f"cannot open {LPATH(key)}")
    lyr = ds.GetLayer(0)
    out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None: continue
        g = g.Clone(); g.Transform(FWD)
        out.append((f.items(), g))
    return out


def pt(g):
    return g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()


def densified_points(feats, step=2.0):
    out = []
    for _, g in feats:
        parts = ([g] if g.GetGeometryType() in (ogr.wkbLineString, ogr.wkbLineString25D)
                 else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())])
        for p in parts:
            q = p.Clone(); q.Segmentize(step)
            out.extend(q.GetPoint(i)[:2] for i in range(q.GetPointCount()))
    return np.array(out) if out else np.zeros((0, 2))


def main():
    print(banner())
    print()
    report = {"site": SITE, "dir": SITE_DIR, "epsg": LOCAL_EPSG,
              "seg_m": SEG_M, "stitch_m": STITCH_M}

    # ---- 2. layers -------------------------------------------------------------------
    print("[2] required wayleave layers")
    miss = missing_required()
    if miss:
        for k in miss: fail(f"missing required layer {k} ({LYR(k)}.shp)")
        print("\nGATE: FAIL -- cannot plan without the wayleave.")
        return 1
    ok("all required layers present")

    # ---- 1. CRS ----------------------------------------------------------------------
    print("[1] CRS")
    want = check_layer(LPATH("span"))
    if want and want != LOCAL_EPSG:
        fail(f"span belongs in EPSG:{want}, measuring in EPSG:{LOCAL_EPSG}; re-run with SITE_EPSG={want}")
    else:
        ok(f"measuring in EPSG:{LOCAL_EPSG}")

    # ---- 3. span ---------------------------------------------------------------------
    print("[3] span network")
    span = load("span")
    lines = []
    for _, g in span:
        parts = ([g] if g.GetGeometryType() in (ogr.wkbLineString, ogr.wkbLineString25D)
                 else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())])
        for p in parts:
            pts = [p.GetPoint(i)[:2] for i in range(p.GetPointCount())]
            if len(pts) >= 2: lines.append(pts)
    raw_m = sum(g.Length() for _, g in span)
    G = build_graph(lines)
    comps = G.components()
    comp_m = [G.component_length(c) for c in comps]
    total_m = G.total_length()
    print(f"        {len(span)} features, {raw_m:,.0f} m raw -> {len(G.coords):,} nodes, "
          f"{total_m:,.0f} m noded (seg {SEG_M} m, stitch {STITCH_M} m)")
    if G.dropped_m > 1.0:
        warn(f"{G.dropped_m:.0f} m dropped as slivers shorter than the stitch tolerance")
    share = (comp_m[0] / total_m) if total_m else 0.0
    print(f"        {len(comps)} component(s); largest {comp_m[0]:,.0f} m ({share:.1%})")
    if share < MAIN_SHARE:
        fail(f"span is fragmented: largest component holds only {share:.1%} of its metres")
        for i, m in enumerate(comp_m[1:6], 2):
            print(f"          component {i}: {m:,.0f} m")
    else:
        ok(f"span is one network ({share:.1%} of metres in the main component)")
    main_comp = comps[0]
    report.update(span_features=len(span), span_m=round(total_m),
                  components=len(comps), main_component_share=round(share, 4))

    # ---- 4. POP ----------------------------------------------------------------------
    print("[4] POP")
    pop = load("pop")
    if not pop:
        fail("POP layer is empty"); popn = None
    else:
        pxy = (pt(pop[0][1]).GetX(), pt(pop[0][1]).GetY())
        popn = G.nearest(pxy)
        d = math.dist(G.coords[popn], pxy)
        if d > POP_SNAP_M:
            fail(f"POP is {d:.0f} m from the nearest span node (limit {POP_SNAP_M:.0f} m)")
        elif popn not in main_comp:
            fail("POP is not on the main span component")
        else:
            ok(f"POP snaps to the span at {d:.1f} m, on the main component")
        report["pop_snap_m"] = round(d, 1)

    # ---- 5. PONs ---------------------------------------------------------------------
    print("[5] PONs")
    pons = load("pons")
    dist = {}
    if popn is not None:
        dist, _ = G.dijkstra([popn])
    keys = list(G.coords)
    A = np.array([G.coords[k] for k in keys])
    NT = cKDTree(A)
    no_span, unreachable, span_in_pon = [], [], []
    for i, (attr, pg) in enumerate(pons):
        label = attr.get("pon_num") or attr.get("label") or attr.get("Name") or (i + 1)
        minx, maxx, miny, maxy = pg.GetEnvelope()
        r = math.hypot(maxx - minx, maxy - miny) / 2 + 5
        cand = NT.query_ball_point([(minx + maxx) / 2, (miny + maxy) / 2], r)
        inside, reach = 0, 0
        for j in cand:
            p = ogr.Geometry(ogr.wkbPoint); p.AddPoint(float(A[j][0]), float(A[j][1]))
            if not pg.Contains(p): continue
            inside += 1
            if dist.get(keys[j], math.inf) < math.inf: reach += 1
        span_in_pon.append(inside)
        if inside == 0: no_span.append(label)
        elif reach == 0: unreachable.append(label)
    print(f"        {len(pons)} PONs; span nodes inside: median {int(np.median(span_in_pon))}, "
          f"min {min(span_in_pon)}")
    if no_span: fail(f"{len(no_span)} PON(s) contain no span at all: {no_span[:10]}")
    if unreachable: fail(f"{len(unreachable)} PON(s) not reachable from the POP: {unreachable[:10]}")
    if not no_span and not unreachable:
        ok(f"all {len(pons)} PONs contain span and are reachable from the POP")
    report.update(pons=len(pons), pons_without_span=len(no_span),
                  pons_unreachable=len(unreachable))

    # ---- 6. demand points ------------------------------------------------------------
    print("[6] demand points")
    dps = load("demand_points")
    SP = densified_points(span, 2.0)
    ST = cKDTree(SP)
    D = np.array([[pt(g).GetX(), pt(g).GetY()] for _, g in dps])
    dd, _ = ST.query(D)
    n = len(D)
    within = int((dd <= DROP_CAP_M).sum())
    print(f"        {n:,} demand points (the operator's own count -- the denominator)")
    for c in (20, 30, DROP_CAP_M):
        print(f"          within {c:>4.0f} m of the span: {int((dd <= c).sum()):,}  "
              f"({100 * (dd <= c).mean():.2f}%)")
    print(f"          distance to span: median {np.median(dd):.1f}  p99 {np.percentile(dd, 99):.1f}  "
          f"max {dd.max():.1f}")
    if within < n:
        warn(f"{n - within} demand point(s) lie beyond the {DROP_CAP_M:.0f} m drop cap "
             f"from the span -- they cannot be served without extending it")
    else:
        ok(f"every demand point is within the {DROP_CAP_M:.0f} m drop cap of the span")
    report.update(demand_points=n, dp_within_drop_cap=within,
                  dp_median_m=round(float(np.median(dd)), 1))

    # PON unit counts vs demand points actually inside
    units = [a.get("units") for a, _ in pons if a.get("units") is not None]
    if units:
        print(f"        PON 'units' field sums to {sum(units):,} against {n:,} demand points")
        if sum(units) != n:
            warn(f"PON unit total {sum(units):,} != demand point count {n:,}")

    # ---- 7. poles --------------------------------------------------------------------
    print("[7] poles")
    if have("poles"):
        poles = load("poles")
        P = np.array([[pt(g).GetX(), pt(g).GetY()] for _, g in poles])
        pd, _ = ST.query(P)
        on = int((pd <= 2.0).sum())
        print(f"        {len(poles):,} poles supplied; {on:,} ({100 * on / len(poles):.1f}%) "
              f"lie on the span (<=2 m)")
        print(f"        implies {total_m / len(poles):.1f} m per pole "
              f"(sec0.20: site-dependent, settlements ~49)")
        if on / len(poles) < 0.9:
            warn("under 90% of the operator's poles sit on the span -- check the pairing")
        report.update(poles=len(poles), poles_on_span=on,
                      m_per_pole=round(total_m / len(poles), 1))
    else:
        warn(f"no pole layer ({LYR('poles')}.shp); poles will have to be generated")

    # ---- 8. roads --------------------------------------------------------------------
    print("[8] roads (the feeder must run roadside)")
    road = load("road")
    RP = densified_points(road, 2.0)
    RT = cKDTree(RP)
    dn, _ = RT.query(A)
    print(f"        {len(road)} road features, {sum(g.Length() for _, g in road):,.0f} m")
    for c in (5, 10, 20, 30):
        m = float(np.mean(dn <= c))
        print(f"          span nodes within {c:>2d} m of a road: {m:.1%}")
    report["span_roadside_20m"] = round(float(np.mean(dn <= 20)), 4)

    # ---- verdict ---------------------------------------------------------------------
    print()
    report["fail"] = FAIL; report["warn"] = WARN
    with open(os.path.join(OUT, f"wayleave_{SITE}.json"), "w") as fh:
        json.dump(report, fh, indent=2)
    if FAIL:
        print(f"GATE: FAIL -- {len(FAIL)} blocking problem(s), {len(WARN)} warning(s)")
        for m in FAIL: print("   * " + m)
        return 1
    print(f"GATE: PASS -- {len(WARN)} warning(s). Wayleave is plannable.")
    for m in WARN: print("   * " + m)
    return 0


if __name__ == "__main__":
    sys.exit(main())
