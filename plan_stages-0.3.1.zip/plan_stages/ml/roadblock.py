"""Drop-over-road feasibility — THE RULE (operator, 2026-08-27, PLANNING-LEARNINGS §0.7):

    "We don't want drop cables going across roads. Feeder cables are fine, distribution
     cables are fine, but specifically drop cables from the poles ... this is a very
     important rule."

A drop is a straight segment home -> collection point. This module answers, vectorised:
which (home, candidate-position) pairs would cross a road line?

Used by BOTH step4_drops.py and cover.py (Step 3's closed loop) so selection optimises the
same constrained problem Step 4 actually solves — the drift hazard cover.py warns about
applies to this constraint too.

Roads come from `Road.shp` in the site inputs when the operator supplies one (Cradock did),
else the pipeline runs unconstrained exactly as before (ROADS env overrides the path).
Provenance of the road lines is the site's problem, not this module's — record it in prep.
"""
import os
import numpy as np
from scipy.spatial import cKDTree


class RoadBlocker:
    """segs: (S, 2, 2) road segment endpoints, metres, same CRS as the homes."""

    def __init__(self, segs):
        segs = np.asarray(segs, float)
        self.segs = segs
        self.mid = segs.mean(axis=1)
        self.half = np.linalg.norm(segs[:, 1] - segs[:, 0], axis=1) / 2.0
        self.tree = cKDTree(self.mid) if len(segs) else None

    @classmethod
    def from_shp(cls, path, to_metric):
        """to_metric: osr.CoordinateTransformation into the site CRS"""
        from osgeo import ogr
        ds = ogr.Open(path)
        if ds is None:
            return None
        segs = []
        for f in ds.GetLayer():
            g = f.GetGeometryRef()
            if g is None:
                continue
            g = g.Clone(); g.FlattenTo2D(); g.Transform(to_metric)
            stack = [g]
            while stack:
                x = stack.pop()
                if x.GetGeometryName() == "LINESTRING":
                    pts = [(x.GetX(i), x.GetY(i)) for i in range(x.GetPointCount())]
                    segs += [(a, b) for a, b in zip(pts[:-1], pts[1:])]
                elif x.GetGeometryCount():
                    stack += [x.GetGeometryRef(i) for i in range(x.GetGeometryCount())]
        return cls(np.array(segs)) if segs else None

    def blocked_from(self, p, Q, reach):
        """One home p (2,) against candidate positions Q (M,2) -> (M,) bool, True where
        the straight drop p->q would CROSS a road segment.

        `reach` bounds the drops that matter (pairs longer than it are infeasible anyway),
        so only road segments within reach of the home are tested — one broadcast
        (M x S_near), no per-pair python loop. This is what keeps the constraint cheap
        enough to sit inside Step 3's closed-loop selection."""
        Q = np.asarray(Q, float)
        out = np.zeros(len(Q), bool)
        if self.tree is None or len(Q) == 0:
            return out
        p = np.asarray(p, float)
        # a pair longer than `reach` is infeasible for the caller by construction, so only
        # positions within reach need a road test at all -- typically ~50 of 3,000
        dq = np.hypot(Q[:, 0] - p[0], Q[:, 1] - p[1])
        js = np.flatnonzero(dq <= reach)
        if len(js) == 0:
            return out
        pad = float(self.half.max()) if len(self.half) else 0.0
        ks = self.tree.query_ball_point(p, reach + pad + 1e-6)
        if not ks:
            return out
        segs = self.segs[np.asarray(ks, int)]
        ax, ay = segs[:, 0, 0] - p[0], segs[:, 0, 1] - p[1]        # (S,) a-p
        bx, by = segs[:, 1, 0] - p[0], segs[:, 1, 1] - p[1]        # (S,) b-p
        qx, qy = (Q[js, 0] - p[0])[:, None], (Q[js, 1] - p[1])[:, None]   # (J,1) q-p
        # proper-intersection test, explicit 2D cross products (np.cross is 10x slower)
        d1 = qx * ay[None, :] - qy * ax[None, :]
        d2 = qx * by[None, :] - qy * bx[None, :]
        abx, aby = (bx - ax)[None, :], (by - ay)[None, :]
        d3 = abx * (-ay[None, :]) - aby * (-ax[None, :])           # cross(b-a, p-a)
        d4 = abx * (qy - ay[None, :]) - aby * (qx - ax[None, :])   # cross(b-a, q-a)
        out[js] = np.any((d1 * d2 < 0) & (d3 * d4 < 0), axis=1)
        return out


def load_for_site(site_dir, to_metric):
    """the pipeline's single entry point: Road.shp in the inputs, or ROADS= override.
    Returns None when the site has no road layer — behaviour then unchanged."""
    path = os.environ.get("ROADS", os.path.join(site_dir, "Road.shp"))
    if not os.path.exists(path):
        return None
    return RoadBlocker.from_shp(path, to_metric)
