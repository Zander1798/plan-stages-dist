"""Which projected CRS this run should measure in.

THE DEFECT THIS FIXES (found 2026-08-21 while inspecting a second AOI). Every script in this
project hardcoded **EPSG:2048** — Hartebeesthoek94 / Lo19. That is correct for Malmesbury at
18.7E and WRONG anywhere outside the 18–20E belt. South Africa's Lo system is a 2-degree-wide
transverse Mercator zone per odd meridian, so a site a few zones away is measured with real
scale distortion — and *every number this project produces is a length in metres.*

Measured on the AOI at `C:/Users/zande/Downloads/Test` (26.23E, Lo27): forcing EPSG:2048 gives
**+1.22% area error, so roughly +0.61% on every length.** On a Malmesbury-sized job that is
~385 m of phantom cable. Small, but it is a **systematic bias, not noise** — it would not
average out, and it would silently make a new site look worse than it is.

NOTE the module is `site_crs`, not `site` — `site` is a Python stdlib module and shadowing it
breaks the interpreter's startup path handling.

Usage in a script:

    from site_crs import LOCAL_EPSG, check_crs
    loc.ImportFromEPSG(LOCAL_EPSG)
    ...
    check_crs(lon_of_the_data)      # warns loudly on mismatch

Override with `SITE_EPSG=2052`. Default stays 2048 so Malmesbury behaviour is unchanged.
"""
import os

# Hartebeesthoek94 / Lo<central meridian> -> EPSG code
LO = {15: 2046, 17: 2047, 19: 2048, 21: 2049, 23: 2050,
      25: 2051, 27: 2052, 29: 2053, 31: 2054, 33: 2055}

LOCAL_EPSG = int(os.environ.get("SITE_EPSG", "2048"))


def epsg_for_lon(lon):
    """the Lo zone whose central meridian is nearest this longitude"""
    m = min(LO, key=lambda k: abs(k - lon))
    return LO[m], m


def check_crs(lon, fatal=False):
    """Warn (or stop) when the CRS in use is not the right Lo zone for the data.

    Call once per run, after the input extent is known. Returns the EPSG that *should*
    be used, so a caller can decide for itself."""
    want, meridian = epsg_for_lon(lon)
    if want != LOCAL_EPSG:
        msg = (f"*** CRS MISMATCH: data at {lon:.3f}E belongs in Lo{meridian} "
               f"(EPSG:{want}), but this run is measuring in EPSG:{LOCAL_EPSG}. ***\n"
               f"*** Every length will carry a systematic scale error. "
               f"Re-run with SITE_EPSG={want}. ***")
        if fatal: raise SystemExit(msg)
        print(msg)
    return want


def check_layer(path, fatal=False):
    """Check a source layer's own longitude against the CRS this run is measuring in.

    Reads the extent BEFORE any transform, so it is unaffected by the very setting it is
    checking. Silent when correct; loud when not."""
    from osgeo import ogr
    ds = ogr.Open(path)
    if ds is None: return None
    x0, x1, _, _ = ds.GetLayer(0).GetExtent()
    return check_crs((x0 + x1) / 2.0, fatal=fatal)
