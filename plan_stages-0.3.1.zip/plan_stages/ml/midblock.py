"""MIDBLOCK or STREET -- which is this metre of cable?

WHY IT MATTERS. HeroTel's TSD defines midblock deployment as the "midblock servitude":
poles planted INSIDE private property, running between the houses. The GPON standard puts
distribution on "5m or 6m poles deployed in midblock" and the feeder on 7 m poles. The
operator, 2026-09-09: *"It's not supposed to run mid-block if it's a feeder cable. The
opposite of mid-block is roadside, or not mid-block. There's not a fixed constraint that it
has to be a certain amount of metres close to a road."*

So the property is about what stands BESIDE the cable, not how far a road centreline is.

THE TEST. A metre is MIDBLOCK when there is a structure within `SIDE_M` on BOTH sides of the
cable (perpendicular offset, within `ALONG_M` along-track so it is beside, not ahead). A
street metre has an open corridor on at least one side.

MEASURED against the operator's own labelled cable on three settlement sites (2026-09-09,
`cable_classes.py`), Google Open Buildings footprints, SIDE_M=12, ALONG_M=8:

    site          DISTRIBUTION midblock    LINK/feeder midblock
    Botshabelo            37.3%                   0.0%
    Middelburg            33.0%                   0.2%
    WUVS                  40.6%                   0.4%

The feeder is never midblock. That is the rule this module lets the feeder router obey.
(Malmesbury, a formal town, reads differently -- LINK 45% midblock -- so this is settlement
grammar. Re-measure before applying it to a town.)

WHY NOT THE CADASTRE. "Inside an erf" was tried first and is contaminated on Ventersdorp: a
third of the site has no erven (F-60), so "outside an erf" there means "unsurveyed", not
"street". Buildings exist everywhere the homes do.

    from midblock import Midblock
    mb = Midblock(building_xy)              # N x 2 array, site metres
    mb.is_midblock(ax, ay, bx, by)          # one segment
"""
import os

import numpy as np
from scipy.spatial import cKDTree

SIDE_M = float(os.environ.get("MIDBLOCK_SIDE_M", "12"))
ALONG_M = float(os.environ.get("MIDBLOCK_ALONG_M", "8"))
SEARCH_M = max(SIDE_M, ALONG_M) * 2.1
# v2 corridor half-width: a shack footprint is ~4-8 m across, so a centroid within 4 m of
# the cable->road line means the house itself sits in the way.
CORRIDOR_HALF_M = float(os.environ.get("MIDBLOCK_CORRIDOR_HALF_M", "4"))


class Midblock:
    def __init__(self, building_xy):
        self.B = np.asarray(building_xy, dtype=float)
        self.T = cKDTree(self.B) if len(self.B) else None

    def sides(self, ax, ay, bx, by):
        """(nearest structure on the left, on the right) of the segment, in metres."""
        if self.T is None:
            return (np.inf, np.inf)
        L = float(np.hypot(bx - ax, by - ay))
        if L < 1e-6:
            return (np.inf, np.inf)
        dx, dy = (bx - ax) / L, (by - ay) / L
        nx, ny = -dy, dx
        mx, my = (ax + bx) / 2.0, (ay + by) / 2.0
        left = right = np.inf
        for k in self.T.query_ball_point([mx, my], SEARCH_M):
            vx, vy = self.B[k][0] - mx, self.B[k][1] - my
            if abs(vx * dx + vy * dy) > ALONG_M:
                continue
            s = vx * nx + vy * ny
            if s >= 0:
                left = min(left, s)
            else:
                right = min(right, -s)
        return (left, right)

    def is_midblock(self, ax, ay, bx, by):
        l, r = self.sides(ax, ay, bx, by)
        return l <= SIDE_M and r <= SIDE_M

    # ------------------------------------------------------------------------------
    # SECOND TEST, 2026-09-09. The both-sides test above calls a run along a NARROW street
    # midblock (houses 3 m on one side, 10 m across the road on the other). The operator,
    # looking at Ventersdorp: "I can see the possibility of a roadside feeder cable on this
    # current wayleave." Their definition of roadside is "along the road, not mid-block",
    # with no metre threshold. The geometric reading of that is:
    #
    #     a metre is ROADSIDE when NOTHING IS BUILT between the cable and the road.
    #     a metre is MIDBLOCK when a structure stands between the cable and the road,
    #     i.e. the cable runs BEHIND the houses.
    #
    # So cast from the segment midpoint to the nearest road point and look for a structure
    # inside that corridor. The only constant is the corridor half-width (a house is not a
    # point), and it is a physical size, not a policy number.
    # ------------------------------------------------------------------------------
    def set_roads(self, road_xy):
        self.R = np.asarray(road_xy, dtype=float)
        self.RT = cKDTree(self.R) if len(self.R) else None

    def behind_a_house(self, ax, ay, bx, by, half_width=None):
        """True when a structure lies between this segment and the nearest road."""
        if self.T is None or getattr(self, "RT", None) is None:
            return False
        hw = CORRIDOR_HALF_M if half_width is None else half_width
        mx, my = (ax + bx) / 2.0, (ay + by) / 2.0
        d, j = self.RT.query([mx, my])
        d = float(d)
        if d < 1e-6:
            return False
        rx, ry = self.R[j]
        ux, uy = (rx - mx) / d, (ry - my) / d            # unit vector cable -> road
        for k in self.T.query_ball_point([mx, my], d + hw):
            vx, vy = self.B[k][0] - mx, self.B[k][1] - my
            t = vx * ux + vy * uy                        # along the corridor
            if t <= 0.5 or t >= d - 0.5:
                continue                                 # not between cable and road
            s = abs(-vx * uy + vy * ux)                  # lateral offset from the corridor
            if s <= hw:
                return True
        return False

    def is_midblock_v2(self, ax, ay, bx, by):
        return self.behind_a_house(ax, ay, bx, by)


def buildings_for_site(site, epsg):
    """Building centroids for a site, in site metres, from the Open Buildings fetch (F-59).

    Returns an empty array (and says so) when the site has none -- the caller then has no
    midblock information and must not pretend otherwise."""
    from osgeo import ogr, osr
    ogr.UseExceptions()
    root = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
    p = os.environ.get("BUILDINGS", os.path.join(root, "work", "buildings", f"{site}_buildings.gpkg"))
    if not os.path.exists(p):
        print(f"*** no building footprints at {p}; midblock test unavailable ***")
        return np.zeros((0, 2))
    ds = ogr.Open(p)
    lyr = ds.GetLayer(0)
    sr = lyr.GetSpatialRef()
    tf = None
    if sr is not None and (sr.GetAuthorityCode(None) is None or int(sr.GetAuthorityCode(None)) != epsg):
        tgt = osr.SpatialReference(); tgt.ImportFromEPSG(epsg)
        src = sr.Clone()
        for s in (src, tgt): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        tf = osr.CoordinateTransformation(src, tgt)
    out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None: continue
        g = g.Clone()
        if tf is not None: g.Transform(tf)
        c = g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()
        out.append((c.GetX(), c.GetY()))
    print(f"buildings: {len(out):,} footprints from {os.path.basename(p)}")
    return np.array(out) if out else np.zeros((0, 2))
