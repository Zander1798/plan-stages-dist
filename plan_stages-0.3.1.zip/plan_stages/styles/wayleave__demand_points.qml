<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" layerType="Vector" maxScale="0" minScale="100000000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="0" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.2.0-Belém do Pará">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="fid" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="DATE_STAMP">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Terrain" customToleranceEnabled="0" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{76cb284c-194d-4805-8cfe-340e36009125}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="114,155,111,255,rgb:0.4470588,0.6078432,0.4352941,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{77e99747-1665-4d0d-ae29-86daa148f225}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="114,155,111,255,rgb:0.4470588,0.6078432,0.4352941,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="81,111,79,255,rgb:0.3193255,0.4341649,0.3109178,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{832257ca-e8e3-495f-ae61-d10f1504dabf}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="114,155,111,255,rgb:0.4470588,0.6078432,0.4352941,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="81,111,79,255,rgb:0.3193255,0.4341649,0.3109178,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="singleSymbol">
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="0" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{d8aaf8e9-e691-46bc-8338-619f9b70760f}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{80107cbe-c175-4a02-b3b4-d81059db7f01}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="0" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="FeatureId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="PRCL_KEY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="LSTATUS">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="WSTATUS">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="GEOM_AREA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="DATE_STAMP">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="MIN_REGION">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="MIN_CODE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Easting">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Northing">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Altitude">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Measure">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Label">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Orientatio">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Length">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Area">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Key1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="EntityId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Key">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ParentId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Track">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ClassId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ChangeId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="UserId">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Timestamp">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Data">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="FeatureId" index="1" name=""/>
    <alias field="ID" index="2" name=""/>
    <alias field="PRCL_KEY" index="3" name=""/>
    <alias field="LSTATUS" index="4" name=""/>
    <alias field="WSTATUS" index="5" name=""/>
    <alias field="GEOM_AREA" index="6" name=""/>
    <alias field="DATE_STAMP" index="7" name=""/>
    <alias field="MIN_REGION" index="8" name=""/>
    <alias field="MIN_CODE" index="9" name=""/>
    <alias field="Easting" index="10" name=""/>
    <alias field="Northing" index="11" name=""/>
    <alias field="Altitude" index="12" name=""/>
    <alias field="Measure" index="13" name=""/>
    <alias field="Label" index="14" name=""/>
    <alias field="Orientatio" index="15" name=""/>
    <alias field="Length" index="16" name=""/>
    <alias field="Area" index="17" name=""/>
    <alias field="Key1" index="18" name=""/>
    <alias field="EntityId" index="19" name=""/>
    <alias field="Key" index="20" name=""/>
    <alias field="ParentId" index="21" name=""/>
    <alias field="Track" index="22" name=""/>
    <alias field="ClassId" index="23" name=""/>
    <alias field="ChangeId" index="24" name=""/>
    <alias field="UserId" index="25" name=""/>
    <alias field="Timestamp" index="26" name=""/>
    <alias field="Data" index="27" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="FeatureId"/>
    <default applyOnUpdate="0" expression="" field="ID"/>
    <default applyOnUpdate="0" expression="" field="PRCL_KEY"/>
    <default applyOnUpdate="0" expression="" field="LSTATUS"/>
    <default applyOnUpdate="0" expression="" field="WSTATUS"/>
    <default applyOnUpdate="0" expression="" field="GEOM_AREA"/>
    <default applyOnUpdate="0" expression="" field="DATE_STAMP"/>
    <default applyOnUpdate="0" expression="" field="MIN_REGION"/>
    <default applyOnUpdate="0" expression="" field="MIN_CODE"/>
    <default applyOnUpdate="0" expression="" field="Easting"/>
    <default applyOnUpdate="0" expression="" field="Northing"/>
    <default applyOnUpdate="0" expression="" field="Altitude"/>
    <default applyOnUpdate="0" expression="" field="Measure"/>
    <default applyOnUpdate="0" expression="" field="Label"/>
    <default applyOnUpdate="0" expression="" field="Orientatio"/>
    <default applyOnUpdate="0" expression="" field="Length"/>
    <default applyOnUpdate="0" expression="" field="Area"/>
    <default applyOnUpdate="0" expression="" field="Key1"/>
    <default applyOnUpdate="0" expression="" field="EntityId"/>
    <default applyOnUpdate="0" expression="" field="Key"/>
    <default applyOnUpdate="0" expression="" field="ParentId"/>
    <default applyOnUpdate="0" expression="" field="Track"/>
    <default applyOnUpdate="0" expression="" field="ClassId"/>
    <default applyOnUpdate="0" expression="" field="ChangeId"/>
    <default applyOnUpdate="0" expression="" field="UserId"/>
    <default applyOnUpdate="0" expression="" field="Timestamp"/>
    <default applyOnUpdate="0" expression="" field="Data"/>
  </defaults>
  <constraints>
    <constraint constraints="0" exp_strength="0" field="fid" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="FeatureId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="PRCL_KEY" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="LSTATUS" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="WSTATUS" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="GEOM_AREA" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="DATE_STAMP" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MIN_REGION" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MIN_CODE" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Easting" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Northing" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Altitude" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Measure" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Label" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Orientatio" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Length" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Area" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Key1" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="EntityId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Key" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ParentId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Track" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ClassId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ChangeId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="UserId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Timestamp" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Data" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="FeatureId"/>
    <constraint desc="" exp="" field="ID"/>
    <constraint desc="" exp="" field="PRCL_KEY"/>
    <constraint desc="" exp="" field="LSTATUS"/>
    <constraint desc="" exp="" field="WSTATUS"/>
    <constraint desc="" exp="" field="GEOM_AREA"/>
    <constraint desc="" exp="" field="DATE_STAMP"/>
    <constraint desc="" exp="" field="MIN_REGION"/>
    <constraint desc="" exp="" field="MIN_CODE"/>
    <constraint desc="" exp="" field="Easting"/>
    <constraint desc="" exp="" field="Northing"/>
    <constraint desc="" exp="" field="Altitude"/>
    <constraint desc="" exp="" field="Measure"/>
    <constraint desc="" exp="" field="Label"/>
    <constraint desc="" exp="" field="Orientatio"/>
    <constraint desc="" exp="" field="Length"/>
    <constraint desc="" exp="" field="Area"/>
    <constraint desc="" exp="" field="Key1"/>
    <constraint desc="" exp="" field="EntityId"/>
    <constraint desc="" exp="" field="Key"/>
    <constraint desc="" exp="" field="ParentId"/>
    <constraint desc="" exp="" field="Track"/>
    <constraint desc="" exp="" field="ClassId"/>
    <constraint desc="" exp="" field="ChangeId"/>
    <constraint desc="" exp="" field="UserId"/>
    <constraint desc="" exp="" field="Timestamp"/>
    <constraint desc="" exp="" field="Data"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column hidden="0" name="fid" type="field" width="-1"/>
      <column hidden="0" name="FeatureId" type="field" width="-1"/>
      <column hidden="0" name="ID" type="field" width="-1"/>
      <column hidden="0" name="PRCL_KEY" type="field" width="-1"/>
      <column hidden="0" name="LSTATUS" type="field" width="-1"/>
      <column hidden="0" name="WSTATUS" type="field" width="-1"/>
      <column hidden="0" name="GEOM_AREA" type="field" width="-1"/>
      <column hidden="0" name="DATE_STAMP" type="field" width="-1"/>
      <column hidden="0" name="MIN_REGION" type="field" width="-1"/>
      <column hidden="0" name="MIN_CODE" type="field" width="-1"/>
      <column hidden="0" name="Easting" type="field" width="-1"/>
      <column hidden="0" name="Northing" type="field" width="-1"/>
      <column hidden="0" name="Altitude" type="field" width="-1"/>
      <column hidden="0" name="Measure" type="field" width="-1"/>
      <column hidden="0" name="Label" type="field" width="-1"/>
      <column hidden="0" name="Orientatio" type="field" width="-1"/>
      <column hidden="0" name="Length" type="field" width="-1"/>
      <column hidden="0" name="Area" type="field" width="-1"/>
      <column hidden="0" name="Key1" type="field" width="-1"/>
      <column hidden="0" name="EntityId" type="field" width="-1"/>
      <column hidden="0" name="Key" type="field" width="-1"/>
      <column hidden="0" name="ParentId" type="field" width="-1"/>
      <column hidden="0" name="Track" type="field" width="-1"/>
      <column hidden="0" name="ClassId" type="field" width="-1"/>
      <column hidden="0" name="ChangeId" type="field" width="-1"/>
      <column hidden="0" name="UserId" type="field" width="-1"/>
      <column hidden="0" name="Timestamp" type="field" width="-1"/>
      <column hidden="0" name="Data" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="Altitude"/>
    <field editable="1" name="Area"/>
    <field editable="1" name="ChangeId"/>
    <field editable="1" name="ClassId"/>
    <field editable="1" name="DATE_STAMP"/>
    <field editable="1" name="Data"/>
    <field editable="1" name="Easting"/>
    <field editable="1" name="EntityId"/>
    <field editable="1" name="FeatureId"/>
    <field editable="1" name="GEOM_AREA"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="Key"/>
    <field editable="1" name="Key1"/>
    <field editable="1" name="LSTATUS"/>
    <field editable="1" name="Label"/>
    <field editable="1" name="Length"/>
    <field editable="1" name="MIN_CODE"/>
    <field editable="1" name="MIN_REGION"/>
    <field editable="1" name="Measure"/>
    <field editable="1" name="Northing"/>
    <field editable="1" name="Orientatio"/>
    <field editable="1" name="PRCL_KEY"/>
    <field editable="1" name="ParentId"/>
    <field editable="1" name="Timestamp"/>
    <field editable="1" name="Track"/>
    <field editable="1" name="UserId"/>
    <field editable="1" name="WSTATUS"/>
    <field editable="1" name="fid"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="Altitude"/>
    <field labelOnTop="0" name="Area"/>
    <field labelOnTop="0" name="ChangeId"/>
    <field labelOnTop="0" name="ClassId"/>
    <field labelOnTop="0" name="DATE_STAMP"/>
    <field labelOnTop="0" name="Data"/>
    <field labelOnTop="0" name="Easting"/>
    <field labelOnTop="0" name="EntityId"/>
    <field labelOnTop="0" name="FeatureId"/>
    <field labelOnTop="0" name="GEOM_AREA"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="Key"/>
    <field labelOnTop="0" name="Key1"/>
    <field labelOnTop="0" name="LSTATUS"/>
    <field labelOnTop="0" name="Label"/>
    <field labelOnTop="0" name="Length"/>
    <field labelOnTop="0" name="MIN_CODE"/>
    <field labelOnTop="0" name="MIN_REGION"/>
    <field labelOnTop="0" name="Measure"/>
    <field labelOnTop="0" name="Northing"/>
    <field labelOnTop="0" name="Orientatio"/>
    <field labelOnTop="0" name="PRCL_KEY"/>
    <field labelOnTop="0" name="ParentId"/>
    <field labelOnTop="0" name="Timestamp"/>
    <field labelOnTop="0" name="Track"/>
    <field labelOnTop="0" name="UserId"/>
    <field labelOnTop="0" name="WSTATUS"/>
    <field labelOnTop="0" name="fid"/>
  </labelOnTop>
  <reuseLastValuePolicy>
    <field name="Altitude" reuseLastValuePolicy="NotAllowed"/>
    <field name="Area" reuseLastValuePolicy="NotAllowed"/>
    <field name="ChangeId" reuseLastValuePolicy="NotAllowed"/>
    <field name="ClassId" reuseLastValuePolicy="NotAllowed"/>
    <field name="DATE_STAMP" reuseLastValuePolicy="NotAllowed"/>
    <field name="Data" reuseLastValuePolicy="NotAllowed"/>
    <field name="Easting" reuseLastValuePolicy="NotAllowed"/>
    <field name="EntityId" reuseLastValuePolicy="NotAllowed"/>
    <field name="FeatureId" reuseLastValuePolicy="NotAllowed"/>
    <field name="GEOM_AREA" reuseLastValuePolicy="NotAllowed"/>
    <field name="ID" reuseLastValuePolicy="NotAllowed"/>
    <field name="Key" reuseLastValuePolicy="NotAllowed"/>
    <field name="Key1" reuseLastValuePolicy="NotAllowed"/>
    <field name="LSTATUS" reuseLastValuePolicy="NotAllowed"/>
    <field name="Label" reuseLastValuePolicy="NotAllowed"/>
    <field name="Length" reuseLastValuePolicy="NotAllowed"/>
    <field name="MIN_CODE" reuseLastValuePolicy="NotAllowed"/>
    <field name="MIN_REGION" reuseLastValuePolicy="NotAllowed"/>
    <field name="Measure" reuseLastValuePolicy="NotAllowed"/>
    <field name="Northing" reuseLastValuePolicy="NotAllowed"/>
    <field name="Orientatio" reuseLastValuePolicy="NotAllowed"/>
    <field name="PRCL_KEY" reuseLastValuePolicy="NotAllowed"/>
    <field name="ParentId" reuseLastValuePolicy="NotAllowed"/>
    <field name="Timestamp" reuseLastValuePolicy="NotAllowed"/>
    <field name="Track" reuseLastValuePolicy="NotAllowed"/>
    <field name="UserId" reuseLastValuePolicy="NotAllowed"/>
    <field name="WSTATUS" reuseLastValuePolicy="NotAllowed"/>
    <field name="fid" reuseLastValuePolicy="NotAllowed"/>
  </reuseLastValuePolicy>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"Label"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
