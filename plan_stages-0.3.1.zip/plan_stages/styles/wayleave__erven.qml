<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" layerType="Vector" maxScale="0" minScale="100000000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.2.0-Belém do Pará">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Terrain" customToleranceEnabled="1" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{4f223d0b-b1ac-470c-b40a-6e996f04dad5}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="190,178,151,255,rgb:0.7450981,0.6980392,0.5921569,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{3d73f943-bd80-4825-ae25-06dd7f55049c}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="190,178,151,255,rgb:0.7450981,0.6980392,0.5921569,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{56c68c1e-14ea-462b-a625-a0043c9e00e7}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="190,178,151,255,rgb:0.7450981,0.6980392,0.5921569,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="136,127,108,255,rgb:0.5322042,0.4985885,0.4229648,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="singleSymbol">
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="0" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{8b868c9f-f941-4de2-a9b8-233506de31f6}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,0,0,rgb:0,0,0,0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="200,200,200,255,rgb:0.7843137,0.7843137,0.7843137,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.1"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="no"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="0" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="FeatureId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ID">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="PRCL_KEY">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="LSTATUS">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="WSTATUS">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="GEOM_AREA">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="DATE_STAMP">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="MIN_REGION">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="MIN_CODE">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Easting">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Northing">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Altitude">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Measure">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Label">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Orientatio">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Length">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Area">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Key1">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="EntityId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Key">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ParentId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Track">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ClassId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="ChangeId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="UserId">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Timestamp">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Data">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="FeatureId" index="1" name=""/>
    <alias field="ID" index="2" name=""/>
    <alias field="PRCL_KEY" index="3" name=""/>
    <alias field="LSTATUS" index="4" name=""/>
    <alias field="WSTATUS" index="5" name=""/>
    <alias field="GEOM_AREA" index="6" name=""/>
    <alias field="DATE_STAMP" index="7" name=""/>
    <alias field="MIN_REGION" index="8" name=""/>
    <alias field="MIN_CODE" index="9" name=""/>
    <alias field="Easting" index="10" name=""/>
    <alias field="Northing" index="11" name=""/>
    <alias field="Altitude" index="12" name=""/>
    <alias field="Measure" index="13" name=""/>
    <alias field="Label" index="14" name=""/>
    <alias field="Orientatio" index="15" name=""/>
    <alias field="Length" index="16" name=""/>
    <alias field="Area" index="17" name=""/>
    <alias field="Key1" index="18" name=""/>
    <alias field="EntityId" index="19" name=""/>
    <alias field="Key" index="20" name=""/>
    <alias field="ParentId" index="21" name=""/>
    <alias field="Track" index="22" name=""/>
    <alias field="ClassId" index="23" name=""/>
    <alias field="ChangeId" index="24" name=""/>
    <alias field="UserId" index="25" name=""/>
    <alias field="Timestamp" index="26" name=""/>
    <alias field="Data" index="27" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="FeatureId"/>
    <default applyOnUpdate="0" expression="" field="ID"/>
    <default applyOnUpdate="0" expression="" field="PRCL_KEY"/>
    <default applyOnUpdate="0" expression="" field="LSTATUS"/>
    <default applyOnUpdate="0" expression="" field="WSTATUS"/>
    <default applyOnUpdate="0" expression="" field="GEOM_AREA"/>
    <default applyOnUpdate="0" expression="" field="DATE_STAMP"/>
    <default applyOnUpdate="0" expression="" field="MIN_REGION"/>
    <default applyOnUpdate="0" expression="" field="MIN_CODE"/>
    <default applyOnUpdate="0" expression="" field="Easting"/>
    <default applyOnUpdate="0" expression="" field="Northing"/>
    <default applyOnUpdate="0" expression="" field="Altitude"/>
    <default applyOnUpdate="0" expression="" field="Measure"/>
    <default applyOnUpdate="0" expression="" field="Label"/>
    <default applyOnUpdate="0" expression="" field="Orientatio"/>
    <default applyOnUpdate="0" expression="" field="Length"/>
    <default applyOnUpdate="0" expression="" field="Area"/>
    <default applyOnUpdate="0" expression="" field="Key1"/>
    <default applyOnUpdate="0" expression="" field="EntityId"/>
    <default applyOnUpdate="0" expression="" field="Key"/>
    <default applyOnUpdate="0" expression="" field="ParentId"/>
    <default applyOnUpdate="0" expression="" field="Track"/>
    <default applyOnUpdate="0" expression="" field="ClassId"/>
    <default applyOnUpdate="0" expression="" field="ChangeId"/>
    <default applyOnUpdate="0" expression="" field="UserId"/>
    <default applyOnUpdate="0" expression="" field="Timestamp"/>
    <default applyOnUpdate="0" expression="" field="Data"/>
  </defaults>
  <constraints>
    <constraint constraints="0" exp_strength="0" field="fid" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="FeatureId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="PRCL_KEY" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="LSTATUS" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="WSTATUS" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="GEOM_AREA" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="DATE_STAMP" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MIN_REGION" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MIN_CODE" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Easting" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Northing" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Altitude" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Measure" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Label" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Orientatio" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Length" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Area" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Key1" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="EntityId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Key" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ParentId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Track" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ClassId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ChangeId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="UserId" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Timestamp" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Data" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="FeatureId"/>
    <constraint desc="" exp="" field="ID"/>
    <constraint desc="" exp="" field="PRCL_KEY"/>
    <constraint desc="" exp="" field="LSTATUS"/>
    <constraint desc="" exp="" field="WSTATUS"/>
    <constraint desc="" exp="" field="GEOM_AREA"/>
    <constraint desc="" exp="" field="DATE_STAMP"/>
    <constraint desc="" exp="" field="MIN_REGION"/>
    <constraint desc="" exp="" field="MIN_CODE"/>
    <constraint desc="" exp="" field="Easting"/>
    <constraint desc="" exp="" field="Northing"/>
    <constraint desc="" exp="" field="Altitude"/>
    <constraint desc="" exp="" field="Measure"/>
    <constraint desc="" exp="" field="Label"/>
    <constraint desc="" exp="" field="Orientatio"/>
    <constraint desc="" exp="" field="Length"/>
    <constraint desc="" exp="" field="Area"/>
    <constraint desc="" exp="" field="Key1"/>
    <constraint desc="" exp="" field="EntityId"/>
    <constraint desc="" exp="" field="Key"/>
    <constraint desc="" exp="" field="ParentId"/>
    <constraint desc="" exp="" field="Track"/>
    <constraint desc="" exp="" field="ClassId"/>
    <constraint desc="" exp="" field="ChangeId"/>
    <constraint desc="" exp="" field="UserId"/>
    <constraint desc="" exp="" field="Timestamp"/>
    <constraint desc="" exp="" field="Data"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValuePolicy/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
