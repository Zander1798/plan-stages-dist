"""Spec tab: client PDFs, Claude's proposed parameter sheet, operator confirmation, Save revision."""
from __future__ import annotations
import json, shutil
from pathlib import Path
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QTableWidget,
                                 QTableWidgetItem, QFileDialog, QLabel, QHeaderView, QInputDialog)
from qgis.core import QgsApplication, QgsTask
from ..core.specsheet import Sheet, SheetEntry, SheetIncomplete, SPEC_KEYS, UNITS, required_keys, spec_sources, copy_sheet
from ..core.spec_claude import MEANING, propose_sheet, ProposalRefused, ProposalFailed
from ..core import deps, env as envmod, stages
from .ui import ask_yes_no, info, warn

COLS = ("key", "meaning", "proposed value", "citation", "value", "status", "confirm")
C_KEY, C_MEANING, C_PROPOSED, C_CITE, C_VALUE, C_STATUS, C_CONFIRM = range(len(COLS))
NA_WORDS = ("n/a", "na", "not applicable")


def _show(v) -> str:
    if v is None:
        return ""
    return v if isinstance(v, str) else json.dumps(v)


def _parse(text: str):
    try:
        v = json.loads(text)
    except ValueError:
        return text
    return v if isinstance(v, (int, float, bool, str)) else text


class SpecTab(QWidget):
    changed = pyqtSignal()

    def __init__(self, on_busy=None, parent=None):
        super().__init__(parent)
        self.store = self.config = None
        self.locked, self.external_busy, self.on_busy = False, False, on_busy
        self.pdfs: list[Path] = []
        self.sheet: Sheet | None = None
        self._task = None
        lay = QVBoxLayout(self)
        self.title = QLabel("No site selected"); lay.addWidget(self.title)
        self.files = QListWidget(); self.files.setMaximumHeight(90); lay.addWidget(self.files)
        bar = QHBoxLayout()
        self.add_btn = QPushButton("Add PDF…"); self.add_btn.clicked.connect(self._add_pdf_dialog)
        self.add_btn.setToolTip("Import a client standards PDF; it is read whole and the sheet is proposed from it")
        self.remove_pdf_btn = QPushButton("Remove PDF"); self.remove_pdf_btn.clicked.connect(self.remove_selected_pdf)
        self.propose_btn = QPushButton("Propose"); self.propose_btn.clicked.connect(self.propose)
        self.clear_btn = QPushButton("Clear spec…"); self.clear_btn.clicked.connect(self._clear_spec_dialog)
        self.clear_btn.setToolTip("Remove every saved spec revision and imported PDF so a new spec can be imported or typed")
        self.copy_btn = QPushButton("Copy from…"); self.copy_btn.clicked.connect(self._copy_dialog)
        self.copy_btn.setToolTip("Fill the sheet from a client template or another site's saved spec; review it, then Save revision")
        self.save_btn = QPushButton("Save revision"); self.save_btn.clicked.connect(self.save_revision)
        self.install_btn = QPushButton("Install anthropic…"); self.install_btn.clicked.connect(self.install_anthropic)
        self.install_btn.setToolTip("The PDF proposal needs the anthropic package in QGIS's Python; this runs pip to add it. "
                                    "Until then, type the values by hand.")
        for b in (self.add_btn, self.remove_pdf_btn, self.propose_btn, self.copy_btn, self.clear_btn, self.save_btn,
                  self.install_btn):
            bar.addWidget(b)
        self.install_btn.setVisible(not deps.have_anthropic())
        lay.addLayout(bar)
        self.table = QTableWidget(0, len(COLS)); self.table.setHorizontalHeaderLabels(COLS)
        self.table.horizontalHeader().setSectionResizeMode(C_MEANING, QHeaderView.ResizeMode.Stretch)
        self.table.setToolTip("Edit 'value' to state your own value; type n/a for not applicable; tick confirm to accept.")
        lay.addWidget(self.table, 1)

    # ---------------- state ----------------
    def set_site(self, store, config, locked: bool):
        self.store, self.config, self.locked = store, config, locked
        self.pdfs, self.sheet = [], None
        if store is not None:
            st = store.load()
            self.title.setText(f"{st['site']} · client {st['client']} · spec {st.get('spec_rev') or '(none)'}")
            if st.get("spec_rev"):
                rd = store.site_dir / "spec" / st["spec_rev"]
                self.pdfs = sorted((rd / "docs").glob("*.pdf"))
                if (rd / "sheet.json").exists():
                    self.sheet = Sheet.load(rd / "sheet.json")
            if self.sheet is None:
                self.sheet = Sheet.blank(st["client"])
        else:
            self.title.setText("No site selected")
        self._fill()
        self.refresh()

    def refresh(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        self.add_btn.setEnabled(usable)
        self.remove_pdf_btn.setEnabled(usable and bool(self.pdfs))
        self.clear_btn.setEnabled(usable)
        self.copy_btn.setEnabled(usable)
        self.save_btn.setEnabled(usable)
        has_key = bool(self.config and self.config.effective_api_key())
        has_pkg = deps.have_anthropic()
        self.install_btn.setVisible(not has_pkg); self.install_btn.setEnabled(usable)
        self.propose_btn.setEnabled(usable and has_key and has_pkg and bool(self.pdfs))
        self.propose_btn.setToolTip("Read the PDFs again and propose the sheet" if has_key and has_pkg else
                                    "Install the anthropic package (button to the right), then set the API key in Config…"
                                    if not has_pkg else
                                    "Set the Anthropic API key in Config… (or the ANTHROPIC_API_KEY environment variable)")
        self.table.setEnabled(self.store is not None and not self.locked)

    def _fill(self):
        self._fill_files_only()
        self.table.setRowCount(0)
        if self.sheet is None:
            return
        req = set(required_keys())
        self.table.setRowCount(len(SPEC_KEYS))
        for r, k in enumerate(SPEC_KEYS):
            e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
            cite = f"{e.document} p.{e.page}: {e.quoted_text}" if e.document and e.page else (e.document or e.note)
            cells = {C_KEY: k + ("" if k in req else " (optional)"), C_MEANING: MEANING.get(k, ""),
                     C_PROPOSED: (_show(e.value) + (f" {e.unit}" if e.unit and e.value is not None else ""))
                     if e.status in ("proposed", "confirmed") else "",
                     C_CITE: cite, C_VALUE: "n/a" if e.status == "not_applicable" else _show(e.value),
                     C_STATUS: e.status}
            for c, text in cells.items():
                it = QTableWidgetItem(text)
                if c != C_VALUE:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if c == C_KEY:
                    it.setData(Qt.ItemDataRole.UserRole, k)
                if c == C_CITE:
                    it.setToolTip(text)
                self.table.setItem(r, c, it)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            chk.setCheckState(Qt.CheckState.Checked if e.status in ("confirmed", "not_applicable")
                              else Qt.CheckState.Unchecked)
            self.table.setItem(r, C_CONFIRM, chk)

    @property
    def proposing(self) -> bool:
        return self._task is not None

    def _busy_changed(self):
        self.refresh()
        if self.on_busy is not None:
            self.on_busy()

    # ---------------- PDFs + proposal ----------------
    def _add_pdf_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Client standards", "", "PDF (*.pdf)")
        self.add_pdfs([Path(p) for p in paths])

    def add_pdfs(self, paths: list[Path]):
        """Import PDFs. Operator ruling 2026-10-07: an imported PDF is read whole at once and the sheet proposed
        from it, so its values are on the table (with page citations) ready to confirm; no key, no proposal."""
        added = False
        for p in paths:
            if p not in self.pdfs:
                self.pdfs.append(p); added = True
        self._fill_files_only()
        self.refresh()
        if added and self.pdfs:
            if self.config and self.config.effective_api_key():
                self.propose()
            else:
                warn(self, "PDF added, not read", "Set the Anthropic API key in Config… (or the ANTHROPIC_API_KEY "
                     "environment variable) and press Propose to read the PDFs and fill the sheet. You can also "
                     "type values straight into the 'value' column.")

    def remove_selected_pdf(self):
        row = self.files.currentRow()
        if row < 0 or row >= len(self.pdfs):
            return
        del self.pdfs[row]
        self._fill_files_only(); self.refresh()

    def _clear_spec_dialog(self):
        if self.store is None or self.locked:
            return
        st = self.store.load()
        if not ask_yes_no(self, "Clear spec?", f"Remove every saved spec revision of site {st['site']} (sheets and "
                          f"imported PDFs) and empty the sheet, so a new spec can be imported or typed? Every "
                          f"started stage goes stale until a new revision is saved. This cannot be undone."):
            return
        self.clear_spec()

    def clear_spec(self):
        from ..core import approval
        approval.clear_spec(self.store)
        self.pdfs, self.sheet = [], Sheet.blank(self.store.load()["client"])
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()

    def _fill_files_only(self):
        self.files.clear()
        for p in self.pdfs:
            self.files.addItem(str(p))

    def install_anthropic(self):
        """pip install anthropic into QGIS's Python through the plugin's launcher, as a background task."""
        if self._task is not None or self.config is None:
            return
        try:
            launcher = envmod.command_for(self.config, stages.get("p4_poles"), "adapters/p4_poles.py")[0]
        except Exception as e:                           # noqa: BLE001 - no QGIS found / bad config
            warn(self, "Install anthropic", f"{type(e).__name__}: {e}")
            return
        cmd = deps.pip_install_cmd(launcher)

        def work(task):
            import subprocess
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode, (r.stdout or "") + (r.stderr or ""))

        def done(exc, result=None):
            self._task = None
            if exc is not None or result is None:
                warn(self, "Install anthropic", f"pip did not run: {exc}")
            elif result[0] != 0:
                warn(self, "Install anthropic", f"pip exited {result[0]}:\n\n{result[1][-1500:]}")
            elif not deps.have_anthropic():
                warn(self, "Install anthropic", "pip reported success, but the package is not importable yet. "
                                                 "Restart QGIS, then try Propose again.")
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: pip install anthropic", work, on_finished=done)
        QgsApplication.taskManager().addTask(self._task)
        self.refresh()

    def propose(self):
        if not (self.config and self.config.effective_api_key()) or not self.pdfs or self._task is not None:
            return
        pdfs, client, key = list(self.pdfs), self.store.load()["client"], self.config.effective_api_key()

        def work(task):
            return propose_sheet(pdfs, client, key)

        def done(exception, result=None):
            self._task = None
            self._busy_changed()
            if exception is not None:
                kind = "refused" if isinstance(exception, ProposalRefused) else \
                    "failed" if isinstance(exception, ProposalFailed) else f"error ({type(exception).__name__})"
                warn(self, f"Proposal {kind}", str(exception))
            elif result is not None:
                self.sheet = result
                self._fill()
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: propose spec sheet", work, on_finished=done)
        self._busy_changed()
        QgsApplication.taskManager().addTask(self._task)

    # ---------------- copy (rollout 2026-10-12) ----------------
    def copy_sources(self) -> list[tuple[str, Path]]:
        return spec_sources(self.store.site_dir.parent, exclude_site=self.store.site) if self.store is not None else []

    def _copy_dialog(self):
        src = self.copy_sources()
        if not src:
            info(self, "Copy spec", "No template or other site with a saved spec was found.")
            return
        label, ok = QInputDialog.getItem(self, "Copy spec from", "Fill this site's sheet from:", [s[0] for s in src], 0, False)
        if ok and label:
            self.copy_from(label, dict(src)[label])
            info(self, "Spec copied", f"Filled from {label}.\nReview every value (edit or untick any that do not apply "
                                      f"to this site), then press Save revision. Nothing is saved until you do.")

    def copy_from(self, label: str, path: Path) -> None:
        """Replace the unsaved table with a copy of the sheet at `path` (marked with its source). Not saved."""
        self.sheet = copy_sheet(Sheet.load(path), self.store.load()["client"], label)
        self._fill()

    # ---------------- save ----------------
    def _sheet_from_table(self) -> Sheet:
        st = self.store.load()
        out = Sheet(st["client"], "", {})
        for r in range(self.table.rowCount()):
            k = self.table.item(r, C_KEY).data(Qt.ItemDataRole.UserRole)
            e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
            text = (self.table.item(r, C_VALUE).text() if self.table.item(r, C_VALUE) else "").strip()
            ticked = self.table.item(r, C_CONFIRM).checkState() == Qt.CheckState.Checked
            entry = SheetEntry(**{**e.__dict__})
            out.entries[k] = entry
            if not ticked:
                if entry.status == "confirmed":
                    entry.status = "proposed"            # un-ticking withdraws the confirmation
                continue
            if text.lower() in NA_WORDS:
                out.mark_not_applicable(k)
            elif not text:
                continue                                 # ticked but empty: stays unresolved
            elif text == _show(e.value) and e.status in ("proposed", "confirmed"):
                entry.status = "confirmed"
            else:
                out.set_operator(k, _parse(text), "entered in the Plan Stages dock")
        return out

    def save_revision(self) -> str | None:
        """Write spec/rev-NNN/{docs,sheet.json}; mark every non-pending stage stale. Returns the rev or None."""
        sheet = self._sheet_from_table()
        missing = sheet.unresolved(required_keys())
        if missing:
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(missing))
            return None
        base = self.store.site_dir / "spec"
        base.mkdir(parents=True, exist_ok=True)
        existing = sorted(p.name for p in base.glob("rev-*") if p.is_dir())
        rev = f"rev-{(int(existing[-1][4:]) + 1 if existing else 1):03d}"
        rd = base / rev
        (rd / "docs").mkdir(parents=True)
        sheet.rev = rev
        try:
            sheet.save(rd / "sheet.json", required_keys())
        except SheetIncomplete as e:
            shutil.rmtree(rd, ignore_errors=True)
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(e.keys))
            return None
        for p in self.pdfs:
            if p.exists():
                shutil.copy2(p, rd / "docs" / p.name)
        self.store.save_spec_revision(rev)
        info(self, "Spec saved", f"Saved {rev}. Every stage already started is now stale.")
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()
        return rev
