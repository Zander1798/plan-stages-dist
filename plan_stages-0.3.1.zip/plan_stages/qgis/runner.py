from __future__ import annotations
import subprocess
from pathlib import Path
from qgis.core import QgsTask


def _kill_tree(proc):
    try:
        subprocess.call(["taskkill", "/T", "/F", "/PID", str(proc.pid)], creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception:
        pass
    try:
        proc.kill()
    except Exception:
        pass


class SubprocessTask(QgsTask):
    def __init__(self, desc: str, cmd: list[str], env: dict, log_path: Path, on_done):
        super().__init__(desc, QgsTask.Flag.CanCancel)
        self.cmd, self.env, self.log_path, self.on_done = cmd, env, log_path, on_done
        self.rc, self.text, self._proc = -1, "", None

    def run(self) -> bool:
        with open(self.log_path, "w", encoding="utf-8") as log:
            self._proc = subprocess.Popen(self.cmd, env=self.env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                          text=True, encoding="utf-8", errors="replace", creationflags=subprocess.CREATE_NO_WINDOW,
                                          cwd=str(Path(self.cmd[1]).parent))
            for line in self._proc.stdout:
                log.write(line); self.text += line
                if self.isCanceled():
                    _kill_tree(self._proc); break
            self.rc = self._proc.wait()
        return self.rc == 0

    def finished(self, result: bool) -> None:
        self.on_done(self.rc, self.text)

    def cancel(self) -> None:
        if self._proc and self._proc.poll() is None:
            _kill_tree(self._proc)
        super().cancel()
