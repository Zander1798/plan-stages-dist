"""Where the project's data is, for the New site CRS suggestion (core/sitecrs.py)."""
from __future__ import annotations
from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsRectangle, QgsVectorLayer


def project_longitude(project) -> float | None:
    """Centre longitude (WGS84) of the combined extent of the project's vector layers with a valid CRS; None
    when there are none."""
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    box = QgsRectangle(); box.setNull()
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.crs().isValid() or lyr.featureCount() == 0:
            continue
        e = lyr.extent()
        if e.isEmpty() and not (e.width() == 0 and e.height() == 0 and lyr.featureCount() == 1):
            continue
        try:
            e = QgsCoordinateTransform(lyr.crs(), wgs, project).transformBoundingBox(e)
        except Exception:                                # noqa: BLE001 - an untransformable layer just doesn't count
            continue
        if box.isNull():
            box = QgsRectangle(e)
        else:
            box.combineExtentWith(e)
    return None if box.isNull() else box.center().x()
