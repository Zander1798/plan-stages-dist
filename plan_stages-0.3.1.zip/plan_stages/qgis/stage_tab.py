"""One tab of stage rows (Generate / Check / Approve / Reject / Revise, plus Load after a restart) and the
selected stage's logs and issues."""
from __future__ import annotations
from pathlib import Path
from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QGridLayout, QLabel, QPushButton, QRadioButton,
                                 QButtonGroup, QPlainTextEdit, QListWidgetItem, QSplitter)
from qgis.core import QgsApplication
from ..core import stages
from ..core.checks import ChecksReport, Issue
from . import layers
from .issue_list import IssueList
from .runner import SubprocessTask
from .ui import ask_yes_no, ask_note, badge_style, tail, warn

BUTTONS = ("generate", "check", "approve", "reject", "revise", "remove")
LOGS = ("run.log", "check.log")          # generator output, then the last Check's output


class StageTab(QWidget):
    changed = pyqtSignal()          # any flow finished: the dock re-evaluates every tab

    def __init__(self, iface, stage_ids: list[str], on_busy=None, parent=None):
        super().__init__(parent)
        self.iface, self.stage_ids, self.on_busy = iface, list(stage_ids), on_busy
        self.controller = self.store = None
        self.wayleave_layer = None       # set by the dock: name -> the project's wayleave layer the operator chose
        self.locked, self.busy = False, False
        self._saving_for = None          # stage whose edits the tab itself is committing (Check/Approve): no auto re-check
        self._tasks: list = []           # keep QgsTasks alive until finished
        self.selected = self.stage_ids[0] if self.stage_ids else None
        self._build()

    # ---------------- layout ----------------
    def _build(self):
        outer = QVBoxLayout(self)
        rows = QWidget(); grid = QGridLayout(rows); grid.setContentsMargins(0, 0, 0, 0)
        self.sel_group = QButtonGroup(self); self.sel_group.setExclusive(True)
        self.rows: dict[str, dict] = {}
        for r, sid in enumerate(self.stage_ids):
            radio = QRadioButton(stages.get(sid).name); radio.setChecked(sid == self.selected)
            radio.toggled.connect(lambda on, s=sid: on and self.select(s))
            self.sel_group.addButton(radio)
            badge = QLabel("-"); badge.setAlignment(Qt.AlignmentFlag.AlignCenter); badge.setMinimumWidth(70)
            grid.addWidget(radio, r, 0); grid.addWidget(badge, r, 1)
            row = {"radio": radio, "badge": badge}
            for c, name in enumerate(BUTTONS):
                b = QPushButton(name.capitalize()); b.setEnabled(False)
                b.clicked.connect(lambda _=False, s=sid, n=name: getattr(self, n)(s))
                grid.addWidget(b, r, 2 + c); row[name] = b
            load = QPushButton("Load"); load.setToolTip("Load this stage's current revision into the project")
            load.clicked.connect(lambda _=False, s=sid: self.load(s)); load.hide()
            grid.addWidget(load, r, 2 + len(BUTTONS)); row["load"] = load
            self.rows[sid] = row
        outer.addWidget(rows)
        split = QSplitter(Qt.Orientation.Vertical)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setPlaceholderText("run.log and check.log of the selected stage")
        self.issues = IssueList(self.iface, self._resolve_issue)
        split.addWidget(self.log); split.addWidget(self.issues)
        outer.addWidget(split, 1)

    # ---------------- state ----------------
    def set_site(self, controller, store, locked: bool):
        self.controller, self.store, self.locked = controller, store, locked
        self.busy = False
        self.refresh()

    def refresh(self):
        """Every button state comes from controller.next_enabled; re-run after every flow."""
        usable = self.controller is not None and not self.locked and not self.busy
        state = self.store.load()["stages"] if self.controller is not None else {}
        for sid, row in self.rows.items():
            status = state.get(sid, {}).get("status", "-")
            row["badge"].setText(status); row["badge"].setStyleSheet(badge_style(status)); row["badge"].setToolTip("")
            try:                                           # one bad row must never freeze the whole tab
                en = self.controller.next_enabled(sid) if usable else {}
            except Exception as e:                         # noqa: BLE001
                en = {}
                row["badge"].setToolTip(f"{type(e).__name__}: {e}")
            for name in BUTTONS:
                row[name].setEnabled(bool(en.get(name)))
            try:
                self._update_load(sid, row, state.get(sid, {}), usable)
            except Exception:                              # noqa: BLE001
                row["load"].hide()
        try:
            self._show_selected()
        except Exception as e:                             # noqa: BLE001
            self.log.setPlainText(f"could not show the selected stage: {type(e).__name__}: {e}")

    def _update_load(self, sid: str, row: dict, s: dict, usable: bool):
        """After a restart the project may not hold a stage's current revision: offer Load (never auto-load)."""
        rev = self.store.rev_dir(sid, s["current_rev"]) if self.store is not None and s.get("current_rev") else None
        need = (rev is not None and (rev / "working.gpkg").exists()
                and layers.find_stage_group(self.store.site, stages.get(sid), rev.name) is None)
        row["load"].setVisible(bool(need))
        row["load"].setEnabled(bool(need) and usable)

    def load(self, stage_id: str):
        stage, store = stages.get(stage_id), self.store
        rev = self._rev(stage_id)
        if rev is None:
            return
        editable = store.stage_state(stage_id)["status"] != "approved"
        self._complete(stage_id, f"{stage.name}: load",
                       lambda: self._load_layers(stage_id, store.site, stage, rev, editable=editable))

    def _load_layers(self, stage_id: str, site: str, stage, rev: Path, editable: bool):
        grp = layers.load_stage(self.iface, site, stage, rev, editable=editable)
        layers.on_commit(layers.group_layers(grp), lambda s=stage_id: self._saved(s))
        return grp

    def _saved(self, stage_id: str):
        """A stage layer was saved by the operator: re-run its Check so fixed errors disappear and the fresh
        checks make Approve available (ruling 2026-10-08). Not when the tab itself is saving for Check/Approve."""
        if self._saving_for == stage_id or self.busy or self.locked or self.controller is None:
            return
        if self.store.stage_state(stage_id)["status"] in ("approved", "pending"):
            return
        QTimer.singleShot(0, lambda: None if self.busy else self.check(stage_id))

    def select(self, stage_id: str):
        self.selected = stage_id
        self._show_selected()

    def _rev(self, stage_id: str, store=None) -> Path | None:
        store = store or self.store
        if store is None:
            return None
        cur = store.stage_state(stage_id)["current_rev"]
        return store.rev_dir(stage_id, cur) if cur else None

    def _group(self, stage_id: str, store=None):
        store = store or self.store
        rev = self._rev(stage_id, store)
        return layers.find_stage_group(store.site, stages.get(stage_id), rev.name) if rev else None

    def _show_selected(self):
        self.log.clear(); self.issues.clear()
        rev = self._rev(self.selected) if self.selected else None
        if rev is None:
            return
        parts = [f"===== {n} =====\n" + (rev / n).read_text(encoding="utf-8", errors="replace")
                 for n in LOGS if (rev / n).exists()]
        self.log.setPlainText("\n".join(parts) if parts else "(no run.log or check.log)")
        cj = rev / "checks.json"
        if not cj.exists():
            return
        try:
            report = ChecksReport.load(cj)
        except Exception as e:                           # noqa: BLE001 - a bad file must not break the tab
            self.issues.addItem(QListWidgetItem(f"checks.json unreadable: {type(e).__name__}: {e}"))
            return
        self.issues.set_report(report)

    def _resolve_issue(self, issue: Issue):
        """The loaded layer an issue of the selected stage lives in: this stage's group for source "working", else
        the loaded group of the dependency stage it names; a wayleave issue falls back to the project layer the
        operator chose in the Wayleave box."""
        if self.store is None or self.selected is None:
            return None
        if issue.source == "working":
            grp = self._group(self.selected)
        else:
            grp = layers.find_stage_group(self.store.site, stages.get(issue.source)) if issue.source in stages.order() else None
        if grp is not None:
            for child in grp.findLayers():
                if child.layer() is not None and child.layer().name() == issue.layer:
                    return child.layer()
        if issue.source == "wayleave" and self.wayleave_layer is not None:
            return self.wayleave_layer(issue.layer)
        return None

    def _set_busy(self, busy: bool):
        self.busy = busy
        try:
            self.refresh()
        finally:
            if self.on_busy is not None:
                self.on_busy()

    def _flow_done(self, stage_id: str):
        self.selected = stage_id
        try:
            self.rows[stage_id]["radio"].setChecked(True)
        finally:
            try:
                self._set_busy(False)
            finally:
                self.changed.emit()

    def _complete(self, stage_id: str, title: str, body):
        """Run a completion body; any exception is shown and the tab always recovers."""
        try:
            body()
        except Exception as e:                           # noqa: BLE001 - never leave the tab wedged
            warn(self, title, f"{type(e).__name__}: {e}")
        finally:
            self._flow_done(stage_id)

    def _launch(self, desc, cmd, env, log_path, on_done):
        task = None

        def done(rc, text):
            if task in self._tasks:
                self._tasks.remove(task)
            on_done(rc, text)
        task = SubprocessTask(desc, cmd, env, log_path, done)
        self._tasks.append(task)
        self._set_busy(True)
        QgsApplication.taskManager().addTask(task)

    def cancel_tasks(self):
        for task in list(self._tasks):
            task.cancel()

    # ---------------- Generate ----------------
    def generate(self, stage_id: str):
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store          # completions bind to the site that launched them
        if stage.generator is None:                       # a manual re-generate copies the saved drawing
            grp = self._group(stage_id)
            if grp is not None and layers.has_unsaved_edits(grp):
                warn(self, f"{stage.name}: generate", "The layers have unsaved edits. Save or discard them first.")
                return
            if not self._flush(stage_id, "generate"):
                return
        try:
            rev, cmd, env = ctl.begin_generate(stage_id)
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            warn(self, f"{stage.name}: generate", f"{type(e).__name__}: {e}")
            self.refresh()
            return
        if cmd is None:                                   # manual stage: editable layers (seeded after rev 1)
            self._complete(stage_id, f"{stage.name}: generate",
                           lambda: self._load_layers(stage_id, store.site, stage, rev, editable=True))
            return
        self._launch(f"{store.site}: generate {stage.name}", cmd, env, rev / "run.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: generate",
                                                     lambda: self._generate_result(ctl, store, stage_id, rev, rc, text)))

    def _generate_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str):
        stage = stages.get(stage_id)
        if ctl.finish_generate(stage_id, rev, rc, log):
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        else:
            warn(self, f"{stage.name}: generate failed", f"rc={rc}\n\n{tail(log)}")

    # ---------------- Check ----------------
    def check(self, stage_id: str):
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        grp = self._group(stage_id)
        if grp is not None and not layers.save_all_edits(grp):
            warn(self, f"{stage.name}: check", "Saving the layer edits failed; fix the edits and Check again.")
            return
        if not self._flush(stage_id, "check"):
            return
        try:
            rev, cmd, env = ctl.begin_check(stage_id)     # hashes working.gpkg as the Check starts
        except Exception as e:                            # noqa: BLE001 - e.g. a busy GeoPackage
            warn(self, f"{stage.name}: check", f"{type(e).__name__}: {e}")
            return
        start = ctl.check_start.get(stage_id)
        cj = rev / "checks.json"                          # never let an old report stand in for this run
        if cj.exists():
            cj.unlink()
        store.set_stage(stage_id, checked_hash=None)
        self._launch(f"{store.site}: check {stage.name}", cmd, env, rev / "check.log",
                     lambda rc, text: self._complete(stage_id, f"{stage.name}: check",
                                                     lambda: self._check_result(ctl, store, stage_id, rev, rc, text,
                                                                                start)))

    def _check_result(self, ctl, store, stage_id: str, rev: Path, rc: int, log: str, start: str | None = None):
        stage = stages.get(stage_id)
        cj = rev / "checks.json"
        # rc != 0 with blocking checks in checks.json is a normal failing check (checks/common.main exits 1).
        # rc != 0 with no report, or with a report claiming success, is a crashed check: never trust it.
        report = ChecksReport.load(cj) if cj.exists() else None
        if rc != 0 and (report is None or report.ok()):
            if cj.exists():
                cj.unlink()
            warn(self, f"{stage.name}: check failed", f"The check exited rc={rc} without a usable checks.json.\n\n"
                                                      f"{tail(log)}")
            return
        report = ctl.finish_check(stage_id, rev, rc, log, start_hash=start)
        if report is None:                               # no checks.json: the check itself failed
            warn(self, f"{stage.name}: check failed", f"The check wrote no checks.json (rc={rc}).\n\n{tail(log)}")
            return
        if ctl.last_warning:
            warn(self, f"{stage.name}: check", ctl.last_warning)
        layers.load_issues(self.iface, store.site, stage, rev)

    def _flush(self, stage_id: str, what: str) -> bool:
        rev = self._rev(stage_id)
        if rev is None or layers.flush_wal(rev / "working.gpkg"):
            return True
        warn(self, f"{stages.get(stage_id).name}: {what}",
             "Could not checkpoint working.gpkg (another program is writing it). Try again.")
        return False

    # ---------------- Approve / Reject ----------------
    def approve(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            note = ask_note(self, f"Approve {stage.name}", "Approval note (required):")
            if note is None:
                return
        if not note.strip():
            warn(self, f"Approve {stage.name}", "An approval note is required.")
            return
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            warn(self, f"Approve {stage.name}", "The layers have unsaved edits. Check again (it saves them) first.")
            return
        if not self._flush(stage_id, "approve"):
            return

        def body():
            refusals = self.controller.approve(stage_id, note.strip())
            if refusals:
                checks, hard = self.controller.approve_blockers(stage_id)
                if hard or not checks:
                    warn(self, f"Approve {stage.name} refused", "\n".join(refusals))
                    return
                # Operator ruling 2026-10-07: failed checks ask, they do not block. The override is recorded.
                if not ask_yes_no(self, f"Approve {stage.name} anyway?",
                                  "These checks fail:\n\n" + "\n".join(checks) +
                                  "\n\nApprove anyway? Your note is recorded as the reason in approval.json."):
                    return
                refusals = self.controller.approve(stage_id, note.strip(), override=note.strip())
                if refusals:
                    warn(self, f"Approve {stage.name} refused", "\n".join(refusals))
                    return
            grp_now = self._group(stage_id)
            if grp_now is not None:                       # approved layers are a record; Revise to change them
                layers.set_group_readonly(grp_now, True)
        self._complete(stage_id, f"Approve {stage.name}", body)

    # ---------------- Revise ----------------
    def revise(self, stage_id: str):
        """Rev N+1 = an editable copy of the latest approved layer (else the current working layer)."""
        stage = stages.get(stage_id)
        ctl, store = self.controller, self.store
        grp = self._group(stage_id)
        if grp is not None and layers.has_unsaved_edits(grp):
            warn(self, f"Revise {stage.name}", "The layers have unsaved edits. Save or discard them first.")
            return
        if not self._flush(stage_id, "revise"):
            return

        def body():
            rev = ctl.begin_revise(stage_id)
            self._load_layers(stage_id, store.site, stage, rev, editable=True)
        self._complete(stage_id, f"Revise {stage.name}", body)

    # ---------------- Remove ----------------
    def remove(self, stage_id: str, confirmed: bool = False):
        """Operator ruling 2026-10-07: delete the stage's current revision and its layers from the project.
        The stage falls back to its previous revision, or to pending; downstream built on it goes stale."""
        stage, store = stages.get(stage_id), self.store
        s = store.stage_state(stage_id)
        cur = s.get("current_rev")
        if not cur:
            return
        remaining = sorted(p.name for p in (store.site_dir / stage_id).glob("rev-*") if p.is_dir() and p.name != cur)
        after = (f"The stage goes back to {remaining[-1]}." if remaining else "The stage goes back to pending.")
        downstream = [stages.get(d).name for d in stages.downstream_of(stage_id)
                      if store.stage_state(d)["status"] != "pending"]
        extra = ("\n\nThis revision is the approved one; these stages were built on it and become stale:\n"
                 + "\n".join(downstream)) if s.get("approved_rev") == cur and downstream else ""
        if not confirmed and not ask_yes_no(self, f"Remove {stage.name} {cur}?",
                                            f"Delete {stage.name} {cur} from disk and its layers from the project? "
                                            f"This cannot be undone. {after}{extra}"):
            return

        def body():
            layers.unload_stage(store.site, stage)
            self.controller.remove(stage_id)
        self._complete(stage_id, f"Remove {stage.name}", body)

    def reject(self, stage_id: str, note: str | None = None):
        stage = stages.get(stage_id)
        if note is None:
            note = ask_note(self, f"Reject {stage.name}", "Rejection note:")
            if note is None:
                return
        self._complete(stage_id, f"Reject {stage.name}", lambda: self.controller.reject(stage_id, note))

