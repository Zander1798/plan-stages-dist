"""The Help tab: help/help.md, what an operator needs before and while using the plugin (design approved
2026-10-13). The dock opens on it the first time the plugin is opened; a QgsSettings flag remembers that."""
from __future__ import annotations
from pathlib import Path
from qgis.core import QgsSettings
from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QTextBrowser

HELP_MD = Path(__file__).resolve().parents[1] / "help" / "help.md"
SEEN_KEY = "plan_stages/help_seen"


def help_seen() -> bool:
    return QgsSettings().value(SEEN_KEY, False, type=bool)


def mark_help_seen() -> None:
    QgsSettings().setValue(SEEN_KEY, True)


class HelpTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        try:
            self.browser.setMarkdown(HELP_MD.read_text(encoding="utf-8"))
        except OSError as e:
            self.browser.setPlainText(f"The help page is missing ({e}). Reinstall the plugin.")
        lay.addWidget(self.browser)
