"""Take the operator to an issue: resolve it to a feature of a loaded layer, zoom there, select it, make its layer
active (so Edit is one click away) and flash it."""
from __future__ import annotations
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeatureRequest, QgsGeometry,
                       QgsPointXY, QgsProject, QgsRectangle, QgsWkbTypes)
from ..core.checks import Issue
from ..core.layermatch import source_field

NEAREST_M = 2.0            # an issue with no FID picks the feature within this many layer units of its point
MIN_HALF_M = 20.0          # the view is never narrower than this around a located feature


def _transform(pt: QgsPointXY, src_epsg: int, dest: QgsCoordinateReferenceSystem) -> QgsPointXY:
    src = QgsCoordinateReferenceSystem(f"EPSG:{src_epsg}")
    if src.isValid() and dest.isValid() and src != dest:
        return QgsCoordinateTransform(src, dest, QgsProject.instance()).transform(pt)
    return pt


def issue_point(issue: Issue, dest: QgsCoordinateReferenceSystem) -> QgsPointXY:
    return _transform(QgsPointXY(issue.x, issue.y), issue.epsg, dest)


def _by_match(layer, match: str):
    """The feature whose attribute equals the issue's "field=value" (the field found by the Wayleave box's own
    name/alias rules, so an operator layer calling it `pon` still works); None when no field or no feature fits."""
    field, _, value = match.partition("=")
    names = [f.name() for f in layer.fields()]
    i, _how = source_field(field, names)
    if i < 0:
        return None
    for f in layer.getFeatures():
        v = f.attribute(i)
        if v is not None and str(v).strip() != "" and str(v).strip().split(".")[0] == value:
            return f
    return None


def find_feature(layer, issue: Issue):
    """The layer feature an issue names: by FID, else by its `match` attribute (a PON by number -- Ventersdorp PON 14's
    point lay in PON 44 and the click went there, 2026-10-12), else the one nearest its point within NEAREST_M."""
    if issue.fid is not None and issue.fid >= 0:
        f = layer.getFeature(issue.fid)
        if f.isValid():
            return f
    if getattr(issue, "match", ""):
        f = _by_match(layer, issue.match)
        if f is not None:
            return f
    p = issue_point(issue, layer.crs())
    tol = NEAREST_M if not layer.crs().isGeographic() else NEAREST_M / 111_000.0
    rect = QgsRectangle(p.x() - tol, p.y() - tol, p.x() + tol, p.y() + tol)
    best, best_d = None, float("inf")
    for f in layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
        d = f.geometry().distance(QgsGeometry.fromPointXY(p))
        if d < best_d:
            best, best_d = f, d
    return best


def is_polygon(layer) -> bool:
    return QgsWkbTypes.geometryType(layer.wkbType()) == QgsWkbTypes.GeometryType.PolygonGeometry


def go_to(iface, layer, fids: list[int], point: QgsPointXY | None) -> None:
    """Zoom the canvas to the given features of `layer` (or to `point` when there are none), select them, make the
    layer active and flash them. `point` is in the canvas CRS when `layer` is None, else in the layer CRS."""
    canvas = iface.mapCanvas()
    dest = canvas.mapSettings().destinationCrs()
    half = MIN_HALF_M if not dest.isGeographic() else MIN_HALF_M / 111_000.0
    if layer is not None and fids:
        rect = QgsRectangle()
        for f in layer.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))):
            rect.combineExtentWith(f.geometry().boundingBox())
        if layer.crs() != dest:
            rect = QgsCoordinateTransform(layer.crs(), dest, QgsProject.instance()).transformBoundingBox(rect)
        c = rect.center()
        rect.combineExtentWith(QgsRectangle(c.x() - half, c.y() - half, c.x() + half, c.y() + half))
        rect.grow(max(rect.width(), rect.height()) * 0.15)
        # Points and lines stay selected (the edit is one click away). A selected POLYGON fills with the selection
        # colour and hides everything inside it (operator, 2026-10-08, on a PON): flash it, do not leave it selected.
        layer.selectByIds([] if is_polygon(layer) else list(fids))
        iface.setActiveLayer(layer)
        canvas.setExtent(rect)
        canvas.refresh()
        try:
            canvas.flashFeatureIds(layer, list(fids))
        except AttributeError:                           # a canvas without flashing (stub or old QGIS)
            pass
        return
    if point is None:
        return
    canvas.setExtent(QgsRectangle(point.x() - half, point.y() - half, point.x() + half, point.y() + half))
    canvas.refresh()
