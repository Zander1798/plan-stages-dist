"""The clickable issues list under a stage (and in the Wayleave box): one header row per check with something to
say, its located issues indented under it, and a footer for what the cap dropped. Clicking an issue takes the
operator to that feature (zoom, select, activate the layer, flash); clicking a header selects every located
feature of that check at once."""
from __future__ import annotations
from typing import Callable, Optional
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont, QColor
from qgis.PyQt.QtWidgets import QListWidget, QListWidgetItem
from ..core.checks import ChecksReport, Issue
from ..core.issues import group_report
from . import locate

ROLE = Qt.ItemDataRole.UserRole


class IssueList(QListWidget):
    def __init__(self, iface, resolve: Callable[[Issue], Optional[object]], parent=None):
        """`resolve(issue)` returns the loaded QgsVectorLayer the issue lives in, or None."""
        super().__init__(parent)
        self.iface, self.resolve = iface, resolve
        self.groups = []
        self._selected: list = []        # layers the last click selected on; cleared before the next click
        self._watched: list = []         # (layer, signal, slot) connected for live edit marking
        self._rows: dict = {}            # (layer id, fid) -> [QListWidgetItem]
        self.itemClicked.connect(self._clicked)
        self.setToolTip("Click an issue to go to it on the map; click a check's header to select every feature it flags")

    # ---------------- content ----------------
    def set_report(self, report: ChecksReport | None) -> None:
        self._unwatch()
        self.clear(); self.groups = []; self._rows = {}
        if report is None:
            return
        self.groups = group_report(report)
        bold = QFont(); bold.setBold(True)
        for gi, g in enumerate(self.groups):
            h = QListWidgetItem(g.title); h.setFont(bold); h.setData(ROLE, ("group", gi))
            if g.issues:
                h.setToolTip(f"{len(g.issues)} located; click to select them all")
            self.addItem(h)
            for ii, i in enumerate(g.issues):
                it = QListWidgetItem(f"    {i.severity} {i.code}: {i.message}")
                it.setData(ROLE, ("issue", gi, ii))
                it.setToolTip(f"{i.layer or 'no layer'} fid {i.fid}" + (f" ({i.source})" if i.source != "working" else ""))
                self.addItem(it)
                self._index(i, it)
        if self.groups.dropped:
            self.addItem(QListWidgetItem(f"{self.groups.dropped} more issues not listed (cap)"))

    # ---------------- live edit marking (operator ruling 2026-10-08: fixed errors disappear) ----------------
    def _index(self, issue: Issue, item) -> None:
        """Remember which row belongs to which loaded feature, and watch that layer's edit buffer. The row is
        marked the moment the operator edits or deletes the feature; the save re-check then removes it for real."""
        if issue.fid is None or issue.fid < 0:
            return
        layer = self.resolve(issue)
        if layer is None:
            return
        self._rows.setdefault((layer.id(), int(issue.fid)), []).append(item)
        if not any(l is layer for l, _, _ in self._watched):
            for sig, slot in (("geometryChanged", lambda fid, _g, l=layer: self._mark(l, fid, "edited")),
                              ("featureDeleted", lambda fid, l=layer: self._mark(l, fid, "deleted")),
                              ("afterRollBack", lambda l=layer: self._unmark(l))):
                getattr(layer, sig).connect(slot); self._watched.append((layer, sig, slot))

    def _unwatch(self) -> None:
        for layer, sig, slot in self._watched:
            try:
                getattr(layer, sig).disconnect(slot)
            except (TypeError, RuntimeError):            # layer removed from the project meanwhile
                pass
        self._watched = []

    def _mark(self, layer, fid: int, what: str) -> None:
        for it in self._rows.get((layer.id(), int(fid)), []):
            base = it.data(ROLE + 1) or it.text()
            it.setData(ROLE + 1, base)
            it.setText(f"{base}   ({what}; confirmed when the layer is saved)")
            f = it.font(); f.setStrikeOut(True); it.setFont(f); it.setForeground(QColor("#8a8a8a"))

    def _unmark(self, layer) -> None:
        for (lid, _fid), items in self._rows.items():
            if lid != layer.id():
                continue
            for it in items:
                base = it.data(ROLE + 1)
                if base:
                    it.setText(base); f = it.font(); f.setStrikeOut(False); it.setFont(f); it.setData(ROLE + 1, None)
                    it.setForeground(QColor())

    def prepend(self, text: str) -> None:
        """An inert notice row at the top (approval refused, override recorded, ...)."""
        self.insertItem(0, QListWidgetItem(text))

    # ---------------- navigation ----------------
    def _clear_previous_selection(self) -> None:
        """What the previous click selected stays yellow on the map until it is cleared (operator, 2026-10-08)."""
        for layer in self._selected:
            try:
                layer.removeSelection()
            except RuntimeError:                         # layer gone
                pass
        self._selected = []

    def _clicked(self, item):
        data = item.data(ROLE)
        if not data:
            return
        self._clear_previous_selection()
        if data[0] == "issue":
            self._go_issue(self.groups[data[1]].issues[data[2]])
        elif data[0] == "group":
            self._go_group(self.groups[data[1]])

    def _go_issue(self, issue: Issue):
        layer = self.resolve(issue)
        f = locate.find_feature(layer, issue) if layer is not None else None
        if f is not None:
            locate.go_to(self.iface, layer, [f.id()], None); self._selected.append(layer)
        else:
            dest = self.iface.mapCanvas().mapSettings().destinationCrs()
            locate.go_to(self.iface, None, [], locate.issue_point(issue, dest))

    def _go_group(self, group):
        found: dict = {}                                 # layer id -> (layer, [fids])
        for i in group.issues:
            layer = self.resolve(i)
            f = locate.find_feature(layer, i) if layer is not None else None
            if f is not None:
                found.setdefault(layer.id(), (layer, []))[1].append(f.id())
        if not found:
            if group.issues:
                self._go_issue(group.issues[0])
            return
        layer, fids = max(found.values(), key=lambda v: len(v[1]))   # one layer gets the selection and the view
        for other, ofids in found.values():
            if other is not layer and not locate.is_polygon(other):   # a selected polygon hides its contents
                other.selectByIds(ofids); self._selected.append(other)
        locate.go_to(self.iface, layer, sorted(set(fids)), None); self._selected.append(layer)
