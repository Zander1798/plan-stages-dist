"""P6 adapter (pyqgis launcher): assemble the approved plan, build the QGIS project and render images.

Needs PLAN_DIR/step3, step4 and a combined step567/claude_step567.gpkg rebuilt from the approved
P3/P4/P5 layers, then runs build_qgis_project.py and render_wayleave_plan.py. generated.gpkg stays empty.
Title-block metrics are recomputed from the approved layers. Exits non-zero if either script fails or the
project / render images are missing.
"""
import json, math, os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import (site_dir, run_step, copy_layer, approved, materialise_p1,
                                               materialise_p2, empty_gpkg, transform as osr_transform,
                                               layer_epsg)
from osgeo import ogr


def _len_m(path, layer, epsg):
    ds = ogr.Open(str(path)); lyr = ds.GetLayerByName(layer)
    t = osr_transform(layer_epsg(lyr, 4326), epsg); total = 0.0
    for f in lyr:
        g = f.GetGeometryRef()
        parts = [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]
        for p in parts:
            pts = [t.TransformPoint(p.GetX(i), p.GetY(i))[:2] for i in range(p.GetPointCount())]
            total += sum(math.dist(a, b) for a, b in zip(pts[:-1], pts[1:]))
    return total


def _count(path, layer):
    ds = ogr.Open(str(path))          # keep the datasource alive while the layer is used
    return ds.GetLayerByName(layer).GetFeatureCount()


def write_metrics(rev, epsg):
    """Title-block totals recomputed from the APPROVED layers (the delivery scripts read these keys)."""
    p1, p2, p3, p4, p5 = (approved(s) for s in ("p1_feeder", "p2_drops", "p3_crossings", "p4_poles", "p5_hardware"))
    src = "approved layers"
    out = {
        "step3/step3_metrics.json": {"distribution_m": round(_len_m(p1, "distribution", epsg)),
                                     "feeder_m": round(_len_m(p1, "feeder", epsg)),
                                     "splitters": _count(p1, "splitters_1to16"), "source": src},
        "step4/step4_metrics.json": {"total_drop_m": round(_len_m(p2, "drops", epsg)), "drops": _count(p2, "drops"),
                                     "collection_points": _count(p2, "collection_points"), "source": src},
        "step567/step567_metrics.json": {"crossings": _count(p3, "road_crossings"), "poles_total": _count(p4, "poles"),
                                         "splitters": _count(p5, "splitters_8way"),
                                         "dome_joints": _count(p5, "dome_joints"), "source": src},
    }
    for rel, d in out.items():
        (rev / rel).parent.mkdir(exist_ok=True)
        (rev / rel).write_text(json.dumps(d, indent=2), encoding="utf-8")
    print("metrics from approved layers:", json.dumps(out))


def main():
    rev = Path(os.environ["PS_REV_DIR"]); epsg = int(os.environ["PS_EPSG"]); site = os.environ["PS_SITE"]
    site_dir()
    empty_gpkg(rev / "generated.gpkg", epsg)
    materialise_p1(rev); materialise_p2(rev)
    s5 = rev / "step567"; s5.mkdir(exist_ok=True)
    dst = s5 / "claude_step567.gpkg"
    if dst.exists():
        dst.unlink()
    copy_layer(approved("p3_crossings"), "road_crossings", dst, "claude_road_crossings")
    copy_layer(approved("p4_poles"), "poles", dst, "claude_poles")
    h = approved("p5_hardware")
    copy_layer(h, "splitters_8way", dst, "claude_8way_splitters")
    copy_layer(h, "dome_joints", dst, "claude_dome_joints")
    write_metrics(rev, epsg)
    first_rc = 0
    for script in ("build_qgis_project.py", "render_wayleave_plan.py"):
        rc = run_step(script, {"TAG": "plan"})
        if rc:
            print(f"{script} exited {rc}")
            first_rc = first_rc or rc
    proj = rev / "qgis" / f"{site}_plan.qgz"
    pngs = list((rev / "render").glob("*.png")) if (rev / "render").exists() else []
    print(f"qgis project: {'written' if proj.exists() else 'MISSING'}; render images: {len(pngs)}")
    if first_rc:
        return first_rc
    if not proj.exists() or not pngs:
        print("P6 FAILED: project or render output missing")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
