"""Gate 0 adapter: run the Step 0 wayleave gate. A FAIL verdict fails the generation."""
import os, shutil, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, empty_gpkg


def main():
    rev = Path(os.environ["PS_REV_DIR"]); epsg = int(os.environ["PS_EPSG"]); site = os.environ["PS_SITE"]
    site_dir()
    rc = run_step("step0_wayleave.py")
    j = rev / "step0" / f"wayleave_{site}.json"
    if j.exists():
        shutil.copyfile(j, rev / j.name)
    if rc:
        print(f"GATE FAILED (exit {rc}); read {j.name} and the log above")
        return rc
    empty_gpkg(rev / "generated.gpkg", epsg)
    return 0


if __name__ == "__main__":
    sys.exit(main())
