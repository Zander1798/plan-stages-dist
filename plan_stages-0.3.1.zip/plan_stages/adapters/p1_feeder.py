"""P1 adapter: step3_span_split -> distribution, feeder, splitters_1to16."""
import os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect


def main():
    site_dir()
    rc = run_step("step3_span_split.py")
    if rc:
        return rc
    s3 = Path(os.environ["PS_REV_DIR"]) / "step3"
    collect({"distribution": (s3 / "claude_distribution_cable.gpkg", "claude_distribution_cable"),
             "feeder": (s3 / "claude_feeder_cable.gpkg", "claude_feeder_cable"),
             "splitters_1to16": (s3 / "claude_1to16_splitters.gpkg", "claude_1to16_splitters")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
