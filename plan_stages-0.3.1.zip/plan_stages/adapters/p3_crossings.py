"""P3 adapter: step567 STAGE=crossings on approved P1 + P2 -> road_crossings."""
import os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect, materialise_p1, materialise_p2


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    materialise_p1(rev); materialise_p2(rev)
    rc = run_step("step567.py", {"STAGE": "crossings"})
    if rc:
        return rc
    collect({"road_crossings": (rev / "step567" / "claude_step567_crossings.gpkg", "claude_road_crossings")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
