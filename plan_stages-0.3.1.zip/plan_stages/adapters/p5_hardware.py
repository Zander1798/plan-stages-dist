"""P5 adapter: step567 STAGE=hardware on approved P1 + P2 -> 8-way splitters, domes."""
import os, sys
from pathlib import Path
import math
import numpy as np
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.adapters._plan_common import (site_dir, run_step, collect, materialise_p1, materialise_p2,
                                               approved, transform, layer_epsg)


def remap_cp_ids(gen_gpkg: Path, p2_gpkg: Path, epsg: int, tol: float = 0.5) -> int:
    """step567 numbers hardware by list position; give each point the real cp_id of the approved collection
    point within `tol` m (site metres). Returns the number of points left with their position id."""
    pds = ogr.Open(str(p2_gpkg)); cps = pds.GetLayerByName("collection_points")
    t = transform(layer_epsg(cps, 4326), epsg)
    ids, xy = [], []
    for f in cps:
        g = f.GetGeometryRef(); ids.append(f.GetField("cp_id")); xy.append(t.TransformPoint(g.GetX(), g.GetY())[:2])
    tree = cKDTree(np.array(xy)) if xy else None
    gds = ogr.Open(str(gen_gpkg), 1); unmatched = 0
    for name in ("splitters_8way", "dome_joints"):
        lyr = gds.GetLayerByName(name); tg = transform(layer_epsg(lyr, 4326), epsg); used = set()
        for f in lyr:
            g = f.GetGeometryRef(); p = tg.TransformPoint(g.GetX(), g.GetY())[:2]
            near = tree.query_ball_point(p, tol) if tree is not None else []
            pos = f.GetField("cp_id")       # step567's list position
            keep = [j for j in near if ids[j] == pos and j not in used]   # co-located CPs: prefer its own id
            pick = keep[0] if keep else next((j for j in sorted(near, key=lambda j: math.dist(p, xy[j])) if j not in used), None)
            if pick is None:
                unmatched += 1
            else:
                used.add(pick); f.SetField("cp_id", ids[pick]); lyr.SetFeature(f)
    gds = None
    print(f"remapped hardware cp_id to approved collection points; {unmatched} without a collection point within {tol} m (kept position id)")
    return unmatched


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    materialise_p1(rev); materialise_p2(rev)
    rc = run_step("step567.py", {"STAGE": "hardware"})
    if rc:
        return rc
    g = rev / "step567" / "claude_step567_hardware.gpkg"
    collect({"splitters_8way": (g, "claude_8way_splitters"), "dome_joints": (g, "claude_dome_joints")})
    remap_cp_ids(rev / "generated.gpkg", approved("p2_drops"), int(os.environ["PS_EPSG"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
