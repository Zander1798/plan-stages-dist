"""Shared plumbing for the plan-phase adapters (gate0, P1 to P6).

The pipeline scripts bundled under plan_stages/ml (synced from scripts/ml) read and write fixed folder names under PLAN_DIR
(step3/, step4/, step567/) and in EPSG:4326. These helpers rebuild those folders from the
operator-APPROVED layers so every stage routes on what was approved, not on what a script
last produced.
"""
import os, shutil, subprocess, sys
from pathlib import Path
from osgeo import ogr, osr

ogr.UseExceptions()
ML = Path(__file__).resolve().parents[1] / "ml"     # the bundled step scripts

STEP3 = (("distribution", "claude_distribution_cable.gpkg", "claude_distribution_cable"),
         ("feeder", "claude_feeder_cable.gpkg", "claude_feeder_cable"),
         ("splitters_1to16", "claude_1to16_splitters.gpkg", "claude_1to16_splitters"))
STEP4 = (("collection_points", "claude_collection_points"), ("drops", "claude_drops"),
         ("drop_review", "claude_drop_review"))


def store_from_env():
    from plan_stages.core.store import SiteStore
    rev = Path(os.environ["PS_REV_DIR"])          # <plan_root>/<site>/<stage>/rev-N
    return SiteStore(rev.parents[2], rev.parents[1].name)


def _to_wgs84_inplace(d: Path) -> None:
    """The step scripts read SITE_DIR shapefiles as EPSG:4326 (the operator's convention) and project
    them themselves; the approved layers are in the site CRS, so rewrite any other shapefile in 4326."""
    from osgeo import gdal
    gdal.UseExceptions()
    for shp in sorted(d.glob("*.shp")):
        ds = ogr.Open(str(shp)); srs = ds.GetLayer(0).GetSpatialRef()
        code = srs.GetAuthorityCode(None) if srs is not None else None
        ds = None
        if code == "4326":
            continue
        tmp = d / ("_wgs_" + shp.name)
        out = gdal.VectorTranslate(str(tmp), str(shp), format="ESRI Shapefile", dstSRS="EPSG:4326",
                                   layerName=shp.stem, options=["-lco", "ENCODING=UTF-8"])
        out = None
        for ext in (".shp", ".shx", ".dbf", ".prj", ".cpg"):
            old = shp.with_suffix(ext)
            if old.exists():
                old.unlink()
            new = tmp.with_suffix(ext)
            if new.exists():
                new.rename(old)


def find_buildings(export_dir: Path, site: str, qgis_root: str, wayleave_root: str) -> Path | None:
    """Building footprints for midblock, first that exists: <rev>/site_export/buildings.gpkg, then
    <qgis_root>/work/buildings/<site>_buildings.gpkg, then <wayleave_root>/work/buildings/<site>_buildings.gpkg."""
    cands = [Path(export_dir) / "buildings.gpkg"]
    for root in (qgis_root, wayleave_root):
        if root:
            cands.append(Path(root) / "work" / "buildings" / f"{site}_buildings.gpkg")
    return next((c for c in cands if c.is_file()), None)


def set_buildings(export_dir: Path) -> Path | None:
    """Set (or clear) BUILDINGS from find_buildings and say which file was used."""
    b = find_buildings(export_dir, os.environ["PS_SITE"], os.environ.get("PS_QGIS_ROOT", ""),
                       os.environ.get("PS_WAYLEAVE_ROOT", ""))
    if b is not None:
        os.environ["BUILDINGS"] = str(b)
        print(f"buildings: {b}")
    else:
        os.environ.pop("BUILDINGS", None)
        print(f"buildings: none for {os.environ['PS_SITE']} (site_export, qgis_root or wayleave_root work/buildings); "
              f"midblock test unavailable")
    return b


def site_dir() -> Path:
    """Export the approved wayleave layers into THIS revision (<rev>/site_export), so the folder a run read
    stays with the run. Sets SITE_DIR, and BUILDINGS from find_buildings (the plugin supplies no footprints)."""
    from plan_stages.core import export
    st = store_from_env()
    d = export.export_site_dir(st, Path(os.environ["PS_REV_DIR"]) / "site_export")
    _to_wgs84_inplace(d)
    os.environ["SITE_DIR"] = str(d)
    set_buildings(d)
    return d


def run_step(script: str, extra_env: dict | None = None) -> int:
    env = dict(os.environ)
    env.update({"CABLE": "claude", "DPSRC": "gt",
                "PLAN_DIR": os.environ["PS_REV_DIR"], "SITE_DIR": os.environ["SITE_DIR"],
                "PYTHONUNBUFFERED": "1"})
    # poles is optional in the wayleave: candidate poles only when the snapshot exported them, else step4
    # falls back to cable candidates by itself.
    if (Path(os.environ["SITE_DIR"]) / "poles.shp").exists():
        env["CANDSRC"] = "poles"
    else:
        env.pop("CANDSRC", None)
    if not os.environ.get("BUILDINGS"):                 # site_dir() set it when footprints were found
        env.pop("BUILDINGS", None)
    env.update(extra_env or {})
    return subprocess.call([sys.executable, str(ML / script)], cwd=str(ML), env=env)


def copy_layer(src_gpkg: Path, src_layer: str, dst_gpkg: Path, dst_layer: str) -> int:
    ds = ogr.Open(str(src_gpkg))
    lyr = ds.GetLayerByName(src_layer)
    if lyr is None:
        raise SystemExit(f"{src_gpkg} has no layer {src_layer}")
    drv = ogr.GetDriverByName("GPKG")
    out = drv.Open(str(dst_gpkg), 1) if Path(dst_gpkg).exists() else drv.CreateDataSource(str(dst_gpkg))
    out.CopyLayer(lyr, dst_layer, ["OVERWRITE=YES"])
    n = lyr.GetFeatureCount()
    out = None
    return n


def collect(mapping: dict) -> None:
    """mapping: registry layer name -> (source gpkg, source layer). Writes generated.gpkg."""
    rev = Path(os.environ["PS_REV_DIR"])
    for dst_layer, (src, src_layer) in mapping.items():
        print(f"{dst_layer}: {copy_layer(Path(src), src_layer, rev / 'generated.gpkg', dst_layer)} features")


def approved(stage_id: str) -> Path:
    """Approved gpkg of a dependency, from PS_DEP_<STAGE> (set by the runner for every registry dep)."""
    v = os.environ.get("PS_DEP_" + stage_id.upper())
    if not v:
        raise SystemExit(f"PS_DEP_{stage_id.upper()} is not set: {stage_id} is not an approved dependency of this stage")
    return Path(v)


def materialise_p1(plan_dir: Path) -> None:
    """Rebuild step3/ from the APPROVED P1 layers so later steps route on the operator's edits."""
    src = approved("p1_feeder")
    d = Path(plan_dir) / "step3"
    d.mkdir(exist_ok=True)
    for f in d.glob("*.gpkg"):
        f.unlink()
    for layer, fname, lname in STEP3:
        copy_layer(src, layer, d / fname, lname)


def materialise_p2(plan_dir: Path) -> None:
    src = approved("p2_drops")
    d = Path(plan_dir) / "step4"
    d.mkdir(exist_ok=True)
    out = d / "claude_step4.gpkg"
    if out.exists():
        out.unlink()
    for a, b in STEP4:
        copy_layer(src, a, out, b)


def transform(src_epsg: int, dst_epsg: int):
    """Coordinate transform with x=east/lon, y=north/lat ordering on both sides."""
    a = osr.SpatialReference(); a.ImportFromEPSG(src_epsg)
    b = osr.SpatialReference(); b.ImportFromEPSG(dst_epsg)
    for s in (a, b):
        s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return osr.CoordinateTransformation(a, b)


def layer_epsg(lyr, default: int) -> int:
    s = lyr.GetSpatialRef()
    return int(s.GetAuthorityCode(None)) if s is not None and s.GetAuthorityCode(None) else default


def empty_gpkg(path: Path, epsg: int) -> None:
    """A stage with no output layers still needs a GeoPackage OGR can open, and OGR refuses one with
    no vector layer at all, so it carries one empty placeholder layer named "_none"."""
    path = Path(path)
    if path.exists():
        path.unlink()
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(str(path))
    srs = osr.SpatialReference(); srs.ImportFromEPSG(epsg)
    ds.CreateLayer("_none", srs, ogr.wkbPoint)
    ds = None
