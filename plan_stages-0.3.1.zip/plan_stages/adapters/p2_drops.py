"""P2 adapter: step4_drops on the APPROVED P1 cable -> collection_points, drops, drop_review."""
import os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect, materialise_p1


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    materialise_p1(rev)
    rc = run_step("step4_drops.py")
    if rc:
        return rc
    s4 = rev / "step4" / "claude_step4.gpkg"
    collect({"collection_points": (s4, "claude_collection_points"), "drops": (s4, "claude_drops"),
             "drop_review": (s4, "claude_drop_review")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
