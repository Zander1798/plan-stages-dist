import sys
from pathlib import Path


def classFactory(iface):
    here = Path(__file__).resolve().parent
    parent = str(here.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    from .plugin import PlanStagesPlugin
    return PlanStagesPlugin(iface)
