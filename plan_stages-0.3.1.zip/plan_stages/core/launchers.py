"""Find the QGIS install the plugin runs inside and write the launcher its subprocesses use.

The step scripts and checks run in QGIS's own Python (GDAL, numpy, scipy and the qgis module all come with it),
started through a batch file that sources OSGeo4W's environment. OSGeo4W's `o4w_env.bat` clears PYTHONPATH
(etc/ini/python3.bat), so the launcher restores it from PS_PYTHONPATH after sourcing. Nothing here is specific to
one machine: the root is discovered from the running QGIS, and the batch file is (re)written next to the plugin's
config on first use."""
from __future__ import annotations
import os, sys
from pathlib import Path

LAUNCHER_NAME = "plan_stages_python.bat"

TEMPLATE = """@echo off
rem Written by the Plan Stages plugin from the QGIS it runs inside. Edit plan_stages.toml to override.
call "{root}\\bin\\o4w_env.bat"
call "{root}\\bin\\qt6_env.bat"
path %OSGEO4W_ROOT%\\apps\\qgis\\bin;%PATH%
set QGIS_PREFIX_PATH=%OSGEO4W_ROOT:\\=/%/apps/qgis
set GDAL_FILENAME_IS_UTF8=YES
set USE_PATH_FOR_GDAL_PYTHON=YES
set VSI_CACHE=TRUE
set VSI_CACHE_SIZE=1000000
set QT_PLUGIN_PATH=%OSGEO4W_ROOT%\\apps\\qgis\\qtplugins;%OSGEO4W_ROOT%\\apps\\qt6\\plugins
set PYTHONPATH=%OSGEO4W_ROOT%\\apps\\qgis\\python;%PS_PYTHONPATH%
python %*
"""


class NoQgisFound(RuntimeError):
    pass


def _is_root(p: Path | None) -> bool:
    return p is not None and (p / "bin" / "o4w_env.bat").is_file()


def discover_root(environ=None, prefix_path: str = "", executable: str = "") -> Path | None:
    """The OSGeo4W root (the folder holding bin\\o4w_env.bat): OSGEO4W_ROOT from the QGIS process environment,
    else two levels above QgsApplication.prefixPath() (<root>/apps/qgis), else above the executable's bin."""
    environ = os.environ if environ is None else environ
    cands = []
    if environ.get("OSGEO4W_ROOT"):
        cands.append(Path(environ["OSGEO4W_ROOT"]))
    if prefix_path:
        cands.append(Path(prefix_path).resolve().parents[1] if len(Path(prefix_path).resolve().parents) > 1 else None)
    if executable:
        cands.append(Path(executable).resolve().parents[1] if len(Path(executable).resolve().parents) > 1 else None)
    for c in cands:
        if _is_root(c):
            return c.resolve()
    return None


def write_launcher(root: Path, dest_dir: Path) -> Path:
    """Write (or refresh) the launcher for `root` under dest_dir and return its path."""
    dest_dir = Path(dest_dir); dest_dir.mkdir(parents=True, exist_ok=True)
    bat = dest_dir / LAUNCHER_NAME
    text = TEMPLATE.format(root=str(Path(root)).rstrip("\\/"))
    if not bat.exists() or bat.read_text(encoding="utf-8") != text:
        bat.write_text(text, encoding="utf-8")
    return bat


def running_qgis_hints() -> tuple[str, str]:
    """(prefix path, executable) of the QGIS this code runs in, when the qgis module is importable."""
    prefix = ""
    try:
        from qgis.core import QgsApplication
        prefix = QgsApplication.prefixPath() or ""
    except Exception:                                    # noqa: BLE001 - not inside QGIS (tests, scripts)
        pass
    return prefix, sys.executable or ""


def auto_launcher(dest_dir: Path, prefix_path: str | None = None, executable: str | None = None) -> Path:
    """The launcher for the discovered QGIS, written under dest_dir. NoQgisFound names what was tried."""
    hp, he = running_qgis_hints()
    prefix_path = hp if prefix_path is None else prefix_path
    executable = he if executable is None else executable
    root = discover_root(os.environ, prefix_path, executable)
    if root is None:
        raise NoQgisFound("Cannot find the QGIS install (no bin\\o4w_env.bat via OSGEO4W_ROOT=%r, prefix %r, exe %r). "
                          "Set gdal_python and pyqgis_python in Config… to a Python launcher of your QGIS."
                          % (os.environ.get("OSGEO4W_ROOT", ""), prefix_path, executable))
    return write_launcher(root, dest_dir)
