"""Optional dependencies. Only the Spec tab's PDF proposal needs the `anthropic` package; without it the tab
degrades to typing values by hand, and offers to install the package into QGIS's Python."""
from __future__ import annotations


def have_anthropic() -> bool:
    try:
        import anthropic  # noqa: F401
        return True
    except ImportError:
        return False


def pip_install_cmd(launcher: str, package: str = "anthropic") -> list[str]:
    """pip inside QGIS's own Python, through the same launcher the step scripts use."""
    return [launcher, "-m", "pip", "install", "--upgrade", package]
