"""Group a ChecksReport for display: one header per check with something to say (blocking first, then warnings),
its located issues under it, and the count the cap dropped. Pure; the dock widgets render it."""
from __future__ import annotations
from dataclasses import dataclass, field
from .checks import ChecksReport, CheckResult, Issue


@dataclass
class Group:
    code: str
    title: str
    blocking: bool
    issues: list[Issue] = field(default_factory=list)


class Grouped(list):
    dropped: int = 0


def group_report(report: ChecksReport) -> Grouped:
    by_code: dict[str, list[Issue]] = {}
    for i in report.issues:
        by_code.setdefault(i.code, []).append(i)
    blocking = {c.code for c in report.blocking()}
    out = Grouped(); seen = set()
    rows: list[CheckResult] = [c for c in report.checks if c.required and c.status != "passed"] + \
                              [c for c in report.checks if not c.required and c.status == "failed"]
    for c in rows:
        if c.code in seen:
            continue
        seen.add(c.code)
        tag = "BLOCKING" if c.code in blocking else "warn"
        out.append(Group(c.code, f"{tag} {c.code}: {c.status} {c.message}".rstrip(), c.code in blocking, by_code.get(c.code, [])))
    for code, issues in by_code.items():                 # issues whose check row passed or does not exist
        if code not in seen:
            seen.add(code)
            sev = "error" if any(i.severity == "error" for i in issues) else "warn"
            out.append(Group(code, f"{sev} {code}: {len(issues)} issue{'s' if len(issues) != 1 else ''}", False, issues))
    out.dropped = report.dropped
    return out
