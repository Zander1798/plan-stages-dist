from __future__ import annotations
import base64
from pathlib import Path
from .specsheet import Sheet, SheetEntry, SPEC_KEYS, UNITS

MODEL = "claude-opus-5-5"
MEANING = {
    "density": "erf-size regime: 'high' (small erven, 1:16 then 1:8) or 'low' (large erven, 1:32 then 1:4)",
    "drop_cap_m": "longest drop cable from pole to home, metres",
    "span_cap_m": "longest pole-to-pole span, metres",
    "span_typical_m": "typical midblock span length, metres (a norm, not a cap)",
    "cable_span_rating_m": "cable's rated suspension distance, metres",
    "cross_span_m": "longest span permitted across a road, metres",
    "fan_cap": "drops per collection point (distribution splitter ratio)",
    "pon_cap": "collection points per PON (feeder/entry splitter ratio)",
    "feeder_split": "feeder/entry dome splitter ratio, e.g. '1:16'",
    "dist_split": "distribution splitter ratio, e.g. '1:8'",
    "pon_target": "stands per PON planners should aim at",
    "pon_max": "hard ceiling of clients per PON",
    "pole_midblock_m": "midblock distribution pole height, metres",
    "pole_crossing_m": "road-crossing pole height, metres",
    "pole_feeder_m": "feeder pole height, metres",
    "pole_boundary_setback_m": "minimum pole distance from a property boundary, metres",
    "pole_pitch_m": "design spacing between poles along the span, metres",
    "direction_change_stay_deg": "route direction change above which a stay or strut is mandatory, degrees",
    "aerial": "true if the deployment is aerial on poles",
}
TOOL = {
    "name": "propose_parameter_sheet",
    "description": "Report every planning parameter found in the supplied client standards, with the page and exact quoted text.",
    "strict": True,
    "input_schema": {
        "type": "object", "additionalProperties": False, "required": ["entries"],
        "properties": {"entries": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["key", "found", "value", "unit", "document_index", "page", "quoted_text"],
            "properties": {"key": {"type": "string"}, "found": {"type": "boolean"},
                           "value": {"type": ["number", "string", "boolean", "null"]}, "unit": {"type": "string"},
                           "document_index": {"type": "integer"}, "page": {"type": "integer"},
                           "quoted_text": {"type": "string"}}}}}},
}


class ProposalRefused(Exception):
    pass


class ProposalFailed(Exception):
    pass


def _default_call(api_key: str):
    import anthropic
    client = anthropic.Anthropic(api_key=api_key or None)
    return lambda params: client.messages.create(**params)


def propose_sheet(pdf_paths: list[Path], client: str, api_key: str, call=None) -> Sheet:
    call = call or _default_call(api_key)
    content = []
    for p in pdf_paths:
        data = base64.standard_b64encode(Path(p).read_bytes()).decode("ascii")
        content.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": data},
                        "title": Path(p).name, "citations": {"enabled": True}})
    keys = "\n".join(f"- {k}: {MEANING[k]}" for k in SPEC_KEYS)
    content.append({"type": "text", "text":
        f"These are the planning standards for the client {client}. For each parameter below, find the value the documents "
        f"state, the document index (0-based, in the order given), the 1-based page, and the exact quoted sentence. "
        f"If the documents do not state a parameter, report found=false. Never infer or default a value. "
        f"Call propose_parameter_sheet exactly once with every key.\n\n{keys}"})
    params = {"model": MODEL, "max_tokens": 16000, "tools": [TOOL], "tool_choice": {"type": "auto"},
              "messages": [{"role": "user", "content": content}]}
    resp = call(params)
    if resp.stop_reason == "refusal":
        raise ProposalRefused("the model declined to read these documents")
    if resp.stop_reason == "max_tokens":
        raise ProposalFailed("response truncated at max_tokens; proposal not usable")
    tool = next((b for b in resp.content if getattr(b, "type", "") == "tool_use"), None)
    if tool is None:
        raise ProposalFailed("no tool call in response")
    sheet = Sheet.blank(client)
    try:
        entries = tool.input["entries"]
    except (KeyError, TypeError) as e:
        raise ProposalFailed(f"malformed tool input: {e}")
    for e in entries:
        try:
            k = e["key"]
            if k not in SPEC_KEYS:
                continue
            if e["found"] and e["value"] is not None:
                doc = pdf_paths[e["document_index"]].name if 0 <= e["document_index"] < len(pdf_paths) else ""
                sheet.entries[k] = SheetEntry(k, e["value"], e["unit"] or UNITS.get(k, ""), "proposed", doc, e["page"], e["quoted_text"], "")
            else:
                sheet.entries[k] = SheetEntry(k, None, UNITS.get(k, ""), "not_found")
        except (KeyError, TypeError) as ex:
            raise ProposalFailed(f"malformed tool input: {ex}")
    return sheet
