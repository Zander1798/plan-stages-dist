"""The chain. One entry per stage; changing manual -> generated is one line here."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class LayerSpec:
    name: str
    geom: str                      # "Point" | "LineString" | "Polygon"
    fields: tuple[tuple[str, str], ...] = ()   # (name, "str"|"int"|"real")
    optional: bool = False         # a source layer the project may not have; its checks are skipped when absent


@dataclass(frozen=True)
class Stage:
    id: str
    name: str
    phase: str                     # "source" | "gate" | "plan"
    deps: tuple[str, ...]
    generator: str | None          # adapters/<x>.py relative to plugin folder, or None = manual
    check: str                     # checks/<x>.py
    outputs: tuple[LayerSpec, ...]
    spec_keys: tuple[str, ...] = ()
    launcher: str = "gdal"         # "gdal" | "pyqgis"


REGISTRY: tuple[Stage, ...] = (
    # The wayleave is the operator's: the dock snapshots the project's layers into one revision ("Use this
    # wayleave"), which is approved only when checks/wayleave.py passes. Nothing generates it.
    Stage("wayleave", "Wayleave (from project)", "source", (), None, "checks/wayleave.py",
          (LayerSpec("span", "LineString"),
           LayerSpec("pons", "Polygon", (("pon_num", "int"), ("homes", "int"))),
           LayerSpec("demand_points", "Point"),
           LayerSpec("pop", "Point", (("name", "str"),)),
           LayerSpec("roads", "LineString"),
           LayerSpec("poles", "Point", (("role", "str"),), optional=True),
           LayerSpec("erven", "Polygon", (("erf_id", "str"),), optional=True),
           LayerSpec("aoi", "Polygon", optional=True),
           # building footprints for the midblock test (rollout 2026-10-12: supplied by the operator, never fetched
           # from one machine's work/buildings); exported as site_export/buildings.gpkg
           LayerSpec("buildings", "Polygon", optional=True)),
          ("drop_cap_m",)),
    Stage("gate0", "Step 0 wayleave gate", "gate", ("wayleave",),
          "adapters/gate0.py", "checks/gate0.py", (), ("drop_cap_m",)),
    Stage("p1_feeder", "P1 Feeder, distribution, 1:16", "plan", ("gate0",), "adapters/p1_feeder.py", "checks/p1_feeder.py",
          (LayerSpec("distribution", "LineString", (("pon", "int"),)), LayerSpec("feeder", "LineString"),
           LayerSpec("splitters_1to16", "Point", (("pon", "int"),)))),
    Stage("p2_drops", "P2 Collection points and drops", "plan", ("gate0", "p1_feeder"), "adapters/p2_drops.py",
          "checks/p2_drops.py",
          (LayerSpec("collection_points", "Point", (("cp_id", "str"), ("n_drops", "int"), ("pon", "int"))),
           LayerSpec("drops", "LineString", (("cp_id", "str"), ("length_m", "real"), ("crosses_road", "int"))),
           LayerSpec("drop_review", "Point", (("note", "str"),))),
          ("drop_cap_m", "fan_cap", "pon_cap")),
    Stage("p3_crossings", "P3 Road crossings", "plan", ("gate0", "p1_feeder", "p2_drops"), "adapters/p3_crossings.py",
          "checks/p3_crossings.py",
          (LayerSpec("road_crossings", "LineString", (("type", "str"), ("length_m", "real"))),), ("cross_span_m", "span_cap_m")),
    Stage("p4_poles", "P4 Pole reconciliation", "plan", ("p1_feeder", "wayleave", "p2_drops", "p3_crossings"), "adapters/p4_poles.py",
          "checks/p4_poles.py",
          (LayerSpec("poles", "Point", (("role", "str"), ("cable", "str"), ("height_m", "real"))),),
          ("span_cap_m", "pole_midblock_m", "pole_crossing_m", "pole_feeder_m")),
    Stage("p5_hardware", "P5 Splitters and dome joints", "plan", ("p1_feeder", "p2_drops", "p4_poles"), "adapters/p5_hardware.py",
          "checks/p5_hardware.py",
          (LayerSpec("splitters_8way", "Point", (("cp_id", "str"),)), LayerSpec("dome_joints", "Point", (("cp_id", "str"),))),
          ("feeder_split", "dist_split")),
    Stage("p6_delivery", "P6 Delivery", "plan", ("p1_feeder", "p2_drops", "p3_crossings", "p4_poles", "p5_hardware"),
          "adapters/p6_delivery.py", "checks/common.py", (), launcher="pyqgis"),
)

_BY_ID = {s.id: s for s in REGISTRY}


def get(stage_id: str) -> Stage:
    return _BY_ID[stage_id]


def order() -> list[str]:
    return [s.id for s in REGISTRY]


def downstream_of(stage_id: str) -> list[str]:
    out, hit = [], {stage_id}
    for s in REGISTRY:
        if s.id != stage_id and (set(s.deps) & hit):
            hit.add(s.id)
            out.append(s.id)
    return out
