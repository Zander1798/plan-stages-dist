"""The site's working CRS: the Hartebeesthoek94 Lo zone for where the data is (pure Python, no QGIS).

Rollout 2026-10-12: the New site prompt defaulted to EPSG:2052 for every site, and a wrong zone is only caught
at Gate 0 (`step0_wayleave` refuses a span outside the zone being measured in). The prompt now proposes the zone
from the project's own layers; the operator can still type another."""
from __future__ import annotations

# Lo<central meridian> -> EPSG, the same table as ml/site_crs.py
LO = {15: 2046, 17: 2047, 19: 2048, 21: 2049, 23: 2050, 25: 2051, 27: 2052, 29: 2053, 31: 2054, 33: 2055}


def lo_zone(lon: float | None) -> tuple[int, int] | None:
    """(EPSG, central meridian) of the Lo zone whose meridian is nearest `lon`; None outside the Lo system."""
    if lon is None or not (14.0 <= lon <= 34.0):
        return None
    m = min(LO, key=lambda k: abs(k - lon))
    return LO[m], m
