from __future__ import annotations
from pathlib import Path
from osgeo import ogr
from . import stages
from .store import SiteStore

_BASENAMES = (  # registry layer -> shapefile basename (scripts/ml/site_config._LAYERS)
    ("span", "Span"), ("pons", "Pons"), ("demand_points", "Demand points"), ("pop", "POP"),
    ("roads", "road"), ("poles", "poles"), ("erven", "Erven"), ("aoi", "AOI"))
_OPTIONAL = {o.name: o.optional for o in stages.get("wayleave").outputs}
MAP = [  # shapefile basename, stage, layer, required (= not LayerSpec.optional in the registry)
    (base, "wayleave", layer, not _OPTIONAL[layer]) for layer, base in _BASENAMES]


class MissingApproved(Exception):
    pass


def export_site_dir(store: SiteStore, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    drv = ogr.GetDriverByName("ESRI Shapefile")
    for base, sid, layer, required in MAP:
        src = store.approved_gpkg(sid)
        if src is None or not src.exists():
            if required:
                raise MissingApproved(sid)
            continue
        ds = ogr.Open(str(src)); lyr = ds.GetLayerByName(layer)
        if lyr is None:
            if required:
                raise MissingApproved(f"{sid}:{layer}")
            continue
        for ext in (".shp", ".shx", ".dbf", ".prj", ".cpg"):
            p = out_dir / f"{base}{ext}"
            if p.exists():
                p.unlink()
        dst = drv.CreateDataSource(str(out_dir / f"{base}.shp"))
        dst.CopyLayer(lyr, base, ["ENCODING=UTF-8"])
        dst = None
    _export_buildings(store, out_dir)
    return out_dir


def _export_buildings(store: SiteStore, out_dir: Path) -> None:
    """The wayleave's optional footprints -> <out_dir>/buildings.gpkg, the first place the step scripts look
    (adapters/_plan_common.find_buildings). Nothing is written for an absent or empty layer, so an empty row never
    shadows the other lookups with a file of zero footprints."""
    target = out_dir / "buildings.gpkg"
    if target.exists():
        target.unlink()
    src = store.approved_gpkg("wayleave")
    if src is None or not src.exists():
        return
    ds = ogr.Open(str(src)); lyr = ds.GetLayerByName("buildings")
    if lyr is None or lyr.GetFeatureCount() == 0:
        return
    dst = ogr.GetDriverByName("GPKG").CreateDataSource(str(target))
    dst.CopyLayer(lyr, "buildings")
    dst = ds = None
