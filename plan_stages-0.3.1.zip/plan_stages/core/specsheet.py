from __future__ import annotations
import json
from dataclasses import dataclass, asdict, field
from pathlib import Path

SPEC_KEYS: tuple[str, ...] = (
    "density", "drop_cap_m", "span_cap_m", "span_typical_m", "cable_span_rating_m", "cross_span_m",
    "fan_cap", "pon_cap", "feeder_split", "dist_split", "pon_target", "pon_max",
    "pole_midblock_m", "pole_crossing_m", "pole_feeder_m", "pole_boundary_setback_m", "pole_pitch_m",
    "direction_change_stay_deg", "aerial",
)
UNITS = {"drop_cap_m": "m", "span_cap_m": "m", "span_typical_m": "m", "cable_span_rating_m": "m", "cross_span_m": "m",
         "pole_midblock_m": "m", "pole_crossing_m": "m", "pole_feeder_m": "m", "pole_boundary_setback_m": "m",
         "pole_pitch_m": "m", "direction_change_stay_deg": "deg"}
STATUSES = ("proposed", "confirmed", "operator_stated", "not_found", "not_applicable")


class SheetIncomplete(Exception):
    def __init__(self, keys: list[str]):
        super().__init__("unresolved: " + ", ".join(keys)); self.keys = keys


@dataclass
class SheetEntry:
    key: str
    value: object = None
    unit: str = ""
    status: str = "not_found"
    document: str = ""
    page: int | None = None
    quoted_text: str = ""
    note: str = ""


@dataclass
class Sheet:
    client: str
    rev: str = ""
    entries: dict[str, SheetEntry] = field(default_factory=dict)

    @classmethod
    def blank(cls, client: str) -> "Sheet":
        return cls(client, "", {k: SheetEntry(k, unit=UNITS.get(k, "")) for k in SPEC_KEYS})

    def confirm(self, key: str) -> None:
        e = self.entries[key]
        if e.status not in ("proposed", "operator_stated"):
            raise ValueError(f"{key} has nothing to confirm (status {e.status})")
        if e.status == "proposed":
            e.status = "confirmed"

    def set_operator(self, key: str, value, note: str) -> None:
        self.entries[key] = SheetEntry(key, value, UNITS.get(key, ""), "operator_stated", "operator-stated", None, "", note)

    def mark_not_applicable(self, key: str) -> None:
        self.entries[key] = SheetEntry(key, None, UNITS.get(key, ""), "not_applicable")

    def unresolved(self, required: tuple[str, ...]) -> list[str]:
        return [k for k in required if self.entries.get(k, SheetEntry(k)).status not in
                ("confirmed", "operator_stated", "not_applicable")]

    def save(self, path: Path, required: tuple[str, ...]) -> None:
        missing = self.unresolved(required)
        if missing:
            raise SheetIncomplete(missing)
        out = {"client": self.client, "rev": self.rev,
               "entries": {k: _export(e) for k, e in self.entries.items()}}
        Path(path).write_text(json.dumps(out, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "Sheet":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(d["client"], d.get("rev", ""), {k: SheetEntry(**v) for k, v in d["entries"].items()})


def _export(e: SheetEntry) -> dict:
    d = asdict(e)
    if e.status == "operator_stated":
        d["status"] = "confirmed"; d["note"] = (e.note + " [operator-stated]").strip()
    return d


def required_keys() -> tuple[str, ...]:
    from . import stages
    keys = {"density"}
    for s in stages.REGISTRY:
        keys.update(s.spec_keys)
    return tuple(k for k in SPEC_KEYS if k in keys)


TEMPLATES = Path(__file__).resolve().parents[1] / "templates"


def spec_sources(plan_root: Path, exclude_site: str) -> list[tuple[str, Path]]:
    """Sheets a new site can copy (rollout 2026-10-12): the client templates shipped with the plugin, then every
    other site under plan_root with a saved spec revision. (label, sheet.json path)."""
    out = []
    for t in sorted(TEMPLATES.glob("*.json")):
        try:
            out.append((f"Template: {json.loads(t.read_text(encoding='utf-8'))['client']}", t))
        except (OSError, ValueError, KeyError):
            continue
    root = Path(plan_root)
    for sj in sorted(root.glob("*/site.json")) if root.is_dir() else []:
        site = sj.parent.name
        if site == exclude_site:
            continue
        try:
            st = json.loads(sj.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        rev = st.get("spec_rev")
        sheet = sj.parent / "spec" / str(rev) / "sheet.json"
        if rev and sheet.exists():
            out.append((f"Site: {site} ({st.get('client', '?')}, {rev})", sheet))
    return out


def copy_sheet(src: Sheet, client: str, source_label: str) -> Sheet:
    """A copy of `src` for another site: every resolved value comes across marked with where it came from (still
    unsaved -- the operator reviews it and presses Save revision); anything unresolved in the source stays
    unresolved here. Nothing is defaulted."""
    out = Sheet.blank(client)
    for k, e in src.entries.items():
        if e.status == "not_applicable":
            out.mark_not_applicable(k)
        elif e.status in ("confirmed", "operator_stated") and e.value is not None:
            out.entries[k] = SheetEntry(k, e.value, e.unit or UNITS.get(k, ""), "confirmed", e.document, e.page,
                                        e.quoted_text, (f"copied from {source_label}; " + e.note).strip("; "))
    return out
