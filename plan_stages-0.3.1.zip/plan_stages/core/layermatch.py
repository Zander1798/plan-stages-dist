"""Pure-Python name matching for the Wayleave box (no QGIS): which project layer feeds a registry layer, and
which source field feeds a registry field."""
from __future__ import annotations

# Operator ruling 2026-10-06: when a project layer has no field of the registry name, take the first field whose
# lowercased name is in this list (in this order); null when none matches.
ALIASES = {"homes": ("units", "stands", "home_count", "homes_count", "count"),
           "pon_num": ("pon", "pon_id", "pon_no", "number", "id"),
           "erf_id": ("id", "erf", "erf_no", "parcel_id", "stand_no"),
           "name": ("label", "title", "site"),
           "role": ("type", "class")}


def source_field(target: str, src_names: list[str]) -> tuple[int, str | None]:
    """(index, how) of the source field feeding registry field `target` among src_names (any case): the
    same name, else the first alias present; (-1, None) when none matches."""
    low = [n.lower() for n in src_names]
    for key in (target.lower(),) + ALIASES.get(target, ()):
        if key in low:
            i = low.index(key)
            return i, src_names[i] if key == target.lower() else f"{src_names[i]} (alias)"
    return -1, None


# Names the operator's projects use for each wayleave layer (live walk 2026-10-07: Cradock has Pon, Demand Point,
# OLT; Ventersdorp has pons, Demand Points, POP). Matched whole, case-insensitive, with spaces/underscores/hyphens
# ignored, so a required row still never fills on a partial match.
LAYER_NAMES = {
    "span": ("span", "spans", "cable span", "wayleave span", "wayleave"),
    "pons": ("pon", "pons", "pond", "ponds", "pon zones", "pon zone", "pon test"),
    "demand_points": ("demand point", "demand points", "demandpoints", "dp", "dps", "homes"),
    "pop": ("pop", "pops", "olt", "olts", "exchange"),
    "roads": ("road", "roads", "road osm", "osm roads", "streets"),
    "poles": ("pole", "poles"),
    "erven": ("erf", "erven", "ervan", "erfs", "stands", "parcels"),
    "aoi": ("aoi", "area of interest", "boundary", "site boundary"),
    "buildings": ("building", "buildings", "footprints", "building footprints", "structures", "open buildings"),
}


def _norm(s: str) -> str:
    return "".join(ch for ch in s.strip().lower() if ch not in " _-")


def match_name(name: str, basename: str, optional: bool, layer_names: list[str]) -> int | None:
    """Index of the layer name that most likely is registry layer `name`: a whole-name match (case-insensitive,
    ignoring spaces, underscores and hyphens) on the registry name, the operator's shapefile basename, or one of
    the names in LAYER_NAMES, in that order; for an OPTIONAL layer only, then the shortest name containing the
    registry name or basename. None when nothing matches."""
    keys = [_norm(name), _norm(basename)] + [_norm(k) for k in LAYER_NAMES.get(name, ())]
    low = [_norm(n) for n in layer_names]
    for key in keys:
        if key in low:
            return low.index(key)
    if not optional:
        return None
    sub = [_norm(name), _norm(basename)]
    hits = [i for i, n in enumerate(low) if any(k in n for k in sub)]
    return min(hits, key=lambda i: (len(layer_names[i]), i)) if hits else None
