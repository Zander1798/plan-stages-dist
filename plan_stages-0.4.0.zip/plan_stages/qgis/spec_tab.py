"""Spec tab: client PDFs, Claude's proposed parameter sheet checked against the PDFs by the plugin, operator
confirmation, Save revision. The values planning needs come first, with a readiness line (2026-10-13)."""
from __future__ import annotations
import json, shutil
from pathlib import Path
from qgis.PyQt.QtCore import Qt, pyqtSignal, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QTableWidget,
                                 QTableWidgetItem, QFileDialog, QLabel, QHeaderView, QInputDialog, QComboBox)
from qgis.core import QgsApplication, QgsTask
from ..core.specsheet import Sheet, SheetEntry, SheetIncomplete, SPEC_KEYS, UNITS, required_keys, spec_sources, copy_sheet
from ..core.spec_claude import MEANING, propose_sheet, ProposalRefused, ProposalFailed
from ..core.spec_verify import LABELS as CHECK_LABELS, BLOCKING
from ..core import deps, env as envmod, stages
from .ui import ask_yes_no, info, warn

COLS = ("key", "meaning", "proposed value", "check", "citation", "value", "status", "confirm")
C_KEY, C_MEANING, C_PROPOSED, C_CHECK, C_CITE, C_VALUE, C_STATUS, C_CONFIRM = range(len(COLS))
NA_WORDS = ("n/a", "na", "not applicable")


def _show(v) -> str:
    if v is None:
        return ""
    return v if isinstance(v, str) else json.dumps(v)


def _parse(text: str):
    try:
        v = json.loads(text)
    except ValueError:
        return text
    return v if isinstance(v, (int, float, bool, str)) else text


class SpecTab(QWidget):
    changed = pyqtSignal()

    def __init__(self, on_busy=None, parent=None):
        super().__init__(parent)
        self.store = self.config = None
        self.locked, self.external_busy, self.on_busy = False, False, on_busy
        self.pdfs: list[Path] = []
        self.sheet: Sheet | None = None
        self._task = None
        lay = QVBoxLayout(self)
        self.title = QLabel("No site selected"); lay.addWidget(self.title)
        self.files = QListWidget(); self.files.setMaximumHeight(90); lay.addWidget(self.files)
        bar = QHBoxLayout()
        self.add_btn = QPushButton("Add PDF…"); self.add_btn.clicked.connect(self._add_pdf_dialog)
        self.add_btn.setToolTip("Import a client standards PDF; it is read whole and the sheet is proposed from it")
        self.remove_pdf_btn = QPushButton("Remove PDF"); self.remove_pdf_btn.clicked.connect(self.remove_selected_pdf)
        self.propose_btn = QPushButton("Propose"); self.propose_btn.clicked.connect(self.propose)
        self.clear_btn = QPushButton("Clear spec…"); self.clear_btn.clicked.connect(self._clear_spec_dialog)
        self.clear_btn.setToolTip("Remove every saved spec revision and imported PDF so a new spec can be imported or typed")
        self.copy_btn = QPushButton("Copy from…"); self.copy_btn.clicked.connect(self._copy_dialog)
        self.copy_btn.setToolTip("Fill the sheet from a client template or another site's saved spec; review it, then Save revision")
        self.save_btn = QPushButton("Save revision"); self.save_btn.clicked.connect(self.save_revision)
        self.install_btn = QPushButton("Install anthropic…"); self.install_btn.clicked.connect(self.install_anthropic)
        self.install_btn.setToolTip("Reading a spec PDF needs the anthropic package (and pypdf to check its quotes) in "
                                    "QGIS's Python; this runs pip to add what is missing. Until then, type the values by hand.")
        for b in (self.add_btn, self.remove_pdf_btn, self.propose_btn, self.copy_btn, self.clear_btn, self.save_btn,
                  self.install_btn):
            bar.addWidget(b)
        self.install_btn.setVisible(bool(deps.missing_packages()))
        lay.addLayout(bar)
        self.ready_label = QLabel(""); self.ready_label.setWordWrap(True); lay.addWidget(self.ready_label)
        self.table = QTableWidget(0, len(COLS)); self.table.setHorizontalHeaderLabels(COLS)
        self.table.horizontalHeader().setSectionResizeMode(C_MEANING, QHeaderView.ResizeMode.Stretch)
        self.table.setToolTip("Edit 'value' to state your own value; type n/a for not applicable; tick confirm to accept.")
        self.table.itemChanged.connect(lambda _it: self._update_ready())
        self.table.currentCellChanged.connect(lambda r, _c, _pr, _pc: self._row_selected(r))
        lay.addWidget(self.table, 1)
        # the selected row's source: its quote, every statement the documents make about it, and its page
        self.source_label = QLabel("Select a row to see where its value comes from.")
        self.source_label.setWordWrap(True); self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.source_label)
        src = QHBoxLayout()
        self.cand_combo = QComboBox(); self.cand_combo.setMinimumWidth(200)
        self.use_btn = QPushButton("Use this statement"); self.use_btn.clicked.connect(lambda: self.use_statement(self.cand_combo.currentIndex()))
        self.use_btn.setToolTip("Take this statement's value for the row (the documents state more than one)")
        self.open_page_btn = QPushButton("Open page"); self.open_page_btn.clicked.connect(self.open_page)
        self.open_page_btn.setToolTip("Show the PDF page the value was quoted from, with the sentence highlighted")
        src.addWidget(self.cand_combo, 1); src.addWidget(self.use_btn); src.addWidget(self.open_page_btn)
        lay.addLayout(src)
        self._source_widgets(None)

    # ---------------- state ----------------
    def set_site(self, store, config, locked: bool):
        self.store, self.config, self.locked = store, config, locked
        self.pdfs, self.sheet = [], None
        if store is not None:
            st = store.load()
            self.title.setText(f"{st['site']} · client {st['client']} · spec {st.get('spec_rev') or '(none)'}")
            if st.get("spec_rev"):
                rd = store.site_dir / "spec" / st["spec_rev"]
                self.pdfs = sorted((rd / "docs").glob("*.pdf"))
                if (rd / "sheet.json").exists():
                    self.sheet = Sheet.load(rd / "sheet.json")
            if self.sheet is None:
                self.sheet = Sheet.blank(st["client"])
        else:
            self.title.setText("No site selected")
        self._fill()
        self.refresh()

    def refresh(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        self.add_btn.setEnabled(usable)
        self.remove_pdf_btn.setEnabled(usable and bool(self.pdfs))
        self.clear_btn.setEnabled(usable)
        self.copy_btn.setEnabled(usable)
        self.save_btn.setEnabled(usable)
        has_key = bool(self.config and self.config.effective_api_key())
        has_pkg = deps.have_anthropic()
        missing = deps.missing_packages()
        self.install_btn.setVisible(bool(missing)); self.install_btn.setEnabled(usable)
        if missing:
            self.install_btn.setText(f"Install {' and '.join(missing)}…")
        self.propose_btn.setEnabled(usable and has_key and has_pkg and bool(self.pdfs))
        self.propose_btn.setToolTip("Read the PDFs again and propose the sheet" if has_key and has_pkg else
                                    "Install the anthropic package (button to the right), then set the API key in Config…"
                                    if not has_pkg else
                                    "Set the Anthropic API key in Config… (or the ANTHROPIC_API_KEY environment variable)")
        self.table.setEnabled(self.store is not None and not self.locked)

    @staticmethod
    def row_keys() -> list[str]:
        """The values planning needs first, then the rest (information only)."""
        req = set(required_keys())
        return [k for k in SPEC_KEYS if k in req] + [k for k in SPEC_KEYS if k not in req]

    def _fill(self):
        self._fill_files_only()
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        if self.sheet is None:
            self.table.blockSignals(False); self._update_ready()
            return
        req = set(required_keys())
        keys = self.row_keys()
        self.table.setRowCount(len(keys))
        for r, k in enumerate(keys):
            self._fill_row(r, k, k in req)
        self.table.blockSignals(False)
        self._update_ready()
        self._row_selected(self.table.currentRow())

    def _fill_row(self, r: int, k: str, needed: bool):
        e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
        cite = f"{e.document} p.{e.page}: {e.quoted_text}" if e.document and e.page else (e.document or e.note)
        if e.status == "conflict":
            proposed, check = f"{len(e.candidates)} statements", "⚠ documents disagree: pick one below"
        else:
            proposed = (_show(e.value) + (f" {e.unit}" if e.unit and e.value is not None else "")) \
                if e.status in ("proposed", "confirmed") else ""
            check = CHECK_LABELS.get(e.check, "") + (f" p.{e.page}" if e.check == "verified" and e.page else "")
        cells = {C_KEY: k + ("" if needed else " (information only)"), C_MEANING: MEANING.get(k, ""),
                 C_PROPOSED: proposed, C_CHECK: check, C_CITE: cite,
                 C_VALUE: "n/a" if e.status == "not_applicable" else _show(e.value), C_STATUS: e.status}
        for c, text in cells.items():
            it = QTableWidgetItem(text)
            if c != C_VALUE:
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if c == C_KEY:
                it.setData(Qt.ItemDataRole.UserRole, k)
            if c in (C_CITE, C_CHECK):
                it.setToolTip(e.check_note if c == C_CHECK and e.check_note else text)
            self.table.setItem(r, c, it)
        chk = QTableWidgetItem()
        chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if e.status in ("confirmed", "not_applicable")
                          else Qt.CheckState.Unchecked)
        self.table.setItem(r, C_CONFIRM, chk)

    def row_of(self, key: str) -> int:
        for r in range(self.table.rowCount()):
            if self.table.item(r, C_KEY).data(Qt.ItemDataRole.UserRole) == key:
                return r
        return -1

    def _update_ready(self):
        """'Ready to plan: N of 11': the values the planning stages read that the table settles right now."""
        if self.sheet is None or self.table.rowCount() == 0:
            self.ready_label.setText(""); return
        req = required_keys()
        missing = self._sheet_from_table().unresolved(req)
        done = len(req) - len(missing)
        self.ready_label.setText(f"Ready to plan: {done} of {len(req)} planning values settled" +
                                 ("" if missing else ". Press Save revision."))
        self.ready_label.setStyleSheet("color: #2e7d32;" if not missing else "color: #8d6e00;")
        self.ready_label.setToolTip("Still to settle (tick, type a value, or n/a): " + ", ".join(missing)
                                    if missing else "Every value the planning stages read is settled.")

    # ---------------- source of the selected row (2026-10-13) ----------------
    def _key_at(self, row: int) -> str | None:
        it = self.table.item(row, C_KEY) if 0 <= row < self.table.rowCount() else None
        return it.data(Qt.ItemDataRole.UserRole) if it is not None else None

    def _source_widgets(self, e: SheetEntry | None):
        many = e is not None and len(e.candidates) > 1
        self.cand_combo.setVisible(many); self.use_btn.setVisible(many)
        self.open_page_btn.setEnabled(e is not None and bool(e.document and e.page) and self._pdf_named(e.document) is not None)

    def _row_selected(self, row: int):
        k = self._key_at(row)
        e = self.sheet.entries.get(k) if (k and self.sheet) else None
        self.cand_combo.clear()
        if e is None:
            self.source_label.setText("Select a row to see where its value comes from.")
        else:
            where = f"{e.document}, page {e.page}" if e.document and e.page else (e.document or "no document")
            quote = f"“{e.quoted_text}”" if e.quoted_text else (e.note or "")
            check = f" ({e.check_note})" if e.check_note else ""
            self.source_label.setText(f"{k}: {quote} — {where}{check}" if e.status != "conflict" else
                                      f"{k}: the documents state {len(e.candidates)} values. Pick the one that "
                                      f"applies to this site and press Use this statement, or type your own value.")
            for c in e.candidates:
                self.cand_combo.addItem(f"{_show(c['value'])} {c.get('unit', '')} — {c.get('document', '')} "
                                        f"p.{c.get('page')}: {c.get('quoted_text', '')[:70]} "
                                        f"[{CHECK_LABELS.get(c.get('check', ''), '')}]")
        self._source_widgets(e)

    def select_key(self, key: str):
        self.table.setCurrentCell(self.row_of(key), C_KEY)
        self._row_selected(self.row_of(key))

    def use_statement(self, index: int):
        """Take statement `index` of the selected row (documents that disagree). The operator still ticks it."""
        k = self._key_at(self.table.currentRow())
        if not k or index < 0 or index >= len(self.sheet.entries[k].candidates):
            return
        self.sheet.pick(k, index)
        self.table.blockSignals(True)
        self._fill_row(self.row_of(k), k, k in set(required_keys()))
        self.table.blockSignals(False)
        self._row_selected(self.row_of(k))
        self._update_ready()

    def _pdf_named(self, name: str) -> Path | None:
        return next((p for p in self.pdfs if p.name == name and p.exists()), None)

    def page_dialog(self, key: str):
        """The page the key's value was quoted from, in a dialog (not shown); None without Qt's PDF module."""
        from .pdf_page import HAVE_QTPDF, PdfPageDialog
        e = self.sheet.entries.get(key) if self.sheet else None
        pdf = self._pdf_named(e.document) if e is not None and e.document else None
        if pdf is None or not e.page or not HAVE_QTPDF:
            return None
        return PdfPageDialog(pdf, int(e.page), e.quoted_text, self)

    def open_page(self):
        k = self._key_at(self.table.currentRow())
        if not k:
            return
        dlg = self.page_dialog(k)
        if dlg is not None:
            dlg.exec(); dlg.deleteLater()
            return
        pdf = self._pdf_named(self.sheet.entries[k].document)
        if pdf is not None:                     # no Qt PDF module: the system viewer, at page 1
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(pdf)))

    @property
    def proposing(self) -> bool:
        return self._task is not None

    def _busy_changed(self):
        self.refresh()
        if self.on_busy is not None:
            self.on_busy()

    # ---------------- PDFs + proposal ----------------
    def _add_pdf_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Client standards", "", "PDF (*.pdf)")
        self.add_pdfs([Path(p) for p in paths])

    def add_pdfs(self, paths: list[Path]):
        """Import PDFs. Operator ruling 2026-10-07: an imported PDF is read whole at once and the sheet proposed
        from it, so its values are on the table (with page citations) ready to confirm; no key, no proposal."""
        added = False
        for p in paths:
            if p not in self.pdfs:
                self.pdfs.append(p); added = True
        self._fill_files_only()
        self.refresh()
        if added and self.pdfs:
            if self.config and self.config.effective_api_key():
                self.propose()
            else:
                warn(self, "PDF added, not read", "Set the Anthropic API key in Config… (or the ANTHROPIC_API_KEY "
                     "environment variable) and press Propose to read the PDFs and fill the sheet. You can also "
                     "type values straight into the 'value' column.")

    def remove_selected_pdf(self):
        row = self.files.currentRow()
        if row < 0 or row >= len(self.pdfs):
            return
        del self.pdfs[row]
        self._fill_files_only(); self.refresh()

    def _clear_spec_dialog(self):
        if self.store is None or self.locked:
            return
        st = self.store.load()
        if not ask_yes_no(self, "Clear spec?", f"Remove every saved spec revision of site {st['site']} (sheets and "
                          f"imported PDFs) and empty the sheet, so a new spec can be imported or typed? Every "
                          f"started stage goes stale until a new revision is saved. This cannot be undone."):
            return
        self.clear_spec()

    def clear_spec(self):
        from ..core import approval
        approval.clear_spec(self.store)
        self.pdfs, self.sheet = [], Sheet.blank(self.store.load()["client"])
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()

    def _fill_files_only(self):
        self.files.clear()
        for p in self.pdfs:
            self.files.addItem(str(p))

    def install_anthropic(self):
        """pip install anthropic into QGIS's Python through the plugin's launcher, as a background task."""
        if self._task is not None or self.config is None:
            return
        try:
            launcher = envmod.command_for(self.config, stages.get("p4_poles"), "adapters/p4_poles.py")[0]
        except Exception as e:                           # noqa: BLE001 - no QGIS found / bad config
            warn(self, "Install anthropic", f"{type(e).__name__}: {e}")
            return
        cmd = deps.pip_install_cmd(launcher, *(deps.missing_packages() or ["anthropic"]))

        def work(task):
            import subprocess
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode, (r.stdout or "") + (r.stderr or ""))

        def done(exc, result=None):
            self._task = None
            if exc is not None or result is None:
                warn(self, "Install anthropic", f"pip did not run: {exc}")
            elif result[0] != 0:
                warn(self, "Install anthropic", f"pip exited {result[0]}:\n\n{result[1][-1500:]}")
            elif not deps.have_anthropic():
                warn(self, "Install anthropic", "pip reported success, but the package is not importable yet. "
                                                 "Restart QGIS, then try Propose again.")
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: pip install anthropic", work, on_finished=done)
        QgsApplication.taskManager().addTask(self._task)
        self.refresh()

    def propose(self):
        if not (self.config and self.config.effective_api_key()) or not self.pdfs or self._task is not None:
            return
        pdfs, client, key = list(self.pdfs), self.store.load()["client"], self.config.effective_api_key()

        def work(task):
            return propose_sheet(pdfs, client, key)

        def done(exception, result=None):
            self._task = None
            self._busy_changed()
            if exception is not None:
                kind = "refused" if isinstance(exception, ProposalRefused) else \
                    "failed" if isinstance(exception, ProposalFailed) else f"error ({type(exception).__name__})"
                warn(self, f"Proposal {kind}", str(exception))
            elif result is not None:
                self.sheet = result
                self._fill()
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: propose spec sheet", work, on_finished=done)
        self._busy_changed()
        QgsApplication.taskManager().addTask(self._task)

    # ---------------- copy (rollout 2026-10-12) ----------------
    def copy_sources(self) -> list[tuple[str, Path]]:
        return spec_sources(self.store.site_dir.parent, exclude_site=self.store.site) if self.store is not None else []

    def _copy_dialog(self):
        src = self.copy_sources()
        if not src:
            info(self, "Copy spec", "No template or other site with a saved spec was found.")
            return
        label, ok = QInputDialog.getItem(self, "Copy spec from", "Fill this site's sheet from:", [s[0] for s in src], 0, False)
        if ok and label:
            self.copy_from(label, dict(src)[label])
            info(self, "Spec copied", f"Filled from {label}.\nReview every value (edit or untick any that do not apply "
                                      f"to this site), then press Save revision. Nothing is saved until you do.")

    def copy_from(self, label: str, path: Path) -> None:
        """Replace the unsaved table with a copy of the sheet at `path` (marked with its source). Not saved."""
        self.sheet = copy_sheet(Sheet.load(path), self.store.load()["client"], label)
        self._fill()

    # ---------------- save ----------------
    def _sheet_from_table(self) -> Sheet:
        st = self.store.load()
        out = Sheet(st["client"], "", {})
        for r in range(self.table.rowCount()):
            k = self.table.item(r, C_KEY).data(Qt.ItemDataRole.UserRole)
            e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
            text = (self.table.item(r, C_VALUE).text() if self.table.item(r, C_VALUE) else "").strip()
            ticked = self.table.item(r, C_CONFIRM).checkState() == Qt.CheckState.Checked
            entry = SheetEntry(**{**e.__dict__})
            out.entries[k] = entry
            if not ticked:
                if entry.status == "confirmed":
                    entry.status = "proposed"            # un-ticking withdraws the confirmation
                continue
            if text.lower() in NA_WORDS:
                out.mark_not_applicable(k)
            elif not text:
                continue                                 # ticked but empty: stays unresolved
            elif text == _show(e.value) and e.status in ("proposed", "confirmed") and e.check in BLOCKING:
                # the plugin could not find Claude's quote (or the value in it) in the PDF: ticking it makes the
                # value the operator's own statement, never a cited document value
                out.set_operator(k, e.value, f"{e.check_note or e.check}: quote not found in the PDF; "
                                             f"value stated by the operator in the Plan Stages dock")
            elif text == _show(e.value) and e.status in ("proposed", "confirmed"):
                entry.status = "confirmed"
            else:
                out.set_operator(k, _parse(text), "entered in the Plan Stages dock")
        return out

    def save_revision(self) -> str | None:
        """Write spec/rev-NNN/{docs,sheet.json}; mark every non-pending stage stale. Returns the rev or None."""
        sheet = self._sheet_from_table()
        missing = sheet.unresolved(required_keys())
        if missing:
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(missing))
            return None
        base = self.store.site_dir / "spec"
        base.mkdir(parents=True, exist_ok=True)
        existing = sorted(p.name for p in base.glob("rev-*") if p.is_dir())
        rev = f"rev-{(int(existing[-1][4:]) + 1 if existing else 1):03d}"
        rd = base / rev
        (rd / "docs").mkdir(parents=True)
        sheet.rev = rev
        try:
            sheet.save(rd / "sheet.json", required_keys())
        except SheetIncomplete as e:
            shutil.rmtree(rd, ignore_errors=True)
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(e.keys))
            return None
        for p in self.pdfs:
            if p.exists():
                shutil.copy2(p, rd / "docs" / p.name)
        self.store.save_spec_revision(rev)
        info(self, "Spec saved", f"Saved {rev}. Every stage already started is now stale.")
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()
        return rev
