"""The plugin's own check of every value Claude proposes from a client's spec PDFs (design approved 2026-10-13):
the quoted sentence must be on the cited page (or, page corrected, on another page of that PDF), the value must be
in the quote, and the value must be the right kind and in a plausible range. The PDF text is read with pypdf, which
ships with QGIS; a PDF or page with no text (a scan) cannot be checked and says so."""
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path

VERIFIED = "verified"
QUOTE_NOT_FOUND = "quote_not_found"
VALUE_NOT_IN_QUOTE = "value_not_in_quote"
BAD_VALUE = "bad_value"
UNREADABLE = "unreadable"
# a value with one of these checks may not be confirmed as the document's value (the operator may still type it)
BLOCKING = (QUOTE_NOT_FOUND, VALUE_NOT_IN_QUOTE, BAD_VALUE)
LABELS = {VERIFIED: "✓ verified", QUOTE_NOT_FOUND: "⚠ quote not in PDF", VALUE_NOT_IN_QUOTE: "⚠ value not in quote",
          BAD_VALUE: "⚠ implausible value", UNREADABLE: "could not check"}

SPLITS = (2, 4, 8, 16, 32, 64)
# kind, then (low, high) for numbers: what a value of each key may be
KINDS = {
    "density": ("choice", ("high", "low")),
    "drop_cap_m": ("metres", (10, 200)), "span_cap_m": ("metres", (20, 150)), "span_typical_m": ("metres", (10, 150)),
    "cable_span_rating_m": ("metres", (20, 200)), "cross_span_m": ("metres", (10, 150)),
    "fan_cap": ("count", (2, 32)), "pon_cap": ("count", (2, 64)),
    "feeder_split": ("ratio", None), "dist_split": ("ratio", None),
    "pon_target": ("count", (8, 256)), "pon_max": ("count", (8, 512)),
    "pole_midblock_m": ("metres", (4, 15)), "pole_crossing_m": ("metres", (4, 15)), "pole_feeder_m": ("metres", (4, 15)),
    "pole_boundary_setback_m": ("metres", (0, 20)), "pole_pitch_m": ("metres", (10, 100)),
    "direction_change_stay_deg": ("degrees", (1, 90)), "aerial": ("bool", None),
}
_NUM = re.compile(r"\d+(?:[.,]\d+)?")


@dataclass
class Candidate:
    key: str
    value: object
    unit: str
    document: str          # path of the PDF
    page: int | None       # 1-based, as cited
    quoted_text: str


@dataclass
class Result:
    check: str
    note: str
    page: int | None
    value: object          # the normalised value (None when it is not a valid value of the key)


def _num(v) -> float | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = _NUM.search(str(v)) if v is not None else None
    return float(m.group(0).replace(",", ".")) if m else None


def normalise(key: str, v):
    """The value as the planning scripts take it, or None when it is not a valid, plausible value of `key`."""
    kind, rng = KINDS[key]
    if kind == "choice":
        s = str(v).strip().lower() if v is not None else ""
        return s if s in rng else None
    if kind == "bool":
        if isinstance(v, bool):
            return v
        s = str(v).strip().lower()
        return True if s in ("true", "yes", "y", "1", "aerial") else False if s in ("false", "no", "n", "0") else None
    if kind == "ratio":
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            n = v
        else:
            m = re.fullmatch(r"\s*1\s*[:/]\s*(\d+)\s*", str(v)) if v is not None else None
            n = int(m.group(1)) if m else None
        return f"1:{int(n)}" if n is not None and float(n) == int(n) and int(n) in SPLITS else None
    x = _num(v)
    if x is None or not (rng[0] <= x <= rng[1]):
        return None
    if kind == "count":
        return int(x) if x == int(x) else None
    return x


def _flat(s: str) -> str:
    """Text reduced to what a quote must match: lower case, no whitespace, plain quotes/dashes, no bullet glyphs."""
    s = s.lower().translate({0x2018: "'", 0x2019: "'", 0x201C: '"', 0x201D: '"', 0x2013: "-", 0x2014: "-",
                             0x2022: None, 0xF0B7: None, 0x00A0: " "})
    return re.sub(r"\s+", "", s)


class PdfTexts:
    """Page texts per PDF, read once."""

    def __init__(self):
        self._cache: dict[str, list[str] | None] = {}

    def pages(self, pdf) -> list[str] | None:
        key = str(pdf)
        if key not in self._cache:
            try:
                import logging, pypdf
                logging.getLogger("pypdf").setLevel(logging.ERROR)      # a damaged PDF is reported, not logged
                reader = pypdf.PdfReader(key)
                self._cache[key] = [(p.extract_text() or "") for p in reader.pages]
            except Exception:                 # noqa: BLE001 - missing pypdf, damaged or encrypted PDF: not checkable
                self._cache[key] = None
        return self._cache[key]


def _value_in_quote(key: str, value, quote: str) -> bool:
    kind, _ = KINDS[key]
    if kind in ("choice", "bool"):
        return True                           # a regime or yes/no is stated in words, not as a number
    if kind == "ratio":
        n = value.split(":")[1]
        return re.search(rf"(?<!\d){n}(?!\d)", quote) is not None
    nums = [float(m.group(0).replace(",", ".")) for m in _NUM.finditer(quote)]
    return any(abs(n - float(value)) < 1e-6 for n in nums)


def check(c: Candidate, texts: PdfTexts) -> Result:
    value = normalise(c.key, c.value)
    if value is None:
        return Result(BAD_VALUE, f"{c.value!r} is not a plausible {c.key}", c.page, None)
    pages = texts.pages(c.document)
    name = Path(c.document).name
    if not pages or not any(p.strip() for p in pages):
        return Result(UNREADABLE, f"{name} has no readable text (a scan?): check the page by eye", c.page, value)
    q = _flat(c.quoted_text)
    if not q:
        return Result(QUOTE_NOT_FOUND, "no quote given", c.page, value)
    order = list(range(len(pages)))
    if c.page and 1 <= c.page <= len(pages):
        order.remove(c.page - 1); order.insert(0, c.page - 1)
    hit = next((i for i in order if q in _flat(pages[i])), None)
    if hit is None:
        cited = pages[c.page - 1] if c.page and 1 <= c.page <= len(pages) else ""
        if c.page and not cited.strip():
            return Result(UNREADABLE, f"page {c.page} of {name} has no readable text: check it by eye", c.page, value)
        return Result(QUOTE_NOT_FOUND, f"the quoted sentence is not in {name}", c.page, value)
    if not _value_in_quote(c.key, value, c.quoted_text):
        return Result(VALUE_NOT_IN_QUOTE, f"{c.value!r} does not appear in the quoted sentence", hit + 1, value)
    note = f"found on p.{hit + 1} of {name}" + (f" (cited p.{c.page})" if c.page != hit + 1 else "")
    return Result(VERIFIED, note, hit + 1, value)
