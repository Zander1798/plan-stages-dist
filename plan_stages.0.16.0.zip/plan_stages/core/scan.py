"""Scan current wayleave state (0.16.0): which plan steps the operator's project already holds, and which of them
the takeover processes in order. Pure Python, no QGIS: the window supplies the picks and the feature counts."""
from __future__ import annotations
from dataclasses import dataclass, field
from . import stages

# Chain order. p8_delivery, wayleave and gate0 are never taken over.
SCANNED = ("p1_feeder", "p2_1to16", "p3_distribution", "p4_drops", "p5_crossings", "p7_hardware")

# Plan layers a step must hold to count as covered. P4's collection points are optional (worked out when missing).
NEEDED = {"p1_feeder": ("feeder",), "p2_1to16": ("splitters_1to16",), "p3_distribution": ("distribution",),
          "p4_drops": ("drops",), "p5_crossings": ("road_crossings",),
          "p7_hardware": ("splitters_8way", "dome_joints")}
OPTIONAL = {"p4_drops": ("collection_points",)}


def snapshot_outputs(stage_id: str) -> tuple:
    """The plan layers a takeover snapshots for a step: its outputs minus drop_review (plugin-only, never scanned)."""
    return tuple(o for o in stages.get(stage_id).outputs if o.name != "drop_review")


@dataclass
class Row:
    stage_id: str
    state: str                     # "found" | "outstanding" | "in_progress" | "approved"
    layers: dict[str, list[str]] = field(default_factory=dict)   # plan layer -> picked project layers WITH features
    note: str = ""
    stale: bool = False            # in_progress only: approved before, now stale (final review M3, 2026-10-29)


LABEL = {"found": "Found", "outstanding": "Outstanding",
         "in_progress": "Started in the plugin, not yet approved", "approved": "Already done in the plugin"}
STALE = "Approved in the plugin, now stale (an earlier step or the spec changed)"


def label(row: Row) -> str:
    """The plain words the Scan window shows for a row's state."""
    return STALE if row.stale else LABEL[row.state]


def _note(sid: str, picks: dict, usable: dict, found: bool) -> str:
    if found:
        return ""
    if sid == "p7_hardware":
        # spec P6 line: a lone dome layer is not used, a lone 8-way layer likewise
        if "dome_joints" in usable and "splitters_8way" not in usable:
            return f"your dome joints ({', '.join(usable['dome_joints'])}) are not used: no 8-way splitter layer found"
        if "splitters_8way" in usable and "dome_joints" not in usable:
            return f"your 8-way splitters ({', '.join(usable['splitters_8way'])}) are not used: no dome joint layer found"
    if any(picks.get(k) for k in NEEDED[sid]):
        return "the picked layer has no features; the plugin will generate this step"
    return "no layer found; the plugin will generate this step"


def rows(store, picks: dict[str, list[str]], counts: dict[str, int]) -> list[Row]:
    """One Row per scanned step. Approved / in_progress come from site.json, else found / outstanding from the picks."""
    stages = store.load()["stages"]
    out = []
    for sid in SCANNED:
        usable = {}
        for plan_layer in NEEDED[sid] + OPTIONAL.get(sid, ()):
            names = [n for n in picks.get(plan_layer, []) if counts.get(n, 0) > 0]
            if names:
                usable[plan_layer] = names
        found = all(k in usable for k in NEEDED[sid])
        s = stages.get(sid, {})
        if s.get("status") == "approved":
            state = "approved"
        elif s.get("current_rev") and s.get("status") != "failed":    # a failed rev is no work to keep
            state = "in_progress"
        else:
            state = "found" if found else "outstanding"
        out.append(Row(sid, state, usable if found else ({} if state in ("found", "outstanding") else usable),
                       _note(sid, picks, usable, found) if state in ("found", "outstanding") else "",
                       stale=state == "in_progress" and s.get("status") == "stale" and bool(s.get("approved_rev"))))
    return out


def _takeable(row: Row, replace: set) -> bool:
    """Rule 2 content test: found, or a started/approved row the operator switched to their project layers."""
    if row.state == "found":
        return True
    if row.state in ("approved", "in_progress") and row.stage_id in replace:
        return all(k in row.layers for k in NEEDED[row.stage_id])
    return False


def walk(store, rows: list[Row], replace: set[str]) -> tuple[list[str], str | None, str]:
    """(take_over_in_order, stop_stage, why). Spec rules: an approved step that is kept is left (1); a found step is
    taken when every step before it is approved (2), counting steps taken earlier in this same press; anything
    else stops the walk, and later found layers wait (3). A kept approved step built (transitively) on a step taken
    in this press goes stale when that step is approved, so it stops the walk too (final review I1, 2026-10-29)."""
    if store.load()["stages"].get("gate0", {}).get("status") != "approved":
        return [], "p1_feeder", "run Gate 0 first; these steps will then be taken over"
    take: list[str] = []
    for row in rows:
        if row.state == "approved" and row.stage_id not in replace:
            under = next((t for t in take if row.stage_id in stages.downstream_of(t)), None)
            if under is not None:
                return take, row.stage_id, (f"{stages.get(row.stage_id).name} goes stale when "
                                            f"{stages.get(under).name} is replaced: Generate it again "
                                            f"(or untick keep)")
            continue
        if _takeable(row, replace):
            take.append(row.stage_id)
            continue
        if row.state == "in_progress" and row.stale:
            why = "approved before, now stale (an earlier step or the spec changed): Generate it again (or untick keep)"
        elif row.state == "in_progress":
            why = "started in the plugin and not yet approved: finish it first"
        elif row.state == "approved":
            why = "you switched it to your project layers, but none were found"
        else:
            why = "no layer found for this step; the plugin will generate it, then the rest can follow"
        return take, row.stage_id, why
    return take, None, ""
