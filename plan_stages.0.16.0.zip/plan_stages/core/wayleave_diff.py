"""Is the wayleave on screen still the approved snapshot? (operator 2026-10-14, D-PS.8: Generate stops and says so
when it is not.) Both sides are written by the same wayleave_box.write_snapshot, so a feature is the same when its
geometry (rounded to 0.001 site units) and its snapshot fields match. A moved feature is one added, one removed."""
from __future__ import annotations
import re
from collections import Counter
from pathlib import Path
from osgeo import ogr

_NUM = re.compile(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")


def _wkt(g) -> str:
    if g is None or g.IsEmpty():
        return ""
    return _NUM.sub(lambda m: f"{float(m.group()):.3f}".replace("-0.000", "0.000"), g.ExportToWkt())


def fingerprint(gpkg: Path) -> dict[str, Counter]:
    ds = ogr.Open(str(gpkg)); out = {}
    for i in range(ds.GetLayerCount() if ds is not None else 0):
        lyr = ds.GetLayer(i); defn = lyr.GetLayerDefn()
        names = [defn.GetFieldDefn(k).GetName() for k in range(defn.GetFieldCount())]
        out[lyr.GetName()] = Counter((_wkt(f.GetGeometryRef()), tuple(str(f.GetField(n)) for n in names)) for f in lyr)
    ds = None
    return out


def fingerprint_hash(gpkg: Path) -> str:
    """One sha256 of fingerprint(gpkg), independent of feature order (0.16.0 Scan: the raw takeover snapshot's hash,
    recorded in takeover.json and compared on a rescan)."""
    import hashlib
    fp = fingerprint(gpkg)
    rows = [[name, sorted([w, list(attrs), n] for (w, attrs), n in fp[name].items())] for name in sorted(fp)]
    return hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()


def diff(approved: Path, screen: Path, picked: set[str]) -> list[str]:
    a, b = fingerprint(approved), fingerprint(screen)
    out = []
    for name in sorted(set(a) | set(b)):
        if name in a and name not in picked:
            out.append(f"{name}: not picked in the Wayleave box")
        elif name not in a:
            out.append(f"{name}: picked but not in the snapshot")
        else:
            now = b.get(name, Counter())
            added, removed = sum((now - a[name]).values()), sum((a[name] - now).values())
            if added or removed:
                out.append(f"{name}: {added} added, {removed} removed")
    return out
