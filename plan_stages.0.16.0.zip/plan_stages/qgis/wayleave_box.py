"""The Plan tab's Wayleave box: pick the project's wayleave layers and snapshot them as the approved input.

The plugin never generates a wayleave. One row per registry output of the `wayleave` stage, each a layer combo
auto-matched by name; "Use this wayleave" writes the chosen layers into a new wayleave revision's working.gpkg
(reprojected to the site CRS, registry fields only) and hands it to StageController.import_wayleave, which
checks it and approves it only when the checks pass. That press is the operator's approval."""
from __future__ import annotations
from pathlib import Path
from qgis.PyQt.QtCore import QMetaType, Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                                 QListWidgetItem, QApplication, QComboBox, QSizePolicy)
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField, QgsGeometry,
                       QgsMapLayerProxyModel, QgsProject, QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes)
from qgis.gui import QgsMapLayerComboBox
from ..core import export, stages
from ..core.layermatch import int_value, match_name, source_field
from ..core.controller import WAYLEAVE
from . import layers
from .issue_list import IssueList
from .ui import ask_yes_no, badge_style, warn

_FILTER = {"Point": QgsMapLayerProxyModel.Filter.PointLayer, "LineString": QgsMapLayerProxyModel.Filter.LineLayer,
           "Polygon": QgsMapLayerProxyModel.Filter.PolygonLayer}
_QTYPE = {"str": QMetaType.Type.QString, "int": QMetaType.Type.Int, "real": QMetaType.Type.Double}
_CAST = {"str": str, "int": int, "real": float}
# The operator's shapefile basenames (scripts/ml/site_config._LAYERS), keyed by registry layer name.
BASENAME = {layer: base for base, _sid, layer, _req in export.MAP}


def _outputs():
    return stages.get(WAYLEAVE).outputs


class LayerCombo(QgsMapLayerComboBox):
    """Live walk 2026-10-15: scrolling the dock over an unfocused combo changed its layer (pop jumped to the
    plugin's own issue layer and Generate refused). Unfocused, the wheel is ignored, so Qt hands it on to the
    dock, which scrolls; a click or Tab gives the combo focus and the wheel then works in it as usual."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def wheelEvent(self, event):
        if not self.hasFocus():
            event.ignore()
            return
        super().wheelEvent(event)


def match_layer(spec, candidates: list) -> QgsVectorLayer | None:
    """The project layer a registry layer most likely is (core.layermatch.match_name: exact registry name, then
    the operator's shapefile basename, then, for optional rows only, the shortest name containing either).
    Candidates are already of the right geometry type. A matching layer with features goes before an empty one, and
    a required row is not given an empty layer while another candidate has features (walk 2026-10-29)."""
    i = match_name(spec.name, BASENAME.get(spec.name, spec.name), spec.optional, [l.name() for l in candidates],
                   counts=[l.featureCount() for l in candidates])
    return candidates[i] if i is not None else None


def _geom_ok(lyr, geom: str) -> bool:
    want = {"Point": QgsWkbTypes.GeometryType.PointGeometry, "LineString": QgsWkbTypes.GeometryType.LineGeometry,
            "Polygon": QgsWkbTypes.GeometryType.PolygonGeometry}[geom]
    return isinstance(lyr, QgsVectorLayer) and lyr.isValid() and lyr.geometryType() == want


def own_layer(lyr, store, controller) -> bool:
    """A layer this plugin loaded (a stage revision or an issue layer): never a wayleave or Scan source. Marked by
    layers.OWN_PROP; issue layers from before the mark are known by name, stage layers by the plan root."""
    if lyr.customProperty(layers.OWN_PROP, False) in (True, "true"):
        return True
    if store is not None and lyr.name() in {f"{store.site} · {stages.get(s).name} issues" for s in stages.order()}:
        return True
    if controller is None:
        return False
    try:
        root = Path(controller.config.plan_root).resolve()
        src = Path(lyr.source().split("|")[0]).resolve()
        return root == src or root in src.parents
    except (OSError, ValueError):
        return False


def project_layers(store, controller, geom: str) -> list:
    """The project's vector layers of this geometry type that are the operator's own (Scan, 0.16.0)."""
    return [l for l in QgsProject.instance().mapLayers().values()
            if _geom_ok(l, geom) and not own_layer(l, store, controller)]


def _is_null(value) -> bool:
    if value is None:
        return True
    try:
        return bool(hasattr(value, "isNull") and value.isNull())
    except TypeError:
        return False


def _numeric(text: str) -> bool:
    try:
        float(text)
        return True
    except ValueError:
        return False


def _cast(value, typ: str, int_labels: bool = False):
    """The value as the registry field's type, or None. With `int_labels` (plan-step takeover snapshots only, walk
    2026-10-29) an int field also takes a label ending in its number ("PON 047" -> 47, layermatch.int_value). The
    wayleave snapshot keeps the old int(float()) reading (controller ruling 2026-10-29): Cradock's Pons hold PON as
    'P001'.., null in every approved wayleave, so reading them would make Generate report the wayleave changed."""
    if _is_null(value):
        return None
    if typ == "int" and int_labels:
        return int_value(value)
    try:
        return _CAST[typ](value) if typ != "int" else int(float(value))
    except (TypeError, ValueError):
        return None


def write_snapshot(path: Path, chosen: dict, epsg: int, log: list | None = None, outputs=None,
                   link_flag=None, single_parts: bool = False, int_labels: bool = False) -> dict[str, int]:
    """Write one GeoPackage layer per chosen registry layer: features reprojected to EPSG:<epsg>, registry fields
    filled from the first source field whose lowercased name matches (missing ones left null). Multipoints are
    split into points (the registry layer is Point). Returns feature counts by layer; `log` collects one line
    per registry field saying which source field (or alias) fed it.
    Scan (2026-10-29): a chosen value may be a list of layers, merged into the one output layer (a step the
    operator drew across several layers); `outputs` defaults to the wayleave's registry layers; `link_flag(layer)`
    gives the `link` value for every feature of that layer (None = follow the normal field matching). Lines keep
    their own geometry; sources mixing single and multi lines write a multi-line layer.
    `single_parts` (final review C1, 2026-10-29; plan-step snapshots only, the wayleave's stays as it was): QGIS
    reports every line shapefile as MultiLineString, so when every feature has one part the layer is written single
    (LineString, Polygon) with each geometry its one part, exactly the same coordinates; a genuine multi-part
    feature keeps the layer multi.
    `int_labels` (walk 2026-10-29; plan-step snapshots only): an int field reads a label ending in its number
    ("PON 047" -> 47). The wayleave's snapshot leaves it off, so its output stays exactly as before."""
    path = Path(path)
    dest = QgsCoordinateReferenceSystem(f"EPSG:{epsg}")
    ctx = QgsProject.instance().transformContext()
    counts, first = {}, True
    for spec in (outputs if outputs is not None else _outputs()):
        val = chosen.get(spec.name)
        srcs = [val] if isinstance(val, QgsVectorLayer) else list(val or [])
        if not srcs:
            continue
        flats = {QgsWkbTypes.flatType(s.wkbType()) for s in srcs}
        multi = spec.geom != "Point" and len(flats) > 1 and any(QgsWkbTypes.isMultiType(f) for f in flats)
        flat = QgsWkbTypes.multiType(next(iter(flats))) if multi else next(iter(flats))
        out = []                                    # [(attributes, geometry)]
        for src in srcs:
            skipped = []
            src_names = [f.name() for f in src.fields()]
            found = [source_field(n, src_names) for n, _t in spec.fields]
            idx = [i for i, _how in found]
            flag = link_flag(src) if link_flag is not None else None
            if log is not None:
                log.append(f"{spec.name}: source {src.name()} CRS {src.crs().authid() or '(none)'} -> EPSG:{epsg}")
                for (n, _t), (_i, how) in zip(spec.fields, found):
                    log.append(f"{spec.name}.{n} <- "
                               + (f"link flag {flag}" if flag is not None and n == "link"
                                  else how or 'null (no matching field)'))
            ct = QgsCoordinateTransform(src.crs(), dest, QgsProject.instance())
            lost, from_text = {}, {}                # field -> [count, first value]: values not read / read from a label
            for f in src.getFeatures():
                raw = [f.attributes()[i] if i >= 0 else None for i in idx]
                attrs = [_cast(v, t, int_labels) for v, (_n, t) in zip(raw, spec.fields)]
                if log is not None:
                    for v, a, (n, t) in zip(raw, attrs, spec.fields):
                        if a is None and not _is_null(v) and not (isinstance(v, str) and not v.strip()):
                            lost.setdefault(n, [0, v])[0] += 1
                        elif t == "int" and isinstance(v, str) and a is not None and not _numeric(v):
                            from_text.setdefault(n, [0, v, a])[0] += 1
                if flag is not None:
                    attrs = [flag if n == "link" else a for a, (n, _t) in zip(attrs, spec.fields)]
                g = f.geometry()
                if g is None or g.isNull() or g.isEmpty():
                    skipped.append(f.id())          # a feature with no location cannot be planned (walk 2026-10-07)
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                parts = [g]
                if spec.geom == "Point" and g.isMultipart():
                    parts = [QgsGeometry.fromPointXY(p) for p in g.asMultiPoint()]
                elif multi and not g.isMultipart():
                    g.convertToMultiType()
                out.extend((attrs, part) for part in parts)
            if log is not None:
                for n, (c, v, a) in from_text.items():
                    log.append(f"{spec.name}.{n}: number read from the text of {c} value(s) of {src.name()} "
                               f"(e.g. {v!r} -> {a})")
                for n, (c, v) in lost.items():
                    log.append(f"{spec.name}.{n}: {c} value(s) of {src.name()} could not be read as "
                               f"{'a whole number' if dict(spec.fields)[n] == 'int' else 'a number'} "
                               f"(e.g. {v!r}); left null")
            if skipped and log is not None:
                ids = ", ".join(str(i) for i in skipped[:20]) + (" ..." if len(skipped) > 20 else "")
                log.append(f"{spec.name}: {len(skipped)} feature(s) of {src.name()} with no geometry skipped "
                           f"(feature ids {ids})")
        if (single_parts and spec.geom != "Point" and QgsWkbTypes.isMultiType(flat)
                and all(not g.isMultipart() or g.constGet().numGeometries() == 1 for _a, g in out)):
            flat = QgsWkbTypes.singleType(flat)
            for _a, g in out:
                if g.isMultipart():
                    g.convertToSingleType()
        gtype = "Point" if spec.geom == "Point" else QgsWkbTypes.displayString(flat)
        mem = QgsVectorLayer(f"{gtype}?crs=EPSG:{epsg}", spec.name, "memory")
        mem.dataProvider().addAttributes([QgsField(n, _QTYPE[t]) for n, t in spec.fields])
        mem.updateFields()
        feats = []
        for attrs, g in out:
            nf = QgsFeature(mem.fields())
            nf.setGeometry(g)
            nf.setAttributes(attrs)
            feats.append(nf)
        mem.dataProvider().addFeatures(feats)
        mem.updateExtents()
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = spec.name
        opts.fileEncoding = "UTF-8"
        opts.actionOnExistingFile = (QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile if first
                                     else QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer)
        err, msg, _f, _l = QgsVectorFileWriter.writeAsVectorFormatV3(mem, str(path), ctx, opts)
        if err != QgsVectorFileWriter.WriterError.NoError:
            raise RuntimeError(f"writing {spec.name} from {', '.join(s.name() for s in srcs)}: {msg}")
        counts[spec.name] = len(out)
        first = False
    return counts


class WayleaveBox(QWidget):
    changed = pyqtSignal()          # a snapshot or check finished: the dock re-evaluates every tab

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.controller = self.store = None
        self.locked = self.busy = self.external_busy = False     # external: a plan stage task is running
        self._auto = False                       # True while auto-matching, so combo changes are not "manual"
        self.manual: set[str] = set()            # rows the operator picked by hand: auto-match leaves them alone
        self.note_edited = False
        self.last_report = None
        self._ids: dict[str, str | None] = {}   # row -> id of the layer chosen for it (by auto-match or by hand)
        self._removing = False                   # inside a project layer removal
        self._lost: set[str] = set()             # rows whose chosen layer is being removed
        # 2026-10-20: set by the dock; saves the Spec tab's sheet, returns the line to show, or None when incomplete
        self.ensure_spec = None
        self.stage_tab = None                    # 0.16.0: set by the dock; the Scan window runs its chain there
        self._scan_dlg = None
        self._build()
        prj = QgsProject.instance()
        self._conns = [(sig, sig.connect(fn)) for sig, fn in (
            (prj.layersWillBeRemoved, self._layers_will_be_removed),
            (prj.layersRemoved, lambda _ids: self._layers_removed()),
            (prj.layersAdded, lambda _l: self._project_layers_changed()))]

    def shutdown(self):
        """Disconnect from the project, which outlives this widget (plugin unload)."""
        self.close_scan()
        for sig, conn in self._conns:
            try:
                sig.disconnect(conn)
            except (TypeError, RuntimeError):
                pass
        self._conns = []

    def _project_layers_changed(self):
        """A project signal: fill rows that are still empty. An exception escaping a PyQt6 slot aborts QGIS."""
        try:
            self._hide_own_layers()
            self.auto_match(only_unset=True)
        except Exception:                        # noqa: BLE001
            pass

    def _layers_will_be_removed(self, ids):
        """When a row's layer leaves the project the combo jumps to another layer of the same type; that jump must
        never stand as the operator's choice. Remember the rows, then empty and re-match them once it is gone."""
        try:
            self._removing = True
            gone = set(ids)
            self._lost |= {n for n, i in self._ids.items() if i in gone}
        except Exception:                        # noqa: BLE001
            pass

    def _layers_removed(self):
        try:
            self._removing = False
            lost, self._lost = self._lost, set()
            self._auto = True
            try:
                for n in lost:
                    self.combos[n].setLayer(None)
                    self._ids[n] = None
                    self.manual.discard(n)
            finally:
                self._auto = False
            self._hide_own_layers()
            self.auto_match(only_unset=True)
        except Exception:                        # noqa: BLE001
            pass

    # ---------------- layout ----------------
    def _build(self):
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        head = QHBoxLayout()
        head.addWidget(QLabel("<b>Wayleave (from project)</b>"))
        self.badge = QLabel("-"); self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter); self.badge.setMinimumWidth(70)
        self.rev_label = QLabel("")
        self.check_btn = QPushButton("Check"); self.check_btn.setEnabled(False)
        self.check_btn.setToolTip("Re-run the wayleave check on the current snapshot")
        self.check_btn.clicked.connect(lambda _=False: self.check())
        head.addWidget(self.badge); head.addWidget(self.rev_label, 1); head.addWidget(self.check_btn)
        lay.addLayout(head)
        grid = QGridLayout(); grid.setContentsMargins(0, 0, 0, 0)
        self.combos: dict[str, QgsMapLayerComboBox] = {}
        self.info: dict[str, QLabel] = {}
        for r, spec in enumerate(_outputs()):
            grid.addWidget(QLabel(spec.name + ("" if not spec.optional else " (optional)")), r, 0)
            cb = LayerCombo()
            cb.setFilters(_FILTER[spec.geom])
            cb.setAllowEmptyLayer(True, "(none)" if spec.optional else "(required: choose a layer)")
            cb.setLayer(None)
            cb.layerChanged.connect(lambda _l, n=spec.name: self._picked(n))
            # a long layer name must not widen the dock: the combo shrinks and the full name is its tooltip
            cb.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(12)
            grid.addWidget(cb, r, 1); self.combos[spec.name] = cb
            lab = QLabel(""); lab.setMinimumWidth(150)       # count and CRS stay visible; the combo takes the rest
            grid.addWidget(lab, r, 2); self.info[spec.name] = lab
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)
        bar = QHBoxLayout()
        self.note = QLineEdit(); self.note.setPlaceholderText("approval note")
        self.note.textEdited.connect(lambda _t: setattr(self, "note_edited", True))
        self.use_btn = QPushButton("Use this wayleave"); self.use_btn.clicked.connect(lambda _=False: self.use_wayleave())
        self.use_btn.setToolTip("Snapshot the chosen layers as this site's wayleave; approved when its checks pass")
        bar.addWidget(self.note, 1); bar.addWidget(self.use_btn)
        lay.addLayout(bar)
        # 0.16.0 (spec 2026-10-29): the plan steps the operator already drew, taken over in order
        self.scan_btn = QPushButton("Scan current wayleave state"); self.scan_btn.setEnabled(False)
        self.scan_btn.clicked.connect(lambda _=False: self.open_scan())
        lay.addWidget(self.scan_btn, 0, Qt.AlignmentFlag.AlignRight)
        self.reason = QLabel(""); self.reason.setWordWrap(True); self.reason.setStyleSheet("color: #8d6e00;")
        lay.addWidget(self.reason)
        self.report = IssueList(self.iface, lambda issue: self.chosen().get(issue.layer)); self.report.setMaximumHeight(110)
        lay.addWidget(self.report)

    # ---------------- state ----------------
    def set_site(self, controller, store, locked: bool):
        self.close_scan()                        # fix round T6: never a Scan window of the previous site
        self.controller, self.store, self.locked = controller, store, locked
        self.busy = False
        self.manual.clear(); self.note_edited = False
        self.report.clear(); self.reason.setText(""); self.last_report = None    # a fresh slate every time
        self._hide_own_layers()
        self.auto_match(only_unset=False)
        self._restore_picks()
        self.refresh()

    # 2026-10-14 (0.7.0 review): Generate compares the wayleave on screen with the snapshot, so the layers the
    # snapshot came from must come back when the site is opened again, hand-picked rows included.
    def remember_picks(self):
        if self.store is None:
            return
        st = self.store.load()
        st["wayleave_picks"] = {n: {"id": l.id(), "name": l.name(), "source": l.source()} for n, l in self.chosen().items()}
        self.store.save(st)

    def _restore_picks(self):
        if self.store is None:
            return
        picks = self.store.load().get("wayleave_picks") or {}
        layers_now = [l for l in QgsProject.instance().mapLayers().values() if isinstance(l, QgsVectorLayer)]
        specs = {s.name: s for s in _outputs()}
        self._auto = True
        try:
            for name, p in picks.items():
                if name not in self.combos or name not in specs:
                    continue
                ok = [l for l in layers_now if _geom_ok(l, specs[name].geom) and not self._own_layer(l)]
                hit = next((l for l in ok if l.id() == p.get("id")), None) or \
                    next((l for l in ok if p.get("source") and l.source() == p.get("source")), None) or \
                    next((l for l in ok if l.name() == p.get("name")), None)
                if hit is not None:
                    self.combos[name].setLayer(hit); self._ids[name] = hit.id(); self.manual.add(name)
        finally:
            self._auto = False
        self._update_info()

    def chosen(self) -> dict:
        return {n: cb.currentLayer() for n, cb in self.combos.items() if cb.currentLayer() is not None}

    def missing_required(self) -> list[str]:
        ch = self.chosen()
        return [s.name for s in _outputs() if not s.optional and s.name not in ch]

    def _own_layer(self, lyr) -> bool:
        return own_layer(lyr, self.store, self.controller)

    def _hide_own_layers(self):
        """The plugin's own layers are left out of every combo's list (live walk 2026-10-15)."""
        own = [l for l in QgsProject.instance().mapLayers().values() if self._own_layer(l)]
        for cb in self.combos.values():
            cb.setExceptedLayerList(own)

    def auto_match(self, only_unset: bool = False):
        layers_now = [l for l in QgsProject.instance().mapLayers().values() if isinstance(l, QgsVectorLayer)]
        self._auto = True
        try:
            for spec in _outputs():
                cb = self.combos[spec.name]
                cur = cb.currentLayer()
                held = cur is not None and cur.id() == self._ids.get(spec.name)   # not a combo's own jump
                if only_unset and (spec.name in self.manual or held):
                    continue
                cands = [l for l in layers_now if _geom_ok(l, spec.geom) and not self._own_layer(l)]
                hit = match_layer(spec, cands)
                cb.setLayer(hit)
                self._ids[spec.name] = hit.id() if hit is not None else None
        finally:
            self._auto = False
        self._update_info()

    def _picked(self, name: str):
        if self._removing:                       # the combo's own jump during a removal, not a choice
            return
        lyr = self.combos[name].currentLayer()
        self._ids[name] = lyr.id() if lyr is not None else None
        if not self._auto:
            self.manual.add(name)
        self._update_info()

    def _update_info(self):
        epsg = self.store.load()["epsg"] if self.store is not None else None
        for spec in _outputs():
            lyr, lab = self.combos[spec.name].currentLayer(), self.info[spec.name]
            if lyr is None:
                lab.setText("" if spec.optional else "missing"); lab.setStyleSheet("" if spec.optional else "color: #c62828;")
                continue
            crs = lyr.crs().authid() or "no CRS"
            lab.setText(f"{lyr.featureCount():,} · {crs}" + (f" → EPSG:{epsg}" if epsg and crs != f"EPSG:{epsg}" else ""))
            lab.setStyleSheet("" if lyr.crs().isValid() else "color: #c62828;")
        if not self.note_edited:
            names = ", ".join(l.name() for l in self.chosen().values())
            self.note.setText(f"snapshot of project layers: {names}" if names else "")
        self.refresh()

    def refresh(self):
        s = self.store.load() if self.store is not None else None
        ws = s["stages"][WAYLEAVE] if s else {}
        status = ws.get("status", "-")
        self.badge.setText(status); self.badge.setStyleSheet(badge_style(status))
        self.rev_label.setText(f"{ws.get('current_rev') or ''}" + (f" (approved {ws['approved_rev']})"
                                                                     if ws.get("approved_rev") else ""))
        usable = self.controller is not None and not self.locked and not self.busy and not self.external_busy
        try:
            can_check = usable and self.controller.next_enabled(WAYLEAVE)["check"]
        except Exception:                          # noqa: BLE001 - a bad row must not freeze the box
            can_check = False
        self.check_btn.setEnabled(bool(can_check))
        why = self.use_blocked_reason()
        self.use_btn.setEnabled(usable and why is None)
        self.use_btn.setToolTip(why or "Snapshot the chosen layers as this site's wayleave; approved when its checks pass")
        for cb in self.combos.values():
            cb.setEnabled(usable)
        scan_ok = usable and self.stage_tab is not None and status == "approved"
        self.scan_btn.setEnabled(bool(scan_ok))
        self.scan_btn.setToolTip("Find the plan steps your project already holds (feeder, 1:16s, distribution, "
                                 "drops ...) and take them over in order" if scan_ok else
                                 "Press Use this wayleave first" if usable and status != "approved" else "")

    def open_scan(self):
        """The Scan window (non-modal: the chain's Checks run in the background and the dock stays usable)."""
        from .scan_dialog import ScanDialog
        self.close_scan()
        self._scan_dlg = ScanDialog(self.iface, self.controller, self.store, self.stage_tab, self,
                                    on_done=self.changed.emit)
        self._scan_dlg.show()
        return self._scan_dlg

    def close_scan(self):
        """A Scan window belongs to the site it was opened on: closed when the site changes or the plugin unloads."""
        dlg, self._scan_dlg = self._scan_dlg, None
        if dlg is not None:                      # closed, not deleted: a chain still running calls back into it
            try:
                dlg.close()
            except RuntimeError:                 # already deleted
                pass

    def use_blocked_reason(self) -> str | None:
        if self.store is None:
            return "no site selected"
        if not self.store.load().get("spec_rev") and self.ensure_spec is None:
            return "save a spec revision on the Spec tab first"
        miss = self.missing_required()
        if miss:
            return "choose a layer for: " + ", ".join(miss)
        bad = [f"{n} ({l.name()})" for n, l in self.chosen().items() if not l.crs().isValid()]
        if bad:
            return "set a valid CRS on: " + ", ".join(bad)
        return None

    def _show_report(self, report):
        self.report.set_report(report)
        if report is None:
            return
        for c in report.checks:                          # the passed rows too: the box is the operator's receipt
            if c.status == "passed":
                self.report.addItem(QListWidgetItem(f"passed {c.code}: {c.message}"))

    def _set_busy(self, busy: bool):
        self.busy = busy
        if busy:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        else:
            QApplication.restoreOverrideCursor()
        self.refresh()

    # ---------------- actions ----------------
    def use_wayleave(self, note: str | None = None):
        """Write the snapshot, import it (check, then approve only if the checks pass), show the report."""
        why = self.use_blocked_reason()
        if why is not None:
            warn(self, "Use this wayleave", why)
            return None
        note = (note if note is not None else self.note.text()).strip()
        if not note:
            warn(self, "Use this wayleave", "A note is required.")
            return None
        # Operator, 2026-10-20: open the plugin and generate; no saved spec is not a reason to stop. The sheet the Spec
        # tab shows (a new site's preset) is saved now; only a sheet missing a required value stops, and says which.
        spec_saved = None
        if not self.store.load().get("spec_rev"):
            spec_saved = self.ensure_spec() if self.ensure_spec is not None else None
            if not spec_saved:
                return None
        ctl, store = self.controller, self.store
        stage = stages.get(WAYLEAVE)
        report, refusal, rev, imported = None, None, None, False
        fields_log: list[str] = []
        self._set_busy(True)
        try:
            rev = ctl.begin_wayleave()
            counts = write_snapshot(rev / "working.gpkg", self.chosen(), store.load()["epsg"], fields_log)
            self.remember_picks()
            (rev / "run.log").write_text("snapshot of project layers\n" + "".join(
                f"{n}: {c} features from {self.combos[n].currentLayer().name()}\n" for n, c in counts.items())
                + "".join(line + "\n" for line in fields_log), encoding="utf-8")
            imported = True
            report, refusal = ctl.import_wayleave(rev / "working.gpkg", note)
            layers.load_issues(self.iface, store.site, stage, rev)
        except Exception as e:                       # noqa: BLE001 - never leave the box wedged
            if rev is not None and not imported:     # the snapshot was never written whole: badge shows failed
                store.mark_failed(WAYLEAVE, rev, f"snapshot failed: {type(e).__name__}: {e}\n")
            warn(self, "Use this wayleave", f"{type(e).__name__}: {e}")
        finally:
            self._set_busy(False)
        self.last_report = report
        self._show_report(report)
        if spec_saved:
            self.report.prepend(spec_saved)
        for line in reversed([l for l in (fields_log if imported else []) if " skipped (" in l]):
            self.report.prepend(f"warn geom_skipped: {line}")
        if refusal:
            self.report.prepend(f"APPROVAL REFUSED: {refusal}")
            warn(self, "Wayleave not approved", f"The checks passed but approval was refused:\n{refusal}")
        elif report is not None and not report.ok():
            # Operator ruling 2026-10-07: failed checks ask, they do not block. The override is recorded.
            blocking = "\n".join(f"{c.code}: {c.status} {c.message}" for c in report.blocking())
            if ask_yes_no(self, "Use this wayleave anyway?", "The snapshot's checks fail:\n\n" + blocking +
                          "\n\nUse it anyway? Your note is recorded as the reason in approval.json."):
                refusal = "; ".join(ctl.approve(WAYLEAVE, note, override=note))
                if refusal:
                    self.report.prepend(f"APPROVAL REFUSED: {refusal}")
                    warn(self, "Wayleave not approved", refusal)
                else:
                    self.report.prepend("APPROVED OVER FAILED CHECKS (operator override)")
        self.changed.emit()
        return report

    def check(self):
        ctl, store = self.controller, self.store
        report = None
        self._set_busy(True)
        try:
            report = ctl.check_now(WAYLEAVE)
            rev = store.rev_dir(WAYLEAVE, store.stage_state(WAYLEAVE)["current_rev"])
            layers.load_issues(self.iface, store.site, stages.get(WAYLEAVE), rev)
        except Exception as e:                       # noqa: BLE001
            warn(self, "Wayleave check", f"{type(e).__name__}: {e}")
        finally:
            self._set_busy(False)
        self.last_report = report
        self._show_report(report)
        self.changed.emit()
        return report
