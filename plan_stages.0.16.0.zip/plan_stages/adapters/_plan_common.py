"""Shared plumbing for the plan-phase adapters (gate0, P1 to P7).

The pipeline scripts bundled under plan_stages/ml (synced from scripts/ml) read and write fixed folder names under PLAN_DIR
(step3/, step4/, step567/) and in EPSG:4326. These helpers rebuild those folders from the
operator-APPROVED layers so every stage routes on what was approved, not on what a script
last produced.
"""
import os, shutil, subprocess, sys
from pathlib import Path
from osgeo import ogr, osr

ogr.UseExceptions()
ML = Path(__file__).resolve().parents[1] / "ml"     # the bundled step scripts

STEP3 = (("p3_distribution", "distribution", "claude_distribution_cable.gpkg", "claude_distribution_cable"),
         ("p1_feeder", "feeder", "claude_feeder_cable.gpkg", "claude_feeder_cable"),
         ("p2_1to16", "splitters_1to16", "claude_1to16_splitters.gpkg", "claude_1to16_splitters"))
STEP4 = (("collection_points", "claude_collection_points"), ("drops", "claude_drops"),
         ("drop_review", "claude_drop_review"))


def store_from_env():
    from plan_stages.core.store import SiteStore
    rev = Path(os.environ["PS_REV_DIR"])          # <plan_root>/<site>/<stage>/rev-N
    return SiteStore(rev.parents[2], rev.parents[1].name)


def _to_wgs84_inplace(d: Path) -> None:
    """Delegates to core.export.to_wgs84_inplace (which QGIS-side code may import without flipping OGR exceptions)."""
    from plan_stages.core import export
    export.to_wgs84_inplace(d)


def find_buildings(export_dir: Path, site: str, qgis_root: str, wayleave_root: str) -> Path | None:
    """Building footprints for midblock, first that exists: <rev>/site_export/buildings.gpkg, then
    <qgis_root>/work/buildings/<site>_buildings.gpkg, then <wayleave_root>/work/buildings/<site>_buildings.gpkg."""
    cands = [Path(export_dir) / "buildings.gpkg"]
    for root in (qgis_root, wayleave_root):
        if root:
            cands.append(Path(root) / "work" / "buildings" / f"{site}_buildings.gpkg")
    return next((c for c in cands if c.is_file()), None)


def set_buildings(export_dir: Path) -> Path | None:
    """Set (or clear) BUILDINGS from find_buildings and say which file was used."""
    b = find_buildings(export_dir, os.environ["PS_SITE"], os.environ.get("PS_QGIS_ROOT", ""),
                       os.environ.get("PS_WAYLEAVE_ROOT", ""))
    if b is not None:
        os.environ["BUILDINGS"] = str(b)
        print(f"buildings: {b}")
    else:
        os.environ.pop("BUILDINGS", None)
        print(f"buildings: none for {os.environ['PS_SITE']} (site_export, qgis_root or wayleave_root work/buildings); "
              f"midblock test unavailable")
    return b


def site_dir() -> Path:
    """Export the approved wayleave layers into THIS revision (<rev>/site_export), so the folder a run read
    stays with the run. Sets SITE_DIR, and BUILDINGS from find_buildings (the plugin supplies no footprints)."""
    from plan_stages.core import export
    st = store_from_env()
    d = export.export_site_dir(st, Path(os.environ["PS_REV_DIR"]) / "site_export")
    _to_wgs84_inplace(d)
    os.environ["SITE_DIR"] = str(d)
    set_buildings(d)
    return d


def run_step(script: str, extra_env: dict | None = None) -> int:
    env = dict(os.environ)
    env.update({"CABLE": "claude", "DPSRC": "gt",
                "PLAN_DIR": os.environ["PS_REV_DIR"], "SITE_DIR": os.environ["SITE_DIR"],
                "PYTHONUNBUFFERED": "1"})
    # poles is optional in the wayleave: candidate poles only when the snapshot exported them, else step4
    # falls back to cable candidates by itself.
    if (Path(os.environ["SITE_DIR"]) / "poles.shp").exists():
        env["CANDSRC"] = "poles"
    else:
        env.pop("CANDSRC", None)
    if not os.environ.get("BUILDINGS"):                 # site_dir() set it when footprints were found
        env.pop("BUILDINGS", None)
    env.update(extra_env or {})
    return subprocess.call([sys.executable, str(ML / script)], cwd=str(ML), env=env)


def copy_layer(src_gpkg: Path, src_layer: str, dst_gpkg: Path, dst_layer: str, wgs84: bool = False) -> int:
    """Copy one layer. wgs84=True writes it in EPSG:4326 when it is in another CRS: the step scripts read step3/ and
    step4/ as 4326 (what they write), and a layer taken over by Scan (0.16.0) is approved in the site CRS."""
    ds = ogr.Open(str(src_gpkg))
    lyr = ds.GetLayerByName(src_layer)
    if lyr is None:
        raise SystemExit(f"{src_gpkg} has no layer {src_layer}")
    drv = ogr.GetDriverByName("GPKG")
    out = drv.Open(str(dst_gpkg), 1) if Path(dst_gpkg).exists() else drv.CreateDataSource(str(dst_gpkg))
    epsg = layer_epsg(lyr, 4326)
    if not wgs84 or epsg == 4326:
        out.CopyLayer(lyr, dst_layer, ["OVERWRITE=YES"])
    else:
        t = transform(epsg, 4326)
        wgs = osr.SpatialReference(); wgs.ImportFromEPSG(4326)
        dst = out.CreateLayer(dst_layer, wgs, lyr.GetGeomType(), ["OVERWRITE=YES"])
        defn = lyr.GetLayerDefn()
        for i in range(defn.GetFieldCount()):
            dst.CreateField(defn.GetFieldDefn(i))
        lyr.ResetReading()
        out.StartTransaction()              # final review T7a: one commit, not one per feature (5,000 lines 11 s)
        try:
            for f in lyr:
                g = f.GetGeometryRef()
                nf = ogr.Feature(dst.GetLayerDefn()); nf.SetFrom(f)
                if g is not None:
                    g = g.Clone(); g.Transform(t); nf.SetGeometry(g)
                dst.CreateFeature(nf)
            out.CommitTransaction()
        except BaseException:
            out.RollbackTransaction()
            raise
    n = lyr.GetFeatureCount()
    out = None
    return n


def collect(mapping: dict) -> None:
    """mapping: registry layer name -> (source gpkg, source layer). Writes generated.gpkg."""
    rev = Path(os.environ["PS_REV_DIR"])
    for dst_layer, (src, src_layer) in mapping.items():
        print(f"{dst_layer}: {copy_layer(Path(src), src_layer, rev / 'generated.gpkg', dst_layer)} features")


def approved(stage_id: str) -> Path:
    """Approved gpkg of a dependency, from PS_DEP_<STAGE> (set by the runner for every registry dep)."""
    v = os.environ.get("PS_DEP_" + stage_id.upper())
    if not v:
        raise SystemExit(f"PS_DEP_{stage_id.upper()} is not set: {stage_id} is not an approved dependency of this stage")
    return Path(v)


def need_layer(gpkg: Path, layer: str) -> int:
    """Feature count of an approved layer a step script will read in place; stops with a message when it is missing,
    so the run fails here and not deep in the script."""
    ds = ogr.Open(str(gpkg))
    lyr = ds.GetLayerByName(layer) if ds is not None else None
    if lyr is None:
        raise SystemExit(f"{gpkg} has no layer {layer}")
    n = lyr.GetFeatureCount()
    ds = None
    return n


def materialise_step3(plan_dir: Path) -> None:
    """Rebuild step3/ from the APPROVED feeder (P1), 1:16s (P2) and distribution (P3) so later steps route on the
    operator's edits. Each layer comes from its own stage, when that stage is a dependency of the running one."""
    from plan_stages.core import stages
    deps = set(stages.get(os.environ["PS_STAGE"]).deps)
    d = Path(plan_dir) / "step3"
    d.mkdir(exist_ok=True)
    for f in d.glob("*.gpkg"):
        f.unlink()
    for sid, layer, fname, lname in STEP3:
        if sid in deps:
            copy_layer(approved(sid), layer, d / fname, lname, wgs84=True)


def p1_targets(rev_gpkg: Path) -> Path:
    """The span point P1 aimed at in each PON (<P1 rev>/step3/p1_targets.json, written by step3_span_split
    P1_PART=feeder). An approved rev made by hand (Revise) has no step3/: the latest earlier rev of P1 that has one,
    since its feeder started from that one. The nominal path (absent) when no rev has one."""
    rev = Path(rev_gpkg).parent
    own = rev / "step3" / "p1_targets.json"
    if own.is_file():
        return own
    earlier = sorted((p for p in rev.parent.glob("rev-*") if p.is_dir() and p.name < rev.name), reverse=True)
    return next((p / "step3" / "p1_targets.json" for p in earlier if (p / "step3" / "p1_targets.json").is_file()), own)


def materialise_drops(plan_dir: Path) -> None:
    src = approved("p4_drops")
    d = Path(plan_dir) / "step4"
    d.mkdir(exist_ok=True)
    out = d / "claude_step4.gpkg"
    if out.exists():
        out.unlink()
    for a, b in STEP4:
        copy_layer(src, a, out, b, wgs84=True)


def transform(src_epsg: int, dst_epsg: int):
    """Coordinate transform with x=east/lon, y=north/lat ordering on both sides."""
    a = osr.SpatialReference(); a.ImportFromEPSG(src_epsg)
    b = osr.SpatialReference(); b.ImportFromEPSG(dst_epsg)
    for s in (a, b):
        s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return osr.CoordinateTransformation(a, b)


def layer_epsg(lyr, default: int) -> int:
    s = lyr.GetSpatialRef()
    return int(s.GetAuthorityCode(None)) if s is not None and s.GetAuthorityCode(None) else default


def empty_gpkg(path: Path, epsg: int) -> None:
    """A stage with no output layers still needs a GeoPackage OGR can open, and OGR refuses one with
    no vector layer at all, so it carries one empty placeholder layer named "_none"."""
    path = Path(path)
    if path.exists():
        path.unlink()
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(str(path))
    srs = osr.SpatialReference(); srs.ImportFromEPSG(epsg)
    ds.CreateLayer("_none", srs, ogr.wkbPoint)
    ds = None
