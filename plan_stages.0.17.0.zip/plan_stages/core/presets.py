"""Client spec presets (operator 2026-10-16): "add a dropdown box, and when the human operator chooses FiberTime, it
loads up FiberTime specs". One Sheet JSON per client and build method in templates/, every value with its document,
page and verbatim quote, built by scripts/build_client_presets.py. The files stay as found in the documents (proposed);
choosing a preset loads it ready to plan (operator 2026-10-26: "It shouldn't be a prerequisite for the person to tick
anything. It should just load up the spec."): every value the documents state comes in accepted, and a cap the client
does not state takes HeroTel's value, marked so. The operator can still untick or retype any row; documents that
disagree still ask for a pick. The plugin checks the quotes when the operator adds the PDF."""
from __future__ import annotations
import copy, json
from dataclasses import dataclass
from pathlib import Path
from .specsheet import Sheet, SheetEntry, TEMPLATES, UNITS, copy_sheet, is_operator
from . import spec_verify as sv


@dataclass
class Preset:
    id: str
    label: str
    client: str
    path: Path


def list_presets(folder: Path = TEMPLATES) -> list[Preset]:
    out = []
    for p in sorted(Path(folder).glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            out.append(Preset(d.get("preset") or p.stem, d.get("label") or d["client"], d["client"], p))
        except (OSError, ValueError, KeyError):
            continue
    return sorted(out, key=lambda x: (x.client != "HeroTel", x.id != "herotel", x.label.lower()))   # HeroTel 14 next


def get(preset_id: str, folder: Path = TEMPLATES) -> Preset:
    for p in list_presets(folder):
        if p.id == preset_id:
            return p
    raise KeyError(preset_id)


# Caps a client's documents may leave unstated; they take HeroTel's value. Density and the split ratios never do:
# those are the client's own design and are only ever taken from its documents.
FILL_FROM_HEROTEL = ("drop_cap_m", "span_cap_m", "cross_span_m")


def preset_sheet(preset_id: str, folder: Path = TEMPLATES) -> Sheet:
    """The unsaved sheet a site starts from, ready to plan. HeroTel's template (confirmed, operator-stated values)
    comes across as Copy from always brought it; a client preset comes across accepted, marked with the preset it
    came from, with the unstated caps filled from HeroTel's template."""
    p = get(preset_id, folder)
    src = Sheet.load(p.path)
    if any(e.status == "confirmed" for e in src.entries.values()):
        return copy_sheet(src, p.client, f"Template: {p.label}")
    out = Sheet(p.client, "", {})
    for k, e in src.entries.items():
        e2 = SheetEntry(**{**e.__dict__, "candidates": [dict(c, check="", check_note="") for c in e.candidates]})
        e2.note = f"from preset {p.label}; {e.note}".rstrip("; ")
        e2.check = e2.check_note = ""
        if e2.status == "proposed":
            e2.status = "confirmed"
        out.entries[k] = e2
    herotel = next((h for h in list_presets(folder) if h.id == "herotel"), None)
    if herotel is not None:
        ref = Sheet.load(herotel.path).entries
        for k in FILL_FROM_HEROTEL:
            h = ref.get(k)
            if out.entries.get(k, SheetEntry(k)).status == "not_found" and h is not None \
                    and h.status == "confirmed" and h.value is not None:
                out.entries[k] = SheetEntry(k, h.value, h.unit or UNITS.get(k, ""), "confirmed", "", None, "",
                                            f"not stated by {p.client}; HeroTel value used")
    out.extras = [dict(x, check="", check_note="") for x in src.extras if not is_operator(x)]
    return out


def cited_documents(sheet: Sheet) -> list[str]:
    """The file names the sheet's statements quote (entries, conflict candidates, PDF extras): verify() matches by these."""
    docs = {e.document for e in sheet.entries.values() if e.document}
    docs |= {c["document"] for e in sheet.entries.values() for c in e.candidates if c.get("document")}
    docs |= {x["document"] for x in sheet.extras if x.get("document") and not is_operator(x)}
    return sorted(docs)


def verify(sheet: Sheet, pdf_paths: list[Path]) -> Sheet:
    """A copy of `sheet` with every statement that cites one of `pdf_paths` (by file name) checked against it: the
    entries, each conflict candidate, and the PDF extras. Values and statuses never change; the page is corrected
    when the sentence is found on another page."""
    by_name = {Path(p).name: Path(p) for p in pdf_paths}
    texts = sv.PdfTexts()
    out = copy.deepcopy(sheet)

    def check_value(key, d):                     # d: SheetEntry.__dict__ or a candidate dict; updated in place
        path = by_name.get(d.get("document") or "")
        if path is None or d.get("value") is None or not d.get("quoted_text"):
            return
        r = sv.check(sv.Candidate(key, d["value"], d.get("unit", ""), str(path), d.get("page"), d["quoted_text"]), texts)
        d["check"], d["check_note"], d["page"] = r.check, r.note, r.page

    for k, e in out.entries.items():
        check_value(k, e.__dict__)
        for c in e.candidates:
            check_value(k, c)
    for x in out.extras:
        path = by_name.get(x.get("document") or "")
        if path is None or is_operator(x) or not x.get("quoted_text"):
            continue
        r = sv.check_quote(path, x.get("page"), x["quoted_text"], texts)
        x["check"], x["check_note"], x["page"] = r.check, r.note, r.page
    return out
