"""Wayleave snapshot check: the project's wayleave layers, as the dock wrote them into working.gpkg.

checks/common covers every required layer (present, valid, non-empty geometry) and each optional layer the
snapshot holds; an optional layer the project did not have is skipped, never failed. Then:
crs_matches_site, pop_count, span_nonempty and demand_nonempty, all required. Operator ruling 2026-10-06:
geometry validity of pons, erven, aoi, poles (and buildings, 2026-10-12) only warns (the pipeline has consumed these layers as-is);
it stays required for span, demand_points, pop and roads."""
import os, sys
from plan_stages.checks.common import main, epsg_of, add_issue, inside_xy
from plan_stages.core import stages
from plan_stages.core.checks import CheckResult
from osgeo import ogr

WARN_ONLY_VALIDITY = ("pons", "erven", "aoi", "poles", "buildings")   # footprints: rollout 2026-10-12


def extra(report, rev):
    for c in report.checks:
        layer = c.code.split(":", 1)[1] if c.code.startswith("geom_valid:") else None
        if layer in WARN_ONLY_VALIDITY:
            c.required = False
    for i in report.issues:
        if i.code == "geom_valid" and i.message.split(" ", 1)[0] in WARN_ONLY_VALIDITY:
            i.severity = "warn"
    ds = ogr.Open(str(rev / "working.gpkg"))
    site = int(os.environ["PS_EPSG"])
    counts, wrong = {}, []
    for spec in stages.get("wayleave").outputs:
        lyr = ds.GetLayerByName(spec.name) if ds else None
        if lyr is None:
            continue
        counts[spec.name] = lyr.GetFeatureCount()
        e = epsg_of(lyr)
        if e != site:
            wrong.append(f"{spec.name} EPSG:{e}")
    report.checks.append(CheckResult("crs_matches_site", True, "failed" if wrong or ds is None else "passed",
                                     ", ".join(wrong) if wrong else f"all layers EPSG:{site}"))
    for code, layer, least in (("pop_count", "pop", 1), ("span_nonempty", "span", 1),
                               ("demand_nonempty", "demand_points", 1)):
        n = counts.get(layer)
        if n is None:
            report.checks.append(CheckResult(code, True, "failed", f"layer {layer} missing"))
        else:
            report.checks.append(CheckResult(code, True, "passed" if n >= least else "failed", f"{n} {layer}"))
    report.checks.append(CheckResult("layer_counts", False, "passed",
                                     ", ".join(f"{k} {v}" for k, v in counts.items())))
    _pon_homes(report, ds)


def _pon_homes(report, ds):
    """0.17.0 HeroTel 14 (operator 2026-10-30): "if there are more demand points in a PON than 112 ... those things
    should be picked up". An error row on each PON over pon_max, never required: nothing stops a start."""
    from plan_stages.checks import _plan as P      # here, not at the top: _plan turns on OGR exceptions
    pmax, cap, fan = P.spec_limit("pon_max"), P.spec_limit("pon_cap"), P.spec_limit("fan_cap")
    if P.spec_limit("pon_cap_hard") is not True or pmax is None or ds is None:
        return
    pl, dl = ds.GetLayerByName("pons"), ds.GetLayerByName("demand_points")
    if pl is None or dl is None:
        report.checks.append(CheckResult("pon_homes", False, "skipped", "pons or demand_points missing"))
        return
    has = pl.GetLayerDefn().GetFieldIndex("pon_num") >= 0
    pons = [(f, f.GetGeometryRef().Clone()) for f in pl if f.GetGeometryRef() is not None]
    pts = [f.GetGeometryRef().Clone() for f in dl if f.GetGeometryRef() is not None]
    over = []
    for f, g in pons:
        n = sum(1 for q in pts if g.Contains(q))
        if n > pmax:
            num = f.GetField("pon_num") if has else None
            label = num if num is not None else f.GetFID()
            over.append(label)
            add_issue(report, pl, None, "pon_homes", "error",
                      f"PON {label} has {n} demand points; this spec allows {pmax} ({cap} collection points x {fan})",
                      xy=inside_xy(g), layer="pons", match=f"pon_num={num}" if num is not None else "")
    report.checks.append(CheckResult("pon_homes", False, "passed" if not over else "failed",
                                     f"{len(over)} PONs with more than {pmax} demand points" +
                                     (": " + ", ".join(str(x) for x in over) if over else "")))


if __name__ == "__main__":
    sys.exit(main(extra))
