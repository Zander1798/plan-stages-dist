from __future__ import annotations
import os, shutil, subprocess
from pathlib import Path
from typing import Callable
from ..config import PluginConfig
from . import approval, env as envmod, gpkg, stages
from .checks import ChecksReport
from .store import SiteStore, sha256

EDITED_DURING_CHECK = "layer edited during Check; re-check"
WAYLEAVE = "wayleave"
CHECK_TIMEOUT_S = 120                      # the foreground wayleave check; longer counts as a crashed check


class CheckCrashed(Exception):
    """A check exited without a usable checks.json; its result must never be trusted."""


class StageController:
    def __init__(self, config: PluginConfig, store: SiteStore, spec_path_provider: Callable[[], Path | None]):
        self.config, self.store, self._spec = config, store, spec_path_provider
        self.check_start: dict[str, str] = {}      # stage id -> working.gpkg sha256 when its Check started
        self.last_warning: str | None = None       # set by finish_check when the layer changed mid-Check

    def _spec_rev(self) -> str | None:
        return self.store.load().get("spec_rev")

    def _new_rev(self, stage_id: str) -> Path:
        """A new revision with its launch-time provenance (dependency revisions, spec revision) on disk."""
        rev = self.store.new_revision(stage_id)
        approval.capture_inputs(self.store, stage_id, rev, self._spec_rev())
        return rev

    def begin_generate(self, stage_id: str):
        stage = stages.get(stage_id)
        seed = self.store.latest_layer(stage_id) if stage.generator is None else None
        rev = self._new_rev(stage_id)
        env = envmod.build_env(self.config, self.store, stage_id, rev, self._spec() or Path(""))
        if stage.generator is None:
            if seed is not None:              # a manual stage keeps the operator's drawing; clean slate only at rev 1
                _copy_layer(seed, rev / "working.gpkg")
                _copy_export(seed, rev)
            else:
                gpkg.create_empty(rev / "working.gpkg", self.store.load()["epsg"], stage.outputs)
            approval.record_generated(self.store, stage_id, rev, self._spec_rev())
            return rev, None, env
        return rev, envmod.command_for(self.config, stage, stage.generator), env

    def finish_generate(self, stage_id: str, rev: Path, rc: int, log: str) -> bool:
        if rc == 0 and (rev / "generated.gpkg").exists():
            gpkg.copy(rev / "generated.gpkg", rev / "working.gpkg")
            approval.record_generated(self.store, stage_id, rev, self._spec_rev())
            return True
        self.store.mark_failed(stage_id, rev, log if rc != 0 else "generator exited 0 but wrote no generated.gpkg\n")
        return False

    def begin_revise(self, stage_id: str) -> Path:
        """Rev N+1 whose working.gpkg is a copy of the latest approved.gpkg (else the current working.gpkg), for
        the operator to edit by hand. No generated.gpkg: there is no generator output to compare against."""
        src = self.store.latest_layer(stage_id)
        if src is None:
            raise ValueError(f"{stage_id} has no approved or working layer to revise")
        rev = self._new_rev(stage_id)
        _copy_layer(src, rev / "working.gpkg")
        _copy_export(src, rev)
        approval.record_generated(self.store, stage_id, rev, self._spec_rev())
        return rev

    # ---------------- the wayleave snapshot ----------------
    def begin_wayleave(self) -> Path:
        """A new wayleave revision (with its launch-time provenance) for the dock to write working.gpkg into."""
        return self._new_rev(WAYLEAVE)

    def import_wayleave(self, gpkg_path: Path, note: str) -> tuple[ChecksReport, str | None]:
        """The operator pressed "Use this wayleave": the snapshot at gpkg_path becomes the current wayleave
        revision, is checked, and is approved when (and only when) its checks pass. That press is the
        operator's approval; a failing snapshot stays generated and the report says why. Returns (report,
        refusal): refusal is approve()'s reason when the checks passed but approval was still refused."""
        if not (note or "").strip():
            raise ValueError("a note is required to use a wayleave")
        gpkg_path = Path(gpkg_path)
        s = self.store.stage_state(WAYLEAVE)
        rev = self.store.rev_dir(WAYLEAVE, s["current_rev"]) if s["status"] == "generating" else None
        if rev is None or ((rev / "working.gpkg").exists()
                           and (rev / "working.gpkg").resolve() != gpkg_path.resolve()):
            rev = self.begin_wayleave()                  # not the revision begin_wayleave handed out: a new one
        wk = rev / "working.gpkg"
        if gpkg_path.resolve() != wk.resolve():
            _copy_layer(gpkg_path, wk)
        if not wk.exists():
            raise FileNotFoundError(f"no wayleave snapshot at {gpkg_path}")
        approval.record_generated(self.store, WAYLEAVE, rev, self._spec_rev())
        report = self.check_now(WAYLEAVE)
        if not report.ok():
            return report, None
        try:
            approval.approve(self.store, WAYLEAVE, note.strip())
        except approval.Refusal as e:
            return report, str(e)
        return report, None

    def check_now(self, stage_id: str) -> ChecksReport:
        """Run a stage's check in the foreground (the wayleave check is quick) and record it like a Check."""
        rev, cmd, env = self.begin_check(stage_id)
        start = self.check_start.get(stage_id)
        cj = rev / "checks.json"
        if cj.exists():
            cj.unlink()
        self.store.set_stage(stage_id, checked_hash=None)
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        try:
            p = subprocess.run(cmd, env=env, cwd=str(Path(cmd[1]).parent), stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                               creationflags=flags, timeout=CHECK_TIMEOUT_S)
        except subprocess.TimeoutExpired as e:
            out = e.output.decode("utf-8", "replace") if isinstance(e.output, bytes) else (e.output or "")
            (rev / "check.log").write_text(out + f"\ntimed out after {CHECK_TIMEOUT_S} s\n", encoding="utf-8")
            raise CheckCrashed(f"{stage_id} check timed out after {CHECK_TIMEOUT_S} s") from None
        (rev / "check.log").write_text(p.stdout or "", encoding="utf-8")
        report = ChecksReport.load(cj) if cj.exists() else None
        if report is None or (p.returncode != 0 and report.ok()):
            if cj.exists():
                cj.unlink()
            tail = "\n".join((p.stdout or "").splitlines()[-25:])
            raise CheckCrashed(f"{stage_id} check exited rc={p.returncode} without a usable checks.json\n{tail}")
        return self.finish_check(stage_id, rev, p.returncode, p.stdout or "", start_hash=start)

    def begin_check(self, stage_id: str):
        stage = stages.get(stage_id)
        s = self.store.stage_state(stage_id)
        rev = self.store.rev_dir(stage_id, s["current_rev"])
        wk = rev / "working.gpkg"
        if wk.exists():
            approval._checkpoint(wk)
            self.check_start[stage_id] = sha256(wk)
        else:
            self.check_start.pop(stage_id, None)
        env = envmod.build_env(self.config, self.store, stage_id, rev, self._spec() or Path(""))
        return rev, envmod.command_for(self.config, stage, stage.check), env

    def finish_check(self, stage_id: str, rev: Path, rc: int, log: str,
                     start_hash: str | None = None) -> ChecksReport | None:
        self.last_warning = None
        cj = rev / "checks.json"
        if not cj.exists():
            return None
        report = ChecksReport.load(cj)
        if approval.record_checked(self.store, stage_id, report, start_hash):
            self.last_warning = EDITED_DURING_CHECK
        return report

    def approve(self, stage_id: str, note: str, override: str | None = None, details_checked=()) -> list[str]:
        try:
            approval.approve(self.store, stage_id, note, override, details_checked)
            return []
        except approval.Refusal as e:
            return [str(e)]

    def approve_blockers(self, stage_id: str) -> tuple[list[str], list[str]]:
        """(failed checks the operator may override, hard reasons they may not) for the current revision."""
        return approval.split_reasons(approval.can_approve(self.store, stage_id))

    def reject(self, stage_id: str, note: str) -> None:
        approval.reject(self.store, stage_id, note)

    def save_progress(self) -> None:
        """Operator ruling 2026-10-07: only saved progress survives the next open of the site."""
        self.store.mark_saved(True)

    def discard_unsaved(self) -> list[str]:
        """Opening a site with unsaved progress: wipe it to a clean slate. Returns the stages wiped ([] when
        the site was saved or had nothing started)."""
        if self.store.is_saved() or not self.store.started_stages():
            return []
        return approval.reset_site(self.store)

    def reset_site(self) -> list[str]:
        """Start over on this site: every stage back to pending, spec kept; see approval.reset_site."""
        return approval.reset_site(self.store)

    def remove(self, stage_id: str) -> dict:
        """Delete the current revision (operator's Remove button); see approval.remove_revision."""
        return approval.remove_revision(self.store, stage_id)

    def next_enabled(self, stage_id: str) -> dict[str, bool]:
        st = self.store.load()
        s = st["stages"][stage_id]
        deps_ok = all(st["stages"][d]["status"] == "approved" for d in stages.get(stage_id).deps)
        has_rev = bool(s["current_rev"])
        has_layer = has_rev and (self.store.rev_dir(stage_id, s["current_rev"]) / "working.gpkg").exists()
        return {"generate": deps_ok,
                "check": has_layer and s["status"] in ("generated", "checked", "stale", "rejected"),
                # failed checks do not grey Approve out: the press asks "Approve anyway?" (ruling 2026-10-07)
                "approve": has_rev and not approval.split_reasons(approval.can_approve(self.store, stage_id))[1],
                "reject": has_rev,
                "revise": has_rev and self.store.latest_layer(stage_id) is not None,
                "remove": has_rev}


def _copy_layer(src: Path, dst: Path) -> None:
    """Copy a GeoPackage after folding any QGIS -wal into it, so committed edits travel with the copy."""
    approval._checkpoint(src)
    gpkg.copy(src, dst)


def _copy_export(src_layer: Path, rev: Path) -> None:
    """A plan stage's checks read <rev>/site_export; a revision seeded from src_layer never runs the generator,
    so carry the source revision's export folder along (no-op when it has none)."""
    exp = src_layer.parent / "site_export"
    if exp.is_dir():
        shutil.copytree(exp, rev / "site_export", dirs_exist_ok=True)
