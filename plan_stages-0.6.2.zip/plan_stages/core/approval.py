from __future__ import annotations
import json, shutil, sqlite3, time
from pathlib import Path
from . import stages
from .checks import ChecksReport
from .specsheet import Sheet
from .store import SiteStore, sha256


INPUTS = "inputs.json"


def capture_inputs(store: SiteStore, stage_id: str, rev: Path, spec_rev: str | None) -> dict:
    """Write rev/inputs.json at LAUNCH: the dependency revisions and spec revision the generator will read.
    record_generated takes provenance from this file, so a re-approval or spec save during the run is caught."""
    st = store.load()
    d = {"generated_from": {dep: st["stages"][dep]["approved_rev"] for dep in stages.get(stage_id).deps},
         "spec_rev": spec_rev}
    (Path(rev) / INPUTS).write_text(json.dumps(d, indent=2), encoding="utf-8")
    return d


def record_generated(store: SiteStore, stage_id: str, rev: Path, spec_rev: str | None) -> None:
    st = store.load()
    p = Path(rev) / INPUTS
    if p.exists():
        d = json.loads(p.read_text(encoding="utf-8"))
        gen_from, spec_rev = d["generated_from"], d["spec_rev"]
    else:
        # No inputs.json (a revision made outside StageController.begin_generate/begin_revise): fall back to
        # the live state, which is only right if nothing was re-approved since launch.
        gen_from = {d: st["stages"][d]["approved_rev"] for d in stages.get(stage_id).deps}
    s = st["stages"][stage_id]
    # An upstream approval or spec save during the run already marked this stage stale: keep that.
    status = "stale" if s["status"] == "stale" else "generated"
    s.update(status=status, current_rev=rev.name, generated_from=gen_from, spec_rev=spec_rev, checked_hash=None)
    store.save(st)


def _checkpoint(path: Path) -> None:
    """QGIS commits GeoPackage edits into <gpkg>-wal; fold them into the main file before hashing or copying it."""
    path = Path(path)
    if not path.with_name(path.name + "-wal").exists():
        return
    con = sqlite3.connect(str(path), timeout=10)
    try:
        busy, _log, _done = con.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
    finally:
        con.close()
    if busy:
        raise Refusal("GeoPackage busy; close edits and retry")


def record_checked(store: SiteStore, stage_id: str, report: ChecksReport, start_hash: str | None = None) -> bool:
    """Record a finished Check. `start_hash` is working.gpkg's hash when the Check STARTED; if the file changed
    while the check ran, the report describes other content, so nothing is recorded as checked.
    Returns True when the layer was edited during the Check."""
    s = store.stage_state(stage_id)
    rev_path = store.rev_dir(stage_id, s["current_rev"])
    _checkpoint(rev_path / "working.gpkg")
    h = sha256(rev_path / "working.gpkg")
    report.save(rev_path / "checks.json")
    if start_hash is not None and h != start_hash:
        store.set_stage(stage_id, checked_hash=None)
        return True
    store.set_stage(stage_id, checked_hash=h, status="checked" if report.ok() else s["status"])
    store.mark_saved(False)
    return False


def can_approve(store: SiteStore, stage_id: str) -> list[str]:
    st = store.load()
    s = st["stages"][stage_id]
    reasons = []
    if s["status"] in ("rejected", "failed"):
        reasons.append(f"stage is {s['status']}; regenerate first")
    if not s["current_rev"]:
        return ["nothing generated"]
    rev = store.rev_dir(stage_id, s["current_rev"])
    if not (rev / "working.gpkg").exists():
        reasons.append(f"no working layer for {s['current_rev']}")
    elif s["checked_hash"] is None:
        reasons.append("checks have not run on this revision")
    else:
        if sha256(rev / "working.gpkg") != s["checked_hash"]:
            reasons.append("checks stale: layer edited since last Check")
        cj = rev / "checks.json"
        if not cj.exists():
            reasons.append("checks.json missing; re-check")
        else:
            for c in ChecksReport.load(cj).blocking():
                reasons.append(f"check {c.code} {c.status}: {c.message}")
    for dep, used in s["generated_from"].items():
        now = st["stages"][dep]["approved_rev"]
        if now is None:
            reasons.append(f"dependency {dep} has no approved revision")
        elif now != used:
            reasons.append(f"dependency {dep} re-approved as {now}; this revision used {used}")
    if st["spec_rev"] != s["spec_rev"]:
        reasons.append(f"spec changed to {st['spec_rev']}; this revision used {s['spec_rev']}")
    return reasons


def split_reasons(reasons: list[str]) -> tuple[list[str], list[str]]:
    """(overridable, hard). Operator ruling 2026-10-07: a failed check is the spec's opinion and the operator
    may approve over it with a recorded reason; everything else (checks not run, layer edited since the Check,
    checks.json missing, a dependency re-approved, the spec changed, stage rejected/failed) is an integrity
    condition and stays a hard refusal."""
    checks = [r for r in reasons if r.startswith("check ")]
    return checks, [r for r in reasons if r not in checks]


def stage_details(store: SiteStore, stage_id: str) -> list[dict]:
    """The operator's details tagged with this stage (2026-10-14), from the spec revision its current revision
    was generated with; before any revision, from the site's current spec revision. None on disk: none."""
    st = store.load()
    s = st["stages"][stage_id]
    rev = (s.get("spec_rev") if s.get("current_rev") else None) or st.get("spec_rev")
    path = store.site_dir / "spec" / str(rev) / "sheet.json" if rev else None
    if path is None or not path.exists():
        return []
    return Sheet.load(path).operator_details(stage_id)


def approve(store: SiteStore, stage_id: str, note: str, override: str | None = None, details_checked=()) -> Path:
    """Approve the current revision. With `override` (the operator's reason) failed checks no longer refuse;
    they are listed in approval.json as overridden_checks with that reason. Hard reasons always refuse. Every
    operator detail of the stage must be in `details_checked` (hard: no override)."""
    if not (note or "").strip():
        raise Refusal("approval note required")
    cur = store.stage_state(stage_id)["current_rev"]
    if cur:
        _checkpoint(store.rev_dir(stage_id, cur) / "working.gpkg")
    reasons = can_approve(store, stage_id)
    checks, hard = split_reasons(reasons)
    if hard or (checks and not (override or "").strip()):
        raise Refusal("; ".join(reasons))
    details = stage_details(store, stage_id)
    unchecked = [x for x in details if x["id"] not in set(details_checked or ())]
    if unchecked:
        # not in can_approve: that would grey out Approve, and Approve is where the operator ticks them
        raise Refusal("; ".join(f"operator detail {x['id']} not checked against this plan: {x['detail']}"
                                for x in unchecked))
    st = store.load()
    s = st["stages"][stage_id]
    rev = store.rev_dir(stage_id, s["current_rev"])
    shutil.copyfile(rev / "working.gpkg", rev / "approved.gpkg")
    h = sha256(rev / "approved.gpkg")
    record = {"stage": stage_id, "rev": s["current_rev"], "note": note, "sha256": h,
              "generated_from": s["generated_from"], "spec_rev": s["spec_rev"],
              "operator_details_checked": [{"id": x["id"], "detail": x["detail"], "stages": x["stages"]} for x in details],
              "when": time.strftime("%Y-%m-%dT%H:%M:%S")}
    if checks:
        record["overridden_checks"] = checks
        record["override_reason"] = override.strip()
    (rev / "approval.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    s.update(status="approved", approved_rev=s["current_rev"], approved_hash=h)
    for d in stages.downstream_of(stage_id):
        if st["stages"][d]["status"] not in ("pending",):
            st["stages"][d]["status"] = "stale"
    st["saved"] = False
    store.save(st)
    return rev / "approval.json"


def remove_revision(store: SiteStore, stage_id: str) -> dict:
    """Operator ruling 2026-10-07 (Remove button): delete the stage's CURRENT revision folder outright (its
    working and approved layers, checks, logs, exports). The stage falls back to its latest remaining
    revision: approved if that one holds approval.json, else generated (its checks must run again); pending
    when none remains. If the removed revision was the approved one, every started downstream stage goes
    stale, since what it was built on no longer exists. Returns {"removed": rev, "now": rev-or-None}."""
    st = store.load()
    s = st["stages"][stage_id]
    cur = s["current_rev"]
    if not cur:
        raise Refusal("nothing to remove")
    rev = store.rev_dir(stage_id, cur)
    was_approved = s["approved_rev"] == cur
    _checkpoint(rev / "working.gpkg") if (rev / "working.gpkg").exists() else None
    shutil.rmtree(rev, ignore_errors=False)
    remaining = sorted(p.name for p in (store.site_dir / stage_id).glob("rev-*") if p.is_dir())
    if not remaining:
        s.update(status="pending", current_rev=None, approved_rev=None, generated_from={}, spec_rev=None,
                 checked_hash=None, approved_hash=None)
    else:
        last = remaining[-1]
        ld = store.rev_dir(stage_id, last)
        inputs = json.loads((ld / INPUTS).read_text(encoding="utf-8")) if (ld / INPUTS).exists() else {}
        s.update(current_rev=last, checked_hash=None,
                 generated_from=inputs.get("generated_from", {}), spec_rev=inputs.get("spec_rev"))
        if (ld / "approval.json").exists() and (ld / "approved.gpkg").exists():
            rec = json.loads((ld / "approval.json").read_text(encoding="utf-8"))
            s.update(status="approved", approved_rev=last, approved_hash=rec.get("sha256"),
                     checked_hash=rec.get("sha256"),            # working == approved at approval time
                     generated_from=rec.get("generated_from", s["generated_from"]),
                     spec_rev=rec.get("spec_rev", s["spec_rev"]))
        else:
            if was_approved:
                s.update(approved_rev=None, approved_hash=None)
            s.update(status="generated" if (ld / "working.gpkg").exists() else "failed")
    if was_approved and s["approved_rev"] != cur:
        for d in stages.downstream_of(stage_id):
            if st["stages"][d]["status"] != "pending":
                st["stages"][d]["status"] = "stale"
    st["saved"] = False
    store.save(st)
    return {"removed": cur, "now": s["current_rev"]}


def reset_site(store: SiteStore) -> list[str]:
    """Operator ruling 2026-10-07 (Start over): wipe every stage's revisions (the wayleave snapshot included) and
    put every stage back to pending. The site, its CRS and client, and its spec revisions are kept, so the
    operator can plan the same site again from the Wayleave box. Returns the stages that had revisions."""
    from .store import _blank_stage
    st = store.load()
    wiped = []
    for sid in stages.order():
        d = store.site_dir / sid
        if d.is_dir():
            shutil.rmtree(d)
            wiped.append(sid)
        st["stages"][sid] = _blank_stage()
    st["saved"] = True                        # a clean slate has nothing unsaved
    store.save(st)
    return wiped


def clear_spec(store: SiteStore) -> list[str]:
    """Operator ruling 2026-10-07 (Clear spec): delete every saved spec revision (sheets and imported PDFs) and
    unset the site's spec revision, so a new spec can be imported or typed. Every started stage goes stale,
    because the numbers it was planned from are gone; nothing runs again until a new revision is saved.
    Returns the revisions removed."""
    st = store.load()
    base = store.site_dir / "spec"
    removed = sorted(p.name for p in base.glob("rev-*") if p.is_dir()) if base.is_dir() else []
    if base.is_dir():
        shutil.rmtree(base)
    st["spec_rev"] = None
    for s in st["stages"].values():
        if s["status"] != "pending":
            s["status"] = "stale"
    store.save(st)
    return removed


def reject(store: SiteStore, stage_id: str, note: str) -> None:
    s = store.stage_state(stage_id)
    rev = store.rev_dir(stage_id, s["current_rev"])
    (rev / "rejection.json").write_text(json.dumps({"note": note, "when": time.strftime("%Y-%m-%dT%H:%M:%S")}),
                                        encoding="utf-8")
    store.mark_saved(False)
    store.set_stage(stage_id, status="rejected")


class Refusal(Exception):
    pass
