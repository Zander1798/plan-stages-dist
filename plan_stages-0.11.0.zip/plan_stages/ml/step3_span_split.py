"""Step 3 (wayleave) -- lay the FEEDER and the DISTRIBUTION onto the operator's span, and
place the 1:16 splitter that roots each PON.

WHERE THE FEEDER LIVES -- settled by the operator on 2026-09-09, on the fourth reading, and
this one reconciles every measurement made that day:

    "The feeder route has to be roadside. Sometimes it runs on span, but it should never go
     mid-block. It's a brand-new route that you need to create. It needs to be the most
     optimal route that reaches all of the PONs ... The span is essentially the distribution
     that spreads off from the feeder that goes roadside."

So:
  * The SPAN is the DISTRIBUTION. All of it. It is not a template for the feeder.
  * The FEEDER is NEW GEOMETRY: the shortest-path tree from the POP to one entry per PON on
    a corridor made of the ROAD NETWORK plus whatever span is itself roadside. Midblock
    span is not in the corridor, so a midblock feeder is impossible by construction.
  * The 1:16 is the span node inside the PON that the corridor reaches most cheaply,
    joined to the corridor by a short CONNECTOR where it is not on it.

Why the earlier readings failed, kept so nobody re-walks them: cutting the feeder OUT of the
span (drops blew to 257 km); a feeder ON the span (31% roadside vs their 95-100%; 37% midblock
vs their 0.0-0.4%, unchanged at a x1000 penalty because street-only span reaches 1-2 of 82
PONs). The operator's own plans carry LINK (= feeder) as a SEPARATE layer from DISTRIBUTION,
which is what this step now produces.

KNOWN LIMIT: OSM `road.shp` is sparse in a settlement -- 23% of Ventersdorp's span is >30 m
from any mapped road, and satellite shows dirt streets between house rows that OSM lacks.
Roadside span fills some of that gap. A PON whose span is further than CONNECTOR_MAX_M from
the corridor is REPORTED as a road-data gap, never bridged by invented geometry.

WHAT REPLACED WHAT. `step3_cable.py` grew a Steiner tree on the erf-boundary graph, because
the route was ours to choose: it swept crossing weights, ran multi-start restarts, scored
candidate trees against a proxy objective and repaired lanes afterwards. Under the wayleave
(operator, 2026-09-09) none of that applies --

    "You already know the route. The route has already been planned out for you, so you
     essentially just copy on top of that route where a distribution cable ought to be and
     where the feeder cable would run."

-- so this step is a CLASSIFICATION, not a search. Every metre of span is already where the
operator wants cable; the only questions are which metres carry the feeder, which carry
distribution, and where the two meet.

THE RULES, as given:
  * The feeder starts at the POP, runs ON THE SPAN, and must reach EVERY PON by the optimal
    route.
  * Each PON has exactly ONE 1:16 splitter, where the feeder enters it.
  * The distribution is the span inside each PON, rooted at that PON's 1:16.
  * Feeder and distribution are different CABLE on different routes; where the feeder uses
    a roadside stretch of span they share the pole (TSD p7), and both layers are written.

HOW THE 1:16 IS CHOSEN. Feeder route and splitter position define each other -- the feeder
ends at the 1:16, and the 1:16 is where the feeder arrives. Resolved with ONE least-cost sweep
from the POP across the span: each PON's 1:16 is the cheapest-to-reach span node inside it,
i.e. the first point of that PON the feeder touches. Measured against the operator's own
splitters on four planned sites, this reproduces the property their data pins down hardest --
the 1:16 sits ON the PON edge: ours median 0.2 m, theirs 0.0-2.9 m.

⚠️ It does NOT yet reproduce their distance to a road (ours median 25.7 m, theirs 7.2-10.7 m,
72-100% within 20 m). On Ventersdorp only 26% of the span is within 20 m of a road, so the
span cannot place them roadside without leaving it. That gap is real, reported by
`ROADSIDE_M` in the metrics, and is the first thing to check against new site data -- one
property matching is not the rule being right (F-59, F-61).

Writes `claude_distribution_cable.gpkg` with the SAME layer name and fields step3_cable.py
wrote, so `step4_drops.py` and `step567.py` consume it unchanged.

Usage:  rungeo.bat step3_span_split.py
In the Plan Stages plugin each stage runs one part (P1_PART, below): P1 Feeder = feeder, P2 1:16 splitters =
splitters, P3 Distribution = distribution.
"""
import json
import math
import os
import sys

import numpy as np
from osgeo import ogr, osr
from scipy.spatial import cKDTree

ogr.UseExceptions()

from site_crs import LOCAL_EPSG
from site_config import work_dir, SITE, L as LYR, path as LPATH, have, banner
from span_graph import build as build_graph, densify, SEG_M, STITCH_M
from midblock import Midblock, buildings_for_site, SIDE_M as MB_SIDE_M

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
OUT = work_dir("step3")

ROADSIDE_M = float(os.environ.get("ROADSIDE_M", "20"))    # "roadside", for reporting only
ROAD_MULT = float(os.environ.get("ROAD_MULT", "1"))       # >1 pulls the feeder to the roadside
# THE FEEDER IS NEVER MIDBLOCK. Measured on the operator's own LINK/feeder cable, three
# settlement sites: 0.0 / 0.2 / 0.4% midblock, against 33-41% for their distribution
# (midblock.py). So a midblock metre costs the feeder MIDBLOCK_MULT times its length; the
# route still exists if a PON can only be reached midblock, but it is charged for it and the
# residual midblock share is reported. 0 disables the test.
MIDBLOCK_MULT = float(os.environ.get("MIDBLOCK_MULT", "25"))   # retained for metrics only
# The feeder corridor (roads + roadside span) is noded coarser than the span: 2 m of
# positional precision on a feeder route is immaterial and 187 km of road at 0.5 m would be
# 375,000 nodes for nothing.
CORRIDOR_SEG_M = float(os.environ.get("CORRIDOR_SEG_M", "2.0"))
CORRIDOR_STITCH_M = float(os.environ.get("CORRIDOR_STITCH_M", "3.0"))
# A 1:16 may sit off the corridor by a short CONNECTOR (their own: 7-11 m from a road).
# Beyond CONNECTOR_MAX_M the PON is REPORTED, not served -- that distance means the road
# layer is missing a street, and inventing one is the old build's mistake.
# A 1:16 sits where the feeder REACHES it, so the connector between the roadside corridor
# and the splitter must be short -- the operator's own 1:16s are 7-11 m from a road. At 40 m
# the connectors became straight lines cutting across whole blocks and PON boundaries, which
# is the defect the operator photographed. A PON with no span this close to a road is
# REPORTED, not bridged.
CONNECTOR_MAX_M = float(os.environ.get("CONNECTOR_MAX_M", "25"))
CONNECTOR_MULT = float(os.environ.get("CONNECTOR_MULT", "20"))     # prefer roadside entries
# Weight on the 1:16's own distance to a road, so the splitter is drawn to the street
# edge of its PON rather than sitting mid-block at the end of a long connector.
ROAD_DIST_MULT = float(os.environ.get("ROAD_DIST_MULT", "20"))
# Cost multiplier on OSM road-centreline corridor edges, so the operator's own roadside
# span (real verge route) is preferred and the centreline only bridges gaps.
ROAD_EDGE_MULT = float(os.environ.get("ROAD_EDGE_MULT", "4"))
# How near a road a span edge must be before the feeder may use it. Their own 1:16s sit
# 7-11 m off a road, so this is a shade wider than that and no more.
FEEDER_ROAD_M = float(os.environ.get("FEEDER_ROAD_M", "0"))
# 🔴 VERGE OFFSET: OFF BY DEFAULT, AND HERE IS WHY -- do not switch it on without solving
# the junction problem first. road.shp is a CENTRELINE and a real feeder stands on the verge,
# so shifting the route sideways looks obviously right. It was tried twice on 2026-09-09 and
# both attempts FAILED, each in an instructive way:
#
#   1. Offset the finished feeder CHAINS. Two chains meeting at an intersection get offset to
#      opposite verges and no longer meet, so the network tears at every junction: 95 of 178
#      feeder terminals ended up standing in the carriageway -- worse than not offsetting.
#   2. Offset the ROAD LINES before noding, expecting the junctions to survive. They do not.
#      A T-junction's stem, offset sideways, stops 6 m short of the crossbar's offset line.
#      Corridor connectivity fell 99.6% -> 68.8% of metres and 4 PONs lost their 1:16.
#
# Reaching all 82 PONs matters more than the cable's lateral position, so the corridor is
# built on the centreline and the feeder's exact offset is left as a KNOWN LIMIT. Doing it
# properly needs a real offset of the road NETWORK (mitred at junctions), or the road widths
# we do not have -- OSM gives a centreline and no carriageway width.
VERGE_OFFSET_M = float(os.environ.get("VERGE_OFFSET_M", "0"))
VERGE_CLEAR_M = float(os.environ.get("VERGE_CLEAR_M", "15"))
SIMPLIFY_M = float(os.environ.get("SIMPLIFY_M", "0.05"))  # drop collinear densification points
# 🔴 THE FEEDER IS ROUTED ON THE ROAD LINE AND THEN MOVED BESIDE THE ROAD AS ONE LINE.
# Operator, 2026-10-20: the feeder ran "straight down the middle of the road" (it was on the OSM
# centreline). Routing on a corridor of verge lines and crossing links put it beside the road
# but "all kinds of weird, zigzaggy patterns and strange bends -- this is fibre ... it was better
# before". So the route is the centreline route of before, and side_offset() moves it sideways
# afterwards. Each STRAND -- a run that carries on through every junction along its straightest
# way -- is moved as a single parallel line, so it bends only where the road bends; a branch
# joins its parent where their two lines meet, or by one straight piece across the road. The
# distance comes from the erven, because the OSM line can be metres off the real road (Vrede:
# >3 m a quarter of the time, once 12 m): FEEDER_PROP_M inside the property line on the strand's
# side, or FEEDER_SIDE_M off the road line where no property line is within FEEDER_REACH_M.
# The two failures recorded above came from moving the CHAINS apart independently with no join;
# the joins here are built, and a branch always meets its parent.
THROUGH_ERF_M = float(os.environ.get("THROUGH_ERF_M", "1.5"))
THROUGH_ERF_MULT = float(os.environ.get("THROUGH_ERF_MULT", "50"))
FEEDER_OFFSET = os.environ.get("FEEDER_OFFSET", "1") != "0"
FEEDER_SIDE_M = float(os.environ.get("FEEDER_SIDE_M", "6.5"))   # the operator's Vrede feeder: median 6.9 m
FEEDER_PROP_M = float(os.environ.get("FEEDER_PROP_M", "2.0"))
FEEDER_REACH_M = float(os.environ.get("FEEDER_REACH_M", "25.0"))
FEEDER_MAX_M = float(os.environ.get("FEEDER_MAX_M", "15.0"))    # Vrede: one OSM line runs 12 m off its road; the P1 Check warns past 20 m
# P1 SPLIT INTO THREE STAGES (operator, 2026-10-21: "it'll give the human operator more control over the
# situation"; order feeder, then 1:16s, then distribution). Each part reads the APPROVED output of the part before:
#   all           today's single run, unchanged
#   feeder        the feeder, p1_targets.json (the span point it aimed at in each PON) and the metrics
#   splitters     one 1:16 per PON on the approved feeder (FEEDER_GPKG/FEEDER_LAYER, TARGETS_JSON)
#   distribution  the span per PON as today, plus a link from each approved 1:16 off its span (SPLITTERS_GPKG/_LAYER)
# An untouched feeder -> splitters -> distribution gives exactly what `all` gives.
P1_PART = os.environ.get("P1_PART", "all")
# a 1:16 this close to a PON (on its edge) belongs to it -- copied from EDGE_M in
# qgis_plugin/plan_stages/checks/p2_1to16.py (one_1to16_per_pon), which the step script cannot import
EDGE_M = 2.0

wgs = osr.SpatialReference(); wgs.ImportFromEPSG(4326)
loc = osr.SpatialReference(); loc.ImportFromEPSG(LOCAL_EPSG)
for s in (wgs, loc): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
FWD = osr.CoordinateTransformation(wgs, loc)
REV = osr.CoordinateTransformation(loc, wgs)


def load(key):
    ds = ogr.Open(LPATH(key))
    if ds is None: raise SystemExit(f"cannot open {LPATH(key)}")
    out = []
    for f in ds.GetLayer(0):
        g = f.GetGeometryRef()
        if g is None: continue
        g = g.Clone(); g.Transform(FWD)
        out.append((f.items(), g))
    return out


def pt(g):
    return g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()


def polylines(feats):
    out = []
    for _, g in feats:
        parts = ([g] if g.GetGeometryType() in (ogr.wkbLineString, ogr.wkbLineString25D)
                 else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())])
        for p in parts:
            pts = [p.GetPoint(i)[:2] for i in range(p.GetPointCount())]
            if len(pts) >= 2: out.append(pts)
    return out


def _verge_offset(ch, B, half=None):
    """Shift a polyline sideways onto the verge, away from whichever side is built up.

    `B` is an N x 2 array of structure centroids. The side is decided ONCE per line, so a
    road does not weave from one verge to the other along its length."""
    if len(ch) < 2 or not len(B):
        return ch
    hw = VERGE_CLEAR_M if half is None else half
    from scipy.spatial import cKDTree as _KD
    T = _KD(B)
    score = 0
    for (ax, ay), (bx, by) in zip(ch, ch[1:]):
        L = math.hypot(bx - ax, by - ay)
        if L < 1e-6: continue
        nx_, ny_ = -(by - ay) / L, (bx - ax) / L
        mx, my = (ax + bx) / 2, (ay + by) / 2
        for k in T.query_ball_point([mx, my], hw):
            s = (B[k][0] - mx) * nx_ + (B[k][1] - my) * ny_
            score += 1 if s < 0 else -1          # + => left is the clearer side
    sgn = 1.0 if score >= 0 else -1.0
    out = []
    for i, (x, y) in enumerate(ch):
        a = ch[max(i - 1, 0)]; b = ch[min(i + 1, len(ch) - 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy)
        if L < 1e-6:
            out.append((x, y)); continue
        out.append((x - sgn * VERGE_OFFSET_M * dy / L, y + sgn * VERGE_OFFSET_M * dx / L))
    return out


def _seg_x(p1, p2, q1, q2):
    """intersection point of segments p1-p2 and q1-q2, or None"""
    r = (p2[0] - p1[0], p2[1] - p1[1]); t_ = (q2[0] - q1[0], q2[1] - q1[1])
    den = r[0] * t_[1] - r[1] * t_[0]
    if abs(den) < 1e-12: return None
    w = (q1[0] - p1[0], q1[1] - p1[1])
    a = (w[0] * t_[1] - w[1] * t_[0]) / den; b = (w[0] * r[1] - w[1] * r[0]) / den
    if 0 <= a <= 1 and 0 <= b <= 1: return (p1[0] + a * r[0], p1[1] + a * r[1])
    return None


def _unloop(pts, window=12):
    """cut the small loops a sideways move makes on the inside of a sharp road bend"""
    out = list(pts); i = 0
    while i < len(out) - 3:
        cut = False
        for j in range(min(len(out) - 2, i + window), i + 1, -1):
            x = _seg_x(out[i], out[i + 1], out[j], out[j + 1])
            if x is not None:
                out = out[:i + 1] + [x] + out[j + 1:]; cut = True; break
        if not cut: i += 1
    return out


def _nearest_on(pts, q):
    """(point, segment index) on polyline `pts` nearest to q"""
    best = (math.inf, None, 0)
    for i, (a, b) in enumerate(zip(pts, pts[1:])):
        vx, vy = b[0] - a[0], b[1] - a[1]; L2 = vx * vx + vy * vy
        t = 0.0 if L2 < 1e-12 else max(0.0, min(1.0, ((q[0] - a[0]) * vx + (q[1] - a[1]) * vy) / L2))
        c = (a[0] + t * vx, a[1] + t * vy); d = math.dist(c, q)
        if d < best[0]: best = (d, c, i)
    return best[1], best[2]


def valid_erf(g):
    """An erf made valid (2026-10-21, Ventersdorp: one self-intersecting erf stopped P1). A valid erf is returned as
    it was; only the polygon parts of a repaired one are kept. Types are compared flattened (final review
    2026-10-21): an erf with Z values repairs to Polygon25D parts, which a plain wkbPolygon test dropped."""
    if g.IsValid(): return g
    v = g.MakeValid()
    if v is None or v.IsEmpty(): return None
    if ogr.GT_Flatten(v.GetGeometryType()) in (ogr.wkbPolygon, ogr.wkbMultiPolygon): return v
    m = ogr.Geometry(ogr.wkbMultiPolygon)
    for i in range(v.GetGeometryCount()):
        q = v.GetGeometryRef(i)
        t = ogr.GT_Flatten(q.GetGeometryType())
        if t == ogr.wkbPolygon: m.AddGeometry(q)
        elif t == ogr.wkbMultiPolygon:
            for j in range(q.GetGeometryCount()): m.AddGeometry(q.GetGeometryRef(j))
    return None if m.IsEmpty() else m


def side_offset(fe_pairs, coords, root, erven):
    """-> feeder polylines moved beside the road (see FEEDER_OFFSET)."""
    adj = {}
    for a, b in fe_pairs:
        adj.setdefault(a, []).append(b); adj.setdefault(b, []).append(a)
    if root not in adj:
        return merge_edges(fe_pairs, coords)
    kids, seen, q = {}, {root}, [root]
    while q:
        u = q.pop()
        for v in adj[u]:
            if v not in seen:
                seen.add(v); kids.setdefault(u, []).append(v); q.append(v)
    # strands: through every junction along the straightest way on
    strands, stack = [], [(root, c, None) for c in kids.get(root, [])]
    while stack:
        a, b, ps = stack.pop()
        nodes = [a, b]
        while kids.get(nodes[-1]):
            cur = nodes[-1]; back = coords[nodes[max(0, len(nodes) - 6)]]
            h = math.atan2(coords[cur][1] - back[1], coords[cur][0] - back[0])

            def turn(k):
                d = math.atan2(coords[k][1] - coords[cur][1], coords[k][0] - coords[cur][0]) - h
                return abs((d + math.pi) % (2 * math.pi) - math.pi)
            ks = sorted(kids[cur], key=turn)
            for k in ks[1:]: stack.append((cur, k, len(strands)))
            nodes.append(ks[0])
        strands.append((nodes, ps))
    BT, grid = None, {}
    for i_, e in enumerate(erven):
        minx, maxx, miny, maxy = e.GetEnvelope()
        for gx in range(int(minx // 50), int(maxx // 50) + 1):
            for gy in range(int(miny // 50), int(maxy // 50) + 1):
                grid.setdefault((gx, gy), []).append(i_)

    def inside(x, y):
        pt_ = ogr.Geometry(ogr.wkbPoint); pt_.AddPoint_2D(x, y)
        return any(erven[i_].Contains(pt_) for i_ in grid.get((int(x // 50), int(y // 50)), ()))
    if erven:
        eu = ogr.Geometry(ogr.wkbMultiPolygon)
        for g in erven:
            for p in ([g] if g.GetGeometryType() == ogr.wkbPolygon else
                      [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())]):
                if p.GetGeometryType() == ogr.wkbPolygon: eu.AddGeometry(p)
        bd = eu.UnionCascaded().Boundary(); bd.Segmentize(0.25)
        BT = cKDTree(np.array([p for ch in polylines([(None, bd)]) for p in ch]))
    steps = np.arange(0.25, FEEDER_REACH_M + 0.25, 0.25)

    def prop(x, y, nx_, ny_):
        if BT is None: return None
        k = np.flatnonzero(BT.query(np.column_stack([x + steps * nx_, y + steps * ny_]))[0] <= 0.3)
        return float(steps[k[0]]) if len(k) else None

    def roll(v, w, f):
        return np.array([f(v[max(0, i - w):i + w + 1]) for i in range(len(v))])

    out, side = [], []
    for nodes, ps in strands:
        g = ogr.Geometry(ogr.wkbLineString)
        for n_ in nodes: g.AddPoint_2D(*coords[n_])
        g = g.SimplifyPreserveTopology(CORRIDOR_STITCH_M)      # the welding wobble of the route
        P = densify([g.GetPoint(i)[:2] for i in range(g.GetPointCount())], 5.0)
        n = len(P)
        if n < 2:
            out.append(P); side.append(1); continue
        N = []
        for i in range(n):
            a, b = P[max(i - 1, 0)], P[min(i + 1, n - 1)]
            L = math.dist(a, b) or 1.0
            N.append((-(b[1] - a[1]) / L, (b[0] - a[0]) / L))
        # Where the road line runs INSIDE an erf (it hugs the property line, or is a little off),
        # the first boundary out on the erf's side is its FAR side, which read as "more room"
        # and moved the feeder into the houses (Vrede, 2026-10-20). So step out of the erf
        # first: the side it is left by is the road, and the erf's side has no room.
        left, right, lmin, rmin = [], [], [], []
        for i in range(n):
            x, y = P[i]; nx_, ny_ = N[i]
            if not inside(x, y):
                left.append(prop(x, y, nx_, ny_)); right.append(prop(x, y, -nx_, -ny_))
                lmin.append(0.0); rmin.append(0.0); continue
            l, r = prop(x, y, nx_, ny_), prop(x, y, -nx_, -ny_)
            if l is not None and (r is None or l <= r):
                ex = l + 0.3; nxt = prop(x + ex * nx_, y + ex * ny_, nx_, ny_)
                left.append(None if nxt is None else ex + nxt); right.append(0.0)
                lmin.append(l + 1.0); rmin.append(0.0)
            elif r is not None:
                ex = r + 0.3; nxt = prop(x - ex * nx_, y - ex * ny_, -nx_, -ny_)
                right.append(None if nxt is None else ex + nxt); left.append(0.0)
                rmin.append(r + 1.0); lmin.append(0.0)
            else:
                left.append(None); right.append(None); lmin.append(0.0); rmin.append(0.0)
        ml = float(np.median([v for v in left if v is not None])) if any(v is not None for v in left) else FEEDER_REACH_M
        mr = float(np.median([v for v in right if v is not None])) if any(v is not None for v in right) else FEEDER_REACH_M
        # the side with more room is the verge (the OSM line leans towards the other); near
        # equal, keep the parent's side so the feeder does not cross at every junction
        sg = (side[ps] if ps is not None else 1) if abs(ml - mr) < 2.0 else (1 if ml > mr else -1)
        pv = left if sg > 0 else right
        raw = np.array([FEEDER_SIDE_M if v is None else (v - FEEDER_PROP_M if v >= 2 * FEEDER_PROP_M else v / 2)
                        for v in pv])
        # over ~100 m, so the line runs parallel to the road instead of following every erf
        # corner and gap (a wandering line is a bend, and a bend is a pole); then back off only
        # where that would come within 1 m of an erf
        d = roll(roll(np.minimum(raw, FEEDER_MAX_M), 10, np.median), 10, np.mean)
        d = np.array([min(d[i], pv[i] - 1.0) if pv[i] is not None else d[i] for i in range(n)])
        d = np.maximum(d, np.maximum(lmin if sg > 0 else rmin, 0.5))     # out of an erf the line stood in
        Q = []
        for i in range(n):
            # mitre: at a bend the parallel line keeps its distance from both legs
            a, b = P[max(i - 1, 0)], P[min(i + 1, n - 1)]
            m = 1.0
            if 0 < i < n - 1:
                u = (P[i][0] - a[0], P[i][1] - a[1]); w = (b[0] - P[i][0], b[1] - P[i][1])
                cu, cw = math.hypot(*u) or 1.0, math.hypot(*w) or 1.0
                c = (u[0] * w[0] + u[1] * w[1]) / (cu * cw)
                m = 1.0 / max(math.sqrt((1 + c) / 2), 0.5)
            Q.append((P[i][0] + sg * d[i] * m * N[i][0], P[i][1] + sg * d[i] * m * N[i][1]))
        Q = _unloop(Q)
        side.append(sg)
        if ps is not None:
            par = out[ps]
            # join where the branch's line meets its parent's, else one straight piece across
            hit = None
            for s_ in range(min(len(Q) - 1, 8)):
                for t_ in range(len(par) - 1):
                    x = _seg_x(Q[s_], Q[s_ + 1], par[t_], par[t_ + 1])
                    if x is not None: hit = (s_, x); break
                if hit: break
            if hit: Q = [hit[1]] + Q[hit[0] + 1:]
            else: Q = [_nearest_on(par, Q[0])[0]] + Q
        out.append(Q)
    return out


def merge_edges(edges, coords):
    """Chain a set of undirected edges into the longest possible polylines.

    The graph is densified to half a metre, so writing one feature per edge would produce
    170,000 two-point lines. Chains are walked from every degree!=2 node first (so junctions
    and ends terminate a run), then any remaining pure cycles are broken arbitrarily."""
    adj = {}
    for a, b in edges:
        adj.setdefault(a, set()).add(b)
        adj.setdefault(b, set()).add(a)
    used = set()
    out = []

    def walk(start, nxt):
        chain = [start, nxt]
        used.add(frozenset((start, nxt)))
        cur, prev = nxt, start
        while len(adj.get(cur, ())) == 2:
            fwd = [n for n in adj[cur] if n != prev]
            if not fwd: break
            n = fwd[0]
            e = frozenset((cur, n))
            if e in used: break
            used.add(e)
            chain.append(n)
            prev, cur = cur, n
        return chain

    for n in adj:
        if len(adj[n]) != 2:
            for m in adj[n]:
                if frozenset((n, m)) not in used:
                    out.append(walk(n, m))
    for a, b in edges:                      # leftover cycles
        if frozenset((a, b)) not in used:
            out.append(walk(a, b))
    return [[coords[n] for n in ch] for ch in out]


def write_lines(dst, layer, chains, extra=None, simplify_m=None):
    """`simplify_m` defaults to SIMPLIFY_M (collinear cleanup). The feeder passes its stitch
    tolerance instead: two lines welded within 3 m leave a 3 m wobble in the chain."""
    tol = SIMPLIFY_M if simplify_m is None else simplify_m
    if os.path.exists(dst): ogr.GetDriverByName("GPKG").DeleteDataSource(dst)
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(dst)
    lyr = ds.CreateLayer(layer, wgs, ogr.wkbLineString)
    lyr.CreateField(ogr.FieldDefn("length_m", ogr.OFTReal))
    for name, typ in (extra or []):
        lyr.CreateField(ogr.FieldDefn(name, typ))
    n, total = 0, 0.0
    for ch in chains:
        pts, attrs = (ch[0], ch[1]) if isinstance(ch, tuple) else (ch, {})
        g = ogr.Geometry(ogr.wkbLineString)
        for p in pts: g.AddPoint_2D(float(p[0]), float(p[1]))
        if tol > 0: g = g.SimplifyPreserveTopology(tol)
        if g is None or g.GetPointCount() < 2: continue
        plen = g.Length(); total += plen
        g.Transform(REV)
        f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
        f.SetField("length_m", round(plen, 2))
        for k, v in attrs.items():
            if v is not None: f.SetField(k, v)
        lyr.CreateFeature(f); f = None; n += 1
    ds = None
    return n, total


def _approved(gpkg_env, layer_env):
    """(datasource, layer, transform to site metres) of an approved layer; it may be in the site CRS, not 4326"""
    gpkg, name = os.environ.get(gpkg_env), os.environ.get(layer_env)
    if not gpkg: raise SystemExit(f"P1_PART={P1_PART} needs {gpkg_env}")
    ds = ogr.Open(gpkg)
    if ds is None: raise SystemExit(f"cannot open {gpkg}")
    lyr = ds.GetLayerByName(name) if name else ds.GetLayer(0)
    if lyr is None: raise SystemExit(f"no layer {name!r} in {gpkg}")
    srs = lyr.GetSpatialRef()
    if srs is None: raise SystemExit(f"{gpkg} ({name}) has no CRS")
    srs = srs.Clone(); srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return ds, lyr, osr.CoordinateTransformation(srs, loc)


def distribution_chains(G, node_pon, pon_label, total_m):
    # ---- distribution = the WHOLE span, attributed to the PON it lies in -------------
    # The feeder is new geometry off the span, so nothing is taken out of it. (An earlier
    # version removed the feeder's metres from distribution; Step 4 answered with 257,056 m
    # of drop cable and single drops of 780 m, because every home along the feeder route
    # was stranded. The spec settles it anyway -- TSD p7: where feeder and distribution
    # share a pole, "the feeder cable always above the distribution cable".)
    dist_edges = []
    orphan_m = 0.0
    per_pon = {}
    for u in G.adj:
        for v, w in G.adj[u]:
            if u >= v: continue
            pi = node_pon.get(u, node_pon.get(v))
            dist_edges.append((u, v, pi))
            if pi is None: orphan_m += w
            else: per_pon[pi] = per_pon.get(pi, 0.0) + w
    dist_m = sum(G.edge_length(u, v) for u, v, _ in dist_edges)
    print(f"distribution {dist_m:,.0f} m ({100 * dist_m / total_m:.1f}% of span"
          + ", the whole span)"
          + (f"; {orphan_m:,.0f} m lies in no PON" if orphan_m > 1 else ""))
    by_pon = {}
    for u, v, pi in dist_edges:
        by_pon.setdefault(pi, []).append((u, v))
    chains = []
    for pi, eds in by_pon.items():
        for ch in merge_edges(eds, G.coords):
            chains.append((ch, {"pon": None if pi is None else int(pon_label[pi])}))
    return chains, dist_m, orphan_m, per_pon


def splitters_part(pons, pon_label, lab, pon_span, rp):
    """P2: one 1:16 per PON on the approved feeder -- on P1's target where it still lies on the feeder (today's
    position, today's attributes), else on the feeder point nearest the PON's span (place_1to16.place)."""
    from place_1to16 import place, read_lines
    ds, lyr, to_site = _approved("FEEDER_GPKG", "FEEDER_LAYER")
    feeder = read_lines(lyr, to_site); ds = None
    tpath = os.environ.get("TARGETS_JSON")
    if not tpath: raise SystemExit("P1_PART=splitters needs TARGETS_JSON")
    with open(tpath, encoding="utf-8") as fh:
        tg = json.load(fh)
    targets = {}
    for i in range(len(pons)):
        t = tg.get(lab(i))
        targets[lab(i)] = None if t is None else tuple(FWD.TransformPoint(float(t["x"]), float(t["y"]))[:2])
    placed, why, gap = place(feeder, targets, pon_span, CONNECTOR_MAX_M)
    print(f"approved feeder: {len(feeder)} line(s); 1:16s on P1's target {sum(p[2] == 'target' for p in placed.values())}, "
          f"moved to the nearest feeder point {sum(p[2] == 'nearest' for p in placed.values())}")
    RT = cKDTree(np.array(rp))

    dst = os.path.join(OUT, "claude_1to16_splitters.gpkg")
    if os.path.exists(dst): ogr.GetDriverByName("GPKG").DeleteDataSource(dst)
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(dst)
    lyr = ds.CreateLayer("claude_1to16_splitters", wgs, ogr.wkbPoint)
    for nm, tp in (("pon", ogr.OFTInteger), ("units", ogr.OFTInteger),
                   ("road_m", ogr.OFTReal), ("feeder_m", ogr.OFTReal), ("how", ogr.OFTString)):
        lyr.CreateField(ogr.FieldDefn(nm, tp))
    done, missing = set(), []
    for i in range(len(pons)):
        p = placed.get(lab(i))
        if p is None:
            missing.append(i); continue
        if lab(i) in done: continue
        done.add(lab(i))
        x, y, how = p
        g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(x, y); g.Transform(REV)
        f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
        f.SetField("pon", int(pon_label[i]))
        if how == "target":        # untouched: today's values, as P1 recorded them
            t = tg[lab(i)]
            units, road_m, feeder_m = t.get("units"), t.get("road_m"), t.get("feeder_m")
        else:                      # the feeder was moved here: no P1 routing cost applies
            units, road_m, feeder_m = pons[i][0].get("units"), round(float(RT.query((x, y))[0]), 1), None
        if units is not None: f.SetField("units", int(units))
        if road_m is not None: f.SetField("road_m", float(road_m))
        if feeder_m is not None: f.SetField("feeder_m", float(feeder_m))
        f.SetField("how", how)
        lyr.CreateFeature(f); f = None
    ds = None
    print(f"wrote {len(done)} 1:16 splitters")
    for i in missing[:15]:
        print(f"        PON {lab(i)}: no 1:16 -- {why.get(lab(i), '')}")
    json.dump({"site": SITE, "pons": len(pons), "splitters": len(done),
               "unreachable_pons": missing,
               # today's format, so checks/p2_1to16.why_no_1to16 reads it (None: no span in the PON, or no feeder;
               # no_1to16_why tells them apart and P2's Check prefers it)
               "no_1to16": {lab(i): (None if gap.get(lab(i)) is None else round(gap[lab(i)], 1)) for i in missing},
               "no_1to16_why": {lab(i): why.get(lab(i), "") for i in missing},
               "connector_max_m": CONNECTOR_MAX_M},
              open(os.path.join(OUT, "step3_metrics.json"), "w"), indent=2)
    return 0


def distribution_part(G, pons, pon_label, lab, node_pon, pon_span, total_m):
    """P3: the span per PON as today, plus one straight link from each approved 1:16 standing off its PON's span."""
    from place_1to16 import links
    chains, dist_m, orphan_m, per_pon = distribution_chains(G, node_pon, pon_label, total_m)
    ds, lyr, to_site = _approved("SPLITTERS_GPKG", "SPLITTERS_LAYER")
    has_pon = lyr.GetLayerDefn().GetFieldIndex("pon") >= 0
    sp = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty(): continue
        g = g.Clone(); g.Transform(to_site); g = pt(g)
        v = f.GetField("pon") if has_pon else None
        try: v = None if v is None else str(int(float(v)))
        except ValueError: v = str(v)
        sp.append((g.GetX(), g.GetY(), v))
    ds = None
    lk = links(sp, {lab(i): pg for i, (_a, pg) in enumerate(pons)}, pon_span, EDGE_M)
    print(f"approved 1:16s: {len(sp)}; {len(lk)} stand off their PON's span and get a link")
    chains = [(ch, {**a, "link": 0}) for ch, a in chains] + [(seg, {"pon": int(p), "link": 1}) for seg, p in lk]
    n, m = write_lines(os.path.join(OUT, "claude_distribution_cable.gpkg"),
                       "claude_distribution_cable", chains,
                       extra=[("pon", ogr.OFTInteger), ("link", ogr.OFTInteger)])
    print(f"wrote {n:,} distribution polylines, {m:,.0f} m")
    json.dump({"site": SITE, "span_m": round(total_m), "distribution_m": round(dist_m), "orphan_m": round(orphan_m),
               "pons": len(pons), "splitters": len(sp), "links": len(lk),
               "link_m": round(sum(math.dist(*seg) for seg, _ in lk), 1),
               "per_pon_m": {str(pon_label[k]): round(v) for k, v in per_pon.items()}},
              open(os.path.join(OUT, "step3_metrics.json"), "w"), indent=2)
    return 0


def main():
    if P1_PART not in ("all", "feeder", "splitters", "distribution"):
        raise SystemExit(f"P1_PART={P1_PART!r}: expected all, feeder, splitters or distribution")
    print(banner()); print()
    span = load("span")
    pons = load("pons")
    pop = load("pop")
    road = load("road")
    if not pop: raise SystemExit("POP layer is empty")

    G = build_graph(polylines(span))
    total_m = G.total_length()
    print(f"span {total_m:,.0f} m over {len(G.coords):,} nodes "
          f"(seg {SEG_M} m, stitch {STITCH_M} m)")

    keys = list(G.coords)
    A = np.array([G.coords[k] for k in keys])
    idx_of = {k: i for i, k in enumerate(keys)}

    # ---- roadside flag per node ------------------------------------------------------
    rp = []
    for _, g in road:
        parts = ([g] if g.GetGeometryType() in (ogr.wkbLineString, ogr.wkbLineString25D)
                 else [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())])
        for p in parts:
            q = p.Clone(); q.Segmentize(2.0)
            rp.extend(q.GetPoint(i)[:2] for i in range(q.GetPointCount()))
    road_d = cKDTree(np.array(rp)).query(A)[0]
    roadside = {k: bool(road_d[idx_of[k]] <= ROADSIDE_M) for k in keys}
    print(f"roadside nodes (<= {ROADSIDE_M:.0f} m): "
          f"{100 * np.mean(road_d <= ROADSIDE_M):.1f}%")

    # ---- which PON is each node in? --------------------------------------------------
    NT = cKDTree(A)
    node_pon = {}
    pon_label = {}
    for i, (attr, pg) in enumerate(pons):
        pon_label[i] = attr.get("pon_num") or attr.get("label") or (i + 1)
        minx, maxx, miny, maxy = pg.GetEnvelope()
        r = math.hypot(maxx - minx, maxy - miny) / 2 + 5
        for j in NT.query_ball_point([(minx + maxx) / 2, (miny + maxy) / 2], r):
            p = ogr.Geometry(ogr.wkbPoint); p.AddPoint(float(A[j][0]), float(A[j][1]))
            if pg.Contains(p): node_pon[keys[j]] = i
    print(f"{len(pons)} PONs; {len(node_pon):,} of {len(keys):,} span nodes fall inside one")

    def lab(i):            # the PON label as the metrics, the targets and place_1to16 key it
        return str(int(pon_label[i])) if isinstance(pon_label[i], (int, float)) else str(pon_label[i])
    if P1_PART in ("splitters", "distribution"):
        # the 1:16 and the distribution read the APPROVED layer before them; neither needs the corridor
        pon_span = {}
        for k, i in node_pon.items():
            pon_span.setdefault(lab(i), []).append(G.coords[k])
        pon_span = {p: np.array(v, float) for p, v in pon_span.items()}
        if P1_PART == "splitters":
            return splitters_part(pons, pon_label, lab, pon_span, rp)
        return distribution_part(G, pons, pon_label, lab, node_pon, pon_span, total_m)

    # ---- which span is itself ROADSIDE? (a structure between cable and road = midblock)
    mb = Midblock(buildings_for_site(SITE, LOCAL_EPSG)); mb.set_roads(np.array(rp))
    midblock = {}
    mb_m = 0.0
    for u in G.adj:
        for v, w in G.adj[u]:
            if u >= v: continue
            (ax, ay), (bx, by) = G.coords[u], G.coords[v]
            m = mb.is_midblock_v2(ax, ay, bx, by)
            midblock[frozenset((u, v))] = m
            if m: mb_m += w
    # WHICH SPAN MAY CARRY THE FEEDER? Operator, 2026-09-09, looking at the plan:
    # "The feeder cable is not following the road ... it's cutting across even across PONs.
    #  We can't have that ... it's almost always roadside."
    # The midblock classifier (structures both sides / a structure between cable and road)
    # was used for this and is TOO PERMISSIVE: it passes any span with an open side, which
    # includes plenty of mid-block run. Roadside for the feeder is the plain geometric
    # thing -- within FEEDER_ROAD_M of a road centreline -- and that is what is used here.
    # The midblock measure stays for reporting, because it is what the operator's own LINK
    # cable was characterised by, but it no longer decides the corridor.
    # 🔴 THE FEEDER CORRIDOR IS THE ROAD NETWORK, FULL STOP.
    # Two earlier versions let "roadside span" into the corridor -- span within 15 m of a
    # road. That does NOT mean the span is roadside: Ventersdorp's blocks are 50-60 m deep,
    # so a run straight down the MIDDLE of a block is only ~25-30 m from a road, and plenty
    # of mid-block span sits inside 15 m. The operator, on seeing the result twice:
    # "you still sort of drew the feeder cable line across the PON here, and you didn't
    #  follow the roadside ... specifically, this needs to go roadside."
    # A distance threshold cannot express "on the road" -- only the road geometry can. So the
    # corridor is road.shp and nothing else, and the feeder cannot cut across a block because
    # there is no edge there to route on. FEEDER_ROAD_M>0 restores the old behaviour and
    # should not be used.
    street_edges = ([] if FEEDER_ROAD_M <= 0 else
                    [tuple(e) for e in
                     ((u, v) for u in G.adj for v, _w in G.adj[u] if u < v)
                     if road_d[idx_of[e[0]]] <= FEEDER_ROAD_M
                     and road_d[idx_of[e[1]]] <= FEEDER_ROAD_M])
    print(f"span: midblock {mb_m:,.0f} m ({100 * mb_m / total_m:.1f}%), roadside "
          f"{total_m - mb_m:,.0f} m -- only the roadside part may carry the feeder")

    # ---- the FEEDER CORRIDOR: the road network, plus the roadside span ---------------
    # Operator, 2026-09-09 (final): "the feeder route has to be roadside. Sometimes it runs
    # on span, but it should never go mid-block. It's a brand-new route that you need to
    # create ... the most optimal route that reaches all of the PONs." So the corridor is
    # road.shp UNION the roadside chains of the span, noded together; midblock span is
    # not in it at all. The feeder is the shortest-path tree on THIS graph.
    # PREFER THE OPERATOR'S OWN ROADSIDE SPAN OVER THE ROAD CENTRELINE. road.shp is an OSM
    # CENTRELINE: a feeder drawn on it sits IN the carriageway, which is wrong twice over --
    # its poles stand in the roadway (measured: 428 of them), and the crossing detector reads
    # running ALONG a road as crossing it, inflating crossing poles from 611 to 1,022.
    # The operator's own feeder sits on the verge, 5-15 m off the centreline.
    # The roadside span IS surveyed verge route, so it is charged 1x and the centreline
    # ROAD_EDGE_MULT x: the feeder then uses their span wherever it exists and falls back to
    # the centreline only to bridge gaps OSM is the only source for.
    span_chains = merge_edges(street_edges, G.coords)
    # OFFSET THE ROADS TO THE VERGE **BEFORE** BUILDING THE GRAPH, not the feeder after.
    # road.shp is a centreline; the feeder belongs on the verge. The first version routed on
    # the centreline and shifted the finished chains sideways, which broke every junction:
    # two chains meeting at an intersection were offset to opposite verges and no longer
    # met, so 95 of 178 feeder terminals ended up standing in the carriageway.
    # Offsetting the ROAD GEOMETRY first and noding it afterwards keeps junctions joined by
    # construction -- offset lines still cross where the roads crossed, and the stitch welds
    # them. Side is chosen per road by which has fewer structures, so the shift never moves
    # the cable into a row of houses.
    road_lines = polylines(road)
    if VERGE_OFFSET_M > 0 and len(mb.B):
        road_lines = [_verge_offset(ch, mb.B) for ch in road_lines]
        print(f"       road centrelines offset {VERGE_OFFSET_M:.0f} m to the verge "
              f"({len(road_lines)} lines) before noding")
    corridor = road_lines + span_chains
    C = build_graph(corridor, seg=CORRIDOR_SEG_M, stitch=CORRIDOR_STITCH_M)
    _spanpts = np.array([p for ch in span_chains for p in ch]) if span_chains else np.zeros((0, 2))
    _spt = cKDTree(_spanpts) if len(_spanpts) else None

    def on_span(u, v):
        if _spt is None: return False
        m = ((C.coords[u][0] + C.coords[v][0]) / 2, (C.coords[u][1] + C.coords[v][1]) / 2)
        return float(_spt.query(m)[0]) <= CORRIDOR_STITCH_M

    # 🔴 A ROAD LINE INSIDE A PROPERTY IS NOT A STREET. road.shp is OSM, and OSM carries tracks,
    # footpaths and service ways that cut across erven. Operator, 2026-10-20, Vrede: "This is
    # literally cutting across an entire property." Measured on Vrede: 761 m of the feeder ran
    # more than 2 m inside an erf, every metre of it on such a line. An edge whose middle stands
    # more than THROUGH_ERF_M inside an erf costs THROUGH_ERF_MULT times as much, so the feeder
    # takes the streets round the property and uses the path only where nothing else reaches.
    # Every erf is made valid first (2026-10-21, Ventersdorp): one self-intersecting erf made the union in
    # side_offset raise "TopologyException: side location conflict" and P1 Generate stopped (see valid_erf).
    erven = [e for e in (valid_erf(g) for _, g in load("erven")) if e is not None and not e.IsEmpty()] if have("erven") else []
    through = set()
    if erven:
        cell = 50.0; grid = {}
        for i, e in enumerate(erven):
            minx, maxx, miny, maxy = e.GetEnvelope()
            for gx in range(int(minx // cell), int(maxx // cell) + 1):
                for gy in range(int(miny // cell), int(maxy // cell) + 1):
                    grid.setdefault((gx, gy), []).append(i)
        for u in C.adj:
            for v, _w in C.adj[u]:
                if u >= v: continue
                mx = (C.coords[u][0] + C.coords[v][0]) / 2; my = (C.coords[u][1] + C.coords[v][1]) / 2
                pt_ = ogr.Geometry(ogr.wkbPoint); pt_.AddPoint_2D(mx, my)
                for i in grid.get((int(mx // cell), int(my // cell)), ()):
                    if erven[i].Contains(pt_) and erven[i].Boundary().Distance(pt_) > THROUGH_ERF_M:
                        through.add(frozenset((u, v))); break
        print(f"       road line inside a property (> {THROUGH_ERF_M:.1f} m into an erf): "
              f"{sum(C.edge_length(*tuple(e)) for e in through):,.0f} m, charged x{THROUGH_ERF_MULT:.0f}")

    def corridor_cost(u, v, w):
        c = w if on_span(u, v) else w * ROAD_EDGE_MULT
        return c * THROUGH_ERF_MULT if frozenset((u, v)) in through else c
    ckeys = list(C.coords)
    CA = np.array([C.coords[k] for k in ckeys])
    CT = cKDTree(CA)
    ccomp = C.components()
    print(f"feeder corridor {C.total_length():,.0f} m over {len(C.coords):,} nodes, "
          f"{len(ccomp)} component(s), largest {100 * C.component_length(ccomp[0]) / C.total_length():.1f}%")

    pxy = (pt(pop[0][1]).GetX(), pt(pop[0][1]).GetY())
    # The corridor has islands (roadside span that touches no road), and the POP's nearest
    # node was on one of them -- the sweep then reached nothing. Source the feeder on the
    # MAIN component, which is the road network.
    main_c = ccomp[0]
    mkeys = [k for k in ckeys if k in main_c]
    MA = np.array([C.coords[k] for k in mkeys])
    _d, _j = cKDTree(MA).query(pxy)
    csrc = mkeys[int(_j)]
    print(f"POP is {float(_d):.1f} m from the main corridor component, "
          f"{math.dist(G.coords[G.nearest(pxy)], pxy):.1f} m from the span")
    cdist, cpar = C.dijkstra([csrc], weight=corridor_cost)

    # ---- the 1:16 per PON: a span node inside the PON, reached by the corridor --------
    # cost = corridor distance from the POP to the nearest corridor node, plus the
    # CONNECTOR from that node to the span node (0 where the span node IS on the corridor,
    # i.e. roadside span). Their own 1:16 sits 7-11 m from a road, so a connector is
    # normal; one longer than CONNECTOR_MAX_M is refused and the PON is reported, because
    # that is a road-data gap (an unmapped street), not a routing choice.
    # Query the REACHABLE corridor only, so an island next to the PON cannot shadow the
    # road that actually feeds it.
    rkeys = [k for k in ckeys if cdist.get(k, math.inf) < math.inf]
    RA = np.array([C.coords[k] for k in rkeys])
    RT2 = cKDTree(RA)
    best = {}
    nearest_gap = {}
    for k, pi in node_pon.items():
        dc, j = RT2.query(A[idx_of[k]])
        dc = float(dc); cn = rkeys[int(j)]
        conn = 0.0 if dc <= CORRIDOR_STITCH_M else dc
        if pi not in nearest_gap or conn < nearest_gap[pi]: nearest_gap[pi] = conn
        if conn > CONNECTOR_MAX_M: continue
        # THE 1:16 MUST BE NEAR A ROAD. Their own sit 7-11 m off one (measured, four
        # sites). Ours is the point where the roadside feeder ENTERS the PON, so a splitter
        # deep inside a block forces a long connector -- and that connector is exactly the
        # mid-block cut the operator rejected. Charging the connector heavily makes the
        # splitter come to the road instead of the feeder going to the splitter.
        c = cdist[cn] + conn * CONNECTOR_MULT + road_d[idx_of[k]] * ROAD_DIST_MULT
        if pi not in best or c < best[pi][2]:
            best[pi] = (k, cn, c, conn)
    missing = [i for i in range(len(pons)) if i not in best]
    if missing:
        print(f"*** {len(missing)} PON(s) got no 1:16: their span is further than "
              f"{CONNECTOR_MAX_M:.0f} m from any reachable corridor -- a ROAD-DATA GAP, not routing:")
        for i in missing[:15]:
            print(f"        PON {pon_label[i]}: nearest reachable corridor {nearest_gap.get(i, float('nan')):.0f} m")
    print(f"1:16 splitters placed: {len(best)} of {len(pons)}")

    # ---- feeder = corridor paths POP -> each 1:16, plus the connectors ---------------
    feeder_c, connectors = set(), []
    for pi, (k, cn, _, conn) in best.items():
        p = C.path(cn, cpar)
        for a, b in zip(p, p[1:]):
            feeder_c.add(frozenset((a, b)))
        if conn > 0:
            connectors.append([C.coords[cn], G.coords[k]])
    fe_pairs = [tuple(e) for e in feeder_c]
    on_c_m = sum(C.edge_length(a, b) for a, b in fe_pairs)
    conn_m = sum(math.dist(c[0], c[1]) for c in connectors)
    feeder_m = on_c_m + conn_m
    # how much of the corridor feeder is on ROAD geometry vs on ROADSIDE SPAN
    on_span_m = sum(C.edge_length(a, b) for a, b in fe_pairs if on_span(a, b))
    print(f"feeder {feeder_m:,.0f} m = {on_c_m - on_span_m:,.0f} m on roads "
          f"+ {on_span_m:,.0f} m on roadside span + {conn_m:,.0f} m of connector "
          f"into {len(connectors)} splitter(s)")
    if connectors:
        cl = sorted(math.dist(c[0], c[1]) for c in connectors)
        print(f"       connector length median {cl[len(cl) // 2]:.1f} m, max {cl[-1]:.1f} m "
              f"(operator's 1:16 -> road: median 7-11 m)")
    fmb = 0.0                                   # midblock feeder is impossible by construction
    fr = feeder_m
    # write the feeder from the corridor graph + connectors
    if FEEDER_OFFSET:
        strands = side_offset(fe_pairs, C.coords, csrc, erven)
        # every 1:16 joins the moved feeder by one straight piece (it stands on the span)
        connectors = []
        for pi, (k, cn, _, conn) in best.items():
            q = G.coords[k]
            cands = [_nearest_on(st, q)[0] for st in strands if len(st) > 1]
            if cands:
                c = min(cands, key=lambda c: math.dist(c, q))
                if math.dist(c, q) > 0.3: connectors.append([c, q])
        feeder_chains = strands + connectors
        print(f"       feeder moved beside the road: {len(strands)} runs, {FEEDER_PROP_M:.1f} m inside the "
              f"property line or {FEEDER_SIDE_M:.1f} m off the road line; {len(connectors)} connectors into 1:16s")
    else:
        feeder_chains = merge_edges(fe_pairs, C.coords) + connectors

    # THE DELIVERED LENGTH IS THE GEOMETRY'S, NOT THE EDGE WEIGHTS'. Edge weights are taken
    # from the pre-weld point positions; a welded node sits at the mean of what was welded
    # into it, so a chain walked through node COORDINATES is not the same length as the sum
    # of its weights (measured 2026-09-09: 22,689 m of weight, 27,726 m of geometry). What
    # ships is the geometry, so that is the number reported -- reporting the cheaper one
    # would understate the cable by 22%.
    geom_m = sum(math.dist(p, q) for ch in feeder_chains for p, q in zip(ch, ch[1:]))
    print(f"       delivered geometry {geom_m:,.0f} m "
          f"(routing cost {feeder_m:,.0f} m; the difference is node welding, see the code)")
    feeder_m = geom_m
    fr = feeder_m

    chains, dist_m, orphan_m, per_pon = distribution_chains(G, node_pon, pon_label, total_m)
    if P1_PART == "all":
        n, m = write_lines(os.path.join(OUT, "claude_distribution_cable.gpkg"),
                           "claude_distribution_cable", chains,
                           extra=[("pon", ogr.OFTInteger)])
        print(f"wrote {n:,} distribution polylines, {m:,.0f} m")

    nf, mf = write_lines(os.path.join(OUT, "claude_feeder_cable.gpkg"),
                         "claude_feeder_cable", feeder_chains,
                         # moved beside the road the line is already clean; 3 m would cut its corners
                         simplify_m=0.3 if FEEDER_OFFSET else CORRIDOR_STITCH_M)
    print(f"wrote {nf:,} feeder polylines, {mf:,.0f} m")

    if P1_PART == "all":
        dst = os.path.join(OUT, "claude_1to16_splitters.gpkg")
        if os.path.exists(dst): ogr.GetDriverByName("GPKG").DeleteDataSource(dst)
        ds = ogr.GetDriverByName("GPKG").CreateDataSource(dst)
        lyr = ds.CreateLayer("claude_1to16_splitters", wgs, ogr.wkbPoint)
        for nm, tp in (("pon", ogr.OFTInteger), ("units", ogr.OFTInteger),
                       ("road_m", ogr.OFTReal), ("feeder_m", ogr.OFTReal)):
            lyr.CreateField(ogr.FieldDefn(nm, tp))
        for pi, (k, cn, d, conn) in sorted(best.items()):
            g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(*[float(c) for c in G.coords[k]])
            g.Transform(REV)
            f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
            f.SetField("pon", int(pon_label[pi]))
            u = pons[pi][0].get("units")
            if u is not None: f.SetField("units", int(u))
            f.SetField("road_m", round(float(road_d[idx_of[k]]), 1))
            f.SetField("feeder_m", round(d, 1))
            lyr.CreateFeature(f); f = None
        ds = None
        print(f"wrote {len(best)} 1:16 splitters")
    else:
        # P1 Feeder: the span point the feeder aimed at in each PON -- today's 1:16 position and its values, so an
        # untouched P2 puts the 1:16 exactly there (null: no 1:16 today -- no span in the PON, or too far from a road)
        tgt = {}
        for i in range(len(pons)):
            if i not in best:
                tgt[lab(i)] = None; continue
            k, cn, d, conn = best[i]
            lon, lat = REV.TransformPoint(*[float(c) for c in G.coords[k]])[:2]
            u = pons[i][0].get("units")
            tgt[lab(i)] = {"x": lon, "y": lat, "road_m": round(float(road_d[idx_of[k]]), 1),
                           "feeder_m": round(d, 1), "units": None if u is None else int(u)}
        with open(os.path.join(OUT, "p1_targets.json"), "w", encoding="utf-8") as fh:
            json.dump(tgt, fh, indent=2)
        print(f"wrote p1_targets.json: {sum(v is not None for v in tgt.values())} of {len(tgt)} PONs have a target")

    json.dump({"site": SITE, "span_m": round(total_m),
               "feeder_m": round(feeder_m),
               "feeder_roadside_frac": round(fr / feeder_m, 4) if feeder_m else None,
               "feeder_midblock_frac": round(fmb / feeder_m, 4) if feeder_m else None,
               "distribution_m": round(dist_m), "orphan_m": round(orphan_m),
               "pons": len(pons), "splitters": len(best),
               "unreachable_pons": missing,
               # 2026-10-19: per PON label, how far the nearest reachable corridor is -- the Check tells the operator why
               # (None: no span runs inside that PON at all)
               "no_1to16": {lab(i): (round(nearest_gap[i], 1) if i in nearest_gap else None) for i in missing},
               "road_mult": ROAD_MULT, "roadside_m": ROADSIDE_M,
               "feeder_on_roads_m": round(on_c_m - on_span_m), "feeder_on_span_m": round(on_span_m),
               "connector_m": round(conn_m), "connectors": len(connectors),
               "connector_max_m": CONNECTOR_MAX_M, "corridor_m": round(C.total_length()),
               "span_midblock_frac": round(mb_m / total_m, 4),
               "per_pon_m": {str(pon_label[k]): round(v) for k, v in per_pon.items()}},
              open(os.path.join(OUT, "step3_metrics.json"), "w"), indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
