"""P8 adapter (pyqgis launcher): assemble the approved plan, build the QGIS project and render images.

Needs PLAN_DIR/step3, step4 and a combined step567/claude_step567.gpkg rebuilt from the approved
P5/P6/P7 layers, then runs build_qgis_project.py and render_wayleave_plan.py. generated.gpkg stays empty.
Title-block metrics are recomputed from the approved layers. Exits non-zero if either script fails or the
project / render images are missing.
"""
import json, math, os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import (site_dir, run_step, copy_layer, approved, materialise_step3,
                                               materialise_drops, empty_gpkg, transform as osr_transform,
                                               layer_epsg)
from osgeo import ogr


def _len_m(path, layer, epsg):
    ds = ogr.Open(str(path)); lyr = ds.GetLayerByName(layer)
    t = osr_transform(layer_epsg(lyr, 4326), epsg); total = 0.0
    for f in lyr:
        g = f.GetGeometryRef()
        parts = [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]
        for p in parts:
            pts = [t.TransformPoint(p.GetX(i), p.GetY(i))[:2] for i in range(p.GetPointCount())]
            total += sum(math.dist(a, b) for a, b in zip(pts[:-1], pts[1:]))
    return total


def _count(path, layer):
    ds = ogr.Open(str(path))          # keep the datasource alive while the layer is used
    return ds.GetLayerByName(layer).GetFeatureCount()


def write_metrics(rev, epsg):
    """Title-block totals recomputed from the APPROVED layers (the delivery scripts read these keys)."""
    feeder_g, one16_g, dist_g, drops_g, cross_g, poles_g, hw_g = (approved(s) for s in (
        "p1_feeder", "p2_1to16", "p3_distribution", "p4_drops", "p5_crossings", "p6_poles", "p7_hardware"))
    src = "approved layers"
    out = {
        "step3/step3_metrics.json": {"distribution_m": round(_len_m(dist_g, "distribution", epsg)),
                                     "feeder_m": round(_len_m(feeder_g, "feeder", epsg)),
                                     "splitters": _count(one16_g, "splitters_1to16"), "source": src},
        "step4/step4_metrics.json": {"total_drop_m": round(_len_m(drops_g, "drops", epsg)), "drops": _count(drops_g, "drops"),
                                     "collection_points": _count(drops_g, "collection_points"), "source": src},
        "step567/step567_metrics.json": {"crossings": _count(cross_g, "road_crossings"), "poles_total": _count(poles_g, "poles"),
                                         "splitters": _count(hw_g, "splitters_8way"),
                                         "dome_joints": _count(hw_g, "dome_joints"), "source": src},
    }
    for rel, d in out.items():
        (rev / rel).parent.mkdir(exist_ok=True)
        (rev / rel).write_text(json.dumps(d, indent=2), encoding="utf-8")
    print("metrics from approved layers:", json.dumps(out))


def main():
    rev = Path(os.environ["PS_REV_DIR"]); epsg = int(os.environ["PS_EPSG"]); site = os.environ["PS_SITE"]
    site_dir()
    empty_gpkg(rev / "generated.gpkg", epsg)
    materialise_step3(rev); materialise_drops(rev)
    s5 = rev / "step567"; s5.mkdir(exist_ok=True)
    dst = s5 / "claude_step567.gpkg"
    if dst.exists():
        dst.unlink()
    copy_layer(approved("p5_crossings"), "road_crossings", dst, "claude_road_crossings")
    copy_layer(approved("p6_poles"), "poles", dst, "claude_poles")
    h = approved("p7_hardware")
    copy_layer(h, "splitters_8way", dst, "claude_8way_splitters")
    copy_layer(h, "dome_joints", dst, "claude_dome_joints")
    write_metrics(rev, epsg)
    first_rc = 0
    for script in ("build_qgis_project.py", "render_wayleave_plan.py"):
        rc = run_step(script, {"TAG": "plan"})
        if rc:
            print(f"{script} exited {rc}")
            first_rc = first_rc or rc
    proj = rev / "qgis" / f"{site}_plan.qgz"
    pngs = list((rev / "render").glob("*.png")) if (rev / "render").exists() else []
    print(f"qgis project: {'written' if proj.exists() else 'MISSING'}; render images: {len(pngs)}")
    if first_rc:
        return first_rc
    if not proj.exists() or not pngs:
        print("P8 FAILED: project or render output missing")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
