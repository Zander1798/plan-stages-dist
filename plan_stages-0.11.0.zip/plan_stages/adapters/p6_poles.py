"""P6 adapter: step567 STAGE=poles on approved P1-P5, then reconcile with the approved wayleave poles.

A generated pole within 2 m of an approved wayleave pole is replaced by that wayleave pole (position kept,
role/cable/height_m taken from the generated one). Wayleave poles the plan does not use are left out: they stay
in the wayleave (operator 2026-10-19: one layer of the poles the plan uses). Output stays in EPSG:4326 like every
other plan layer.
"""
import os, sys
from pathlib import Path
import numpy as np
from osgeo import ogr, osr
from scipy.spatial import cKDTree
from plan_stages.adapters._plan_common import (site_dir, run_step, materialise_step3, materialise_drops,
                                               copy_layer, approved, transform, layer_epsg)

SNAP_M = 2.0
ONE16_M = 2.0      # 2026-10-14: an approved 1:16 with no pole this close gets one


def add_1to16_poles(gen_gpkg: Path, p2_gpkg: Path, epsg: int, height: float, tol: float = ONE16_M) -> int:
    """A feeder pole at every approved P2 1:16 splitter that has no pole within `tol` m (site metres), so P6
    honours the operator's 1:16 positions. Returns the number added."""
    pds = ogr.Open(str(p2_gpkg)); spl = pds.GetLayerByName("splitters_1to16")
    if spl is None:
        return 0
    gds = ogr.Open(str(gen_gpkg), 1); pl = gds.GetLayerByName("poles")
    pe = layer_epsg(pl, 4326); to_site = transform(pe, epsg); back = transform(epsg, pe)
    xy = [to_site.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2] for f in pl
          if f.GetGeometryRef() is not None]
    s_to_site = transform(layer_epsg(spl, epsg), epsg); added = 0
    for f in spl:
        g = f.GetGeometryRef()
        if g is None:
            continue
        p = s_to_site.TransformPoint(g.GetX(), g.GetY())[:2]
        if xy and float(cKDTree(np.array(xy)).query(p)[0]) <= tol:
            continue
        x, y = back.TransformPoint(p[0], p[1])[:2]
        o = ogr.Feature(pl.GetLayerDefn()); pt = ogr.Geometry(ogr.wkbPoint); pt.AddPoint_2D(x, y); o.SetGeometry(pt)
        o.SetField("role", "1to16"); o.SetField("cable", "feeder"); o.SetField("height_m", float(height))
        pl.CreateFeature(o); xy.append(p); added += 1
    gds = pds = None
    return added


def reconcile(gen, wl_xy, snap: float = SNAP_M, used: set | None = None) -> list:
    """`gen`: [(x, y, *attrs)] generated poles in site metres; `wl_xy`: [(x, y)] wayleave poles. Each generated pole
    within `snap` m of a wayleave pole not yet taken moves onto it; the rest stay where generated. Unused wayleave
    poles are not returned. `used` (optional) collects the indices of the wayleave poles taken."""
    wl = np.array(wl_xy, dtype=float).reshape(-1, 2)
    tree = cKDTree(wl) if len(wl) else None
    used = set() if used is None else used; out = []
    for x, y, *attrs in gen:
        hit = None
        if tree is not None:
            dists, idx = tree.query([x, y], k=min(3, len(wl)), distance_upper_bound=snap)
            for d, j in zip(np.atleast_1d(dists), np.atleast_1d(idx)):
                if np.isfinite(d) and int(j) not in used:
                    hit = int(j); break
        if hit is not None:
            used.add(hit); x, y = float(wl[hit][0]), float(wl[hit][1])
        out.append((x, y, *attrs))
    return out


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"]); epsg = int(os.environ["PS_EPSG"])
    materialise_step3(rev); materialise_drops(rev)
    xg = rev / "approved_crossings.gpkg"
    copy_layer(approved("p5_crossings"), "road_crossings", xg, "claude_road_crossings")
    rc = run_step("step567.py", {"STAGE": "poles", "PS_CROSSINGS_GPKG": str(xg)})
    if rc:
        return rc
    gds = ogr.Open(str(rev / "step567" / "claude_step567_poles.gpkg"))
    gen = gds.GetLayerByName("claude_poles")
    wds = ogr.Open(str(approved("wayleave")))
    wl = wds.GetLayerByName("poles")                # optional in the wayleave: absent means no operator poles
    to_site = transform(4326, epsg)                 # generated poles (4326) -> site metres
    to_wgs = transform(epsg, 4326)                  # site metres -> 4326
    if wl is None:
        print("wayleave has no poles layer: every pole is generated")
        wl_xy = np.zeros((0, 2))
    else:
        wl_to_site = transform(layer_epsg(wl, epsg), epsg)
        wl_xy = np.array([wl_to_site.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2]
                          for f in wl if f.GetGeometryRef() is not None]).reshape(-1, 2)
    out_path = rev / "generated.gpkg"
    if out_path.exists():
        out_path.unlink()
    out = ogr.GetDriverByName("GPKG").CreateDataSource(str(out_path))
    srs = osr.SpatialReference(); srs.ImportFromEPSG(4326); srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    ol = out.CreateLayer("poles", srs, ogr.wkbPoint)
    for n, t in (("role", ogr.OFTString), ("cable", ogr.OFTString), ("height_m", ogr.OFTReal)):
        ol.CreateField(ogr.FieldDefn(n, t))
    gen_site = []
    for f in gen:
        g = f.GetGeometryRef()
        mx, my = to_site.TransformPoint(g.GetX(), g.GetY())[:2]
        gen_site.append((mx, my, f.GetField("role"), f.GetField("cable"), f.GetField("height_m")))
    used = set(); rows = reconcile(gen_site, wl_xy, used=used); kept = len(used)
    for x, y, role, cable, h in rows:
        lon, lat = to_wgs.TransformPoint(x, y)[:2]
        o = ogr.Feature(ol.GetLayerDefn()); p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(lon, lat)
        o.SetGeometry(p); o.SetField("role", role); o.SetField("cable", cable); o.SetField("height_m", h)
        ol.CreateFeature(o)
    out = None
    print(f"reconciled: {kept} on wayleave poles, {len(rows) - kept} new; "
          f"{len(wl_xy) - kept} of {len(wl_xy)} wayleave poles not used by the plan (left in the wayleave)")
    import client_spec                                   # the bundled ml/client_spec, on PYTHONPATH via env.build_env
    n = add_1to16_poles(out_path, approved("p2_1to16"), epsg, float(client_spec.limit("pole_feeder_m", 7.0)))
    print(f"1:16 splitters given a feeder pole: {n}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
