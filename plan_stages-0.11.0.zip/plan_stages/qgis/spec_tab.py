"""Spec tab: client PDFs, Claude's proposed parameter sheet checked against the PDFs by the plugin, operator
confirmation, Save revision. The values planning needs come first, with a readiness line (2026-10-13)."""
from __future__ import annotations
import json, shutil
from pathlib import Path
from qgis.PyQt.QtCore import Qt, pyqtSignal, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QTableWidget,
                                 QTableWidgetItem, QFileDialog, QLabel, QHeaderView, QInputDialog,
                                 QGroupBox)
from qgis.core import QgsApplication, QgsTask
from ..core.specsheet import Sheet, SheetEntry, SheetIncomplete, SPEC_KEYS, UNITS, required_keys, spec_sources, copy_sheet, is_operator
from ..core.spec_claude import MEANING, propose_sheet, build_sheet, ProposalRefused, ProposalFailed
from ..core import spec_rules
from ..core.spec_verify import LABELS as CHECK_LABELS, BLOCKING
from ..core import deps, env as envmod, stages, presets
from .ui import WheelSafeCombo, ask_yes_no, info, warn
from .details_dialogs import ask_detail

COLS = ("key", "meaning", "proposed value", "check", "citation", "value", "status", "confirm")
C_KEY, C_MEANING, C_PROPOSED, C_CHECK, C_CITE, C_VALUE, C_STATUS, C_CONFIRM = range(len(COLS))
DCOLS = ("topic", "detail", "stages", "check", "citation", "read")
D_TOPIC, D_DETAIL, D_STAGES, D_CHECK, D_CITE, D_READ = range(len(DCOLS))
NA_WORDS = ("n/a", "na", "not applicable")


def _show(v) -> str:
    if v is None:
        return ""
    return v if isinstance(v, str) else json.dumps(v)


def _stage_names(ids) -> str:
    """A detail's stages by name; an id this plugin does not know is skipped, never a crash (final review
    2026-10-21: a 0.10.0 sheet's p2_drops raised KeyError and the Spec tab did not draw)."""
    known = set(stages.order())
    return ", ".join(stages.get(s).name for s in ids or () if s in known)


def _parse(text: str):
    try:
        v = json.loads(text)
    except ValueError:
        return text
    return v if isinstance(v, (int, float, bool, str)) else text


def _extras_summary(extras: list) -> str:
    pdf = [x for x in extras if not is_operator(x)]
    parts = [f"{len(pdf)} extra details, {sum(1 for x in pdf if x.get('read'))} read"] if pdf else []
    mine = len(extras) - len(pdf)
    return ", ".join(parts + ([f"{mine} of your own"] if mine else []))


class SpecTab(QWidget):
    changed = pyqtSignal()

    def __init__(self, on_busy=None, parent=None):
        super().__init__(parent)
        self.store = self.config = None
        self.locked, self.external_busy, self.on_busy = False, False, on_busy
        self.pdfs: list[Path] = []
        self.sheet: Sheet | None = None
        self._task = None
        lay = QVBoxLayout(self)
        self.title = QLabel("No site selected"); lay.addWidget(self.title)
        # 2026-10-16: the client's preset, one per client and build method (core/presets)
        prow = QHBoxLayout()
        prow.addWidget(QLabel("Client spec:"))
        self.preset_combo = WheelSafeCombo()
        self.preset_combo.addItem("(none)", None)
        for p in presets.list_presets():
            self.preset_combo.addItem(p.label, p.id)
        self.preset_combo.setToolTip("Fill the sheet from a client's preset: every value with its document, page and "
                                     "sentence, for you to tick. Nothing is saved until Save revision.")
        self.preset_combo.activated.connect(self._preset_picked)
        prow.addWidget(self.preset_combo, 1)
        lay.addLayout(prow)
        self.preset_note = QLabel(""); self.preset_note.setWordWrap(True); self.preset_note.setVisible(False)
        self.preset_note.setStyleSheet("color: #8d6e00;")
        lay.addWidget(self.preset_note)
        self.pending_preset = None                 # chosen since the last Save revision
        self.files = QListWidget(); self.files.setMaximumHeight(90); lay.addWidget(self.files)
        bar = QHBoxLayout()
        self.add_btn = QPushButton("Add PDF…"); self.add_btn.clicked.connect(self._add_pdf_dialog)
        self.add_btn.setToolTip("Import a client standards PDF; it is read whole and the sheet is proposed from it")
        self.find_btn = QPushButton("Find in PDFs"); self.find_btn.clicked.connect(self.find_in_pdfs)
        self.find_btn.setToolTip("Find the planning values in the listed PDFs with the client's patterns: no API key, "
                                 "no internet. Anything not found is typed by hand.")
        self.remove_pdf_btn = QPushButton("Remove PDF"); self.remove_pdf_btn.clicked.connect(self.remove_selected_pdf)
        self.propose_btn = QPushButton("Propose"); self.propose_btn.clicked.connect(self.propose)
        self.clear_btn = QPushButton("Clear spec…"); self.clear_btn.clicked.connect(self._clear_spec_dialog)
        self.clear_btn.setToolTip("Remove every saved spec revision and imported PDF so a new spec can be imported or typed")
        self.copy_btn = QPushButton("Copy from…"); self.copy_btn.clicked.connect(self._copy_dialog)
        self.copy_btn.setToolTip("Fill the sheet from another site's saved spec; review it, then Save revision")
        self.save_btn = QPushButton("Save revision"); self.save_btn.clicked.connect(self.save_revision)
        self.install_btn = QPushButton("Install anthropic…"); self.install_btn.clicked.connect(self.install_anthropic)
        self.install_btn.setToolTip("Reading a spec PDF needs the anthropic package (and pypdf to check its quotes) in "
                                    "QGIS's Python; this runs pip to add what is missing. Until then, type the values by hand.")
        for b in (self.add_btn, self.find_btn, self.remove_pdf_btn, self.propose_btn, self.copy_btn, self.clear_btn, self.save_btn,
                  self.install_btn):
            bar.addWidget(b)
        self.install_btn.setVisible(bool(deps.missing_packages()))
        lay.addLayout(bar)
        self._sel = None                          # the selected row: ("key", key) or ("extra", index)
        # block 1: the values the planning stages read
        self.ready_label = QLabel(""); self.ready_label.setWordWrap(True); lay.addWidget(self.ready_label)
        self.table = self._value_table()
        lay.addWidget(self.table, 3)
        # block 2 (operator 2026-10-13): everything else the submitted PDFs say, kept apart; never blocks saving
        self.extras_box = QGroupBox("Extra details (not used by the plan): from the documents, and your own")
        xl = QVBoxLayout(self.extras_box)
        self.extras_label = QLabel(""); self.extras_label.setWordWrap(True); xl.addWidget(self.extras_label)
        xl.addWidget(QLabel("Other values"))
        self.other_table = self._value_table()
        xl.addWidget(self.other_table, 1)
        xl.addWidget(QLabel("Other details"))
        self.details_table = QTableWidget(0, len(DCOLS)); self.details_table.setHorizontalHeaderLabels(DCOLS)
        self.details_table.horizontalHeader().setSectionResizeMode(D_DETAIL, QHeaderView.ResizeMode.Stretch)
        self.details_table.setToolTip("Tick read once you have looked at a detail. Unread details never block saving.")
        self.details_table.itemChanged.connect(lambda _it: self._update_extras_label())
        self.details_table.currentCellChanged.connect(lambda r, _c, _pr, _pc: self._extra_selected(r))
        xl.addWidget(self.details_table, 1)
        dbar = QHBoxLayout()
        self.add_detail_btn = QPushButton("Add a detail…"); self.add_detail_btn.clicked.connect(self._add_detail_dialog)
        self.add_detail_btn.setToolTip("Your own detail for this site, tagged to the stages it affects: each one is "
                                       "ticked as checked against the plan before that stage can be approved")
        self.edit_detail_btn = QPushButton("Edit…"); self.edit_detail_btn.clicked.connect(self._edit_detail_dialog)
        self.remove_detail_btn = QPushButton("Remove"); self.remove_detail_btn.clicked.connect(self._remove_detail_dialog)
        for b in (self.add_detail_btn, self.edit_detail_btn, self.remove_detail_btn):
            dbar.addWidget(b)
        dbar.addStretch(1)
        xl.addLayout(dbar)
        lay.addWidget(self.extras_box, 2)
        # the selected row's source: its quote, every statement the documents make about it, and its page
        self.source_label = QLabel("Select a row to see where its value comes from.")
        self.source_label.setWordWrap(True); self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.source_label)
        src = QHBoxLayout()
        self.cand_combo = WheelSafeCombo(); self.cand_combo.setMinimumWidth(200)
        self.use_btn = QPushButton("Use this statement"); self.use_btn.clicked.connect(lambda: self.use_statement(self.cand_combo.currentIndex()))
        self.use_btn.setToolTip("Take this statement's value for the row (the documents state more than one)")
        self.open_page_btn = QPushButton("Open page"); self.open_page_btn.clicked.connect(self.open_page)
        self.open_page_btn.setToolTip("Show the PDF page the value was quoted from, with the sentence highlighted")
        src.addWidget(self.cand_combo, 1); src.addWidget(self.use_btn); src.addWidget(self.open_page_btn)
        lay.addLayout(src)

    # ---------------- state ----------------
    def set_site(self, store, config, locked: bool):
        self.store, self.config, self.locked = store, config, locked
        self.pdfs, self.sheet = [], None
        self.pending_preset = None
        if store is not None:
            st = store.load()
            self.title.setText(f"{st['site']} · client {st['client']} · spec {st.get('spec_rev') or '(none)'}")
            if st.get("spec_rev"):
                rd = store.site_dir / "spec" / st["spec_rev"]
                self.pdfs = sorted((rd / "docs").glob("*.pdf"))
                if (rd / "sheet.json").exists():
                    self.sheet = Sheet.load(rd / "sheet.json")
            if self.sheet is None and st.get("spec_preset"):
                try:
                    self.sheet = presets.preset_sheet(st["spec_preset"])     # New site: unsaved until Save revision
                except KeyError:
                    self.sheet = None
            if self.sheet is None:
                self.sheet = Sheet.blank(st["client"])
        else:
            self.title.setText("No site selected")
        self._fill()
        self._show_preset(self._current_preset())
        self.refresh()

    # ---------------- client spec presets (2026-10-16) ----------------
    def _preset_picked(self, index: int):
        pid = self.preset_combo.itemData(index)
        if pid is None or self.store is None:
            self._show_preset(self._current_preset())
            return
        if not self.choose_preset(pid):
            self._show_preset(self._current_preset())         # put the combo back

    def _current_preset(self):
        if self.pending_preset is not None:
            return self.pending_preset or None           # "": the sheet was replaced by something other than a preset
        return self.store.load().get("spec_preset") if self.store is not None else None

    def _show_preset(self, pid):
        i = self.preset_combo.findData(pid)
        self.preset_combo.blockSignals(True); self.preset_combo.setCurrentIndex(max(i, 0)); self.preset_combo.blockSignals(False)
        client = self.sheet.client if self.sheet is not None else ""
        note = (f"The planning steps follow HeroTel's method; {client}'s own rules are in the details below."
                if pid not in (None, "herotel") else "")
        self.preset_note.setText(note); self.preset_note.setVisible(bool(note))

    def _dirty(self) -> bool:
        """The table differs from the last saved revision (or, with none saved, holds anything resolved or any PDF
        extra ticked as read)."""
        now = self._sheet_from_table()
        st = self.store.load()
        saved = self.store.site_dir / "spec" / str(st.get("spec_rev")) / "sheet.json"
        reads = [t for x, t in zip(self.sheet.extras, self._read_ticks()) if not is_operator(x)] if self.sheet else []
        if st.get("spec_rev") and saved.exists():
            old = Sheet.load(saved)
            return any((e.status, e.value) != (old.entries.get(k, SheetEntry(k)).status, old.entries.get(k, SheetEntry(k)).value)
                       for k, e in now.entries.items()) or                 reads != [bool(x.get("read")) for x in old.extras if not is_operator(x)]
        return any(e.status in ("confirmed", "operator_stated") for e in now.entries.values()) or any(reads)

    def _not_from_preset(self):
        """The sheet was just replaced by Copy from, Find in PDFs or a proposal: Save revision records no preset."""
        self.pending_preset = ""
        self._show_preset(None)

    def choose_preset(self, preset_id: str, ask: bool = True) -> bool:
        """Replace the sheet with the preset's (the operator's own details stay). Not saved. Asked first when the
        table has unsaved changes or the site has a saved revision (2026-10-19 review)."""
        p = presets.get(preset_id)
        if ask and (self._dirty() or self.store.load().get("spec_rev")) and not ask_yes_no(
                self, "Replace the sheet?", f"Replace the sheet with {p.label}? Your own details are kept. "
                                            f"The saved revision stays until you press Save revision."):
            return False
        self._sync_read_ticks()
        self.sheet = presets.preset_sheet(preset_id).with_operator_extras(self.sheet)
        self.pending_preset = preset_id
        self._fill()
        self._show_preset(preset_id)
        self.refresh()
        return True

    def refresh(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        self.preset_combo.setEnabled(usable)
        self.add_btn.setEnabled(usable)
        self.remove_pdf_btn.setEnabled(usable and bool(self.pdfs))
        self.find_btn.setEnabled(usable and bool(self.pdfs))
        self.clear_btn.setEnabled(usable)
        self.copy_btn.setEnabled(usable)
        self.save_btn.setEnabled(usable)
        has_key = bool(self.config and self.config.effective_api_key())
        has_pkg = deps.have_anthropic()
        missing = deps.missing_packages()
        self.install_btn.setVisible(bool(missing)); self.install_btn.setEnabled(usable)
        if missing:
            self.install_btn.setText(f"Install {' and '.join(missing)}…")
        self.propose_btn.setEnabled(usable and has_key and has_pkg and bool(self.pdfs))
        self.propose_btn.setToolTip("Read the PDFs again and propose the sheet" if has_key and has_pkg else
                                    "Install the anthropic package (button to the right), then set the API key in Config…"
                                    if not has_pkg else
                                    "Set the Anthropic API key in Config… (or the ANTHROPIC_API_KEY environment variable)")
        for t in (self.table, self.other_table, self.details_table):
            t.setEnabled(self.store is not None and not self.locked)
        self._update_detail_buttons()

    def _update_detail_buttons(self):
        usable = self.store is not None and not self.locked and self._task is None and not self.external_busy
        mine = self._selected_operator() is not None
        self.add_detail_btn.setEnabled(usable and self.sheet is not None)
        self.edit_detail_btn.setEnabled(usable and mine); self.remove_detail_btn.setEnabled(usable and mine)

    def _selected_operator(self) -> dict | None:
        if not (self._sel and self._sel[0] == "extra" and self.sheet and self._sel[1] < len(self.sheet.extras)):
            return None
        x = self.sheet.extras[self._sel[1]]
        return x if is_operator(x) else None

    def _value_table(self) -> QTableWidget:
        t = QTableWidget(0, len(COLS)); t.setHorizontalHeaderLabels(COLS)
        t.horizontalHeader().setSectionResizeMode(C_MEANING, QHeaderView.ResizeMode.Stretch)
        t.setToolTip("Edit 'value' to state your own value; type n/a for not applicable; tick confirm to accept.")
        t.itemChanged.connect(self._value_changed)
        t.currentCellChanged.connect(lambda r, _c, _pr, _pc, t=t: self._value_selected(t, r))
        return t

    @staticmethod
    def planning_keys() -> list[str]:
        req = set(required_keys())
        return [k for k in SPEC_KEYS if k in req]

    @staticmethod
    def other_keys() -> list[str]:
        req = set(required_keys())
        return [k for k in SPEC_KEYS if k not in req]

    def _value_tables(self):
        return (self.table, self.other_table)

    def _fill(self):
        self._fill_files_only()
        tables = (self.table, self.other_table, self.details_table)
        for t in tables:
            t.blockSignals(True); t.setRowCount(0)
        if self.sheet is not None:
            for t, keys in ((self.table, self.planning_keys()), (self.other_table, self.other_keys())):
                t.setRowCount(len(keys))
                for r, k in enumerate(keys):
                    self._fill_row(t, r, k)
            self.details_table.setRowCount(len(self.sheet.extras))
            for r, x in enumerate(self.sheet.extras):
                self._fill_extra(r, x)
        for t in tables:
            t.blockSignals(False)
        # every planning value and other value visible without scrolling the table; the dock itself scrolls
        for t, rows in ((self.table, self.table.rowCount()), (self.other_table, self.other_table.rowCount()),
                        (self.details_table, min(max(self.details_table.rowCount(), 2), 10))):
            t.setMinimumHeight(t.horizontalHeader().height() + 4 + rows * t.verticalHeader().defaultSectionSize())
        self._update_ready()
        self._update_extras_label()
        self._show_source()

    def _fill_row(self, table: QTableWidget, r: int, k: str):
        e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
        cite = f"{e.document} p.{e.page}: {e.quoted_text}" if e.document and e.page else (e.document or e.note)
        if e.status == "conflict":
            proposed, check = f"{len(e.candidates)} statements", "⚠ documents disagree: pick one below"
        else:
            proposed = (_show(e.value) + (f" {e.unit}" if e.unit and e.value is not None else "")) \
                if e.status in ("proposed", "confirmed") else ""
            check = CHECK_LABELS.get(e.check, "") + (f" p.{e.page}" if e.check == "verified" and e.page else "")
        cells = {C_KEY: k, C_MEANING: MEANING.get(k, ""), C_PROPOSED: proposed, C_CHECK: check, C_CITE: cite,
                 C_VALUE: "n/a" if e.status == "not_applicable" else _show(e.value), C_STATUS: e.status}
        for c, text in cells.items():
            it = QTableWidgetItem(text)
            if c != C_VALUE:
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if c == C_KEY:
                it.setData(Qt.ItemDataRole.UserRole, k)
            if c in (C_CITE, C_CHECK):
                it.setToolTip(e.check_note if c == C_CHECK and e.check_note else text)
            table.setItem(r, c, it)
        chk = QTableWidgetItem()
        chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if e.status in ("confirmed", "not_applicable")
                          else Qt.CheckState.Unchecked)
        table.setItem(r, C_CONFIRM, chk)

    def _fill_extra(self, r: int, x: dict):
        mine = is_operator(x)
        check = "operator" if mine else \
            CHECK_LABELS.get(x.get("check", ""), "") + (f" p.{x['page']}" if x.get("check") == "verified" and x.get("page") else "")
        cite = "" if mine else f"{x.get('document', '')} p.{x.get('page')}: {x.get('quoted_text', '')}"
        names = _stage_names(x.get("stages")) if mine else ""
        for c, text in {D_TOPIC: x.get("topic", ""), D_DETAIL: x.get("detail", ""), D_STAGES: names, D_CHECK: check,
                        D_CITE: cite}.items():
            it = QTableWidgetItem(text)
            it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            it.setToolTip(x.get("check_note", "") if c == D_CHECK else text)
            self.details_table.setItem(r, c, it)
        chk = QTableWidgetItem()
        # your own details are ticked at Approve on their stages, not here
        chk.setFlags(Qt.ItemFlag.ItemIsEnabled if mine else Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
        chk.setCheckState(Qt.CheckState.Checked if mine or x.get("read") else Qt.CheckState.Unchecked)
        self.details_table.setItem(r, D_READ, chk)

    def _table_of(self, key: str) -> QTableWidget:
        return self.table if key in set(required_keys()) else self.other_table

    def row_of(self, key: str) -> int:
        t = self._table_of(key)
        for r in range(t.rowCount()):
            if t.item(r, C_KEY).data(Qt.ItemDataRole.UserRole) == key:
                return r
        return -1

    def _value_changed(self, item):
        """A value cell changed. Density typed on the sheet keeps only that density section's statements on the
        split rows (and the caps worked out from them); any other density text, or none, shows them all again."""
        if item.column() == C_VALUE and self._key_at(item.tableWidget(), item.row()) == "density" and self.sheet:
            text = item.text().strip().lower()
            self.sheet.apply_density(text if text in ("high", "low") else None)
            req = set(required_keys())
            for k, e in self.sheet.entries.items():
                if any(c.get("regime") for c in e.candidates):
                    t = self._table_of(k)
                    t.blockSignals(True); self._fill_row(t, self.row_of(k), k); t.blockSignals(False)
            self._show_source()
        self._update_ready()

    def _update_ready(self):
        """'Ready to plan: N of 11': the values the planning stages read that the table settles right now."""
        if self.sheet is None or self.table.rowCount() == 0:
            self.ready_label.setText(""); return
        req = required_keys()
        missing = self._sheet_from_table().unresolved(req)
        done = len(req) - len(missing)
        self.ready_label.setText(f"Ready to plan: {done} of {len(req)} planning values settled" +
                                 ("" if missing else ". Press Save revision."))
        self.ready_label.setStyleSheet("color: #2e7d32;" if not missing else "color: #8d6e00;")
        self.ready_label.setToolTip("Still to settle (tick, type a value, or n/a): " + ", ".join(missing)
                                    if missing else "Every value the planning stages read is settled.")

    def _read_ticks(self) -> list[bool]:
        t = self.details_table
        return [t.item(r, D_READ) is not None and t.item(r, D_READ).checkState() == Qt.CheckState.Checked
                for r in range(t.rowCount())]

    def _update_extras_label(self):
        rows = list(zip(self.sheet.extras, self._read_ticks())) if self.sheet is not None else []
        pdf = [t for x, t in rows if not is_operator(x)]
        mine = len(rows) - len(pdf)
        text = (f"Extra details: {sum(pdf)} of {len(pdf)} read. Tick each one you have looked at; unread details "
                f"never block Save revision." if pdf else
                "No extra details from the documents yet. Add the client's PDFs to fill this block: they come only "
                "from the PDFs submitted for this site.")
        if mine:
            text += f" Your own details: {mine}; each is ticked at Approve on the stages it affects."
        self.extras_label.setText(text)

    # ---------------- source of the selected row (2026-10-13) ----------------
    def _key_at(self, table: QTableWidget, row: int) -> str | None:
        it = table.item(row, C_KEY) if 0 <= row < table.rowCount() else None
        return it.data(Qt.ItemDataRole.UserRole) if it is not None else None

    def _value_selected(self, table: QTableWidget, row: int):
        k = self._key_at(table, row)
        self._sel = ("key", k) if k else None
        self._show_source()

    def _extra_selected(self, row: int):
        self._sel = ("extra", row) if self.sheet and 0 <= row < len(self.sheet.extras) else None
        self._show_source()

    def _show_source(self):
        """The selected row's quote, page and check; for documents that disagree, every statement to pick from."""
        self.cand_combo.clear()
        kind, ref = self._sel if self._sel else (None, None)
        e = self.sheet.entries.get(ref) if (kind == "key" and self.sheet) else None
        x = self.sheet.extras[ref] if (kind == "extra" and self.sheet and ref < len(self.sheet.extras)) else None
        doc = page = None
        if e is not None:
            where = f"{e.document}, page {e.page}" if e.document and e.page else (e.document or "no document")
            quote = f"“{e.quoted_text}”" if e.quoted_text else (e.note or "")
            check = f" ({e.check_note})" if e.check_note else ""
            self.source_label.setText(f"{ref}: {quote} — {where}{check}" if e.status != "conflict" else
                                      f"{ref}: the documents state {len(e.candidates)} values. Pick the one that "
                                      f"applies to this site and press Use this statement, or type your own value.")
            for c in e.candidates:
                self.cand_combo.addItem(f"{_show(c['value'])} {c.get('unit', '')} — {c.get('document', '')} "
                                        f"p.{c.get('page')}: {c.get('quoted_text', '')[:70]} "
                                        f"[{CHECK_LABELS.get(c.get('check', ''), '')}]")
            doc, page = e.document, e.page
        elif x is not None and is_operator(x):
            names = _stage_names(x.get("stages"))
            self.source_label.setText(f"{x.get('topic', '')}: {x.get('detail', '')}\nYour own detail ({x['id']}); "
                                      f"ticked at Approve on: {names}")
        elif x is not None:
            note = f" ({x['check_note']})" if x.get("check_note") else ""
            self.source_label.setText(f"{x.get('topic', '')}: {x.get('detail', '')}\n“{x.get('quoted_text', '')}” — "
                                      f"{x.get('document', '')}, page {x.get('page')}{note}")
            doc, page = x.get("document"), x.get("page")
        else:
            self.source_label.setText("Select a row to see where its value comes from.")
        many = e is not None and len(e.candidates) > 1
        self.cand_combo.setVisible(many); self.use_btn.setVisible(many)
        self.open_page_btn.setEnabled(bool(doc and page) and self._pdf_named(doc) is not None)
        self._update_detail_buttons()

    def select_key(self, key: str):
        t = self._table_of(key)
        t.setCurrentCell(self.row_of(key), C_KEY)
        self._value_selected(t, self.row_of(key))

    def select_extra(self, index: int):
        self.details_table.setCurrentCell(index, D_TOPIC)
        self._extra_selected(index)

    def use_statement(self, index: int):
        """Take statement `index` of the selected row (documents that disagree). The operator still ticks it."""
        k = self._sel[1] if self._sel and self._sel[0] == "key" else None
        if not k or index < 0 or index >= len(self.sheet.entries[k].candidates):
            return
        self.sheet.pick(k, index)
        t = self._table_of(k)
        t.blockSignals(True)
        self._fill_row(t, self.row_of(k), k)
        t.blockSignals(False)
        self._show_source()
        self._update_ready()

    # ---------------- your own details (2026-10-14) ----------------
    def _sync_read_ticks(self):
        """The table's read ticks back into the sheet, so rebuilding the table never loses them."""
        if self.sheet is not None and self.details_table.rowCount() == len(self.sheet.extras):
            self.sheet.extras = [{**x, "read": t} for x, t in zip(self.sheet.extras, self._read_ticks())]

    def _show_extra(self, x: dict):
        self._fill(); self.select_extra(self.sheet.extras.index(x))

    def add_detail(self, stage_ids, topic: str, text: str) -> dict:
        self._sync_read_ticks()
        x = self.sheet.add_detail(stage_ids, topic, text)
        self._show_extra(x)
        return x

    def edit_detail(self, detail_id: str, stage_ids, topic: str, text: str) -> dict:
        self._sync_read_ticks()
        x = self.sheet.edit_detail(detail_id, stage_ids, topic, text)
        self._show_extra(x)
        return x

    def remove_detail(self, detail_id: str) -> None:
        self._sync_read_ticks()
        self.sheet.remove_detail(detail_id)
        self._sel = None
        self._fill()

    def _add_detail_dialog(self):
        got = ask_detail(self) if self.sheet is not None else None
        if got:
            try:
                self.add_detail(*got)
            except ValueError as e:
                warn(self, "Add a detail", str(e))

    def _edit_detail_dialog(self):
        x = self._selected_operator()
        got = ask_detail(self, x) if x is not None else None
        if got:
            try:
                self.edit_detail(x["id"], *got)
            except ValueError as e:
                warn(self, "Edit detail", str(e))

    def _remove_detail_dialog(self):
        x = self._selected_operator()
        if x is not None and ask_yes_no(self, "Remove detail?", f"Remove your detail “{x['detail']}”? It is gone "
                                        f"from the spec once you press Save revision."):
            self.remove_detail(x["id"])

    def _pdf_named(self, name: str) -> Path | None:
        return next((p for p in self.pdfs if p.name == name and p.exists()), None)

    def _dialog(self, doc: str, page, quote: str):
        from .pdf_page import HAVE_QTPDF, PdfPageDialog
        pdf = self._pdf_named(doc) if doc else None
        if pdf is None or not page or not HAVE_QTPDF:
            return None
        return PdfPageDialog(pdf, int(page), quote, self)

    def page_dialog(self, key: str):
        """The page the key's value was quoted from, in a dialog (not shown); None without Qt's PDF module."""
        e = self.sheet.entries.get(key) if self.sheet else None
        return self._dialog(e.document, e.page, e.quoted_text) if e is not None else None

    def extra_page_dialog(self, index: int):
        x = self.sheet.extras[index]
        return self._dialog(x.get("document", ""), x.get("page"), x.get("quoted_text", ""))

    def open_page(self):
        if not self._sel:
            return
        kind, ref = self._sel
        dlg = self.page_dialog(ref) if kind == "key" else self.extra_page_dialog(ref)
        if dlg is not None:
            dlg.exec(); dlg.deleteLater()
            return
        doc = self.sheet.entries[ref].document if kind == "key" else self.sheet.extras[ref].get("document", "")
        pdf = self._pdf_named(doc)
        if pdf is not None:                     # no Qt PDF module: the system viewer, at page 1
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(pdf)))

    @property
    def proposing(self) -> bool:
        return self._task is not None

    def _busy_changed(self):
        self.refresh()
        if self.on_busy is not None:
            self.on_busy()

    # ---------------- PDFs + proposal ----------------
    def _add_pdf_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Client standards", "", "PDF (*.pdf)")
        self.add_pdfs([Path(p) for p in paths])

    def add_pdfs(self, paths: list[Path]):
        """Import PDFs. Operator ruling 2026-10-07: an imported PDF is read whole at once and the sheet proposed
        from it, so its values are on the table (with page citations) ready to confirm; no key, no proposal."""
        added = False
        for p in paths:
            if p not in self.pdfs:
                self.pdfs.append(p); added = True
        self._fill_files_only()
        self.refresh()
        if added and self.pdfs:
            if self._current_preset() not in (None, "herotel"):
                # 2026-10-16: a preset sheet is checked against the client's PDFs, never replaced
                self._sync_read_ticks()
                self.sheet = presets.verify(self.sheet, list(self.pdfs))
                self._fill(); self.refresh()
                n = sum(1 for e in self.sheet.entries.values() if e.check == "verified")
                cited = presets.cited_documents(self.sheet)
                hint = ("" if n or any(p.name in cited for p in self.pdfs) else
                        "\n\nNone of your PDFs has the name of a document this preset quotes, so nothing could be "
                        "checked. The preset quotes:\n" + "\n".join(cited) +
                        "\nAdd the client's PDF under its own file name.")
                info(self, "Preset checked", f"Checked the preset's quotes against {len(self.pdfs)} PDF(s): "
                                             f"{n} values verified. No value was changed.{hint}")
            elif self.config and self.config.effective_api_key() and deps.have_anthropic():
                self.propose()
            else:                                # no key (operator 2026-10-13): the client's patterns, offline
                self.find_in_pdfs()

    def find_in_pdfs(self):
        """Fill the sheet from the listed PDFs with the client's patterns (core/spec_rules): no Claude, no key.
        A density already typed on the sheet is kept and applied. Nothing is saved until Save revision."""
        if self.store is None or not self.pdfs or self._task is not None:
            return
        client = self.sheet.client if self.sheet is not None else self.store.load()["client"]
        if not spec_rules.taught(client):
            info(self, "Find in PDFs", f"Find in PDFs is not taught {client}'s wording yet, so the sheet is left as it "
                                       f"is. Use the Client spec dropdown, or type the values.")
            return
        density = ""
        r = self.row_of("density")
        if r >= 0 and self.table.item(r, C_VALUE) is not None:
            density = self.table.item(r, C_VALUE).text().strip().lower()
        found = spec_rules.find(list(self.pdfs), client)
        self._sync_read_ticks()
        sheet = build_sheet(client, list(self.pdfs), found.statements, found.extras).with_operator_extras(self.sheet)
        if density in ("high", "low"):
            sheet.set_operator("density", density, "entered in the Plan Stages dock")
            sheet.apply_density(density)
        self.sheet = sheet
        self._fill()
        self._not_from_preset()
        req = required_keys()
        got = [k for k in req if sheet.entries[k].status in ("proposed", "conflict") or k == "density" and density]
        missing = [k for k in req if k not in got]
        info(self, "Found in the PDFs",
             f"Found {len(got)} of {len(req)} planning values and {sum(1 for x in sheet.extras if not is_operator(x))} extra details in "
             f"{len(self.pdfs)} PDF(s), with no API key.\n\n"
             + ("" if density in ("high", "low") else "Type the site's density (high or low) in the density row: "
                "the split ratios then follow that section of the spec.\n")
             + (f"Not stated in the documents, type them: {', '.join(k for k in missing if k != 'density')}.\n"
                if [k for k in missing if k != "density"] else "")
             + "Check every row, tick what is right, then Save revision."
             + (f"\n\n{found.note}" if found.note else ""))
        self.refresh()

    def remove_selected_pdf(self):
        row = self.files.currentRow()
        if row < 0 or row >= len(self.pdfs):
            return
        del self.pdfs[row]
        self._fill_files_only(); self.refresh()

    def _clear_spec_dialog(self):
        if self.store is None or self.locked:
            return
        st = self.store.load()
        if not ask_yes_no(self, "Clear spec?", f"Remove every saved spec revision of site {st['site']} (sheets and "
                          f"imported PDFs) and empty the sheet, so a new spec can be imported or typed? Every "
                          f"started stage goes stale until a new revision is saved. This cannot be undone."):
            return
        self.clear_spec()

    def clear_spec(self):
        from ..core import approval
        approval.clear_spec(self.store)
        self.pdfs, self.sheet = [], Sheet.blank(self.store.load()["client"])
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()

    def _fill_files_only(self):
        self.files.clear()
        for p in self.pdfs:
            self.files.addItem(str(p))

    def install_anthropic(self):
        """pip install anthropic into QGIS's Python through the plugin's launcher, as a background task."""
        if self._task is not None or self.config is None:
            return
        try:
            launcher = envmod.command_for(self.config, stages.get("p6_poles"), "adapters/p6_poles.py")[0]
        except Exception as e:                           # noqa: BLE001 - no QGIS found / bad config
            warn(self, "Install anthropic", f"{type(e).__name__}: {e}")
            return
        cmd = deps.pip_install_cmd(launcher, *(deps.missing_packages() or ["anthropic"]))

        def work(task):
            import subprocess
            r = subprocess.run(cmd, capture_output=True, text=True)
            return (r.returncode, (r.stdout or "") + (r.stderr or ""))

        def done(exc, result=None):
            self._task = None
            if exc is not None or result is None:
                warn(self, "Install anthropic", f"pip did not run: {exc}")
            elif result[0] != 0:
                warn(self, "Install anthropic", f"pip exited {result[0]}:\n\n{result[1][-1500:]}")
            elif not deps.have_anthropic():
                warn(self, "Install anthropic", "pip reported success, but the package is not importable yet. "
                                                 "Restart QGIS, then try Propose again.")
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: pip install anthropic", work, on_finished=done)
        QgsApplication.taskManager().addTask(self._task)
        self.refresh()

    def propose(self):
        if not (self.config and self.config.effective_api_key()) or not self.pdfs or self._task is not None:
            return
        pdfs, client, key = list(self.pdfs), self.store.load()["client"], self.config.effective_api_key()

        def work(task):
            return propose_sheet(pdfs, client, key)

        def done(exception, result=None):
            self._task = None
            self._busy_changed()
            if exception is not None:
                kind = "refused" if isinstance(exception, ProposalRefused) else \
                    "failed" if isinstance(exception, ProposalFailed) else f"error ({type(exception).__name__})"
                warn(self, f"Proposal {kind}", str(exception))
            elif result is not None:
                self._sync_read_ticks(); self.sheet = result.with_operator_extras(self.sheet)
                self._fill(); self._not_from_preset()
            self.refresh()
        self._task = QgsTask.fromFunction("Plan Stages: propose spec sheet", work, on_finished=done)
        self._busy_changed()
        QgsApplication.taskManager().addTask(self._task)

    # ---------------- copy (rollout 2026-10-12) ----------------
    def copy_sources(self) -> list[tuple[str, Path]]:
        return spec_sources(self.store.site_dir.parent, exclude_site=self.store.site) if self.store is not None else []

    def _copy_dialog(self):
        src = self.copy_sources()
        if not src:
            info(self, "Copy spec", "No other site with a saved spec was found.")
            return
        label, ok = QInputDialog.getItem(self, "Copy spec from", "Fill this site's sheet from:", [s[0] for s in src], 0, False)
        if ok and label:
            self.copy_from(label, dict(src)[label])
            info(self, "Spec copied", f"Filled from {label}.\nReview every value (edit or untick any that do not apply "
                                      f"to this site), then press Save revision. Nothing is saved until you do.")

    def copy_from(self, label: str, path: Path) -> None:
        """Replace the unsaved table with a copy of the sheet at `path` (marked with its source); this site's own
        details stay. Not saved."""
        self._sync_read_ticks()
        self.sheet = copy_sheet(Sheet.load(path), self.store.load()["client"], label).with_operator_extras(self.sheet)
        self._fill()
        self._not_from_preset()

    # ---------------- save ----------------
    def _sheet_from_table(self) -> Sheet:
        st = self.store.load()
        out = Sheet(self.sheet.client if self.sheet is not None else st["client"], "", {})
        out.extras = [{**x, "read": ticked} for x, ticked in zip(self.sheet.extras, self._read_ticks())]
        out.op_seq = self.sheet.op_seq
        for t, r in [(t, r) for t in self._value_tables() for r in range(t.rowCount())]:
            k = t.item(r, C_KEY).data(Qt.ItemDataRole.UserRole)
            e = self.sheet.entries.get(k, SheetEntry(k, unit=UNITS.get(k, "")))
            text = (t.item(r, C_VALUE).text() if t.item(r, C_VALUE) else "").strip()
            ticked = t.item(r, C_CONFIRM).checkState() == Qt.CheckState.Checked
            entry = SheetEntry(**{**e.__dict__})
            out.entries[k] = entry
            if not ticked:
                if entry.status == "confirmed":
                    entry.status = "proposed"            # un-ticking withdraws the confirmation
                continue
            if text.lower() in NA_WORDS:
                out.mark_not_applicable(k)
            elif not text:
                continue                                 # ticked but empty: stays unresolved
            elif text == _show(e.value) and e.status in ("proposed", "confirmed") and e.check in BLOCKING:
                # the plugin could not find Claude's quote (or the value in it) in the PDF: ticking it makes the
                # value the operator's own statement, never a cited document value
                out.set_operator(k, e.value, f"{e.check_note or e.check}: quote not found in the PDF; "
                                             f"value stated by the operator in the Plan Stages dock")
            elif text == _show(e.value) and e.status in ("proposed", "confirmed"):
                entry.status = "confirmed"
            else:
                out.set_operator(k, _parse(text), "entered in the Plan Stages dock")
        return out

    def save_quietly(self) -> str | None:
        """Use this wayleave with no revision saved (2026-10-20): save the sheet on show and return the line the
        Wayleave box shows, with the extras Approve will ask about; None when the sheet lacks a required value."""
        rev = self.save_revision(announce=False)
        if not rev:
            return None
        summary = _extras_summary(self.sheet.extras) if self.sheet is not None else ""
        return (f"spec {rev} saved from the sheet on the Spec tab (no revision was saved yet)"
                + (f"; {summary}" if summary else ""))

    def save_revision(self, announce: bool = True) -> str | None:
        """Write spec/rev-NNN/{docs,sheet.json}; mark every non-pending stage stale. Returns the rev or None.
        announce=False: Use this wayleave saved it (2026-10-20) and says so in its own report."""
        sheet = self._sheet_from_table()
        missing = sheet.unresolved(required_keys())
        if missing:
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(missing))
            return None
        base = self.store.site_dir / "spec"
        base.mkdir(parents=True, exist_ok=True)
        existing = sorted(p.name for p in base.glob("rev-*") if p.is_dir())
        rev = f"rev-{(int(existing[-1][4:]) + 1 if existing else 1):03d}"
        rd = base / rev
        (rd / "docs").mkdir(parents=True)
        sheet.rev = rev
        try:
            sheet.save(rd / "sheet.json", required_keys())
        except SheetIncomplete as e:
            shutil.rmtree(rd, ignore_errors=True)
            warn(self, "Spec sheet incomplete", "Resolve these keys first:\n" + "\n".join(e.keys))
            return None
        for p in self.pdfs:
            if p.exists():
                shutil.copy2(p, rd / "docs" / p.name)
        self.store.save_spec_revision(rev)
        if self.pending_preset is not None:
            self.store.set_client_preset(sheet.client, self.pending_preset or None)
            self.pending_preset = None
        summary = _extras_summary(sheet.extras)
        extras = f"\n{summary}." if summary else ""
        if announce:
            info(self, "Spec saved", f"Saved {rev}. Every stage already started is now stale.{extras}")
        self.set_site(self.store, self.config, self.locked)
        self.changed.emit()
        return rev
