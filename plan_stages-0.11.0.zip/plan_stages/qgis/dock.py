"""The Plan Stages dock: site selector, config dialog, site lock, and the Spec / Plan / Help tabs. The Plan tab starts
with the Wayleave box (the project's wayleave layers, snapshotted as the approved input), then gate0 and P1 to P8."""
from __future__ import annotations
import re
from dataclasses import fields
from pathlib import Path
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QTabWidget,
                                 QLabel, QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QInputDialog, QScrollArea,
                                 QFrame)
from ..config import PluginConfig, default_config_path
from ..core import stages, presets
from ..core.controller import StageController
from ..core.store import SiteStore, LockHeld, MigrationBlocked
from ..core.sitecrs import lo_zone
from .sitecrs_qgis import project_longitude
from .spec_tab import SpecTab
from qgis.core import QgsProject
from . import layers
from .stage_tab import StageTab
from .wayleave_box import WayleaveBox
from . import help_tab
from .help_tab import HelpTab
from .ui import ask_yes_no, warn



class ConfigDialog(QDialog):
    def __init__(self, config: PluginConfig, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Plan Stages configuration")
        form = QFormLayout(self)
        self.edits: dict[str, QLineEdit] = {}
        for f in fields(PluginConfig):
            e = QLineEdit(str(getattr(config, f.name)))
            if f.name == "anthropic_api_key":
                e.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow(f.name, e); self.edits[f.name] = e
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        form.addRow(bb)

    def value(self) -> PluginConfig:
        return PluginConfig(**{k: e.text().strip() for k, e in self.edits.items()})


class PlanStagesDock(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Plan Stages", parent or iface.mainWindow())
        self.iface = iface
        self.setObjectName("PlanStagesDock")
        self.config = PluginConfig.load(default_config_path())
        self.store: SiteStore | None = None
        self.controller: StageController | None = None
        self.has_lock = False
        self.locked = False
        self._build()
        self.reload_sites()
        # A project opened or cleared in QGIS gives the dock a fresh slate (ruling 2026-10-07).
        prj = QgsProject.instance()
        self._prj_conns = [(prj.readProject, lambda _doc: self._project_changed()),
                           (prj.cleared, self._project_changed)]
        for sig, fn in self._prj_conns:
            sig.connect(fn)

    # ---------------- layout ----------------
    def _build(self):
        body = QWidget(); lay = QVBoxLayout(body)
        top = QHBoxLayout()
        self.site_combo = QComboBox(); self.site_combo.setMinimumWidth(160)
        self.site_combo.activated.connect(lambda _i: self.select_site(self.site_combo.currentText()))
        self.new_btn = QPushButton("New site…"); self.new_btn.clicked.connect(self._new_site_dialog)
        self.reset_btn = QPushButton("Start over…"); self.reset_btn.clicked.connect(self._start_over_dialog)
        self.reset_btn.setToolTip("Wipe this site's planning progress (every stage back to pending); keeps the spec")
        self.save_btn = QPushButton("Save"); self.save_btn.clicked.connect(self.save_progress)
        self.save_btn.setToolTip("Keep this site's planning progress. Unsaved progress is discarded the next time "
                                 "the site is opened (ruling 2026-10-07)")
        self.cfg_btn = QPushButton("Config…"); self.cfg_btn.clicked.connect(self._config_dialog)
        top.addWidget(QLabel("Site")); top.addWidget(self.site_combo, 1)
        top.addWidget(self.new_btn); top.addWidget(self.save_btn); top.addWidget(self.reset_btn); top.addWidget(self.cfg_btn)
        lay.addLayout(top)
        self.lock_label = QLabel(""); self.lock_label.setStyleSheet("color: #c62828;"); self.lock_label.hide()
        lay.addWidget(self.lock_label)
        self.saved_label = QLabel(""); self.saved_label.setWordWrap(True); self.saved_label.hide()
        lay.addWidget(self.saved_label)
        self.tabs = QTabWidget()
        self.spec_tab = SpecTab(on_busy=self.set_global_busy)
        plan = QWidget(); pl = QVBoxLayout(plan)
        self.wayleave_box = WayleaveBox(self.iface)
        self.plan_reason = QLabel(""); self.plan_reason.setWordWrap(True); self.plan_reason.setStyleSheet("color: #c62828;")
        rows = [s.id for s in stages.REGISTRY if s.phase in ("gate", "plan")]
        self.plan_tab = StageTab(self.iface, rows, on_busy=self.set_global_busy)
        self.wayleave_box.ensure_spec = self.spec_tab.save_quietly
        self.plan_tab.wayleave_layer = lambda name: self.wayleave_box.chosen().get(name)
        self.plan_tab.wayleave_chosen = lambda: self.wayleave_box.chosen()
        pl.addWidget(self.wayleave_box); pl.addWidget(self.plan_reason); pl.addWidget(self.plan_tab, 1)
        self.tabs.addTab(self.spec_tab, "Spec")
        self.plan_index = self.tabs.addTab(plan, "Plan")
        self.help_tab = HelpTab()
        self.help_index = self.tabs.addTab(self.help_tab, "Help")
        if not help_tab.help_seen():          # the very first time the plugin is opened, show what it needs
            self.tabs.setCurrentIndex(self.help_index)
            help_tab.mark_help_seen()
        for t in (self.spec_tab, self.wayleave_box, self.plan_tab):
            t.changed.connect(self.refresh)
        lay.addWidget(self.tabs, 1)
        # The dock must shrink to whatever width the operator drags it to: the body scrolls instead of
        # imposing its natural width (eight layer rows + seven button rows) on the QGIS window.
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(body)
        self.setWidget(scroll)
        self.setMinimumWidth(240)

    # ---------------- sites ----------------
    def site_names(self) -> list[str]:
        root = Path(self.config.plan_root)
        return sorted(p.name for p in root.iterdir() if (p / "site.json").exists()) if root.is_dir() else []

    def reload_sites(self):
        current = self.store.site if self.store else None
        self.site_combo.blockSignals(True)
        self.site_combo.clear()
        self.site_combo.addItems(self.site_names())
        if current:
            self.site_combo.setCurrentText(current)
        else:
            self.site_combo.setCurrentIndex(-1)
        self.site_combo.blockSignals(False)
        self.refresh()

    def _new_site_dialog(self):
        name, ok = QInputDialog.getText(self, "New site", "Site name (folder):")
        if not ok or not name.strip():
            return
        zone = lo_zone(project_longitude(QgsProject.instance()))
        hint = (f"Suggested from the project's layers: EPSG:{zone[0]} (Hartebeesthoek94 / Lo{zone[1]})." if zone else
                "No layers in the project to suggest from: load the wayleave first, or type the Lo zone's EPSG "
                "(Lo19 2048, Lo25 2051, Lo27 2052, Lo29 2053 ...).")
        epsg, ok = QInputDialog.getInt(self, "New site", f"EPSG of the site's working CRS.\n{hint}",
                                       zone[0] if zone else 2052, 1024, 999999)
        if not ok:
            return
        plist = presets.list_presets()
        label, ok = QInputDialog.getItem(self, "New site", "Client spec:", [p.label for p in plist], 0, False)
        if not ok or not label:
            return
        self.create_site(name.strip(), epsg, next(p.id for p in plist if p.label == label))

    def create_site(self, name: str, epsg: int, preset_id: str) -> bool:
        """The new-site code path (the dialog only collects these three values). Selects the new site; its sheet
        starts from the chosen client spec preset, unsaved (2026-10-16)."""
        if not re.fullmatch(r"[A-Za-z0-9_\-]+", name):
            warn(self, "New site", "Use letters, digits, '_' or '-' only for the site name.")
            return False
        store = SiteStore(Path(self.config.plan_root), name)
        if (store.site_dir / "site.json").exists():
            warn(self, "New site", f"Site {name} already exists; selecting it.")
        else:
            p = presets.get(preset_id)
            store.create_site(int(epsg), p.client, preset=preset_id)
        self.select_site(name)
        self.reload_sites()
        return True

    def _start_over_dialog(self):
        if self.store is None or self.locked:
            return
        started = [sid for sid, s in self.store.load()["stages"].items() if s["status"] != "pending"]
        names = ", ".join(stages.get(s).name for s in started) or "(nothing started yet)"
        if not ask_yes_no(self, f"Start over on {self.store.site}?",
                          f"Delete every stage revision of site {self.store.site} from disk and its layers from "
                          f"the project, and put every stage back to pending? The spec is kept.\n\n"
                          f"Started stages: {names}\n\nThis cannot be undone."):
            return
        self.start_over()

    def _discard_unsaved(self):
        """Ruling 2026-10-07: a site opened with unsaved progress starts clean; only saved progress persists."""
        self.plan_tab.cancel_tasks()
        if not self.store.is_saved() and self.store.started_stages():
            layers.unload_all(self.store.site)       # release the GeoPackage locks before the revisions are deleted
        try:
            wiped = self.controller.discard_unsaved()
        except Exception as e:                       # noqa: BLE001 - a locked file must not leave the dock siteless
            warn(self, "Plan Stages", f"Could not discard unsaved progress of {self.store.site}: "
                                      f"{type(e).__name__}: {e}" + "\n\nClose whatever holds the file and pick the site again.")
            wiped = []
        if wiped:
            self.saved_label.setStyleSheet("color: #8d6e00;")
            self.saved_label.setText(f"Unsaved progress of {self.store.site} discarded on open "
                                     f"({', '.join(stages.get(s).name for s in wiped)}). Press Save to keep progress.")
            self.saved_label.show()
        else:
            self.saved_label.hide()

    def save_progress(self):
        if self.store is None or self.locked:
            return
        self.controller.save_progress()
        self.refresh()

    def start_over(self):
        """Ruling 2026-10-07: the same site planned again from the Wayleave box."""
        self.plan_tab.cancel_tasks()
        for sid in stages.order():
            layers.unload_stage(self.store.site, stages.get(sid)); layers.unload_issues(self.store.site, stages.get(sid))
        self.controller.reset_site()
        self.select_site(self.store.site)

    def _project_changed(self):
        """QGIS opened or cleared a project: a fresh slate against the new project (sites re-read, Wayleave rows
        re-matched, reports cleared). An exception escaping a PyQt slot aborts QGIS, so swallow everything."""
        try:
            self.reload_sites()
            if self.store is not None:
                self.select_site(self.store.site)
        except Exception:                        # noqa: BLE001
            pass

    def _spec_path(self) -> Path | None:
        rev = self.store.load().get("spec_rev") if self.store else None
        return self.store.site_dir / "spec" / rev / "sheet.json" if rev else None

    def select_site(self, name: str):
        """Open a site fresh from disk: state re-read, Wayleave rows re-matched against the open project, old
        reports and logs cleared. Choosing the site already open does the same (ruling 2026-10-07); the lock
        is kept, not re-taken."""
        if not name:
            return
        same = self.store is not None and self.store.site == name and self.has_lock
        if not same:
            self._release()
            self.store = SiteStore(Path(self.config.plan_root), name)
            self.controller = StageController(self.config, self.store, self._spec_path)
            self._acquire()
            if self.has_lock:
                self._discard_unsaved()
        if self.has_lock:                      # a project saved with old stage layers opens clean; wayleave layers stay
            layers.unload_stale(self.store.site, self.store.load()["stages"])
        self.spec_tab.set_site(self.store, self.config, self.locked)
        # set_site refreshes each row; a stage whose current revision is not in the project (e.g. after a
        # restart) gets a Load button there, which loads it editable unless approved. Nothing auto-loads.
        self.plan_tab.set_site(self.controller, self.store, self.locked)
        self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.refresh()

    # ---------------- lock ----------------
    def _acquire(self):
        self.has_lock = self.locked = False
        try:
            self.store.acquire_lock()
            self.has_lock = True
            self.lock_label.hide()
        except LockHeld as e:
            self.locked = True
            self.lock_label.setText(f"Site {self.store.site} is open in another QGIS (pid {e.pid}, since {e.when}). "
                                    f"Read-only.")
            self.lock_label.show()
            return
        self._move_old_layout()

    def _move_old_layout(self):
        """A site made with 0.10.0: its old plan work moves to old-layout/ now, before anything else reads or wipes
        it (final review 2026-10-21). Its layers leave the project first, or Windows refuses to move their files.
        Refused: nothing moved, nothing deleted, the site shown read-only until the operator picks it again."""
        try:
            if not self.store.old_layout():
                return
            layers.unload_old_layout(self.store.site)
            self.store.load()                    # the lock holder's first read moves the old folders aside
        except MigrationBlocked as e:
            self._release()
            self.locked = True
            msg = (f"Site {self.store.site} was planned with an older Plan Stages. Its old plan work could not be "
                   f"moved to the old-layout folder ({e}). Close the old plan layers (or the other QGIS that has this "
                   f"site open) and pick the site again. Nothing was moved or deleted. Read-only until then.")
            self.lock_label.setText(msg); self.lock_label.setWordWrap(True); self.lock_label.show()
            warn(self, "Plan Stages", msg)

    def _release(self):
        if self.store is not None and self.has_lock:
            try:
                self.store.release_lock()
            except OSError:
                pass
        self.has_lock = False

    def plan_blocked_reason(self) -> str | None:
        """Why the Plan tab's stage rows are disabled; None when gate0 to P8 may run."""
        if self.store is None:
            return "Select or create a site."
        st = self.store.load()
        w = st["stages"]["wayleave"]       # 2026-10-20: no saved spec is not its own stop; Use this wayleave saves one
        if w["status"] != "approved":
            if w["status"] == "stale":
                return "The spec changed since the wayleave snapshot: press Use this wayleave again."
            return "Press Use this wayleave: the stages below run only on an approved wayleave snapshot."
        return None

    def plan_enabled(self) -> bool:
        return self.plan_blocked_reason() is None

    def refresh(self):
        self.plan_tab.locked = self.locked
        if self.plan_tab.controller is not None:
            self.plan_tab.refresh()
        self.wayleave_box.locked = self.locked
        self.wayleave_box.refresh()
        self.spec_tab.locked = self.locked
        self.spec_tab.refresh()
        why = self.plan_blocked_reason()
        self.plan_reason.setText(why or ""); self.plan_reason.setVisible(why is not None)
        self.plan_tab.setEnabled(why is None)
        if self.store is not None:
            saved = self.store.is_saved() or not self.store.started_stages()
            self.save_btn.setEnabled(not self.locked and not saved)
            self.save_btn.setText("Saved" if saved else "Save")
        else:
            self.save_btn.setEnabled(False); self.save_btn.setText("Save")

    def set_global_busy(self):
        """While any tab runs a task, the site, config, spec-save and wayleave controls are frozen."""
        busy = self.plan_tab.busy or self.spec_tab.proposing
        for w in (self.site_combo, self.new_btn, self.cfg_btn):
            w.setEnabled(not busy)
        self.spec_tab.external_busy = self.plan_tab.busy
        self.spec_tab.refresh()
        self.wayleave_box.external_busy = self.plan_tab.busy
        self.wayleave_box.refresh()

    # ---------------- config ----------------
    def _config_dialog(self):
        dlg = ConfigDialog(self.config, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new = dlg.value()
        new.save(default_config_path())
        root_changed = new.plan_root != self.config.plan_root
        self.config = new
        if root_changed:
            self._release()
            self.store = self.controller = None
            self.plan_tab.set_site(None, None, False)
            self.wayleave_box.set_site(None, None, False)
            self.spec_tab.set_site(None, new, False)
        elif self.store is not None:
            self.controller = StageController(self.config, self.store, self._spec_path)
            self.spec_tab.set_site(self.store, self.config, self.locked)
            self.plan_tab.set_site(self.controller, self.store, self.locked)
            self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.reload_sites()

    # ---------------- lifecycle ----------------
    def showEvent(self, event):
        if self.store is not None and not self.has_lock:      # re-take the lock after a close / reopen
            self._acquire()
            self.select_site_tabs()
        super().showEvent(event)

    def select_site_tabs(self):
        self.plan_tab.set_site(self.controller, self.store, self.locked)
        self.wayleave_box.set_site(self.controller, self.store, self.locked)
        self.spec_tab.set_site(self.store, self.config, self.locked)
        self.refresh()

    def closeEvent(self, event):
        self._release()
        super().closeEvent(event)

    def shutdown(self):
        """Called by the plugin's unload: cancel running stage tasks and release the site lock."""
        self.plan_tab.cancel_tasks()
        self.wayleave_box.shutdown()
        for sig, fn in getattr(self, "_prj_conns", []):
            try:
                sig.disconnect(fn)
            except (TypeError, RuntimeError):
                pass
        self._prj_conns = []
        self._release()
