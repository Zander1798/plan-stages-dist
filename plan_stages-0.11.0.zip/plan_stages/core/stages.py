"""The chain. One entry per stage; changing manual -> generated is one line here."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class LayerSpec:
    name: str
    geom: str                      # "Point" | "LineString" | "Polygon"
    fields: tuple[tuple[str, str], ...] = ()   # (name, "str"|"int"|"real")
    optional: bool = False         # a source layer the project may not have; its checks are skipped when absent


@dataclass(frozen=True)
class Stage:
    id: str
    name: str
    phase: str                     # "source" | "gate" | "plan"
    deps: tuple[str, ...]
    generator: str | None          # adapters/<x>.py relative to plugin folder, or None = manual
    check: str                     # checks/<x>.py
    outputs: tuple[LayerSpec, ...]
    spec_keys: tuple[str, ...] = ()
    launcher: str = "gdal"         # "gdal" | "pyqgis"
    # 2026-10-14 (D-PS.7): approved layers above this stage it deliberately does not read: (stage id, layer, why).
    # tests/test_inputs_contract.py fails for any approved layer a stage neither reads nor lists here.
    ignores: tuple = ()


REGISTRY: tuple[Stage, ...] = (
    # The wayleave is the operator's: the dock snapshots the project's layers into one revision ("Use this
    # wayleave"), which is approved only when checks/wayleave.py passes. Nothing generates it.
    Stage("wayleave", "Wayleave (from project)", "source", (), None, "checks/wayleave.py",
          (LayerSpec("span", "LineString"),
           LayerSpec("pons", "Polygon", (("pon_num", "int"), ("homes", "int"))),
           LayerSpec("demand_points", "Point"),
           LayerSpec("pop", "Point", (("name", "str"),)),
           LayerSpec("roads", "LineString"),
           LayerSpec("poles", "Point", (("role", "str"),), optional=True),
           LayerSpec("erven", "Polygon", (("erf_id", "str"),), optional=True),
           LayerSpec("aoi", "Polygon", optional=True),
           # building footprints for the midblock test (rollout 2026-10-12: supplied by the operator, never fetched
           # from one machine's work/buildings); exported as site_export/buildings.gpkg
           LayerSpec("buildings", "Polygon", optional=True)),
          ("drop_cap_m",)),
    Stage("gate0", "Step 0 wayleave gate", "gate", ("wayleave",),
          "adapters/gate0.py", "checks/gate0.py", (), ("drop_cap_m",)),
    # P1 SPLIT INTO THREE STAGES (operator 2026-10-21: "it'll give the human operator more control over the
    # situation"; order feeder, then 1:16s, then distribution). Each runs one part of step3_span_split.py (P1_PART)
    # on the approved layer of the stage before, so the operator corrects each before the next is built on it.
    Stage("p1_feeder", "P1 Feeder", "plan", ("gate0",), "adapters/p1_feeder.py", "checks/p1_feeder.py",
          (LayerSpec("feeder", "LineString"),)),
    Stage("p2_1to16", "P2 1:16 splitters", "plan", ("gate0", "p1_feeder"), "adapters/p2_1to16.py", "checks/p2_1to16.py",
          (LayerSpec("splitters_1to16", "Point", (("pon", "int"),)),)),
    # `link` 1 = the straight piece joining a moved 1:16 to its PON's span (0 = span), kept through approval
    Stage("p3_distribution", "P3 Distribution", "plan", ("gate0", "p2_1to16"), "adapters/p3_distribution.py",
          "checks/p3_distribution.py",
          (LayerSpec("distribution", "LineString", (("pon", "int"), ("link", "int"))),)),
    Stage("p4_drops", "P4 Collection points and drops", "plan", ("gate0", "p1_feeder", "p2_1to16", "p3_distribution"),
          "adapters/p4_drops.py", "checks/p4_drops.py",
          (LayerSpec("collection_points", "Point", (("cp_id", "str"), ("n_drops", "int"), ("pon", "int"))),
           LayerSpec("drops", "LineString", (("cp_id", "str"), ("length_m", "real"), ("crosses_road", "int"))),
           LayerSpec("drop_review", "Point", (("note", "str"),))),
          ("drop_cap_m", "fan_cap", "pon_cap"),
          ignores=(("p1_feeder", "feeder", "drops and collection points hang on the distribution cable only"),
                   ("p2_1to16", "splitters_1to16", "drops and collection points do not depend on where the 1:16 stands"))),
    Stage("p5_crossings", "P5 Road crossings", "plan", ("gate0", "p1_feeder", "p2_1to16", "p3_distribution", "p4_drops"),
          "adapters/p5_crossings.py", "checks/p5_crossings.py",
          (LayerSpec("road_crossings", "LineString", (("type", "str"), ("length_m", "real"))),), ("cross_span_m", "span_cap_m"),
          ignores=(("p2_1to16", "splitters_1to16", "crossings come from the cable spans"),
                   ("p4_drops", "drops", "drops make no cable crossings; P4's Check warns on a road-crossing drop"),
                   ("p4_drops", "drop_review", "review markers for the operator, not plan input"))),
    Stage("p6_poles", "P6 Pole reconciliation", "plan",
          ("p1_feeder", "p2_1to16", "p3_distribution", "wayleave", "p4_drops", "p5_crossings"), "adapters/p6_poles.py",
          "checks/p6_poles.py",
          (LayerSpec("poles", "Point", (("role", "str"), ("cable", "str"), ("height_m", "real"))),),
          ("span_cap_m", "pole_midblock_m", "pole_crossing_m", "pole_feeder_m"),
          ignores=(("p4_drops", "drops", "poles stand at collection points and on the cable, not on drops"),
                   ("p4_drops", "drop_review", "review markers for the operator, not plan input"))),
    Stage("p7_hardware", "P7 Splitters and dome joints", "plan", ("p1_feeder", "p2_1to16", "p3_distribution", "p4_drops", "p6_poles"),
          "adapters/p7_hardware.py", "checks/p7_hardware.py",
          (LayerSpec("splitters_8way", "Point", (("cp_id", "str"),)), LayerSpec("dome_joints", "Point", (("cp_id", "str"),))),
          ("feeder_split", "dist_split"),
          ignores=(("p2_1to16", "splitters_1to16", "8-way splitters and domes belong to collection points"),
                   ("p4_drops", "drops", "hardware is per collection point"),
                   ("p4_drops", "drop_review", "review markers for the operator, not plan input"))),
    Stage("p8_delivery", "P8 Delivery", "plan",
          ("p1_feeder", "p2_1to16", "p3_distribution", "p4_drops", "p5_crossings", "p6_poles", "p7_hardware"),
          "adapters/p8_delivery.py", "checks/common.py", (), launcher="pyqgis"),
)

_BY_ID = {s.id: s for s in REGISTRY}


def get(stage_id: str) -> Stage:
    return _BY_ID[stage_id]


def order() -> list[str]:
    return [s.id for s in REGISTRY]


def downstream_of(stage_id: str) -> list[str]:
    out, hit = [], {stage_id}
    for s in REGISTRY:
        if s.id != stage_id and (set(s.deps) & hit):
            hit.add(s.id)
            out.append(s.id)
    return out
