"""A fingerprint of the feature an issue points at (0.8.1, operator walk 2026-10-15). Stamped on every issue at Check
time, in the dock process, so that a re-check can say an issue is "still found after your edit" and a warning the
operator removed stays removed only while its feature is unchanged."""
from __future__ import annotations
import hashlib
from pathlib import Path
from osgeo import ogr


def _hash(ds, layer: str, fid) -> str:
    lyr = ds.GetLayerByName(layer) if ds is not None and layer else None
    f = lyr.GetFeature(int(fid)) if lyr is not None and fid is not None and int(fid) >= 0 else None
    g = f.GetGeometryRef() if f is not None else None
    if g is None:
        return ""
    g = g.Clone(); g.FlattenTo2D()
    return hashlib.sha1(bytes(g.ExportToIsoWkb())).hexdigest()


def fingerprint(path, layer: str, fid) -> str:
    if not path or not Path(path).exists() or fid is None or int(fid) < 0:
        return ""
    return _hash(ogr.Open(str(path)), layer, fid)


def issue_source_path(store, rev: Path, issue) -> Path | None:
    p = Path(rev) / "working.gpkg" if issue.source == "working" else store.approved_gpkg(issue.source)
    return Path(p) if p is not None and Path(p).exists() else None


def stamp(report, rev: Path, store, previous=None) -> None:
    """Set geom_hash on every located issue (one open per source file), and after_edit where the previous report
    had the same issue on the same feature with a different, known geometry."""
    open_ds: dict = {}
    for i in report.issues:
        if not i.layer or i.fid is None or i.fid < 0:
            continue
        p = issue_source_path(store, rev, i)
        if p is None:
            continue
        if p not in open_ds:
            open_ds[p] = ogr.Open(str(p))
        i.geom_hash = _hash(open_ds[p], i.layer, i.fid)
    before = {(i.code, i.layer, i.fid, i.source): i.geom_hash for i in (previous.issues if previous else [])}
    for i in report.issues:
        old = before.get((i.code, i.layer, i.fid, i.source), "")
        i.after_edit = bool(old and i.geom_hash and old != i.geom_hash)
