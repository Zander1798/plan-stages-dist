from __future__ import annotations
import json
from dataclasses import dataclass, asdict, fields
from pathlib import Path

MAX_ISSUES = 5000      # per check report; the rest are counted in ChecksReport.dropped


@dataclass
class CheckResult:
    code: str
    required: bool
    status: str      # passed | failed | skipped
    message: str = ""


@dataclass
class Issue:
    x: float
    y: float
    epsg: int
    code: str
    severity: str    # error | warn
    message: str = ""
    layer: str = ""          # layer the offending feature lives in ("" = none, zoom to the point only)
    fid: int = -1            # its FID in that layer (-1 = unknown: find the feature nearest x, y)
    source: str = "working"  # "working" = this stage's working.gpkg; else the dependency stage id whose approved layer it is
    match: str = ""          # "field=value" naming the feature by attribute (a PON by pon_num); tried before x, y
    geom_hash: str = ""      # sha1 of the feature's geometry when checked (0.8.1): removals and "still found after your edit"
    after_edit: bool = False # this feature's geometry changed since the previous Check and the issue is still found
    why: str = ""            # plain words on why the step did not make it (2026-10-19), shown when the issue is clicked


@dataclass
class ChecksReport:
    checks: list[CheckResult]
    issues: list[Issue]
    dropped: int = 0         # issues not listed because the check hit its cap

    def blocking(self) -> list[CheckResult]:
        return [c for c in self.checks if c.required and c.status in ("failed", "skipped")]

    def ok(self) -> bool:
        return not self.blocking()

    def save(self, path: Path) -> None:
        Path(path).write_text(json.dumps(
            {"checks": [asdict(c) for c in self.checks], "issues": [asdict(i) for i in self.issues],
             "dropped": self.dropped}, indent=2),
            encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "ChecksReport":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls([_known(CheckResult, c) for c in d["checks"]], [_known(Issue, i) for i in d["issues"]],
                   int(d.get("dropped", 0)))


def _known(kind, d: dict):
    """Build `kind` from the keys it knows. A checks.json written by newer plugin code (a check runs as a fresh
    subprocess, the dock is whatever QGIS loaded at start) may carry fields this version lacks; 2026-10-12 an extra
    `match` made the open dock refuse the whole report."""
    names = {f.name for f in fields(kind)}
    return kind(**{k: v for k, v in d.items() if k in names})
