"""The update pop-up's decisions (operator, 2026-10-26): is a newer Plan Stages published, and what is new in it.
No QGIS here; qgis/update_dialog.py fetches the list and shows the pop-up each time the panel opens.

The published list is the plugins.xml every user's QGIS already reads (release doc section 1); since 0.15.0 the
build also writes the metadata changelog into it, so the pop-up can say what changed."""
from __future__ import annotations
import os, re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

REPO_XML = "https://raw.githubusercontent.com/Zander1798/plan-stages-dist/main/plugins.xml"
NAME = "Plan Stages"


@dataclass
class Update:
    version: str
    download_url: str
    changes: list = field(default_factory=list)      # [(version, notes)], newest first, all newer than installed


def _key(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or ""))


def newer(a: str, b: str) -> bool:
    """True when version a is newer than version b (0.10.0 is newer than 0.9.0)."""
    return _key(a) > _key(b)


_ENTRY = re.compile(r"(?:^|;\s*)(\d+\.\d+\.\d+)\s+")


def split_changelog(text: str) -> list:
    """The metadata changelog ("0.14.0 notes; 0.13.0 notes; ...") as [(version, notes)]. An entry starts at a
    version number at the very start or after "; ", so the semicolons inside an entry's own notes stay in it."""
    text = (text or "").strip()
    marks = list(_ENTRY.finditer(text))
    out = []
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        out.append((m.group(1), text[m.end():end].strip().rstrip(";").strip()))
    return out


def available_update(xml_text: str, installed: str) -> Update | None:
    """The newer Plan Stages in the published list, or None (up to date, or the list is missing or unreadable)."""
    try:
        root = ET.fromstring(xml_text or "")
    except ET.ParseError:
        return None
    for p in root.iter("pyqgis_plugin"):
        if p.get("name") != NAME:
            continue
        v = (p.findtext("version") or p.get("version") or "").strip()
        url = (p.findtext("download_url") or "").strip()
        if not v or not url or not newer(v, installed):
            return None
        changes = [(cv, n) for cv, n in split_changelog(p.findtext("changelog") or "") if newer(cv, installed)]
        return Update(v, url, changes)
    return None


def is_dev_install(plugin_dir) -> bool:
    """True on the development PC, where the plugin folder is a junction (or link) into the source: QGIS's installer
    would delete the source through it (release doc section 3), so no update is offered there."""
    p = os.path.abspath(str(plugin_dir))
    return os.path.normcase(os.path.realpath(p)) != os.path.normcase(os.path.normpath(p))


def installed_version(plugin_dir) -> str:
    import configparser
    cp = configparser.ConfigParser()
    cp.read(Path(plugin_dir) / "metadata.txt", encoding="utf-8")
    return cp.get("general", "version", fallback="0")
