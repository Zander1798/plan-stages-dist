"""Issues the operator removed (0.8.1, operator walk 2026-10-15): "the human operator can then decide whether
something is a true error or not". Kept per revision in dismissed.json; a removal holds only while the feature's
geometry is unchanged (ruling: until the feature changes) and Approve records them. 2026-10-16 rulings: errors can
be removed too, and a removal survives a new generation while the regenerated feature has the same geometry, so it
is matched by geometry, not by fid (a regenerated feature may get another fid). Each entry says `how`: "removed" (the
Remove issue button) or "fixed" (the operator edited the feature and the Check still finds it: "the human operators
fixes should remain crossed out", 2026-10-16). 2026-10-19 review: an entry names one
issue, by where the check put it, not every issue on that feature (span_cap puts a gap per pole pair on one line);
entries written before that match by their message."""
from __future__ import annotations
import json, time
from pathlib import Path

NAME = "dismissed.json"


def _loc(x, y, epsg=None) -> tuple:
    """About 0.1 m either way: 6 decimals in degrees, 1 in metres. 2026-10-20 review: plan layers are EPSG:4326, and
    0.1 of a degree (11 km) made every gap on a line one removal. An entry with no epsg (written before) is in
    degrees when its y could be a latitude."""
    deg = epsg == 4326 if epsg else abs(float(y)) <= 90          # 0: a layer with no CRS
    nd = 6 if deg else 1
    return (round(float(x), nd), round(float(y), nd))


def key(issue) -> tuple:
    return (issue.code, issue.layer, issue.source, issue.geom_hash, _loc(issue.x, issue.y, issue.epsg))


def _ekey(e: dict) -> tuple:
    return (e["code"], e["layer"], e["source"], e["geom_hash"],
            _loc(e["x"], e["y"], e.get("epsg")) if "x" in e else None)


def _names(e: dict, issue) -> bool:
    k = _ekey(e)
    if k[4] is None:                                     # written before locations were kept
        return k[:4] == key(issue)[:4] and e.get("message") == issue.message
    return k == key(issue)


def load(rev: Path) -> list[dict]:
    p = Path(rev) / NAME
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
    except (OSError, ValueError):
        return []


def _save(rev: Path, entries: list[dict]) -> None:
    (Path(rev) / NAME).write_text(json.dumps(entries, indent=2), encoding="utf-8")


def add(rev: Path, issue, how: str = "removed") -> None:
    if not issue.layer or issue.fid is None or issue.fid < 0 or not issue.geom_hash:
        raise ValueError("only an issue located on a feature can be removed")
    entries = [e for e in load(rev) if not _names(e, issue)]
    entries.append({"code": issue.code, "layer": issue.layer, "fid": int(issue.fid), "source": issue.source,
                    "x": float(issue.x), "y": float(issue.y), "epsg": int(issue.epsg), "message": issue.message, "geom_hash": issue.geom_hash, "how": how,
                    "when": time.strftime("%Y-%m-%dT%H:%M:%S")})
    _save(rev, entries)


def restore(rev: Path, issue) -> None:
    entries = load(rev)
    keep = [e for e in entries if not _names(e, issue)]
    if len(keep) != len(entries):
        _save(rev, keep)


def _matches(entries: list[dict], issue) -> dict | None:
    if not issue.geom_hash or issue.fid is None or issue.fid < 0:
        return None
    return next((e for e in entries if _names(e, issue)), None)


def split(report, rev: Path) -> tuple[list, list]:
    """(shown, removed): an issue is removed while a removal names it AND its feature's geometry is unchanged."""
    entries = load(rev); shown, removed = [], []
    for i in report.issues:
        (removed if _matches(entries, i) else shown).append(i)
    return shown, removed


def split_how(report, rev: Path) -> tuple[list, list, list]:
    """(shown, removed by the button, fixed by an edit): split() with the removals sorted by how they were made."""
    entries = load(rev); shown, removed, fixed = [], [], []
    for i in report.issues:
        e = _matches(entries, i)
        (shown if e is None else fixed if e.get("how") == "fixed" else removed).append(i)
    return shown, removed, fixed


def active(report, rev: Path) -> list[dict]:
    """The removals that still hold against `report` (what Approve records)."""
    entries, out = load(rev), []
    for e in (_matches(entries, i) for i in report.issues):
        if e is not None and e not in out:
            out.append(e)
    return out


def cleared_checks(report, rev: Path) -> set[str]:
    """Failed checks the operator has cleared: every issue of the check is removed and none were dropped by the
    cap. Approve does not count them as failed (2026-10-16: an error the operator removed is not an error)."""
    if report.dropped:
        return set()
    shown, removed = split(report, rev)
    left = {_check_of(i) for i in shown}
    return {_check_of(i) for i in removed} - left


def _check_of(issue) -> str:
    """The check an issue belongs to: checks/common.py codes invalid geometry geom_valid, its check geom_valid:<layer>."""
    return f"geom_valid:{issue.layer}" if issue.code == "geom_valid" else issue.code


def carry(src_rev: Path, dst_rev: Path) -> None:
    """A new revision of the same stage starts with the previous one's removals (Revise and Generate)."""
    src = Path(src_rev) / NAME
    if src.exists():
        (Path(dst_rev) / NAME).write_bytes(src.read_bytes())
