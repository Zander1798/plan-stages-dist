from __future__ import annotations
import os
from pathlib import Path
from ..config import PluginConfig, default_config_path
from .store import SiteStore
from .stages import Stage, get
from . import launchers

PLUGIN_DIR = Path(__file__).resolve().parents[1]
ML_DIR = PLUGIN_DIR / "ml"            # the bundled step scripts (synced from scripts/ml by scripts/sync_plan_stages_ml.py)

# Pipeline overrides the scripts honour ahead of the spec sheet or the approved layers. A value inherited from
# the QGIS process environment would silently override the operator's confirmed spec, so none is passed on.
SCRUB = ("DROP_CAP_M", "FAN_CAP", "PON_CAP", "SPAN_CAP_M", "OUTTAG", "HONOUR_HAND_EDITS", "BUILDINGS", "PLAN_DIR",
         "SITE_DIR", "SPEC_SHEET", "CABLE", "DPSRC", "CANDSRC", "STAGE", "PS_CROSSINGS_GPKG", "ONCABLE_M", "GAP_M")


def build_env(config: PluginConfig, store: SiteStore, stage_id: str, rev_dir: Path, spec_path: Path) -> dict[str, str]:
    st = store.load()
    e = {k: v for k, v in os.environ.items()
         if k.upper() not in SCRUB and not k.upper().startswith(("LAYER_", "PS_DEP_"))}
    e.update({
        "PS_SITE": st["site"], "PS_EPSG": str(st["epsg"]), "PS_CLIENT": st["client"], "PS_STAGE": stage_id,
        "PS_REV_DIR": str(rev_dir), "PLAN_DIR": str(rev_dir),
        "PS_QGIS_ROOT": config.qgis_root, "PS_WAYLEAVE_ROOT": config.wayleave_root, "PYTHONUNBUFFERED": "1",
        "SITE": st["site"], "SITE_EPSG": str(st["epsg"]), "CLIENT": st["client"].lower(),
    })
    if spec_path and Path(spec_path).is_file():
        e["SPEC_SHEET"] = str(spec_path)
    else:
        e.pop("SPEC_SHEET", None)
    for d in get(stage_id).deps:
        ap = store.approved_gpkg(d)
        if ap is not None:
            e["PS_DEP_" + d.upper()] = str(ap)
    pp = [str(PLUGIN_DIR.parent), str(ML_DIR)] + [r for r in (config.qgis_root, config.wayleave_root) if r]
    inherited = [p for p in e.get("PYTHONPATH", "").split(os.pathsep) if p]      # QGIS 3's may end in a separator
    e["PYTHONPATH"] = os.pathsep.join(pp + inherited)
    e["PS_PYTHONPATH"] = e["PYTHONPATH"]
    return e


def command_for(config: PluginConfig, stage: Stage, script_rel: str, prefix_path: str | None = None,
                executable: str | None = None) -> list[str]:
    """The launcher plus script: the config override for this stage's launcher kind when set, else the launcher
    written from the discovered QGIS next to the plugin config (launchers.NoQgisFound when there is none)."""
    launcher = config.pyqgis_python if stage.launcher == "pyqgis" else config.gdal_python
    if not launcher:
        launcher = str(launchers.auto_launcher(default_config_path().parent, prefix_path, executable))
    return [launcher, str(PLUGIN_DIR / script_rel)]
