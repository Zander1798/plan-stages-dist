"""Small repairs the plugin makes to an operator-edited layer before checking it (2026-10-14): a collection point
drawn by hand has no cp_id, and P6 (p7_hardware) hangs hardware by cp_id, so P4's Check gives it the next free one."""
from __future__ import annotations
from pathlib import Path
from osgeo import ogr


def _as_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def next_ids(rows: list[tuple[int, object]]) -> list[tuple[int, int]]:
    """(fid, new cp_id) for every row whose cp_id is None, in fid order, after the largest whole-number cp_id."""
    top = max((n for n in (_as_int(v) for _f, v in rows) if n is not None), default=0)
    out = []
    for fid, v in sorted(rows, key=lambda r: r[0]):
        if v is None:
            top += 1; out.append((fid, top))
    return out


def assign_missing_cp_ids(gpkg: Path, layer: str = "collection_points") -> list[str]:
    ds = ogr.Open(str(gpkg), 1)
    lyr = ds.GetLayerByName(layer) if ds is not None else None
    if lyr is None or lyr.GetLayerDefn().GetFieldIndex("cp_id") < 0:
        return []
    todo = next_ids([(f.GetFID(), f.GetField("cp_id")) for f in lyr])
    for fid, n in todo:
        f = lyr.GetFeature(fid); f.SetField("cp_id", n); lyr.SetFeature(f)
    ds = None
    return [f"cp_id {n} given to collection point fid {fid}" for fid, n in todo]
