"""Optional dependencies. Only the Spec tab's PDF proposal needs them: `anthropic` to ask Claude, `pypdf` (ships
with QGIS 4.2) to check Claude's quotes against the PDF. Without them the tab degrades to typing values by hand
(or to "could not check"), and offers to install what is missing into QGIS's Python."""
from __future__ import annotations


def have_anthropic() -> bool:
    try:
        import anthropic  # noqa: F401
        return True
    except ImportError:
        return False


def have_pypdf() -> bool:
    try:
        import pypdf  # noqa: F401
        return True
    except ImportError:
        return False


def missing_packages() -> list[str]:
    return [n for n, ok in (("anthropic", have_anthropic()), ("pypdf", have_pypdf())) if not ok]


def pip_install_cmd(launcher: str, *packages: str) -> list[str]:
    """pip inside QGIS's own Python, through the same launcher the step scripts use."""
    return [launcher, "-m", "pip", "install", "--upgrade", *(packages or ("anthropic",))]
