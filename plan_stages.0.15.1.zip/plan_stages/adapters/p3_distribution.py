"""P3 Distribution adapter: step3_span_split P1_PART=distribution on the APPROVED P2 1:16s -> distribution.

The span per PON as before, plus one straight link (link=1) from each approved 1:16 standing off its PON's span."""
import os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect, approved, need_layer


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    spl = approved("p2_1to16")
    print(f"approved P2 1:16s: {need_layer(spl, 'splitters_1to16')}")
    rc = run_step("step3_span_split.py", {"P1_PART": "distribution", "SPLITTERS_GPKG": str(spl),
                                          "SPLITTERS_LAYER": "splitters_1to16"})
    if rc:
        return rc
    collect({"distribution": (rev / "step3" / "claude_distribution_cable.gpkg", "claude_distribution_cable")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
