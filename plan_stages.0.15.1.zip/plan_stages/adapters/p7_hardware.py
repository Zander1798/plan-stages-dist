"""P7 adapter (shown as P6 since 0.13.0): step567 STAGE=hardware on approved P1-P4 -> 8-way splitters, domes,
hung on the approved wayleave poles."""
import os, sys
from pathlib import Path
import math
import numpy as np
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.adapters._plan_common import (site_dir, run_step, collect, materialise_step3, materialise_drops,
                                               approved, transform, layer_epsg)


def remap_cp_ids(gen_gpkg: Path, drops_gpkg: Path, epsg: int, tol: float = 0.5) -> int:
    """step567 numbers hardware by list position; give each point the real cp_id of the approved collection
    point within `tol` m (site metres). Returns the number of points left with their position id."""
    pds = ogr.Open(str(drops_gpkg)); cps = pds.GetLayerByName("collection_points")
    t = transform(layer_epsg(cps, 4326), epsg)
    ids, xy = [], []
    for f in cps:
        g = f.GetGeometryRef(); ids.append(f.GetField("cp_id")); xy.append(t.TransformPoint(g.GetX(), g.GetY())[:2])
    tree = cKDTree(np.array(xy)) if xy else None
    gds = ogr.Open(str(gen_gpkg), 1); unmatched = 0
    for name in ("splitters_8way", "dome_joints"):
        lyr = gds.GetLayerByName(name); tg = transform(layer_epsg(lyr, 4326), epsg); used = set()
        for f in lyr:
            g = f.GetGeometryRef(); p = tg.TransformPoint(g.GetX(), g.GetY())[:2]
            near = tree.query_ball_point(p, tol) if tree is not None else []
            pos = f.GetField("cp_id")       # step567's list position
            keep = [j for j in near if ids[j] == pos and j not in used]   # co-located CPs: prefer its own id
            pick = keep[0] if keep else next((j for j in sorted(near, key=lambda j: math.dist(p, xy[j])) if j not in used), None)
            if pick is None:
                unmatched += 1
            else:
                used.add(pick); f.SetField("cp_id", ids[pick]); lyr.SetFeature(f)
    gds = None
    print(f"remapped hardware cp_id to approved collection points; {unmatched} without a collection point within {tol} m (kept position id)")
    return unmatched


HANG_M = 2.0       # 2026-10-14: hardware goes on the approved pole this close to its collection point


def hang_on_poles(gen_gpkg: Path, drops_gpkg: Path, poles_gpkg: Path, epsg: int, tol: float = HANG_M) -> tuple[int, int]:
    """Move each 8-way splitter and dome joint onto the approved wayleave pole nearest its collection point (by cp_id;
    its own position when the cp_id matches none), if one stands within `tol` m. Returns (moved, left)."""
    pds = ogr.Open(str(poles_gpkg)); pl = pds.GetLayerByName("poles")
    cds = ogr.Open(str(drops_gpkg)); cps = cds.GetLayerByName("collection_points")
    gds = ogr.Open(str(gen_gpkg), 1)
    lyrs = [gds.GetLayerByName(n) for n in ("splitters_8way", "dome_joints")]
    total = sum(l.GetFeatureCount() for l in lyrs if l is not None)
    if pl is None or pl.GetFeatureCount() == 0:
        gds = pds = cds = None
        return 0, total
    tp = transform(layer_epsg(pl, 4326), epsg)
    pxy = np.array([tp.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2] for f in pl
                    if f.GetGeometryRef() is not None])
    tree = cKDTree(pxy)
    cp_at = {}
    if cps is not None:
        tc = transform(layer_epsg(cps, 4326), epsg)
        for f in cps:
            g = f.GetGeometryRef()
            if g is not None:
                cp_at[f.GetField("cp_id")] = tc.TransformPoint(g.GetX(), g.GetY())[:2]
    moved = left = 0
    for lyr in lyrs:
        if lyr is None:
            continue
        le = layer_epsg(lyr, 4326); to_site = transform(le, epsg); back = transform(epsg, le)
        for f in lyr:
            g = f.GetGeometryRef()
            here = to_site.TransformPoint(g.GetX(), g.GetY())[:2]
            d, j = tree.query(cp_at.get(f.GetField("cp_id"), here))
            if d > tol:
                left += 1
                continue
            x, y = back.TransformPoint(float(pxy[j][0]), float(pxy[j][1]))[:2]
            pt = ogr.Geometry(ogr.wkbPoint); pt.AddPoint_2D(x, y); f.SetGeometry(pt); lyr.SetFeature(f); moved += 1
    gds = pds = cds = None
    return moved, left


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    materialise_step3(rev); materialise_drops(rev)
    rc = run_step("step567.py", {"STAGE": "hardware"})
    if rc:
        return rc
    g = rev / "step567" / "claude_step567_hardware.gpkg"
    collect({"splitters_8way": (g, "claude_8way_splitters"), "dome_joints": (g, "claude_dome_joints")})
    remap_cp_ids(rev / "generated.gpkg", approved("p4_drops"), int(os.environ["PS_EPSG"]))
    moved, left = hang_on_poles(rev / "generated.gpkg", approved("p4_drops"), approved("wayleave"), int(os.environ["PS_EPSG"]))
    print(f"hardware on the wayleave poles: {moved} moved, {left} with no pole within {HANG_M} m of their collection point")
    return 0


if __name__ == "__main__":
    sys.exit(main())
