"""P1 Feeder adapter: step3_span_split P1_PART=feeder -> feeder (and <rev>/step3/p1_targets.json for P2)."""
import os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect


def main():
    site_dir()
    rc = run_step("step3_span_split.py", {"P1_PART": "feeder"})
    if rc:
        return rc
    s3 = Path(os.environ["PS_REV_DIR"]) / "step3"
    collect({"feeder": (s3 / "claude_feeder_cable.gpkg", "claude_feeder_cable")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
