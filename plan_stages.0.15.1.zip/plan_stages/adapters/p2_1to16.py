"""P2 1:16 splitters adapter: step3_span_split P1_PART=splitters on the APPROVED P1 feeder -> splitters_1to16.

One 1:16 per PON on the approved feeder: on the span point P1 aimed at (p1_targets.json) where it still lies on the
feeder, else on the feeder point nearest the PON's span (place_1to16.place)."""
import json, os, sys
from pathlib import Path
from plan_stages.adapters._plan_common import site_dir, run_step, collect, approved, need_layer, p1_targets


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"])
    feeder = approved("p1_feeder")
    print(f"approved P1 feeder: {need_layer(feeder, 'feeder')} lines")
    targets = p1_targets(feeder)
    if not targets.is_file():
        # an approved P1 made by hand has no targets: every 1:16 goes on the feeder point nearest its PON's span
        print(f"no P1 targets at {targets}: every 1:16 goes on the feeder point nearest its PON's span")
        targets = rev / "p1_targets_none.json"
        targets.write_text(json.dumps({}), encoding="utf-8")
    rc = run_step("step3_span_split.py", {"P1_PART": "splitters", "FEEDER_GPKG": str(feeder), "FEEDER_LAYER": "feeder",
                                          "TARGETS_JSON": str(targets)})
    if rc:
        return rc
    s3 = rev / "step3"
    collect({"splitters_1to16": (s3 / "claude_1to16_splitters.gpkg", "claude_1to16_splitters")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
