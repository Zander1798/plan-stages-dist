"""Small dialog and styling helpers shared by the dock tabs."""
from __future__ import annotations
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QComboBox, QInputDialog, QLineEdit, QMessageBox

_BADGE = {"pending": "#9e9e9e", "generating": "#5c6bc0", "generated": "#1976d2", "checked": "#00897b", "approved": "#2e7d32",
          "stale": "#f9a825", "rejected": "#c62828", "failed": "#c62828"}


def badge_style(status: str) -> str:
    return f"QLabel {{ background: {_BADGE.get(status, '#757575')}; color: white; border-radius: 3px; padding: 1px 6px; }}"


def warn(parent, title: str, text: str) -> None:
    QMessageBox.warning(parent, title, text)


def info(parent, title: str, text: str) -> None:
    QMessageBox.information(parent, title, text)


def ask_yes_no(parent, title: str, text: str) -> bool:
    btn = QMessageBox.question(parent, title, text, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                               QMessageBox.StandardButton.No)
    return btn == QMessageBox.StandardButton.Yes


def ask_note(parent, title: str, label: str) -> str | None:
    text, ok = QInputDialog.getText(parent, title, label, QLineEdit.EchoMode.Normal, "")
    return text if ok else None


def tail(text: str, lines: int = 25) -> str:
    return "\n".join((text or "").splitlines()[-lines:]) or "(no output)"


class WheelSafeCombo(QComboBox):
    """A combo in the dock's scroll area (2026-10-19 review; the Wayleave box's LayerCombo does the same): unfocused,
    the wheel is ignored so the dock scrolls instead of the pick changing; a click or Tab gives it focus."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def wheelEvent(self, event):
        if not self.hasFocus():
            event.ignore()
            return
        super().wheelEvent(event)
