"""One page of a client spec PDF, shown inside QGIS with the quoted sentence highlighted (2026-10-13). Uses Qt's PDF
module, which ships with QGIS 4; where it is missing, the Spec tab opens the PDF in the system viewer instead."""
from __future__ import annotations
from pathlib import Path
from qgis.PyQt.QtCore import QPointF, QBuffer, QByteArray, QIODevice, QTimer, QModelIndex
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel

try:
    from PyQt6.QtPdf import QPdfDocument, QPdfSearchModel
    from PyQt6.QtPdfWidgets import QPdfView
    HAVE_QTPDF = True
except ImportError:
    HAVE_QTPDF = False


class PdfPageDialog(QDialog):
    def __init__(self, pdf: Path, page: int, quote: str, parent=None):
        super().__init__(parent)
        self.page = page
        self.setWindowTitle(f"{Path(pdf).name}, page {page}")
        self.resize(820, 1000)
        lay = QVBoxLayout(self)
        cap = QLabel(f"“{quote}”" if quote else ""); cap.setWordWrap(True); lay.addWidget(cap)
        # loaded from memory: QPdfDocument.load(path) keeps the file locked on Windows even after close()
        self._buf = QBuffer(self)
        self._buf.setData(QByteArray(Path(pdf).read_bytes()))
        self._buf.open(QIODevice.OpenModeFlag.ReadOnly)
        self.doc = QPdfDocument(self)
        self.doc.load(self._buf)
        self.view = QPdfView(self)
        self.view.setDocument(self.doc)
        self.view.setPageMode(QPdfView.PageMode.MultiPage)
        self.view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        # highlight the sentence: search for its opening words (a whole sentence can break across lines)
        self.search = QPdfSearchModel(self)
        self.search.setDocument(self.doc)
        self.search.setSearchString(" ".join(quote.split()[:6]))
        self.view.setSearchModel(self.search)
        lay.addWidget(self.view, 1)

    def showEvent(self, event):
        super().showEvent(event)
        # the view lays the document out only once shown; jump after that
        QTimer.singleShot(150, self.go_to_quote)

    def go_to_quote(self):
        """Scroll to the highlighted sentence on the cited page, else to the first hit, else to the page."""
        hits = [self.search.resultAtIndex(i) for i in range(self.search.rowCount(QModelIndex()))]
        on_page = [i for i, h in enumerate(hits) if h.page() == self.page - 1]
        if on_page or hits:
            self.view.setCurrentSearchResultIndex((on_page or [0])[0])
        elif 1 <= self.page <= self.doc.pageCount():
            self.view.pageNavigator().jump(self.page - 1, QPointF(0, 0), 0)
