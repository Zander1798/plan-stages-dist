"""The operator's own details (2026-10-14): adding or editing one on the Spec tab, and ticking each one as checked
against the plan before a stage is approved."""
from __future__ import annotations
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QCheckBox, QComboBox, QPlainTextEdit,
                                 QDialogButtonBox, QGroupBox)
from ..core import stages
from ..core.specsheet import detail_stage_ids
from ..core.spec_claude import TOPICS


def _buttons(dlg: QDialog) -> QDialogButtonBox:
    b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
    b.accepted.connect(dlg.accept); b.rejected.connect(dlg.reject)
    return b


class DetailDialog(QDialog):
    """Affects (the Plan tab's stages), topic, detail. OK needs at least one stage and some text."""

    def __init__(self, parent=None, detail: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Edit detail" if detail else "Add a detail")
        lay = QVBoxLayout(self)
        box = QGroupBox("Affects: tick every stage this detail must be checked against before it is approved")
        bl = QVBoxLayout(box)
        self.stage_boxes: dict[str, QCheckBox] = {}
        for sid in detail_stage_ids():
            cb = QCheckBox(stages.get(sid).name); cb.setChecked(bool(detail) and sid in detail.get("stages", ()))
            cb.toggled.connect(self._update_ok); bl.addWidget(cb); self.stage_boxes[sid] = cb
        lay.addWidget(box)
        lay.addWidget(QLabel("Topic"))
        self.topic = QComboBox(); self.topic.addItems(list(TOPICS))
        self.topic.setCurrentText(detail.get("topic", "other") if detail else "other")
        lay.addWidget(self.topic)
        lay.addWidget(QLabel("Detail"))
        self.text = QPlainTextEdit(detail.get("detail", "") if detail else "")
        self.text.textChanged.connect(self._update_ok); lay.addWidget(self.text)
        self.buttons = _buttons(self); lay.addWidget(self.buttons)
        self._update_ok()

    @property
    def ok_btn(self):
        return self.buttons.button(QDialogButtonBox.StandardButton.Ok)

    def values(self) -> tuple[list[str], str, str]:
        return ([s for s, cb in self.stage_boxes.items() if cb.isChecked()], self.topic.currentText(),
                self.text.toPlainText().strip())

    def _update_ok(self):
        ids, _topic, text = self.values()
        self.ok_btn.setEnabled(bool(ids) and bool(text))


class DetailsCheckDialog(QDialog):
    """One tick per operator detail of the stage; OK only when every one is ticked."""

    def __init__(self, parent, stage_name: str, details: list[dict]):
        super().__init__(parent)
        self.setWindowTitle(f"Approve {stage_name}: your details")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"Before approving {stage_name}, check each of your details against this plan:"))
        self.boxes: list[QCheckBox] = []
        self.labels: list[QLabel] = []
        for x in details:
            # the detail in its own plain, wrapped label: a checkbox would not wrap, and would turn "&" into a shortcut
            row = QHBoxLayout()
            cb = QCheckBox("Checked against this plan:"); cb.setProperty("detail_id", x["id"])
            cb.toggled.connect(self._update_ok); self.boxes.append(cb)
            label = QLabel(x["detail"]); label.setTextFormat(Qt.TextFormat.PlainText); label.setWordWrap(True)
            self.labels.append(label)
            row.addWidget(cb, 0, Qt.AlignmentFlag.AlignTop); row.addWidget(label, 1)
            lay.addLayout(row)
        self.buttons = _buttons(self); lay.addWidget(self.buttons)
        self._update_ok()

    @property
    def ok_btn(self):
        return self.buttons.button(QDialogButtonBox.StandardButton.Ok)

    def checked_ids(self) -> list[str]:
        return [cb.property("detail_id") for cb in self.boxes if cb.isChecked()]

    def _update_ok(self):
        self.ok_btn.setEnabled(all(cb.isChecked() for cb in self.boxes))


def ask_detail(parent, detail: dict | None = None):
    """(stage ids, topic, text) from the add/edit dialog, or None when cancelled."""
    dlg = DetailDialog(parent, detail)
    try:
        return dlg.values() if dlg.exec() else None
    finally:
        dlg.deleteLater()


def confirm_details(parent, stage_name: str, details: list[dict]):
    """The ids ticked (all of them) or None when cancelled."""
    dlg = DetailsCheckDialog(parent, stage_name, details)
    try:
        return dlg.checked_ids() if dlg.exec() else None
    finally:
        dlg.deleteLater()
