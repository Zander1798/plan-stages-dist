"""The update pop-up (operator, 2026-10-26): each time the Plan Stages panel is opened, a newer published version is
announced with what is new in it, an Update button and a Skip for now button. Skip brings it back the next time the
panel opens, until they update. Nothing shows when offline, up to date, or on the development PC (core/updates)."""
from __future__ import annotations
import html, os, tempfile
from pathlib import Path
from qgis.PyQt.QtCore import QTimer, QUrl
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox, QLabel, QMessageBox, QPushButton, QTextBrowser, QVBoxLayout
from ..core import updates

# Not resolved: on the development PC this is the junction, which is how is_dev_install recognises it.
PLUGIN_DIR = Path(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir)))


class UpdateDialog(QDialog):
    def __init__(self, parent, update: updates.Update, installed: str):
        super().__init__(parent)
        self.setWindowTitle("Plan Stages update")
        lay = QVBoxLayout(self)
        self.title = QLabel(f"<b>A new version of Plan Stages is available: {html.escape(update.version)}</b>"
                            f"<br>You have {html.escape(installed)}.")
        lay.addWidget(self.title)
        lay.addWidget(QLabel("What's new:"))
        self.notes = QTextBrowser()
        self.notes.setHtml("".join(f"<h4>{html.escape(v)}</h4><p>{html.escape(n)}</p>" for v, n in update.changes)
                           or "<p>See the plugin's changelog after updating.</p>")
        lay.addWidget(self.notes, 1)
        self.update_btn = QPushButton("Update"); self.update_btn.setDefault(True)
        self.skip_btn = QPushButton("Skip for now")
        box = QDialogButtonBox()
        box.addButton(self.update_btn, QDialogButtonBox.ButtonRole.AcceptRole)
        box.addButton(self.skip_btn, QDialogButtonBox.ButtonRole.RejectRole)
        box.accepted.connect(self.accept); box.rejected.connect(self.reject)
        lay.addWidget(box)
        self.resize(560, 420)


class UpdateChecker:
    """check() each time the panel opens. `fetch` (tests): a function returning the published list's text, used
    instead of the network."""

    def __init__(self, iface, dock_getter, plugin_dir=PLUGIN_DIR, fetch=None):
        self.iface, self.dock_getter, self.plugin_dir, self.fetch = iface, dock_getter, Path(plugin_dir), fetch
        self._reply = None
        self.dialog = None

    def check(self):
        if self.dialog is not None or self._reply is not None or updates.is_dev_install(self.plugin_dir):
            return
        installed = updates.installed_version(self.plugin_dir)
        if self.fetch is not None:
            self._offer(self.fetch(), installed)
            return
        from qgis.core import QgsNetworkAccessManager
        req = QNetworkRequest(QUrl(updates.REPO_XML))
        req.setAttribute(QNetworkRequest.Attribute.CacheLoadControlAttribute,
                         QNetworkRequest.CacheLoadControl.AlwaysNetwork)
        self._reply = reply = QgsNetworkAccessManager.instance().get(req)
        reply.finished.connect(lambda: self._fetched(reply, installed))

    def _fetched(self, reply, installed):
        # An exception escaping a PyQt slot aborts QGIS, and an update check must never get in the way.
        try:
            self._reply = None
            if reply.error() == QNetworkReply.NetworkError.NoError:
                self._offer(bytes(reply.readAll()).decode("utf-8", "replace"), installed)
        except Exception:
            pass
        finally:
            reply.deleteLater()

    def _offer(self, text: str, installed: str):
        u = updates.available_update(text, installed)
        if u is None:
            return
        self.dialog = UpdateDialog(self.iface.mainWindow(), u, installed)
        try:
            take = self.dialog.exec() == QDialog.DialogCode.Accepted
        finally:
            self.dialog = None
        if take:
            self.update(u)

    def _save_first(self) -> bool:
        """An unsaved site is wiped when it is next opened (ruling 2026-10-07), and the update reloads the plugin:
        offer to Save it first. False: the operator cancelled."""
        dock = self.dock_getter()
        store = getattr(dock, "store", None)
        if store is None or getattr(dock, "locked", False) or store.is_saved() or not store.started_stages():
            return True
        b = QMessageBox.question(self.iface.mainWindow(), "Plan Stages update",
                                 f"{store.site} has unsaved progress, which is discarded the next time it is opened.\n\n"
                                 "Save it and update?",
                                 QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel,
                                 QMessageBox.StandardButton.Save)
        if b != QMessageBox.StandardButton.Save:
            return False
        dock.save_progress()
        return True

    def update(self, u: updates.Update):
        if not self._save_first():
            return
        from qgis.core import QgsNetworkAccessManager
        got = QgsNetworkAccessManager.instance().blockingGet(QNetworkRequest(QUrl(u.download_url)))
        if got.error() != QNetworkReply.NetworkError.NoError or not got.content():
            QMessageBox.warning(self.iface.mainWindow(), "Plan Stages update",
                                f"Could not download Plan Stages {u.version}: {got.errorString()}\n\n"
                                "Try again the next time you open the panel, or use Plugins > Manage and Install "
                                "Plugins > Upgradeable.")
            return
        fd, path = tempfile.mkstemp(prefix=f"plan_stages.{u.version}.", suffix=".zip")
        with os.fdopen(fd, "wb") as f:
            f.write(bytes(got.content()))
        iface = self.iface
        # QGIS's installer unloads this plugin (the panel closes) and loads the new one: let this click finish first.
        QTimer.singleShot(0, lambda: _install(iface, path, u.version))


def _install(iface, path: str, version: str):
    try:
        import pyplugin_installer
        ok = pyplugin_installer.instance().installFromZipFile(path)
    except Exception as e:                                 # never let the update take QGIS down
        ok = False
        QMessageBox.warning(iface.mainWindow(), "Plan Stages update", f"The update did not install: {e}")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if ok:
        QMessageBox.information(iface.mainWindow(), "Plan Stages update",
                                f"Plan Stages {version} is installed. Restart QGIS to finish the update.")
