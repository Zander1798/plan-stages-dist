"""The clickable issues list under a stage (and in the Wayleave box): one header row per check with something to
say, its located issues indented under it, and a footer for what the cap dropped. Clicking an issue takes the
operator to that feature (zoom, select, activate the layer, flash); clicking a header selects every located
feature of that check at once."""
from __future__ import annotations
from typing import Callable, Optional
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QFont, QColor
from qgis.PyQt.QtWidgets import QDialog, QLabel, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout
from ..core.checks import ChecksReport, Issue
from ..core.issues import group_report
from . import locate

ROLE = Qt.ItemDataRole.UserRole


class WhyWindow(QDialog):
    """The small window a click on an issue opens when the step said why it did not make something (operator
    2026-10-19: 14 PONs had no 1:16 and nothing said why). One window, refilled by each click; not modal."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Why")
        self.setModal(False)
        self._label = QLabel(); self._label.setWordWrap(True)
        self._label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._label.setMinimumWidth(380)
        close = QPushButton("Close"); close.clicked.connect(self.hide)
        lay = QVBoxLayout(self); lay.addWidget(self._label); lay.addWidget(close)

    def show_issue(self, issue: Issue) -> None:
        self._label.setText(f"{issue.message}\n\n{issue.why}")
        self.adjustSize(); self.show(); self.raise_()

    def text(self) -> str:
        return self._label.text()


class IssueList(QListWidget):
    marked = pyqtSignal()           # a row's live edit mark was set or cleared (0.8.1: Remove re-evaluates)
    def __init__(self, iface, resolve: Callable[[Issue], Optional[object]], parent=None):
        """`resolve(issue)` returns the loaded QgsVectorLayer the issue lives in, or None."""
        super().__init__(parent)
        self.iface, self.resolve = iface, resolve
        self.groups = []
        self.removed: list = []          # issues the operator removed (0.8.1), shown last
        self._n_fixed = 0                # the first _n_fixed of `removed` were fixed by an edit (2026-10-16)
        self._selected: list = []        # layers the last click selected on; cleared before the next click
        self._watched: list = []         # (layer, signal, slot) connected for live edit marking
        self._rows: dict = {}            # (layer id, fid) -> [QListWidgetItem]
        self.itemClicked.connect(self._clicked)
        self.why_window = WhyWindow(self)
        self.setToolTip("Click an issue to go to it on the map; click a check's header to select every feature it flags")

    # ---------------- content ----------------
    def set_report(self, report: ChecksReport | None, removed=(), fixed=()) -> None:
        """`removed`: issues the operator removed (0.8.1), listed last and greyed; `fixed`: issues on a feature the
        operator edited that the Check still finds (2026-10-16: "fixes should remain crossed out"), listed last and
        crossed out. Both can be restored. `report` holds the shown ones."""
        self._unwatch()
        self.clear(); self.groups = []; self._rows = {}
        self.removed = list(fixed) + list(removed); self._n_fixed = len(list(fixed))
        if report is None:
            return
        self.groups = group_report(report)
        bold = QFont(); bold.setBold(True)
        for gi, g in enumerate(self.groups):
            n_fx = sum(1 for i in self.removed[:self._n_fixed] if i.code == g.code)
            n_rm = sum(1 for i in self.removed[self._n_fixed:] if i.code == g.code)
            how = "fixed or removed" if n_fx and n_rm else "fixed" if n_fx else "removed"
            title = g.title + (f" — all {n_fx + n_rm} {how} by you" if n_fx + n_rm and not g.issues else "")
            h = QListWidgetItem(title); h.setFont(bold); h.setData(ROLE, ("group", gi))
            if g.issues:
                h.setToolTip(f"{len(g.issues)} located; click to select them all")
            self.addItem(h)
            for ii, i in enumerate(g.issues):
                it = QListWidgetItem(f"    {i.severity} {i.code}: {i.message}" +
                                     (" (still found after your edit)" if i.after_edit else ""))
                it.setData(ROLE, ("issue", gi, ii))
                it.setToolTip(f"{i.layer or 'no layer'} fid {i.fid}" + (f" ({i.source})" if i.source != "working" else "") +
                              ("\nClick to read why" if i.why else ""))
                self.addItem(it)
                self._index(i, it)
        if self.groups.dropped:
            self.addItem(QListWidgetItem(f"{self.groups.dropped} more issues not listed (cap)"))
        for start, stop, what, tip in ((0, self._n_fixed, "fixed",
                                        "Issues on features you edited: they stay crossed out. Select one to restore it."),
                                       (self._n_fixed, len(self.removed), "removed",
                                        "Issues you removed. Select one to restore it.")):
            if stop <= start:
                continue
            h = QListWidgetItem(f"{what} by you ({stop - start})"); h.setFont(bold); h.setToolTip(tip)
            self.addItem(h)
            for k in range(start, stop):
                i = self.removed[k]
                it = QListWidgetItem(f"    {i.severity} {i.code}: {i.message} ({what} by you)")
                it.setData(ROLE, ("removed", k)); it.setForeground(QColor("#8a8a8a"))
                if what == "fixed":
                    f = it.font(); f.setStrikeOut(True); it.setFont(f)
                self.addItem(it)

    def current_edited(self) -> bool:
        """The current row's feature was edited since the last Check (review I-1: a removal now would hold the old
        geometry and come back at the next Check)."""
        it = self.currentItem()
        return bool(it is not None and it.data(ROLE + 1))

    def current(self):
        """(issue, removed) under the current row; (None, False) on a header, footer or notice."""
        it = self.currentItem()
        data = it.data(ROLE) if it is not None else None
        if data and data[0] == "issue":
            return self.groups[data[1]].issues[data[2]], False
        if data and data[0] == "removed":
            return self.removed[data[1]], True
        return None, False

    # ---------------- live edit marking (operator ruling 2026-10-08: fixed errors disappear) ----------------
    def _index(self, issue: Issue, item) -> None:
        """Remember which row belongs to which loaded feature, and watch that layer's edit buffer. The row is
        marked the moment the operator edits or deletes the feature; the save re-check then removes it for real."""
        if issue.fid is None or issue.fid < 0:
            return
        layer = self.resolve(issue)
        if layer is None:
            return
        self._rows.setdefault((layer.id(), int(issue.fid)), []).append(item)
        if not any(l is layer for l, _, _ in self._watched):
            for sig, slot in (("geometryChanged", lambda fid, _g, l=layer: self._mark(l, fid, "edited")),
                              ("featureDeleted", lambda fid, l=layer: self._mark(l, fid, "deleted")),
                              ("afterRollBack", lambda l=layer: self._unmark(l))):
                getattr(layer, sig).connect(slot); self._watched.append((layer, sig, slot))

    def _unwatch(self) -> None:
        for layer, sig, slot in self._watched:
            try:
                getattr(layer, sig).disconnect(slot)
            except (TypeError, RuntimeError):            # layer removed from the project meanwhile
                pass
        self._watched = []

    def _mark(self, layer, fid: int, what: str) -> None:
        for it in self._rows.get((layer.id(), int(fid)), []):
            base = it.data(ROLE + 1) or it.text()
            it.setData(ROLE + 1, base)
            it.setText(f"{base}   (fixed by you)" if what == "edited" else f"{base}   ({what})")   # stays crossed out (2026-10-16)
            f = it.font(); f.setStrikeOut(True); it.setFont(f); it.setForeground(QColor("#8a8a8a"))
        self.marked.emit()

    def _unmark(self, layer) -> None:
        for (lid, _fid), items in self._rows.items():
            if lid != layer.id():
                continue
            for it in items:
                base = it.data(ROLE + 1)
                if base:
                    it.setText(base); f = it.font(); f.setStrikeOut(False); it.setFont(f); it.setData(ROLE + 1, None)
                    it.setForeground(QColor())
        self.marked.emit()

    def prepend(self, text: str) -> None:
        """An inert notice row at the top (approval refused, override recorded, ...)."""
        self.insertItem(0, QListWidgetItem(text))

    # ---------------- navigation ----------------
    def _clear_previous_selection(self) -> None:
        """What the previous click selected stays yellow on the map until it is cleared (operator, 2026-10-08)."""
        for layer in self._selected:
            try:
                layer.removeSelection()
            except RuntimeError:                         # layer gone
                pass
        self._selected = []

    def _clicked(self, item):
        data = item.data(ROLE)
        if not data:
            return
        self._clear_previous_selection()
        issue = (self.groups[data[1]].issues[data[2]] if data[0] == "issue" else
                 self.removed[data[1]] if data[0] == "removed" else None)
        if issue is not None and issue.why:
            self.why_window.show_issue(issue)
        else:
            self.why_window.hide()
        if data[0] == "issue":
            self._go_issue(self.groups[data[1]].issues[data[2]])
        elif data[0] == "removed":
            self._go_issue(self.removed[data[1]])
        elif data[0] == "group":
            self._go_group(self.groups[data[1]])

    def _go_issue(self, issue: Issue):
        layer = self.resolve(issue)
        f = locate.find_feature(layer, issue) if layer is not None else None
        if f is not None:
            locate.go_to(self.iface, layer, [f.id()], None); self._selected.append(layer)
        else:
            dest = self.iface.mapCanvas().mapSettings().destinationCrs()
            locate.go_to(self.iface, None, [], locate.issue_point(issue, dest))

    def _go_group(self, group):
        found: dict = {}                                 # layer id -> (layer, [fids])
        for i in group.issues:
            layer = self.resolve(i)
            f = locate.find_feature(layer, i) if layer is not None else None
            if f is not None:
                found.setdefault(layer.id(), (layer, []))[1].append(f.id())
        if not found:
            if group.issues:
                self._go_issue(group.issues[0])
            return
        layer, fids = max(found.values(), key=lambda v: len(v[1]))   # one layer gets the selection and the view
        for other, ofids in found.values():
            if other is not layer and not locate.is_polygon(other):   # a selected polygon hides its contents
                other.selectByIds(ofids); self._selected.append(other)
        locate.go_to(self.iface, layer, sorted(set(fids)), None); self._selected.append(layer)
