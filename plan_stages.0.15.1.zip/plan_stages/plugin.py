from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt


class PlanStagesPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None
        self.updater = None

    def initGui(self):
        self.action = QAction("Plan Stages", self.iface.mainWindow())
        self.action.triggered.connect(self.show_dock)
        self.iface.addPluginToMenu("&Plan Stages", self.action)

    def unload(self):
        self.iface.removePluginMenu("&Plan Stages", self.action)
        if self.dock is not None:
            self.dock.shutdown()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

    def show_dock(self):
        if self.dock is None:
            from .qgis.dock import PlanStagesDock
            self.dock = PlanStagesDock(self.iface)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock.show()
        self.dock.raise_()
        self.check_for_update()

    def check_for_update(self):
        """Each time the panel opens (operator, 2026-10-26): announce a newer published version until they update."""
        try:
            if self.updater is None:
                from .qgis.update_dialog import UpdateChecker
                self.updater = UpdateChecker(self.iface, lambda: self.dock)
            self.updater.check()
        except Exception:
            pass
