"""Where each 1:16 goes on the operator-approved feeder (P2), and which 1:16 needs a link to its PON's span (P3).

Pure geometry, site metres. Imports no sibling ml module so the plugin tests can load it on its own.
"""
import math

import numpy as np
from osgeo import ogr
from scipy.spatial import cKDTree


def _densify(a: np.ndarray, step: float = 1.0) -> np.ndarray:
    """Points every <= step m along a polyline, so nearest-point queries are accurate to ~step/2."""
    a = np.asarray(a, float)[:, :2]
    out = [a[:1]]
    for p, q in zip(a[:-1], a[1:]):
        n = max(1, int(math.ceil(math.hypot(*(q - p)) / step)))
        out.append(p + (q - p) * (np.arange(1, n + 1) / n)[:, None])
    return np.vstack(out)


def read_lines(lyr, to_site) -> list[np.ndarray]:
    """Every line part of the layer as an (n,2) array in site metres, Z dropped, densified to 1 m."""
    out = []
    lyr.ResetReading()
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone()
        if to_site is not None:
            g.Transform(to_site)
        stack = [g]
        while stack:
            h = stack.pop()
            t = ogr.GT_Flatten(h.GetGeometryType())
            if t == ogr.wkbLineString:
                pts = np.array([(h.GetX(i), h.GetY(i)) for i in range(h.GetPointCount())], float)
                if len(pts) >= 2:
                    out.append(_densify(pts))
            elif t in (ogr.wkbMultiLineString, ogr.wkbGeometryCollection):
                stack.extend(h.GetGeometryRef(i) for i in reversed(range(h.GetGeometryCount())))
    return out


def place(feeder, targets, pon_span, max_m, on_tol=2.0):
    """Put one 1:16 per PON in `targets` on the approved feeder.

    target rule: the P1 position still lies on the feeder (within on_tol) -> keep it exactly.
    nearest rule: otherwise the feeder point nearest the PON's span, if within max_m, else the PON goes unserved.
    Returns (placed, why, gap): placed[pon] = (x, y, "target"|"nearest"); why/gap for every PON not placed
    (gap = metres from the approved feeder to that PON's span, None when the PON has no span).
    """
    placed, why, gap = {}, {}, {}
    pts = np.vstack([_densify(a) for a in feeder if len(a) >= 2]) if feeder else np.empty((0, 2))
    tree = cKDTree(pts) if len(pts) else None
    for pon, tgt in targets.items():
        sp = pon_span.get(pon)
        has_span = sp is not None and len(sp) > 0
        if tgt is not None and tree is not None and tree.query(tgt)[0] <= on_tol:
            placed[pon] = (float(tgt[0]), float(tgt[1]), "target")
            continue
        if not has_span:
            why[pon], gap[pon] = f"no span runs inside PON {pon}", None
            continue
        if tree is None:
            why[pon], gap[pon] = "no approved feeder to put a 1:16 on", None
            continue
        d, j = tree.query(np.asarray(sp, float)[:, :2])
        k = int(np.argmin(d))
        if d[k] <= max_m:
            placed[pon] = (float(pts[j[k]][0]), float(pts[j[k]][1]), "nearest")
        else:
            gap[pon] = float(d[k])
            why[pon] = f"the nearest feeder is {d[k]:.0f} m from PON {pon}'s span (limit {max_m:.0f} m)"
    return placed, why, gap


def links(splitters, pons, pon_span, edge_m, on_tol=2.0):
    """Straight [1:16 xy, nearest span xy] link for each 1:16 that stands more than on_tol from its PON's span.

    Its PON is the polygon containing it; else a PON within edge_m (the one its own attribute names, else the
    nearest). A 1:16 whose PON has no span gets no link (P3's Check, 1to16_joins_distribution, reports it).
    """
    trees = {}
    out = []
    for x, y, attr in splitters:
        pt = ogr.Geometry(ogr.wkbPoint)
        pt.AddPoint_2D(float(x), float(y))
        pon = next((p for p, g in pons.items() if g.Contains(pt)), None)
        if pon is None:
            near = sorted((g.Distance(pt), p) for p, g in pons.items())
            near = [(d, p) for d, p in near if d <= edge_m]
            if near:
                pon = attr if attr in {p for _, p in near} else near[0][1]
        if pon is None:
            continue
        sp = pon_span.get(pon)
        if sp is None or len(sp) == 0:
            continue
        if pon not in trees:
            sp = np.asarray(sp, float)[:, :2]
            trees[pon] = (cKDTree(sp), sp)
        tree, sp = trees[pon]
        d, i = tree.query((x, y))
        if d > on_tol:
            out.append(([(float(x), float(y)), (float(sp[i][0]), float(sp[i][1]))], pon))
    return out
