"""Build a standalone QGIS project showing OUR generated plan over satellite imagery.

SITE-AWARE: reads SITE / SITE_DIR / SITE_EPSG like the rest of the pipeline, and takes the
feature counts and lengths from the step metrics rather than hardcoding them, so the layer
labels cannot drift from the plan they describe.

Run headless with the QGIS python:
    "C:/Program Files/QGIS 4.2.0/bin/python-qgis.bat" build_qgis_project.py

Writes  work/qgis/<site>_plan.qgz.

Layer order is deliberate -- imagery at the bottom, operator Step 0 inputs above it, our plan
on top, and within our plan the small things (joints, poles) above the long things (cable,
drops) so they are not buried.

⚠️ A GeoPackage open as a QGIS layer is FILE-LOCKED; regenerating it while QGIS holds it
fails with exit 255. Close the project before re-running a step.
"""
import os, sys, json
from qgis.core import (QgsApplication, QgsProject, QgsVectorLayer, QgsRasterLayer,
                       QgsLineSymbol, QgsMarkerSymbol, QgsFillSymbol,
                       QgsSimpleLineSymbolLayer, QgsCoordinateReferenceSystem)
from qgis.PyQt.QtGui import QColor      # QGIS 4.2 is Qt6 -- never PyQt5

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
# PLAN_DIR lets a finished plan be pinned to its own folder. The pipeline always writes to
# work/step3, work/step4, ... so the NEXT site's run overwrites them -- and a project file
# pointing at work/step* would then silently display the wrong site's plan. Copy a finished
# plan to work/<site>/ and set PLAN_DIR to it.
WORK = os.environ.get("PLAN_DIR") or os.path.join(ROOT, "work")
SITE = os.environ.get("SITE", "malmesbury")
SITE_DIR = os.environ.get("SITE_DIR", "")
OUT_DIR = os.path.join(WORK, "qgis"); os.makedirs(OUT_DIR, exist_ok=True)
OUT = os.path.join(OUT_DIR, f"{SITE}_plan.qgz")


def metrics(rel):
    try:
        return json.load(open(os.path.join(WORK, rel)))
    except Exception:
        return {}


m3 = metrics("step3/step3_metrics.json")
m4 = metrics("step4/step4_metrics.json")
m5 = metrics("step567/step567_metrics.json")
# `distribution_m` is the wayleave key (step3_span_split); `total_cable_m` was the old
# router's. Read both so the label cannot silently show 0 after the Step 3 swap.
dist = m3.get("distribution_m") or m3.get("total_cable_m") or 0
drop = m4.get("total_drop_m") or 0
feed = m3.get("feeder_m") or 0
total = dist + drop + feed          # the feeder is our cable too, under the wayleave

QgsApplication.setPrefixPath(os.environ.get("QGIS_PREFIX_PATH", r"C:/Program Files/QGIS 4.2.0/apps/qgis"), True)   # set by the launcher: whichever QGIS runs the plugin
qgs = QgsApplication([], False)
qgs.initQgis()

# ---- PRESERVE THE OPERATOR'S OWN STYLING ------------------------------------------------
# The operator restyles layers in QGIS to suit how they read a plan (2026-09-10: "I like the
# setting for the current layers ... have the colours and stroke widths that the layers are
# currently saved as be the same"). Rebuilding the project from scratch would silently throw
# that away, so any existing project is read FIRST and each layer's symbology saved to a QML
# keyed by its DATA SOURCE -- not its name, because the names carry feature counts that
# change every run. Whatever this script would have styled is then overridden by the
# operator's own.
STYLE_DIR = os.path.join(OUT_DIR, "styles"); os.makedirs(STYLE_DIR, exist_ok=True)
SAVED_STYLES = {}


def _skey(src):
    """stable key for a layer's data: file basename + |layername=..., lowercased"""
    src = src.replace("\\", "/")
    base = src.split("/")[-1]
    return base.lower()


def _harvest_styles(path):
    if not os.path.exists(path):
        return
    try:
        prev = QgsProject()
        if not prev.read(path):
            return
        for lyr in prev.mapLayers().values():
            if not hasattr(lyr, "renderer"):
                continue
            k = _skey(lyr.source())
            qml = os.path.join(STYLE_DIR, k.replace("|", "_").replace("=", "_") + ".qml")
            msg, ok = lyr.saveNamedStyle(qml)
            if ok:
                SAVED_STYLES[k] = qml
        prev.clear()
        if SAVED_STYLES:
            print(f"  kept {len(SAVED_STYLES)} operator-set layer style(s) from the existing project")
    except Exception as e:
        print(f"  (could not read existing styles: {e})")


def apply_saved_style(layer):
    """re-apply the operator's own symbology, if they had set one for this data source"""
    qml = SAVED_STYLES.get(_skey(layer.source()))
    if qml and os.path.exists(qml):
        layer.loadNamedStyle(qml)
        return True
    return False


_harvest_styles(OUT)
p = QgsProject.instance()
p.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))     # web mercator, to match XYZ tiles
root = p.layerTreeRoot()


def add(layer, group, visible=True):
    if not layer.isValid():
        print(f"  FAILED  {layer.name()}")
        return None
    apply_saved_style(layer)        # operator styling wins over this script's defaults
    p.addMapLayer(layer, False)
    node = group.addLayer(layer)
    node.setItemVisibilityChecked(visible)
    return layer


def line(rgb, width):
    s = QgsLineSymbol.createSimple({})
    sl = QgsSimpleLineSymbolLayer(QColor(*rgb)); sl.setWidth(width)
    s.changeSymbolLayer(0, sl)
    return s


def marker(rgb, size, shape="circle"):
    return QgsMarkerSymbol.createSimple({"name": shape, "color": "%d,%d,%d" % rgb,
                                         "outline_color": "0,0,0",
                                         "outline_width": "0.2", "size": str(size)})


def outline_only(rgb, width, style="solid"):
    return QgsFillSymbol.createSimple({"color": "0,0,0,0", "style": "no",
                                       "outline_color": "%d,%d,%d" % rgb,
                                       "outline_width": str(width),
                                       "outline_style": style})


# ---- 1. imagery ----------------------------------------------------------------------
g_base = root.addGroup("Imagery")
google = ("type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D"
          "%26z%3D%7Bz%7D&zmax=20&zmin=0")
add(QgsRasterLayer(google, "Google Satellite", "wms"), g_base, True)

# ---- 2. operator WAYLEAVE inputs -------------------------------------------------------
# Layer names come from site_config's LAYER_<KEY> overrides where set, because a wayleave
# names things per site ("PON Zones HT2", "Poles 40m (2729) - poles_40m").
g_ctx = root.insertGroup(0, "Operator wayleave (Step 0)")


def _lyr(key, default):
    return os.environ.get("LAYER_" + key.upper(), default)


if SITE_DIR:
    for fname, label, rgb, width, style, vis in [
            (_lyr("erven", "Erven"), "Erven", (200, 200, 200), 0.10, "solid", True),
            (_lyr("pons", "Pons"), "PON boundaries", (0, 200, 255), 0.60, "dash", True),
            (_lyr("aoi", "AOI"), "AOI", (255, 255, 255), 0.80, "dash", False)]:
        pth = f"{SITE_DIR}/{fname}.shp"
        if not os.path.exists(pth):
            continue
        l = QgsVectorLayer(pth, label, "ogr")
        if l.isValid():
            l.renderer().setSymbol(outline_only(rgb, width, style))
            add(l, g_ctx, vis)
    # THE SPAN is the wayleave's core: the route the operator has already chosen. Shown
    # under our distribution so the two can be compared at a glance -- our distribution
    # should lie exactly on it.
    for fname, label, rgb, w, vis in [
            (_lyr("span", "Span"), "SPAN  (operator's chosen route)", (255, 255, 255), 0.55, True),
            (_lyr("road", "road"), "Roads", (150, 150, 150), 0.25, True),
            ("feeder", "Feeder (operator, reference only)", (80, 140, 255), 0.9, False)]:
        pth = f"{SITE_DIR}/{fname}.shp"
        if os.path.exists(pth):
            l = QgsVectorLayer(pth, label, "ogr")
            if l.isValid():
                l.renderer().setSymbol(line(rgb, w))
                add(l, g_ctx, vis)
    for fname, label, shape, rgb, size in [
            (_lyr("poles", "poles"), "Poles (operator's wayleave)", "circle", (255, 200, 120), 1.6),
            (_lyr("pop", "POP"), "POP  (network origin)", "triangle", (255, 255, 255), 6.0),
            ("OLT", "OLT  (network origin)", "triangle", (255, 255, 255), 6.0)]:
        pth = f"{SITE_DIR}/{fname}.shp"
        if os.path.exists(pth):
            l = QgsVectorLayer(pth, label, "ogr")
            if l.isValid():
                l.renderer().setSymbol(marker(rgb, size, shape))
                add(l, g_ctx, True)

# ---- SITE EXTENT, for the stale-layer guard --------------------------------------------
# `work/step3|step4|step567|step2` are SHARED SCRATCH: the next site's run overwrites them.
# A project built from those paths can therefore pick up ANOTHER SITE's output and display
# it as this plan -- which happened on 2026-09-09 (Malmesbury's demand points in the
# Ventersdorp project). Every layer added below is checked against the site's own extent,
# and one that does not overlap is REFUSED rather than drawn.
SITE_EXTENT = None
SITE_CRS = None
if SITE_DIR:
    for _c in (_lyr("pons", "Pons"), _lyr("aoi", "AOI"), _lyr("span", "Span")):
        _p = f"{SITE_DIR}/{_c}.shp"
        if os.path.exists(_p):
            _l = QgsVectorLayer(_p, "_x", "ogr")
            if _l.isValid():
                _e = _l.extent()
                SITE_EXTENT = (_e.xMinimum(), _e.yMinimum(), _e.xMaximum(), _e.yMaximum())
                SITE_CRS = _l.crs()
                break


def on_site(layer, label):
    """False when a layer sits outside this site -- i.e. it is another site's scratch. The layer's extent is taken
    into the site layer's CRS first: Kingsway's P7 poles (Lo29 metres) were compared with a site extent in degrees
    and REFUSED, so the delivery project had no Poles layer (2026-10-26)."""
    if SITE_EXTENT is None:
        return True
    e = layer.extent()
    if e.isNull():          # no features; a single point (zero area, isEmpty) is still checked
        return True
    if SITE_CRS is not None and SITE_CRS.isValid() and layer.crs().isValid() and layer.crs() != SITE_CRS:
        from qgis.core import QgsCoordinateTransform
        try:
            e = QgsCoordinateTransform(layer.crs(), SITE_CRS, QgsProject.instance()).transformBoundingBox(e)
        except Exception:
            return True
    x0, y0, x1, y1 = SITE_EXTENT
    pad = max(x1 - x0, y1 - y0) * 0.5 + 0.05
    if (e.xMaximum() < x0 - pad or e.xMinimum() > x1 + pad
            or e.yMaximum() < y0 - pad or e.yMinimum() > y1 + pad):
        print(f"  *** REFUSED (not on this site -- stale scratch?)  {label}")
        print(f"      layer {e.xMinimum():.3f},{e.yMinimum():.3f} .. "
              f"{e.xMaximum():.3f},{e.yMaximum():.3f}   site {x0:.3f},{y0:.3f} .. {x1:.3f},{y1:.3f}")
        return False
    return True


# ---- 3. our plan ----------------------------------------------------------------------
g = root.insertGroup(0, f"CLAUDE PLAN — {SITE}  ({total:,.0f} m total)")

PLAN = [
    ("step4/claude_step4.gpkg", "claude_drops", "line",
     f"Drops  {m4.get('drops',0):,}  ({drop:,.0f} m)",          (255, 130, 220), 0.18, True),
    ("step3/claude_distribution_cable.gpkg", "claude_distribution_cable", "line",
     f"Distribution cable  ({dist:,.0f} m)",                    (255,   0, 255), 0.75, True),
    # WAYLEAVE (2026-09-09): the feeder and the 1:16s are OUR output now, not Step 0 inputs,
    # so they belong in this group. Drawn heavier than the distribution -- it is the trunk.
    ("step3/claude_feeder_cable.gpkg", "claude_feeder_cable", "line",
     f"Feeder cable  ({m3.get('feeder_m', 0):,.0f} m, roadside)", (0, 210, 255), 1.30, True),
    ("step567/claude_step567.gpkg", "claude_road_crossings", "line",
     f"Road crossings  {m5.get('crossings',0):,}",              (255, 235,   0), 1.10, True),
    # DEMAND POINTS ARE ALWAYS THE OPERATOR'S under the wayleave -- Step 2 is retired, and
    # `work/step2/` still holds another SITE's output. Pointing at it put 2,859 MALMESBURY
    # demand points (18.69E) into the Ventersdorp project (26.78E), ~1,000 km away. Invisible
    # only because the layer defaulted to switched-off; had it been on, the plan would have
    # shown the wrong town's homes. Read the operator's layer directly, by its wayleave name.
    ("@operator_demand_points", "", "point",
     "Demand points (operator)",                                (255, 255, 255), 1.0,  True),
    # ONE pole layer, styled by the cable it carries -- feeder poles are 7 m and
    # distribution midblock poles 5-6 m per spec, and the BOM depends on the split.
    # Two SEPARATE layers were tried first and broke the build: this GeoPackage is already
    # opened for crossings, poles, splitters and joints, and a fifth concurrent sqlite
    # connection to it failed with "unable to open database file". A rule-based renderer
    # gives the same visual split on one connection.
    ("step567/claude_step567.gpkg", "claude_poles", "poles",
     f"Poles  {m5.get('poles_total',0):,}  (orange = feeder 7 m, red = distribution)",
     (255, 60, 60), 1.4, True),
    ("step567/claude_step567.gpkg", "claude_8way_splitters", "point",
     f"1:8 splitters  {m5.get('splitters',0):,}",               (255, 160,   0), 1.6,  False),
    ("step567/claude_step567.gpkg", "claude_dome_joints", "point",
     f"Dome joints  {m5.get('dome_joints',0):,}",               (120, 255, 120), 2.0,  True),
    ("step4/claude_step4.gpkg", "claude_collection_points", "point",
     f"Collection points  {m4.get('collection_points',0):,}",   (  0, 255, 255), 2.4,  True),
    ("step3/claude_1to16_splitters.gpkg", "claude_1to16_splitters", "point",
     f"1:16 PON-entry splitters  {m3.get('splitters', 0)}  (ours)", (255, 255, 0), 4.2, True),
    ("step3/claude_distribution_cable.gpkg", "claude_escalations", "point",
     f"!! ESCALATIONS  {m3.get('unreached',0)} unreachable homes", (255, 0, 0),   5.0,  True),
]

for _row in PLAN:
    # a 7th field is an optional SUBSET FILTER, so one GeoPackage layer can appear
    # twice under different styling (the two pole heights).
    rel, lyr, kind, label, rgb, size, vis = _row[:7]
    subset = _row[7] if len(_row) > 7 else None
    if rel == "@operator_demand_points":
        src = f"{SITE_DIR}/{_lyr('demand_points', 'Demand points')}.shp"
        if not os.path.exists(src):
            print(f"  SKIP (no file)  {label}"); continue
    else:
        src = f"{WORK}/{rel}|layername={lyr}"
    if rel != "@operator_demand_points" and not os.path.exists(os.path.join(WORK, rel)):
        # Demand points may be OPERATOR-SUPPLIED rather than generated by our Step 2 (they
        # were at Middelburg and Cradock). A plan that does not show the properties it
        # serves is incomplete, so fall back to the supplied layer rather than skipping.
        alt = os.path.join(SITE_DIR, "Demand points.shp") if SITE_DIR else None
        if "Demand points" in label and alt and os.path.exists(alt):
            src = alt
            label = "Demand points  (operator-supplied)"
        else:
            print(f"  SKIP (no file)  {label}")
            continue
    l = QgsVectorLayer(src, label, "ogr")
    if not l.isValid():
        if lyr == "claude_escalations" and not m3.get("unreached", 0):
            print(f"  none    {label}")          # no unreachable homes: the layer is not written at all
        else:
            print(f"  FAILED  {label}")
        continue
    if subset:
        if l.fields().indexFromName(subset.split('"')[1]) < 0:
            print(f"  SKIP (no field for filter)  {label}")
            continue
        l.setSubsetString(subset)
    if kind == "poles":
        from qgis.core import QgsRuleBasedRenderer
        _root = QgsRuleBasedRenderer.Rule(None)
        for _expr, _lbl, _rgb, _sz in (
                ("\"cable\" = 'feeder'", "feeder 7 m", (255, 165, 0), 2.0),
                ("ELSE", "distribution 5.4 m", (255, 60, 60), 1.3)):
            _r = QgsRuleBasedRenderer.Rule(marker(_rgb, _sz))
            if _expr == "ELSE": _r.setIsElse(True)
            else: _r.setFilterExpression(_expr)
            _r.setLabel(_lbl); _root.appendChild(_r)
        if l.fields().indexFromName("cable") >= 0:
            l.setRenderer(QgsRuleBasedRenderer(_root))
        else:
            l.renderer().setSymbol(marker(rgb, size))
    elif kind == "line":
        l.renderer().setSymbol(line(rgb, size))
    else:
        shape = ("star" if "ESCALATION" in label else
                 "square" if "1:16" in label else "circle")
        l.renderer().setSymbol(marker(rgb, size, shape))
    l.triggerRepaint()
    if not on_site(l, label):
        continue
    add(l, g, vis)
    print(f"  {label:<46} {l.featureCount()}")

p.write(OUT)
print(f"\nwrote {OUT}")
# QGIS 3.44 crashes inside exitQgis() after everything is written (0xC0000005, 2026-10-26), and the P7 Delivery
# stage reads the crash as a failure. Every output is closed by now, so end this one-shot process without the
# teardown: the same on QGIS 4, where exitQgis() did nothing that is needed.
sys.stdout.flush(); sys.stderr.flush()
os._exit(0)
