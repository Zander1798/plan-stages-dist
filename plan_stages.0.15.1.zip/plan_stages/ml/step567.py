"""
Steps 7, 5 and 6 — road crossings, poles, splitters and dome joints.

Run order is 7 -> 5 -> 6, not 5 -> 6 -> 7: R5.2 puts a pole on each side of every road
crossing, so the crossings must be known before the poles can be placed. R7.6 keeps them
as separate layers regardless.

Inputs: ground-truth Distribution Cable + Erven + AOI, and our own Step 4 collection points.

STEP 7  R3.6   roads are implicit -- the negative space between blocks of erven
        R7.5   <=20 m -> Drill, >=25 m -> Trench, 20-25 m -> escalate (C1)
        Q7.4   backhaul is operator-supplied, never generated: long runs are excluded
STEP 5  R5.1   a pole at every drop-collection point
        R5.2   a pole each side of every road crossing
        R5.3   intermediate poles wherever needed to hold the span -- emergent, no target
        R5.4   span ceiling 70 m (HeroTel). NOT 50 m; that is the drop cap
        R5.5   poles stand on erven, not in the roadway
STEP 6  R6.1/2 one 1:8 splitter per collection point, position inherited exactly
        R6.6   one dome joint per splitter, same position, emitted together

Reference: 113 crossings (106 Drill / 7 Trench), 798 poles, 414 splitters, 413 dome joints.
Per R5.3 a generated pole COUNT must not be scored against Malmesbury's -- spacing is
emergent. Score on constraint satisfaction instead.

The same now goes for the CROSSING count. D-7.10 (Zander, 2026-08-21): "we shouldn't avoid
road crossings" / "we can use that cable." A crossing is ordinary construction, not overhead
to be routed around, so CROSS_COST_M is 0 by ruling and 134 crossings against the reference's
113 is NOT a defect. The reference counts below are printed for orientation only -- do not
tune toward them. Crossing DETECTION recall is still a real measure (F-22); crossing COUNT is
not.
"""
import os, json
import numpy as np
from scipy.spatial import cKDTree
from osgeo import ogr, osr
ogr.UseExceptions()

from client_spec import limit, banner as client_banner   # R4.7: limits are PER-CLIENT (F-35)

from site_crs import LOCAL_EPSG, check_layer   # EPSG:2048 is Malmesbury-only

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
from site_config import work_dir, SITE_DIR as D, have, ref, banner
from site_config import L as LYR   # NOT `L` -- step3 and step567 both use
                                   # a local `L` for a cable length in metres
TAG = os.environ.get("OUTTAG", "")
STEP4 = os.path.join(work_dir("step4"), f"claude_step4{TAG}.gpkg")
OUT = work_dir("step567")
STAGE = os.environ.get("STAGE", "all")          # crossings | poles | hardware | all
assert STAGE in ("crossings", "poles", "hardware", "all"), STAGE
WANT = {"all": {"crossings", "poles", "hardware"}}.get(STAGE, {STAGE})

SPAN_CAP_M = float(os.environ.get("SPAN_CAP_M", limit("span_cap_m", required=True)))
# R5.4. CONFIRMED by 2026_OPL_GPON_FTTH_Standard.pdf p2, "Maximum span distance of 70m" --
# it was reverse-engineered from the reference poles until 2026-08-21, which R0.11 forbade.
# PLANNING-LEARNINGS sec0.8 (measured from Malmesbury Trenching.shp, 2026-08-29):
# every TRUE road crossing in the accepted plan is a DRILL -- 7-24 m, median 10.1, 50mm
# HDPE. "Trench" is NOT a crossing class at all: it is a long buried run alongside a road
# (22-277 m, 7 in the whole town), a different construction. So a crossing marker is Drill
# up to DRILL_MAX and anything longer is an ESCALATION (either a detector artefact or a
# buried-run candidate the operator must rule on) -- never emitted as "Trench".
# SUPERSEDED 2026-10-19, operator: "We essentially just need basic road crossings, either drill or
# trench, and that would be your decision" -- the escalate class oversaturated the wayleave. A
# crossing longer than DRILL_MAX (24-30 m; longer is not a crossing, ROAD_MAX) is now Trench.
# 2026-10-20, operator: yes to moving the cutoff to 30 m -- wide streets are drilled. At 24 m more than half of
# Vrede's crossings (24-30 m) came out Trench. Malmesbury's longest drill (24.0 m) was a measurement, not a limit.
DRILL_MAX = 30.0
TRENCH_MIN = 25.0     # retained only for the reference annotation split
ROAD_MAX = 30.0     # reference drill maxes at 24.0 m; longer off-erf runs are not crossings
SAMPLE_M = 1.0
XING_ERF_TOL = float(os.environ.get("XING_ERF_TOL", "0.5"))    # R5.5 boundary tolerance
XING_BEND_STOP = float(os.environ.get("XING_BEND_STOP", "30"))  # a turn this sharp = the flanking pole
XING_MIN_ANGLE = float(os.environ.get("XING_MIN_ANGLE", "20"))  # below this the cable runs ALONG the road
# How far the crossing walk-out must travel before an erf edge may end it. A crossing spans
# a carriageway, so it cannot be 0 m wide -- see the comment at the walk itself.
XING_MIN_OUT = float(os.environ.get("XING_MIN_OUT", "3.0"))
# Half-width of the trafficked carriageway around a road CENTRELINE. A feeder pole nearer
# than this is in the road; beyond it, it is on the verge, which is where a public-
# deployment feeder pole belongs. Residential streets here are ~6-8 m kerb to kerb.
CARRIAGEWAY_HALF_M = float(os.environ.get("CARRIAGEWAY_HALF_M", "4.0"))
# 🔴 A CROSSING ENDS ONCE THE CABLE HAS CLEARED THE ROAD. Operator, 2026-10-20, Vrede P3: "the
# road crossings, specifically the trenching, are in areas where they're not supposed to be
# road crossings ... nowhere is it actually crossing a road." The walk-out below stops at an
# erf edge or a bend, and where neither comes (open ground, missing erven, a cable that crosses
# and runs on along the verge) it ran on to ROAD_MAX each side: 66 of Vrede's 74 distribution
# Trenches ended on no erf at either end, median 43 m. So it also stops XING_CLEAR_M from the
# road it crossed: past the feeder's verge, which P1 puts at most 8.5 m off the centreline.
XING_CLEAR_M = float(os.environ.get("XING_CLEAR_M", "10.0"))
XING_ALONG_M = float(os.environ.get("XING_ALONG_M", "18.0"))   # see the Road.shp validation

wgs = osr.SpatialReference(); wgs.ImportFromEPSG(4326)
loc = osr.SpatialReference(); loc.ImportFromEPSG(LOCAL_EPSG)
for s in (wgs, loc): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
fwd = osr.CoordinateTransformation(wgs, loc)
check_layer(f"{D}/{LYR('pons')}.shp")   # loud if EPSG:2048 is wrong for this site
rev = osr.CoordinateTransformation(loc, wgs)

def load(path, layer=None):
    ds = ogr.Open(path); l = ds.GetLayer(layer) if layer else ds.GetLayer(); o = []
    for f in l:
        g = f.GetGeometryRef()
        if g is None: continue
        g = g.Clone(); g.FlattenTo2D(); g.Transform(fwd); o.append(g)
    return o
def shp(n): return load(f"{D}/{n}.shp")
def lines(gs):
    out = []
    for g in gs:
        st = [g]
        while st:
            x = st.pop()
            if x.GetGeometryName() == "LINESTRING":
                out.append(np.array([(x.GetX(i), x.GetY(i)) for i in range(x.GetPointCount())]))
            elif x.GetGeometryCount():
                st += [x.GetGeometryRef(i) for i in range(x.GetGeometryCount())]
    return out
def P(g): return g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()

# CABLE=claude routes everything onto OUR OWN Step 3 cable instead of the
# operator's, which is the only way to test the pipeline end to end.
CABLE = os.environ.get("CABLE", "gt")
if CABLE == "claude":
    _p = os.path.join(work_dir("step3"), "claude_distribution_cable.gpkg")
    _ds = ogr.Open(_p); _l = _ds.GetLayer(); _g = []
    for _f in _l:
        _x = _f.GetGeometryRef()
        if _x is None: continue
        _x = _x.Clone(); _x.FlattenTo2D(); _x.Transform(fwd); _g.append(_x)
    dc = lines(_g)
    print(f"USING OUR OWN Step 3 cable: {len(dc)} segments")
else:
    if not have("ref_cable"):
        raise SystemExit("CABLE=gt needs the reference Distribution Cable layer, which "
                         "this site does not have. Use CABLE=claude.")
    dc = lines(shp(LYR("ref_cable")))
# WAYLEAVE: erven are optional now (the span is the routing graph, not the erf boundary),
# so a site with no cadastre must still plan. Poles fall back to the span itself.
erven = shp(LYR("erven")) if have("erven") else []
CP = np.array([(P(g).GetX(), P(g).GetY()) for g in load(STEP4, "claude_collection_points")])
print(f"cable {len(dc)} spans   erven {len(erven)}   our collection points {len(CP)}")

# ---- erf lookup: grid hash of envelopes, then Contains ----
CELL = 60.0
grid = {}
for i, g in enumerate(erven):
    x0, x1, y0, y1 = g.GetEnvelope()
    for cx in range(int(x0//CELL), int(x1//CELL)+1):
        for cy in range(int(y0//CELL), int(y1//CELL)+1):
            grid.setdefault((cx, cy), []).append(i)
def erf_at(x, y):
    """index of the erf containing this point, or -1"""
    p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(float(x), float(y))
    for i in grid.get((int(x//CELL), int(y//CELL)), ()):
        if erven[i].Contains(p): return i
    return -1
def on_erf(x, y): return erf_at(x, y) >= 0

def near_erf(x, y, tol=0.5):
    """R5.5 asks whether a pole stands on an erf rather than in the roadway. Contains()
    EXCLUDES the boundary, and our cable deliberately runs ON erf boundaries (R3.9), so a
    pole sitting exactly on an edge scored as 'in the road'. Allow a small tolerance."""
    if erf_at(x, y) >= 0: return True
    p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(float(x), float(y))
    for i in grid.get((int(x//CELL), int(y//CELL)), ()):
        if erven[i].Distance(p) <= tol: return True
    return False

# ================= STEP 7 — road crossings =================
def walk(c, step):
    """-> (points, stations) sampled along a polyline"""
    pts, st = [c[0]], [0.0]
    acc = 0.0
    for a, b in zip(c[:-1], c[1:]):
        L = float(np.hypot(*(b-a)))
        n = max(int(L/step), 1)
        for k in range(1, n+1):
            pts.append(a + (b-a)*(k/n)); st.append(acc + L*k/n)
        acc += L
    return np.array(pts), np.array(st)

# R7.1 — a marker at every road crossing on EITHER cable type, so the feeder counts too.
# WAYLEAVE (2026-09-09): the feeder used to be an operator INPUT layer. It is now OUR
# output -- step3_span_split picks it out of the span -- so the crossings are counted on
# the feeder we chose, not on one we were handed.
_fp = os.path.join(work_dir("step3"), "claude_feeder_cable.gpkg")
if os.path.exists(_fp):
    _fds = ogr.Open(_fp); _fg = []
    for _f in _fds.GetLayer():
        _x = _f.GetGeometryRef()
        if _x is None: continue
        _x = _x.Clone(); _x.FlattenTo2D(); _x.Transform(fwd); _fg.append(_x)
    feeder = lines(_fg)
    print(f"USING OUR OWN feeder: {len(feeder)} segments")
else:
    feeder = []
    print("no feeder from step 3 -- crossings counted on distribution only")
routes = [("dc", c) for c in dc] + [("feeder", c) for c in feeder]
print(f"routes tested for crossings: {len(dc)} distribution + {len(feeder)} feeder")

crossings = []          # (kind, s0, s1, p0, p1, length, type)
grey = 0

# ---- CROSSINGS FROM THE ROAD NETWORK (operator, 2026-08-29) --------------------------
# "The crossing is not going across straight, not following the distribution cable, and
#  not connected to any poles." Root cause: the erf-gap heuristic INFERS crossings and can
# emit geometry detached from the route. The human layering is the opposite: the crossing
# IS the stretch of the cable between its two flanking poles where it passes over the
# road. So, where Road.shp exists, derive each marker directly: intersect the route with
# the road lines, then walk out along the CABLE to the erf edge each side. The marker lies
# ON the cable by construction, and its endpoints ARE the R5.2 flanking pole positions.
_ROADS_P = os.path.join(D, "Road.shp")
HAVE_ROADS = os.path.exists(_ROADS_P)
if HAVE_ROADS:
    _rsegs = []
    _rds = ogr.Open(_ROADS_P)   # keep the DataSource referenced or the Layer proxy dangles
    for _f in _rds.GetLayer():
        _g = _f.GetGeometryRef().Clone(); _g.FlattenTo2D(); _g.Transform(fwd)
        _stk = [_g]
        while _stk:
            _x = _stk.pop()
            if _x.GetGeometryName() == "LINESTRING":
                _p2 = [(_x.GetX(i), _x.GetY(i)) for i in range(_x.GetPointCount())]
                _rsegs += [(np.array(a2), np.array(b2)) for a2, b2 in zip(_p2[:-1], _p2[1:])]
            elif _x.GetGeometryCount():
                _stk += [_x.GetGeometryRef(i) for i in range(_x.GetGeometryCount())]
    _rmid = np.array([(a2 + b2) / 2 for a2, b2 in _rsegs])
    _rhalf = np.array([float(np.hypot(*(b2 - a2))) / 2 for a2, b2 in _rsegs])
    _rtree = cKDTree(_rmid)
    _rpad = float(_rhalf.max()) if len(_rhalf) else 0.0

    for kind, c in routes:
        pts, st = walk(c, SAMPLE_M)
        if len(pts) < 2: continue
        hits = []
        for k in range(len(pts) - 1):
            a, b = pts[k], pts[k + 1]
            v = b - a
            L = float(np.hypot(*v))
            if L <= 0: continue
            for jj in _rtree.query_ball_point((a + b) / 2, L / 2 + _rpad + 1e-6):
                a2, b2 = _rsegs[jj]
                ba = b2 - a2      # explicit 2-D cross products (np.cross deprecated for 2-vectors)
                d1 = v[0] * (a2 - a)[1] - v[1] * (a2 - a)[0]
                d2 = v[0] * (b2 - a)[1] - v[1] * (b2 - a)[0]
                d3 = ba[0] * (a - a2)[1] - ba[1] * (a - a2)[0]
                d4 = ba[0] * (b - a2)[1] - ba[1] * (b - a2)[0]
                if d1 * d2 < 0 and d3 * d4 < 0:
                    # A CROSSING IS TRANSVERSE. A cable running ALONG a road weaves over the
                    # OSM centreline again and again, and each weave passes the segment-
                    # intersection test above -- so before the feeder was routed on roads
                    # this cost nothing, and after it the crossing poles went 611 -> 1,022
                    # and 428 poles landed in the roadway (2026-09-09). Require the cable to
                    # meet the road at XING_MIN_ANGLE or more; below that it is running
                    # alongside, which is what a feeder on the verge does by design.
                    nb = float(np.hypot(*ba))
                    if nb > 1e-9:
                        ang = abs(np.degrees(np.arcsin(np.clip(
                            abs(v[0] * ba[1] - v[1] * ba[0]) / (L * nb), -1, 1))))
                        if ang < XING_MIN_ANGLE: continue
                    tpar = abs(d3) / (abs(d3) + abs(d4) + 1e-12)
                    hits.append((st[k] + tpar * L, jj))
        hits.sort()
        merged = []
        for h in hits:
            if merged and h[0] - merged[-1][0] < 6.0: continue
            merged.append(h)
        # The marker is the stretch between the two FLANKING POLES (R5.2). The walk-out
        # ends where the cable reaches an erf -- with the R5.5 tolerance, because Contains()
        # excludes the boundary and the cable runs ON boundaries (R3.9) -- or where the
        # cable TURNS to run along the far side, since that turn is itself a pole (R5.9,
        # operator: "go straight over, place a second pole, and run down or up from that
        # one"). Measured before this (F-49): the strict-Contains walk overran along the
        # road up to ROAD_MAX, so 25% of Middelburg markers were >24 m (the reference: 3%)
        # and the chord between the ends ran ALONG the road instead of across it.
        def _turn(k):
            if k <= 0 or k >= len(pts) - 1: return 0.0
            u = pts[k] - pts[k - 1]; w = pts[k + 1] - pts[k]
            nu, nw = float(np.hypot(*u)), float(np.hypot(*w))
            if nu < 1e-6 or nw < 1e-6: return 0.0
            return float(np.degrees(np.arccos(np.clip(np.dot(u, w) / (nu * nw), -1, 1))))
        def _clear(k, jj):
            """metres from pts[k] to the road segment the cable crossed"""
            a2, b2 = _rsegs[jj]; ba = b2 - a2; nb = float(ba @ ba)
            t = 0.0 if nb < 1e-12 else min(1.0, max(0.0, float((pts[k] - a2) @ ba) / nb))
            return float(np.hypot(*(pts[k] - (a2 + t * ba))))
        def _stop(k, jj): return (near_erf(*pts[k], XING_ERF_TOL) or _turn(k) >= XING_BEND_STOP
                                  or _clear(k, jj) >= XING_CLEAR_M)
        for s0, jj in merged:
            i0 = int(np.searchsorted(st, s0))
            i0 = max(0, min(i0, len(pts) - 1))
            # 🔴 THE WALK MUST CLEAR THE CARRIAGEWAY BEFORE IT MAY STOP.
            # `_stop` ends the walk-out at an erf edge, and in Ventersdorp the erven run
            # right up to (and across) the road reserve -- so at many crossings an erf sits
            # within the 0.5 m tolerance of the crossing point ITSELF. Both walks then
            # stopped immediately, W came out under 2 m, and `continue` discarded a real
            # crossing without a word. Measured 2026-09-10: 18 unmarked distribution
            # crossings site-wide, 8 of the 10 sampled had an erf within 0.5 m; the operator
            # spotted one of them by eye ("you only added a road crossing to one of the two
            # that I did").
            # A crossing is at least as wide as the road, so the walk has to travel
            # XING_MIN_OUT before an erf edge is allowed to end it.
            k_lo = i0
            while (k_lo > 0 and s0 - st[k_lo] < ROAD_MAX
                   and (s0 - st[k_lo] < XING_MIN_OUT or not _stop(k_lo, jj))):
                k_lo -= 1
            k_hi = i0
            while (k_hi < len(pts) - 1 and st[k_hi] - s0 < ROAD_MAX
                   and (st[k_hi] - s0 < XING_MIN_OUT or not _stop(k_hi, jj))):
                k_hi += 1
            W = float(st[k_hi] - st[k_lo])
            if W < 2.0: continue
            # operator 2026-10-19: a crossing is Drill or Trench, nothing else -- longer than DRILL_MAX is Trench
            t = "Drill" if W <= DRILL_MAX else "Trench"
            crossings.append((kind, float(st[k_lo]), float(st[k_hi]),
                              pts[k_lo], pts[k_hi], W, t, pts[k_lo], pts[k_hi],
                              pts[k_lo:k_hi + 1]))      # the cable piece itself
else:
    for kind, c in routes:
        pts, st = walk(c, SAMPLE_M)
        off = np.array([not on_erf(*p) for p in pts])
        i = 0
        while i < len(off):
            if not off[i]: i += 1; continue
            j = i
            while j+1 < len(off) and off[j+1]: j += 1
            L = st[j] - st[i]
            # A road crossing has erven on BOTH sides. An off-erf run that runs off the end of
            # the cable, or opens onto open ground, is not a crossing -- it is the veld, and
            # counting it was most of the false positives.
            flanked = i > 0 and j < len(off)-1
            # A crossing comes out on the OTHER SIDE of the corridor. Cable merely running
            # along a boundary re-enters an erf in the same block -- one that touches, or
            # nearly touches, the erf it just left. Those are not crossings.
            crosses = False
            if flanked:
                ea, eb = erf_at(*pts[i-1]), erf_at(*pts[j+1])
                if ea >= 0 and eb >= 0 and ea != eb:
                    gap = erven[ea].Distance(erven[eb])
                    crosses = gap > 3.0
            if crosses and gap <= ROAD_MAX:
                # The marker is the TRANSVERSE part of the run, not the whole run. Where the
                # cable travels along a road and then turns across it, the off-erf run covers
                # both, and marking all of it draws a long line down the road instead of a
                # short one across it -- which is what "the crossings follow the cable" looks
                # like on screen. Centre the marker on the point of maximum clearance (the
                # middle of the corridor) and give it the corridor's width.
                def clear(p):
                    q = ogr.Geometry(ogr.wkbPoint); q.AddPoint_2D(float(p[0]), float(p[1]))
                    return min(erven[ea].Distance(q), erven[eb].Distance(q))
                k = max(range(i, j+1), key=lambda m: clear(pts[m]))
                half = min(0.8*gap, L/2)
                a = max(i-1, int(np.searchsorted(st, st[k]-half)))
                b = min(j+1, int(np.searchsorted(st, st[k]+half)))
                a, b = max(a, 0), min(b, len(pts)-1)
                W = st[b] - st[a]
                if W < 3.0 or W > ROAD_MAX: i = j + 1; continue
                t = "Drill" if W <= DRILL_MAX else "Trench"     # operator 2026-10-19: Drill or Trench only
                # R7.6 — the marker and the poles are SEPARATE layers. The marker is the
                # transverse segment across the corridor; the flanking poles stand on the erf
                # either side (R5.5/R5.7), which is not the same pair of points.
                crossings.append((kind, st[a], st[b], pts[a], pts[b], W, t,
                                  pts[i-1], pts[j+1]))
            i = j + 1


# One road crossed at one place is ONE marker, even where several cables cross together.
# R3.13 has the feeder deliberately running alongside the distribution cable, so the same
# physical crossing is otherwise counted once per cable.
DEDUPE_M = 12.0
crossings.sort(key=lambda x: -x[5])          # keep the longest of a duplicate group
kept = []
for x in crossings:
    mid = (x[3] + x[4]) / 2
    if any(float(np.hypot(*(mid - (k[3]+k[4])/2))) < DEDUPE_M for k in kept): continue
    kept.append(x)
print(f"crossings before dedupe {len(crossings)} -> after {len(kept)}")
crossings = kept
grey = sum(1 for x in crossings if x[6] == "ESCALATE")

if have("ref_trenching"):
    gt_tr = lines(shp(LYR("ref_trenching")))
    gt_len = np.array([float(np.hypot(*(c[1:]-c[:-1]).T).sum()) for c in gt_tr])
    gt_mid = np.array([c[len(c)//2] for c in gt_tr])
else:
    print("no reference Trenching layer for this site: crossing comparison skipped")
    gt_tr, gt_len, gt_mid = [], np.zeros(0), np.zeros((0, 2))
ours_mid = np.array([(x[3]+x[4])/2 for x in crossings]) if crossings else np.zeros((0, 2))
lens = np.array([x[5] for x in crossings])
# ---- D5 (operator 2026-08-29): a crossing must actually CROSS A ROAD. The erf-gap
# heuristic above predates having road data (F-16) and mislabels corner connectors as
# crossings -- measured 94 of 361 (26%) on WUVS never touch a road line. Where the site
# carries Road.shp, validate every marker against the road network and DROP the fakes.
_rds_path = os.path.join(D, "Road.shp")
if os.path.exists(_rds_path):
    _rg = ogr.Geometry(ogr.wkbMultiLineString)
    _rds = ogr.Open(_rds_path)
    for _f in _rds.GetLayer():
        _g = _f.GetGeometryRef().Clone(); _g.FlattenTo2D(); _g.Transform(fwd)
        _st = [_g]
        while _st:
            _x = _st.pop()
            if _x.GetGeometryName() == "LINESTRING": _rg.AddGeometry(_x.Clone())
            elif _x.GetGeometryCount():
                _st += [_x.GetGeometryRef(i) for i in range(_x.GetGeometryCount())]
    # 🔴 A MARKER THAT LIES ALONG THE ROAD IS NOT A CROSSING. P1 puts the feeder on the
    # property line where the OSM line is metres off the real road (2026-10-20), so the feeder
    # can drift across the OSM line at a shallow angle and pass the angle test. A real crossing
    # meets the road at XING_MIN_ANGLE (20 deg) or more, so at most 3 / sin 20 x 2 = 17.5 m of it
    # lies within 3 m of the road line; the drifting ones on Vrede had ~31 m. More than
    # XING_ALONG_M there and it is running along the road. (A share does not work: a 10 m square
    # crossing of a narrow road is 60% within 3 m.)
    _rb = _rg.Buffer(3.0, 4)
    _keep, _along = [], 0
    for x in crossings:
        _s = ogr.Geometry(ogr.wkbLineString)
        _s.AddPoint_2D(float(x[3][0]), float(x[3][1]))
        _s.AddPoint_2D(float(x[4][0]), float(x[4][1]))
        if not _s.Intersects(_rg): continue
        _c = ogr.Geometry(ogr.wkbLineString)
        for _q in (x[9] if len(x) > 9 else (x[3], x[4])): _c.AddPoint_2D(float(_q[0]), float(_q[1]))
        if _c.Intersection(_rb).Length() > XING_ALONG_M:
            _along += 1; continue
        _keep.append(x)
    _dropped = len(crossings) - len(_keep) - _along
    crossings = _keep
    print(f"\ncrossing markers validated against Road.shp: {_dropped} dropped "
          f"(no road under them), {_along} dropped (lying along the road), {len(crossings)} remain")

# ---- plugin stages: honour the operator's APPROVED crossings ----
_xg = os.environ.get("PS_CROSSINGS_GPKG")
if _xg and STAGE in ("poles", "hardware"):
    _ds = ogr.Open(_xg); _l = _ds.GetLayerByName("claude_road_crossings")
    _approved = []
    for _f in _l:
        _g = _f.GetGeometryRef().Clone(); _g.Transform(fwd); _approved.append(_g)
    def _xmid(x):
        p0, p1 = x[3], x[4]
        return ogr.CreateGeometryFromWkt(f"POINT ({(p0[0]+p1[0])/2} {(p0[1]+p1[1])/2})")
    _kept = [x for x in crossings if any(_xmid(x).Distance(a) <= 2.0 for a in _approved)]
    _unmatched = sum(1 for a in _approved if not any(_xmid(x).Distance(a) <= 2.0 for x in crossings))
    print(f"approved crossings: {len(_approved)} loaded, {len(_kept)}/{len(crossings)} recomputed kept, "
          f"{_unmatched} approved with no recomputed match (operator-added; not reproduced)")
    crossings = _kept

print(f"\n--- Step 7: road crossings ---")
print(f"crossings found        {len(crossings):>5}{ref('crossings')}")
print(f"  Drill (<={DRILL_MAX:.0f} m)      {sum(1 for x in crossings if x[6]=='Drill'):>5}{ref('drill')}")
print(f"  Trench (>{DRILL_MAX:.0f} m)      {sum(1 for x in crossings if x[6]=='Trench'):>5}{ref('trench')}")
if len(lens):
    print(f"crossing length  median {np.median(lens):.1f} m   max {lens.max():.1f} m"
          f"{ref('crossing_stats')}")
if len(ours_mid) and len(gt_mid):
    d, _ = cKDTree(gt_mid).query(ours_mid)
    hit = int((d <= 15.0).sum())
    d2, _ = cKDTree(ours_mid).query(gt_mid)
    rec = int((d2 <= 15.0).sum())
    print(f"matched to a reference crossing within 15 m: {hit}/{len(ours_mid)} "
          f"({100*hit/len(ours_mid):.0f}% precision)")
    print(f"reference crossings we found:                {rec}/{len(gt_tr)} "
          f"({100*rec/len(gt_tr):.0f}% recall)")

# ================= STEP 5 — poles =================
# Each pole is (x, y, role, cable) -- `cable` is "dc" or "feeder", and it decides the pole
# HEIGHT downstream (spec: feeder 7 m, distribution midblock 5-6 m).
poles = [(p[0], p[1], "collection", "dc") for p in CP]           # R5.1
for x in crossings:                                               # R5.2
    q0, q1 = x[7], x[8]          # on-erf points either side, NOT the marker ends
    poles.append((q0[0], q0[1], "crossing", x[0]))
    poles.append((q1[0], q1[1], "crossing", x[0]))

# R5.9 / R5.10 / R5.11 — MEASURED FROM THE REFERENCE 2026-08-20, not in planning-spec.md.
# Aerial cable cannot change direction in mid-air and cannot terminate on nothing, so the
# human plants a pole at every bend, every run end and every junction. Measured on their
# design: bends 5-15 deg 100%, 15-30 deg 91%, 30-60 deg 94%, 60+ deg 96%; run ends 166/166
# = 100%; junctions 1/1. Ours had 33-66% of bends and 26% of ends -- exactly the missing
# poles Zander spotted on screen.
BEND_MIN_DEG = 5.0
# THE FEEDER MUST BE CARRIED TOO. Until 2026-09-09 these loops ran over `dc` alone, because
# the feeder was an operator INPUT and its poles were their business. Under the wayleave the
# feeder is OUR output, and it was being drawn with no poles under it at all: measured on
# Ventersdorp, 25,692 m of feeder had 224 poles near it and every one was a road-CROSSING
# pole -- nothing carrying the cable between crossings. Operator, 2026-09-09: "we do need
# poles to carry the feeder cable."
# Aerial cable cannot change direction in mid-air or terminate on nothing, and that is as
# true of the feeder as of the distribution, so the same three rules apply to both routes.
# The cable each pole carries is recorded, because the spec gives them DIFFERENT HEIGHTS:
# "Feeder poles should always be 7m"; distribution is "5m or 6m poles deployed in midblock".
for kind, c in routes:
    if len(c) < 2: continue
    poles.append((c[0][0], c[0][1], "terminal", kind))          # R5.10
    poles.append((c[-1][0], c[-1][1], "terminal", kind))
    for i in range(1, len(c)-1):                                # R5.9
        v1 = c[i] - c[i-1]; v2 = c[i+1] - c[i]
        n1 = float(np.hypot(*v1)); n2 = float(np.hypot(*v2))
        if n1 < 1e-6 or n2 < 1e-6: continue
        ang = np.degrees(np.arccos(np.clip(float(np.dot(v1, v2))/(n1*n2), -1.0, 1.0)))
        if ang >= BEND_MIN_DEG: poles.append((c[i][0], c[i][1], "bend", kind))

# One physical pole per location: collection points, crossings, bends and terminals all
# land on the cable and frequently coincide. Keep the most specific role.
PRIORITY = {"collection": 0, "crossing": 1, "junction": 2, "bend": 3, "terminal": 4}
POLE_DEDUPE_M = 2.5
poles.sort(key=lambda p: PRIORITY.get(p[2], 9))
kept = []; karr = []
for x, y, role, cable in poles:
    if karr and min(float(np.hypot(x-a, y-b)) for a, b in karr) < POLE_DEDUPE_M: continue
    kept.append((x, y, role, cable)); karr.append((x, y))
print(f"poles after bend/terminal rules and dedupe: {len(poles)} -> {len(kept)}")
poles = kept

# R5.3 — add poles along each cable so no consecutive span exceeds the ceiling
ptree_pts = np.array([(p[0], p[1]) for p in poles])
added = 0
# Both cables need span poles: a 25.7 km feeder with none would hang in mid-air.
for li, (kind, c) in enumerate(routes):
    pts, st = walk(c, 1.0)
    if len(pts) < 2: continue
    d, idx = cKDTree(pts).query(ptree_pts)
    on = sorted(set(st[idx[d <= 3.0]].tolist()))                  # poles sitting on this line
    on = [0.0] + on + [st[-1]]
    on = sorted(set(round(v, 2) for v in on))
    for a, b in zip(on[:-1], on[1:]):
        gap = b - a
        if gap <= SPAN_CAP_M: continue
        n = int(np.ceil(gap / SPAN_CAP_M)) - 1
        for k in range(1, n+1):
            s = a + gap*k/(n+1)
            j = int(np.searchsorted(st, s)); j = min(max(j, 0), len(pts)-1)
            # R5.5 — a pole stands on an erf, not in the roadway. Nudge along the route to
            # the nearest on-erf sample; if the whole neighbourhood is road, leave it and
            # let the metric report it.
            if not on_erf(*pts[j]):
                # the nudge must never push a sub-span back over the ceiling (found
                # 2026-08-28: a 15 m nudge on a wide gap left one 71 m span standing).
                # Each side of this pole is gap/(n+1); it may move at most the slack.
                max_off = int(min(15.0, SPAN_CAP_M - gap / (n + 1)))
                for off in range(1, max(max_off, 0) + 1):
                    for cand in (j-off, j+off):
                        if 0 <= cand < len(pts) and on_erf(*pts[cand]): j = cand; break
                    else: continue
                    break
            poles.append((pts[j][0], pts[j][1], "span", kind)); added += 1
print(f"\n--- Step 5: poles ---")
print(f"collection poles (R5.1) {sum(1 for p in poles if p[2]=='collection'):>5}{ref('poles_collection')}")
print(f"crossing poles   (R5.2) {sum(1 for p in poles if p[2]=='crossing'):>5}{ref('poles_crossing')}")
print(f"bend poles       (R5.9) {sum(1 for p in poles if p[2]=='bend'):>5}   (measured rule, not in spec)")
print(f"terminal poles  (R5.10) {sum(1 for p in poles if p[2]=='terminal'):>5}   (measured rule, not in spec)")
print(f"   of which carry the FEEDER: {sum(1 for p in poles if p[3]=='feeder'):>5}   (7 m poles; the feeder had NONE before 2026-09-09)")
print(f"span poles       (R5.3) {added:>5}{ref('poles_span')}")
print(f"total poles             {len(poles):>5}{ref('poles')}")

# verify the span constraint actually holds, the same way R5.4 was measured
allp = np.array([(p[0], p[1]) for p in poles])
spans = []
for kind, c in routes:
    pts, st = walk(c, 1.0)
    d, idx = cKDTree(pts).query(allp)
    on = sorted(set(st[idx[d <= 3.0]].tolist()))
    spans += [b-a for a, b in zip(on[:-1], on[1:]) if b > a]
spans = np.array(spans)
if len(spans):
    print(f"span  median {np.median(spans):.1f} m   p90 {np.percentile(spans,90):.1f} m   "
          f"max {spans.max():.1f} m{ref('span_stats')}")
    print(f"spans over {SPAN_CAP_M:.0f} m   {(spans > SPAN_CAP_M + 0.5).sum():>5}   (must be 0)")
oe = sum(1 for p in poles if near_erf(p[0], p[1]))
print(f"poles standing on an erf (R5.5) {oe}/{len(poles)} ({100*oe/len(poles):.0f}%)"
      f"{ref('poles_on_erf')}")

# ---- POLE-IN-ROADWAY AUDIT (operator 2026-08-29: 'you placed the pole in the middle of
# the road'). A pole off every erf AND within the road corridor is a build error, not a
# statistic. Where Road.shp exists, RELOCATE it along its own cable to the nearest on-erf
# sample within the span slack; whatever cannot move is COUNTED AND FLAGGED loudly.
if os.path.exists(os.path.join(D, "Road.shp")):
    _rpts = []
    _rds = ogr.Open(os.path.join(D, "Road.shp"))
    for _f in _rds.GetLayer():
        _g = _f.GetGeometryRef().Clone(); _g.FlattenTo2D(); _g.Transform(fwd)
        _st = [_g]
        while _st:
            _x = _st.pop()
            if _x.GetGeometryName() == "LINESTRING":
                _p2 = [(_x.GetX(i), _x.GetY(i)) for i in range(_x.GetPointCount())]
                for _a, _b in zip(_p2[:-1], _p2[1:]):
                    _L = float(np.hypot(_b[0]-_a[0], _b[1]-_a[1])); _n = max(int(_L/2), 1)
                    _rpts += [(_a[0]+(_b[0]-_a[0])*k/_n, _a[1]+(_b[1]-_a[1])*k/_n)
                              for k in range(_n+1)]
            elif _x.GetGeometryCount():
                _st += [_x.GetGeometryRef(i) for i in range(_x.GetGeometryCount())]
    _rt = cKDTree(np.array(_rpts))
    # THE TEST IS DIFFERENT FOR THE TWO CABLES, because the two deployments are different.
    # TSD sec1: a midblock distribution pole is a PRIVATE deployment -- planted inside a
    # property under the "midblock servitude" -- so being off every erf means it is in the
    # road, which is the build error the operator photographed. A FEEDER pole is a PUBLIC
    # deployment: it stands in the municipal road reserve, on the VERGE, and is not
    # supposed to be on an erf at all ("No street poles closer than 1-meter from a property
    # boundary", TSD sec2). Judging it by the erf test flags every correct feeder pole --
    # measured 2026-09-09: adding the feeder's own poles took this count 108 -> 246 purely
    # by mis-classification.
    # So: distribution poles must be ON AN ERF; feeder poles must merely be CLEAR OF THE
    # CARRIAGEWAY. Both are still real failures when they fail.
    # P1 runs the feeder 2 m inside the road reserve from the property line wherever one is
    # near, because the OSM line can be metres off the real road (2026-10-20). A feeder pole
    # that close to a property line is beside the road, however near the OSM line it is.
    _in_road = [k for k, p in enumerate(poles)
                if (_rt.query((p[0], p[1]))[0] <= CARRIAGEWAY_HALF_M and not near_erf(p[0], p[1], 2.5)
                    if p[3] == "feeder"
                    else (not near_erf(p[0], p[1]) and _rt.query((p[0], p[1]))[0] <= 3.5))]
    _moved = 0
    for k in _in_road:
        p = poles[k]
        best = None
        for c in dc:
            pts2, st2 = walk(c, 1.0)
            d2, j2 = cKDTree(pts2).query((p[0], p[1]))
            if d2 > 2.0: continue
            for off in range(1, 16):
                for cand in (j2-off, j2+off):
                    if 0 <= cand < len(pts2) and near_erf(*pts2[cand]) \
                       and _rt.query(pts2[cand])[0] > 3.5:
                        best = pts2[cand]; break
                if best is not None: break
            if best is not None: break
        if best is not None:
            poles[k] = (float(best[0]), float(best[1]), p[2], p[3]); _moved += 1
    _left = len(_in_road) - _moved
    _lf = sum(1 for k in _in_road[_moved:] if poles[k][3] == "feeder")
    print(f"poles IN THE ROADWAY: {len(_in_road)} found, {_moved} relocated along cable, "
          f"{_left} REMAIN -- {'FLAG FOR OPERATOR' if _left else 'clean'}")
    print(f"   distribution poles off every erf and in the road: {_left - _lf}")
    print(f"   feeder poles inside the {CARRIAGEWAY_HALF_M:.1f} m carriageway: {_lf}"
          f"   (a feeder pole on the VERGE is correct -- TSD public deployment)")

# ================= STEP 6 — splitters and dome joints =================
# R6.2/R6.6: position inherited exactly from the collection point, emitted together.
splitters = [(p[0], p[1]) for p in CP]
domes = [(p[0], p[1]) for p in CP]
print(f"\n--- Step 6: splitters and dome joints ---")
print(f"8-way splitters {len(splitters):>5}{ref('splitters')}")
print(f"dome joints     {len(domes):>5}{ref('dome_joints')}")
print(f"coincident with their collection point: "
      f"{sum(1 for a, b in zip(splitters, domes) if a == b)}/{len(splitters)} (R6.3 requires 100%)")

# ---- write ----
suffix = "" if STAGE == "all" else f"_{STAGE}"
dst = os.path.join(OUT, f"claude_step567{TAG}{suffix}.gpkg")
if os.path.exists(dst): ogr.GetDriverByName("GPKG").DeleteDataSource(dst)
ds = ogr.GetDriverByName("GPKG").CreateDataSource(dst)

if "crossings" in WANT:
    lyr = ds.CreateLayer("claude_road_crossings", wgs, ogr.wkbLineString)
    for n_, t_ in (("type", ogr.OFTString), ("length_m", ogr.OFTReal)):
        lyr.CreateField(ogr.FieldDefn(n_, t_))
    for x in crossings:
        p0, p1, L, t = x[3], x[4], x[5], x[6]
        g = ogr.Geometry(ogr.wkbLineString)
        # road-derived markers carry the cable piece itself (on the cable by construction);
        # the no-roads fallback still draws the transverse chord
        for q in (x[9] if len(x) > 9 else (p0, p1)):
            g.AddPoint_2D(float(q[0]), float(q[1]))
        g.Transform(rev)
        f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
        f.SetField("type", t); f.SetField("length_m", round(float(L), 2))
        lyr.CreateFeature(f); f = None

if "poles" in WANT:
    lyr = ds.CreateLayer("claude_poles", wgs, ogr.wkbPoint)
    for _n, _t in (("role", ogr.OFTString), ("cable", ogr.OFTString),
                   ("height_m", ogr.OFTReal)):
        lyr.CreateField(ogr.FieldDefn(_n, _t))
    # POLE HEIGHT IS SET BY THE SPEC, and it differs by cable and by role:
    #   feeder                : "Feeder poles should always be 7m poles" (GPON standard p2)
    #   distribution midblock : "5m or 6m poles deployed in midblock"    (p3)
    #   any road crossing     : "Place 7m poles on each side of road for road crossings" (p3)
    # The BOM depends on this, so it is written per pole rather than left to be assumed.
    # Under SPEC_SHEET these fallbacks apply only to keys the sheet marks not_applicable (client_spec.limit).
    H_FEEDER = float(limit("pole_feeder_m", 7.0))
    H_CROSS = float(limit("pole_crossing_m", 7.2))
    _mid = limit("pole_midblock_m", (5.4,))
    H_MIDBLOCK = float(_mid[0] if isinstance(_mid, (tuple, list)) else _mid)
    for x, y, role, cable in poles:
        h = H_CROSS if role == "crossing" else (H_FEEDER if cable == "feeder" else H_MIDBLOCK)
        g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(float(x), float(y)); g.Transform(rev)
        f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g)
        f.SetField("role", role); f.SetField("cable", "feeder" if cable == "feeder" else "distribution")
        f.SetField("height_m", h)
        lyr.CreateFeature(f); f = None

if "hardware" in WANT:
    for name, pts in (("claude_8way_splitters", splitters), ("claude_dome_joints", domes)):
        lyr = ds.CreateLayer(name, wgs, ogr.wkbPoint)
        lyr.CreateField(ogr.FieldDefn("cp_id", ogr.OFTInteger))
        for k, (x, y) in enumerate(pts):
            g = ogr.Geometry(ogr.wkbPoint); g.AddPoint_2D(float(x), float(y)); g.Transform(rev)
            f = ogr.Feature(lyr.GetLayerDefn()); f.SetGeometry(g); f.SetField("cp_id", k)
            lyr.CreateFeature(f); f = None

ds = None
print(f"\nwrote {dst}")

json.dump({"crossings": len(crossings),
           "drill": sum(1 for x in crossings if x[6] == "Drill"),
           "trench": sum(1 for x in crossings if x[6] == "Trench"),
           "escalate_grey_band": grey,
           "poles_total": len(poles),
           "poles_collection": sum(1 for p in poles if p[2] == "collection"),
           "poles_crossing": sum(1 for p in poles if p[2] == "crossing"),
           "poles_span": added,
           "span_median_m": round(float(np.median(spans)), 1) if len(spans) else None,
           "span_max_m": round(float(spans.max()), 1) if len(spans) else None,
           "spans_over_cap": int((spans > SPAN_CAP_M + 0.5).sum()) if len(spans) else None,
           "poles_on_erf_pct": round(100*oe/len(poles), 1),
           "splitters": len(splitters), "dome_joints": len(domes)},
          open(os.path.join(OUT, "step567_metrics.json"), "w"), indent=2)
