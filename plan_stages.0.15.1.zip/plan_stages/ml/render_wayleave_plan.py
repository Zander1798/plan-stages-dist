"""SHOW THE FINISHED WAYLEAVE PLAN OVER SATELLITE, so the operator can look at it.

Operator, 2026-09-09: *"I have no idea what it looks like. You're going to have to show me
the plan when you're done planning it."* Every number this pipeline reports is an aggregate,
and sec0.19 has said since 2026-09-07 that the visual check is mandatory every wave -- the
render is what caught the feeder running mid-block and the poles standing in the road, both
of which the metrics called fine.

Draws, over Google satellite:
    FEEDER        thick cyan     -- ours, roadside, POP -> every PON
    DISTRIBUTION  magenta        -- the operator's span, classified as distribution
    DROPS         thin green     -- to each home
    CROSSINGS     yellow         -- where cable crosses a road
    POLES         red dots, and feeder poles as larger orange dots (7 m vs 5.4 m)
    1:16          big yellow stars -- one per PON, the root of each tree
    PON edges     dashed white

Three scales, because different defects show at different zooms:
    SITE      the whole AOI -- does the feeder reach everywhere, is anything stranded?
    BLOCK     ~600 m        -- how the feeder and distribution relate
    DETAIL    ~150 m        -- drops, poles, splitters; the constructability view

Env: SITE_DIR, SITE_EPSG, PLAN_DIR (default work), LAYER_PONS, AT ("x,y;x,y"), TAG
Out: PLAN_DIR/render/<TAG>_<scale>_<k>.png       (run under python-qgis.bat)
"""
import os
import sys

import numpy as np
from qgis.core import (QgsApplication, QgsVectorLayer, QgsRasterLayer, QgsMapSettings,
                       QgsMapRendererParallelJob, QgsRectangle, QgsLineSymbol,
                       QgsMarkerSymbol, QgsFillSymbol, QgsCoordinateReferenceSystem,
                       QgsRuleBasedRenderer)
from qgis.PyQt.QtGui import QColor, QImage, QPainter, QFont
from qgis.PyQt.QtCore import QSize, Qt
from osgeo import ogr, osr

ogr.UseExceptions()
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = r"C:/Users/zande/Documents/AI Workspace/QGIS Automation"
SITE_DIR = os.environ["SITE_DIR"]
EPSG = int(os.environ["SITE_EPSG"])
PLAN = os.environ.get("PLAN_DIR", os.path.join(ROOT, "work"))
PONS = os.environ.get("LAYER_PONS", "Pons")
TAG = os.environ.get("TAG", "plan")
OUT = os.path.join(PLAN, "render"); os.makedirs(OUT, exist_ok=True)

qgs = QgsApplication([], False); qgs.initQgis()
CRS = QgsCoordinateReferenceSystem("EPSG:%d" % EPSG)


def line(rgb, w, style=None):
    s = QgsLineSymbol.createSimple({"line_style": style} if style else {})
    s.setColor(QColor(*rgb)); s.setWidth(w)
    return s


def marker(rgb, size, shape="circle", stroke=None):
    s = QgsMarkerSymbol.createSimple({"name": shape, "size": str(size)})
    s.setColor(QColor(*rgb))
    s.symbolLayer(0).setStrokeColor(QColor(*(stroke or rgb)))
    s.symbolLayer(0).setStrokeWidth(0.2 if stroke else 0)
    return s


def outline(rgb, w, style="dash"):
    return QgsFillSymbol.createSimple({"style": "no", "outline_color": "%d,%d,%d" % rgb,
                                       "outline_width": str(w), "outline_style": style})


def vec(path, name, sym):
    l = QgsVectorLayer(path, name, "ogr")
    if not l.isValid():
        print("   (missing) " + name)
        return None
    if sym is not None:
        l.renderer().setSymbol(sym)
    return l


sat = QgsRasterLayer(
    "type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D{x}%26y%3D{y}%26z%3D{z}&zmax=20&zmin=0",
    "Google Satellite", "wms")

S3 = os.path.join(PLAN, "step3"); S4 = os.path.join(PLAN, "step4"); S5 = os.path.join(PLAN, "step567")

# poles: feeder poles drawn larger and orange, because their height differs (7 m vs 5.4 m)
poles = QgsVectorLayer(os.path.join(S5, "claude_step567.gpkg") + "|layername=claude_poles",
                       "poles", "ogr")
if poles.isValid() and poles.fields().indexFromName("cable") >= 0:
    root = QgsRuleBasedRenderer.Rule(None)
    for expr, lbl, sym in (("\"cable\" = 'feeder'", "feeder pole 7 m", marker((255, 165, 0), 1.9)),
                           ("ELSE", "distribution pole", marker((255, 70, 70), 1.2))):
        r = QgsRuleBasedRenderer.Rule(sym)
        if expr == "ELSE": r.setIsElse(True)
        else: r.setFilterExpression(expr)
        r.setLabel(lbl); root.appendChild(r)
    poles.setRenderer(QgsRuleBasedRenderer(root))

# top of the list draws on top
LAYERS = [
    vec(os.path.join(S3, "claude_1to16_splitters.gpkg") + "|layername=claude_1to16_splitters",
        "1:16", marker((255, 255, 0), 5.5, "star", (0, 0, 0))),
    vec(os.path.join(S4, "claude_step4.gpkg") + "|layername=claude_collection_points",
        "collection points", marker((0, 255, 255), 2.6, "circle", (0, 0, 0))),
    poles if poles.isValid() else None,
    vec(os.path.join(S5, "claude_step567.gpkg") + "|layername=claude_road_crossings",
        "crossings", line((255, 235, 0), 1.6)),
    vec(os.path.join(S3, "claude_feeder_cable.gpkg") + "|layername=claude_feeder_cable",
        "FEEDER", line((0, 225, 255), 2.0)),
    vec(os.path.join(S3, "claude_distribution_cable.gpkg") + "|layername=claude_distribution_cable",
        "distribution", line((255, 0, 220), 1.0)),
    vec(os.path.join(S4, "claude_step4.gpkg") + "|layername=claude_drops",
        "drops", line((120, 255, 120), 0.35)),
    vec(os.path.join(SITE_DIR, PONS + ".shp"), "PONs", outline((255, 255, 255), 0.5)),
]
LAYERS = [l for l in LAYERS if l is not None]
if sat.isValid():
    LAYERS.append(sat)
else:
    print("*** satellite basemap unavailable -- rendering on black ***")

LEGEND = ("FEEDER (ours)  ·  distribution on operator span  ·  drops  ·  "
          "crossings  ·  poles: orange = feeder 7 m, red = distribution  ·  star = 1:16")


def extent_of(path, layer=None):
    ds = ogr.Open(path)
    l = ds.GetLayerByName(layer) if layer else ds.GetLayer(0)
    x0, x1, y0, y1 = l.GetExtent()
    sr = l.GetSpatialRef()
    if sr is not None and (sr.GetAuthorityCode(None) is None or int(sr.GetAuthorityCode(None)) != EPSG):
        src = sr.Clone(); dst = osr.SpatialReference(); dst.ImportFromEPSG(EPSG)
        for s in (src, dst): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        t = osr.CoordinateTransformation(src, dst)
        (x0, y0, _), (x1, y1, _) = t.TransformPoint(x0, y0), t.TransformPoint(x1, y1)
    return x0, x1, y0, y1


def shot(cx, cy, half, name, note, px=1500):
    ms = QgsMapSettings(); ms.setDestinationCrs(CRS); ms.setLayers(LAYERS)
    ms.setExtent(QgsRectangle(cx - half, cy - half, cx + half, cy + half))
    ms.setOutputSize(QSize(px, px)); ms.setBackgroundColor(QColor(15, 15, 18))
    job = QgsMapRendererParallelJob(ms); job.start(); job.waitForFinished()
    img = job.renderedImage()
    p = QPainter(img)
    p.fillRect(0, 0, px, 52, QColor(0, 0, 0, 190))
    p.setPen(QColor(255, 255, 255)); p.setFont(QFont("Arial", 15, QFont.Weight.Bold))
    p.drawText(14, 24, note)
    p.setFont(QFont("Arial", 11)); p.setPen(QColor(225, 225, 225))
    p.drawText(14, 44, LEGEND)
    p.end()
    out = os.path.join(OUT, name)
    img.save(out); print("wrote", out)


x0, x1, y0, y1 = extent_of(os.path.join(S3, "claude_distribution_cable.gpkg"),
                           "claude_distribution_cable")
cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
# abs: a Lo (south-oriented) CRS runs x westwards, so the transformed corners come back swapped (2026-10-19)
site_half = max(abs(x1 - x0), abs(y1 - y0)) / 2 * 1.04
shot(cx, cy, site_half, f"{TAG}_site.png",
     f"{os.environ.get('SITE', 'site').upper()} — WHOLE SITE  ({2 * site_half:,.0f} m across)")

# denser windows for the closer scales: the busiest places, spread out
ds = ogr.Open(os.path.join(S4, "claude_step4.gpkg"))
lyr = ds.GetLayerByName("claude_collection_points")
pts = []
for f in lyr:
    g = f.GetGeometryRef()
    if g is None: continue
    g = g.Clone()
    sr = lyr.GetSpatialRef()
    if sr is not None and (sr.GetAuthorityCode(None) is None or int(sr.GetAuthorityCode(None)) != EPSG):
        src = sr.Clone(); dst = osr.SpatialReference(); dst.ImportFromEPSG(EPSG)
        for s in (src, dst): s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        g.Transform(osr.CoordinateTransformation(src, dst))
    q = g if g.GetGeometryType() == ogr.wkbPoint else g.Centroid()
    pts.append((q.GetX(), q.GetY()))
P = np.array(pts)

AT = os.environ.get("AT", "").strip()
if AT:
    centres = [tuple(float(v) for v in a.split(",")) for a in AT.split(";") if a]
else:
    from scipy.spatial import cKDTree
    T = cKDTree(P)
    dens = np.array([len(T.query_ball_point(p, 120.0)) for p in P])
    order = np.argsort(-dens)
    centres = []
    for i in order:
        if all(abs(P[i][0] - c[0]) > 500 or abs(P[i][1] - c[1]) > 500 for c in centres):
            centres.append((float(P[i][0]), float(P[i][1])))
        if len(centres) >= 3:
            break

for k, (bx, by) in enumerate(centres, 1):
    shot(bx, by, 300.0, f"{TAG}_block_{k}.png", f"BLOCK VIEW {k} — 600 m across")
    shot(bx, by, 80.0, f"{TAG}_detail_{k}.png", f"DETAIL VIEW {k} — 160 m across")

# QGIS 3.44 crashes inside exitQgis() after every image is saved (0xC0000005, 2026-10-26), and the P7 Delivery
# stage reads the crash as a failure: end this one-shot process without the teardown (see build_qgis_project.py).
sys.stdout.flush(); sys.stderr.flush()
os._exit(0)
