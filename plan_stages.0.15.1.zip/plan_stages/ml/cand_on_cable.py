"""Where may a collection point stand? (Plan Stages 0.8.0, operator 2026-10-15)

The operator corrects the generated P1 cable; P4 must follow the correction. A wayleave pole is a candidate only
if it lies within ONCABLE_M of the approved distribution cable -- a pole the corrected cable left behind is never
used. Where the cable runs with no such pole within GAP_M (the measured wayleave pole spacing, 31.5 m), points
along the cable become candidates too; P6 then proposes a pole there and the operator corrects the poles in P6.

Measured on Ventersdorp: untouched P1 -> all 2,729 poles kept, 0 gap points (so the candidates are exactly the
0.7.0 ones); one 1,559 m line moved 15 m -> 37 poles dropped, 759 gap points along the moved line.
"""
import numpy as np
from scipy.spatial import cKDTree


def _densify(cable, step):
    pts = []
    for c in cable:
        for a, b in zip(c[:-1], c[1:]):
            n = max(int(float(np.hypot(*(b - a))) / step), 1)
            pts += [a + (b - a) * (k / n) for k in range(n)]
        pts.append(c[-1])
    return np.array(pts, float).reshape(-1, 2)


def _dist_to_piece(pts, c):
    """Exact distance from each point to one cable piece (all points against all its segments at once)."""
    a, ab = c[:-1], c[1:] - c[:-1]
    L2 = (ab ** 2).sum(1); L2[L2 == 0] = 1e-12
    rel = pts[:, None, :] - a[None, :, :]                        # (P, S, 2)
    t = np.clip((rel * ab[None]).sum(2) / L2[None], 0.0, 1.0)    # (P, S)
    return np.hypot(*(rel - ab[None] * t[:, :, None]).transpose(2, 0, 1)).min(1)


EPS = 1e-6           # csgraph reads an explicit 0 weight as "no edge"


def _along_cable_dist(cable, on, oncable_m, step_m, gap_m):
    """Densified cable points and, for each, the distance ALONG THE CONNECTED CABLE to the nearest on-cable pole
    (inf beyond gap_m). Pieces join where an end lies within step_m of another piece (shared vertex or a T onto a
    segment); a pole joins the cable points within oncable_m + step_m of it. A line that does not touch the poled
    cable is never covered by its poles, however close it runs (review 2026-10-15)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import dijkstra
    parts = [_densify([c], step_m) for c in cable]
    pts = np.vstack(parts); n = len(pts); rows, cols, w = [], [], []
    start = 0; ends = []; piece = np.repeat(np.arange(len(parts)), [len(p) for p in parts])
    for p in parts:                                   # consecutive points along each piece
        k = np.arange(start, start + len(p) - 1)
        rows += list(k); cols += list(k + 1); w += list(np.hypot(*(p[1:] - p[:-1]).T) + EPS)
        ends += [start, start + len(p) - 1]; start += len(p)
    tree = cKDTree(pts)
    for e in ends:                                    # joins to OTHER pieces (coo_matrix sums duplicate edges)
        for j in tree.query_ball_point(pts[e], step_m):
            if piece[j] != piece[e]:
                rows.append(e); cols.append(j); w.append(float(np.hypot(*(pts[j] - pts[e]))) + EPS)
    src = []
    for i, q in enumerate(on):                        # each on-cable pole is a source node n + i
        for j in tree.query_ball_point(q, oncable_m + step_m):
            rows.append(n + i); cols.append(j); w.append(float(np.hypot(*(pts[j] - q))) + EPS)
        src.append(n + i)
    m = n + len(on)
    g = coo_matrix((w, (rows, cols)), shape=(m, m)).tocsr()
    d = dijkstra(g, directed=False, indices=src, min_only=True, limit=gap_m) if src else np.full(m, np.inf)
    return pts, d[:n]


def on_cable_candidates(poles, cable, oncable_m=2.0, gap_m=31.5, step_m=2.0):
    """-> (cand_xy (N,2), is_pole (N,) bool, n_dropped). Poles first, in their input order, then gap points.

    A cable point is covered when an on-cable pole is within gap_m ALONG THE CONNECTED CABLE (review 2026-10-15):
    straight-line distance let a line corrected to run 15-30 m beside another poled line borrow that line's
    poles and get no candidates of its own."""
    poles = np.asarray(poles, float).reshape(-1, 2)
    cable = [np.asarray(c, float) for c in cable if len(c) >= 2]
    if not cable:
        return poles.copy(), np.ones(len(poles), bool), 0
    on_any = np.zeros(len(poles), bool)
    for c in cable:
        if len(poles):
            on_any |= _dist_to_piece(poles, c) <= oncable_m
    on = poles[on_any]
    pts, d = _along_cable_dist(cable, on, oncable_m, step_m, gap_m)
    gaps = pts[~(d <= gap_m)]
    cand = np.vstack([on, gaps]) if len(gaps) else on.copy()
    is_pole = np.r_[np.ones(len(on), bool), np.zeros(len(gaps), bool)]
    return cand, is_pole, int(len(poles) - len(on))
