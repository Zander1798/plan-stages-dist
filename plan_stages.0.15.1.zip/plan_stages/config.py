"""Plugin configuration. Everything defaults to self-contained: sites under the operator's Documents, the launcher
discovered from the running QGIS, no repo roots. The roots and launchers are optional overrides (a development
checkout sets them through scripts/install_plan_stages.ps1)."""
from __future__ import annotations
import os
import re
from dataclasses import dataclass, asdict, fields
from pathlib import Path
try:
    import tomllib
except ImportError:          # Python < 3.11 (QGIS 3 before 3.36 on Windows ships 3.9)
    tomllib = None


def _loads(text: str) -> dict:
    """The file save() writes: `key = "value"` lines. tomllib where Python has it, else those lines read directly."""
    if tomllib is not None:
        return tomllib.loads(text)
    out = {}
    for line in text.splitlines():
        m = re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"((?:[^"\\]|\\.)*)"\s*(#.*)?$', line)
        if m:
            out[m.group(1)] = m.group(2).replace('\\"', '"').replace("\\\\", "\\")
    return out

def default_plan_root() -> str:
    return (Path.home() / "Documents" / "PlanStages").as_posix()


@dataclass
class PluginConfig:
    plan_root: str = ""          # "" = Documents/PlanStages
    qgis_root: str = ""          # optional: a QGIS Automation checkout (building footprints under work/buildings)
    wayleave_root: str = ""      # optional: a Wayleave Automation checkout (same)
    gdal_python: str = ""        # optional: launcher for the step scripts and checks ("" = discovered from this QGIS)
    pyqgis_python: str = ""      # optional: launcher for P8 ("" = the same discovered launcher)
    anthropic_api_key: str = ""

    def __post_init__(self):
        if not self.plan_root:
            self.plan_root = default_plan_root()

    def effective_api_key(self) -> str:
        """The key the Spec tab uses: the config value, else the ANTHROPIC_API_KEY environment variable."""
        return (self.anthropic_api_key or "").strip() or os.environ.get("ANTHROPIC_API_KEY", "").strip()

    @classmethod
    def load(cls, path: Path) -> "PluginConfig":
        if not Path(path).exists():
            return cls()
        data = _loads(Path(path).read_text(encoding="utf-8-sig"))   # PowerShell writes a BOM
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in known})

    def save(self, path: Path) -> None:
        lines = [f'{k} = "{str(v).replace(chr(92), "/")}"' for k, v in asdict(self).items()]
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def default_config_path() -> Path:
    env = os.environ.get("PLAN_STAGES_CONFIG")
    if env:
        return Path(env)
    appdata = os.environ.get("APPDATA", str(Path.home() / "AppData/Roaming"))
    return Path(appdata) / "QGIS/QGIS4/profiles/default/plan_stages.toml"
