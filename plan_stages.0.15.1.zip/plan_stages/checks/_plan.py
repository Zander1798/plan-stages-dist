"""Helpers shared by the plan-phase check scripts (P1 to P7)."""
import math, os, sys
from pathlib import Path
import numpy as np
from osgeo import ogr, osr

from plan_stages.core.checks import MAX_ISSUES  # noqa: E402,F401 - re-exported for the check scripts

ogr.UseExceptions()


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))   # the bundled client_spec


def spec_limit(name):
    """Client cap via the bundled client_spec.limit(required=True); None (check skipped) when the sheet lacks it."""
    try:
        import client_spec
        return client_spec.limit(name, required=True)
    except SystemExit:
        return None


def site_epsg() -> int:
    return int(os.environ["PS_EPSG"])


def to_site(layer_epsg: int):
    a = osr.SpatialReference(); a.ImportFromEPSG(layer_epsg)
    b = osr.SpatialReference(); b.ImportFromEPSG(site_epsg())
    for s in (a, b):
        s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return osr.CoordinateTransformation(a, b)


def layer_epsg(lyr) -> int:
    s = lyr.GetSpatialRef()
    return int(s.GetAuthorityCode(None)) if s is not None and s.GetAuthorityCode(None) else 4326


def lines_site(lyr) -> list:
    """Every LineString part of a layer as an (n,2) array in site metres."""
    t = to_site(layer_epsg(lyr)); out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        parts = [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]
        for p in parts:
            out.append(np.array([t.TransformPoint(p.GetX(i), p.GetY(i))[:2] for i in range(p.GetPointCount())]))
    return out


def points_site(lyr) -> np.ndarray:
    t = to_site(layer_epsg(lyr))
    return np.array([t.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2]
                     for f in lyr]).reshape(-1, 2)


def back_to_layer(lyr, x: float, y: float):
    """site metres -> the layer's own CRS, for Issue coordinates."""
    a = osr.SpatialReference(); a.ImportFromEPSG(site_epsg())
    b = osr.SpatialReference(); b.ImportFromEPSG(layer_epsg(lyr))
    for s in (a, b):
        s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return osr.CoordinateTransformation(a, b).TransformPoint(x, y)[:2]


def densify(lines, step=2.0) -> np.ndarray:
    pts = []
    for ln in lines:
        for a, b in zip(ln[:-1], ln[1:]):
            n = max(1, int(math.ceil(math.dist(a, b) / step)))
            for k in range(n):
                t = k / n
                pts.append((a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])))
        pts.append(tuple(ln[-1]))
    return np.array(pts).reshape(-1, 2)


def lines_site_fids(lyr) -> list:
    """Like lines_site, but each part comes with the FID of the feature it belongs to: [(fid, (n,2) array), ...]."""
    t = to_site(layer_epsg(lyr)); out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        parts = [g.GetGeometryRef(i) for i in range(g.GetGeometryCount())] if g.GetGeometryCount() else [g]
        for part in parts:
            out.append((f.GetFID(), np.array([t.TransformPoint(part.GetX(i), part.GetY(i))[:2]
                                              for i in range(part.GetPointCount())])))
    return out


def point_at(ln: np.ndarray, chainage: float):
    """The point `chainage` metres along polyline ln (clamped to its ends)."""
    run = 0.0
    for a, b in zip(ln[:-1], ln[1:]):
        L = float(math.dist(a, b))
        if run + L >= chainage and L > 0:
            t = (chainage - run) / L
            return (float(a[0] + t * (b[0] - a[0])), float(a[1] + t * (b[1] - a[1])))
        run += L
    return (float(ln[-1][0]), float(ln[-1][1]))


def project(ln: np.ndarray, p):
    """(distance, chainage) of point p on polyline ln."""
    best = (float("inf"), 0.0); run = 0.0
    for a, b in zip(ln[:-1], ln[1:]):
        ab = b - a; L2 = float(ab @ ab); L = math.sqrt(L2)
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, float((p - a) @ ab) / L2))
        d = float(np.linalg.norm(p - (a + t * ab)))
        if d < best[0]:
            best = (d, run + t * L)
        run += L
    return best


def export_dir() -> Path:
    """The shapefile folder this revision's adapter exported from the approved layers (<rev>/site_export)."""
    return Path(os.environ["PS_REV_DIR"]) / "site_export"


def length_site(lyr, f) -> float:
    """Length in site metres of a feature's line geometry (0 when it has none)."""
    g = f.GetGeometryRef()
    if g is None or g.IsEmpty():
        return 0.0
    g = g.Clone(); g.Transform(to_site(layer_epsg(lyr)))
    return float(g.Length())


def cap_length(lyr, f) -> float:
    """The length a cap is tested against: the larger of the length_m attribute and the drawn geometry, so a
    geometry edit that leaves length_m behind can only make the check stricter."""
    return max(float(f.GetField("length_m") or 0.0), length_site(lyr, f))


PON_KEYS = ("pon_num", "PON", "label", "Label")


def open_pons(shp: Path):
    """(datasource, layer, pon-number field) of the exported PON polygons, or (None, None, None)."""
    if not Path(shp).exists():
        return None, None, None
    ds = ogr.Open(str(shp)); lyr = ds.GetLayer(0)
    names = [lyr.GetLayerDefn().GetFieldDefn(i).GetName() for i in range(lyr.GetLayerDefn().GetFieldCount())]
    key = next((n for n in PON_KEYS if n in names), None)
    return (ds, lyr, key) if key else (None, None, None)


def polygon_containing(lyr, geom, geom_epsg: int):
    """The feature of polygon layer `lyr` containing `geom` (given in EPSG geom_epsg), or None."""
    g = geom.Clone()
    if layer_epsg(lyr) != geom_epsg:
        a = osr.SpatialReference(); a.ImportFromEPSG(geom_epsg)
        b = osr.SpatialReference(); b.ImportFromEPSG(layer_epsg(lyr))
        for s in (a, b):
            s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        g.Transform(osr.CoordinateTransformation(a, b))
    lyr.SetSpatialFilter(g)
    try:
        for f in lyr:
            pg = f.GetGeometryRef()
            if pg is not None and pg.Contains(g):
                return f
        return None
    finally:
        lyr.SetSpatialFilter(None); lyr.ResetReading()


def approved_path(stage_id: str):
    """Approved gpkg of a registry dependency (PS_DEP_<STAGE>), or None."""
    return os.environ.get("PS_DEP_" + stage_id.upper())
