"""P2 1:16 splitters Check: one 1:16 per PON (2026-10-21: moved unchanged from the old combined P1 Check)."""
import json
import sys
import numpy as np
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

EDGE_M = 2.0               # a 1:16 this close to a PON (on its edge) belongs to it
ON_POLE_M = 2.0            # 0.13.0: a 1:16 this close to a wayleave pole stands on it


def why_no_1to16(rev, pon: int) -> str:
    """Why PON `pon` has no 1:16, from what P2's Generate recorded (<rev>/step3/step3_metrics.json); "" when it
    recorded nothing (an older run, or the layers came from elsewhere)."""
    try:
        m = json.loads((rev / "step3" / "step3_metrics.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    if "no_1to16" not in m:
        return ""
    if str(pon) not in m["no_1to16"]:
        return ("P2 placed a 1:16 for this PON at Generate, but none stands inside this PON or within 2 m of its edge "
                "now: it was deleted or moved since, or P2 placed it just outside the edge. Put one inside the PON or on "
                "its edge, or Remove this issue if it stands where it should.")
    # ruling R9 (2026-10-21): P2's own reason (place_1to16) first -- a None distance means "no span" OR "no
    # approved feeder at all", and only that text tells them apart
    told = (m.get("no_1to16_why") or {}).get(str(pon))
    if told:
        return (f"P2 did not place a 1:16 here: {told}. A 1:16 stands on the approved P1 feeder, at most "
                f"{float(m.get('connector_max_m', 25)):.0f} m from this PON's span. Correct the feeder in P1, or the "
                f"span and PON outline in the wayleave, or place the 1:16 by hand.")
    gap = m["no_1to16"][str(pon)]
    if gap is None:
        return ("P2 did not place a 1:16 here: no span runs inside this PON, and the 1:16 stands on the span. Check "
                "the span and the PON outline in the wayleave.")
    cap = float(m.get("connector_max_m", 25))
    return (f"P2 did not place a 1:16 here. A 1:16 goes where the feeder can reach it: along roads (or span beside a "
            f"road) from the POP, then at most {cap:.0f} m off the road to the PON's span. The nearest road the feeder "
            f"can reach is {gap:,.0f} m from this PON's span, so this PON's streets are not joined to the POP's road "
            f"network in the Roads layer (a gap, or a street that is not mapped). Join them in Roads, then press Use "
            f"this wayleave and Generate P1 and P2 again. Or place the 1:16 and draw the feeder to it by hand.")


def pon_number_unique(report, pl, key):
    """An error on each wayleave PON outline whose number another outline also has (final review 2026-10-21). P2
    places one 1:16 per PON number, so two outlines sharing one got a single 1:16 and one_1to16_per_pon passed;
    before the split, two were placed and the duplicate was flagged. Located on each outline (no `match`: the
    number names both, so the click goes to the outline the issue's point stands in)."""
    count = {}
    for f in pl:
        if f.GetField(key) is not None:
            count[int(f.GetField(key))] = count.get(int(f.GetField(key)), 0) + 1
    pl.ResetReading()
    dup = sorted(k for k, n in count.items() if n > 1)
    for f in pl:
        k = f.GetField(key)
        if k is not None and int(k) in dup and f.GetGeometryRef() is not None:
            add_issue(report, pl, None, "pon_number_unique", "error",
                      f"PON {int(k)}: {count[int(k)]} PON outlines in the wayleave have this number; give each its own "
                      f"number in Pons, then press Use this wayleave and Generate P2 again",
                      layer="pons", source="wayleave", xy=inside_xy(f.GetGeometryRef()))
    pl.ResetReading()
    report.checks.append(CheckResult("pon_number_unique", True, "passed" if not dup else "failed",
                                     f"{len(count)} PON numbers, shared by more than one outline: {dup[:10]}"))


def on_pole(report, spl):
    """0.13.0 (operator 2026-10-23, P6 Pole reconciliation removed): nothing adds a pole under a 1:16 any more. Each
    1:16 more than ON_POLE_M from every wayleave pole is a warning, so the operator moves it onto a pole or draws
    the pole in the wayleave. From geometry, like P4's cp_needs_pole."""
    shp = P.export_dir() / "poles.shp"
    ds = ogr.Open(str(shp)) if shp.exists() else None
    if spl is None or ds is None:
        report.checks.append(CheckResult("1to16_on_pole", False, "skipped", "splitters or wayleave poles missing"))
        return
    pl = ds.GetLayer(); xy = P.points_site(pl) if pl.GetFeatureCount() else np.zeros((0, 2))
    tree = cKDTree(xy) if len(xy) else None
    t = P.to_site(P.layer_epsg(spl)); n = 0; spl.ResetReading()
    for f in spl:
        g = f.GetGeometryRef()
        if g is None:
            continue
        d = float(tree.query(t.TransformPoint(g.GetX(), g.GetY())[:2])[0]) if tree is not None else float("inf")
        if d > ON_POLE_M:
            n += 1; add_issue(report, spl, f, "1to16_on_pole", "warn",
                              f"1:16 {d:.1f} m from the nearest wayleave pole: move it onto a pole, or draw a pole "
                              f"here in the wayleave")
    spl.ResetReading()
    report.checks.append(CheckResult("1to16_on_pole", False, "passed" if n == 0 else "failed",
                                     f"{n} 1:16s with no wayleave pole within {ON_POLE_M:.0f} m"))


def extra(report, rev):
    ds2, spl = open_layer(str(rev / "working.gpkg"), "splitters_1to16")
    on_pole(report, spl)
    pons = P.export_dir() / "Pons.shp"
    if spl is None or not pons.exists():
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "splitters or Pons.shp missing"))
        return
    pds = ogr.Open(str(pons)); pl = pds.GetLayer(0)
    names = [pl.GetLayerDefn().GetFieldDefn(i).GetName() for i in range(pl.GetLayerDefn().GetFieldCount())]
    key = next((n for n in ("pon_num", "PON", "label", "Label") if n in names), None)
    if key is None:
        report.checks.append(CheckResult("one_1to16_per_pon", True, "skipped", "no PON number field on Pons.shp"))
        return
    want = {int(f.GetField(key)) for f in pl if f.GetField(key) is not None}
    pl.ResetReading()
    pon_number_unique(report, pl, key)
    # 2026-10-14: a 1:16 belongs to the PON polygon it stands in, not to its `pon` attribute (stale after a move)
    have, of = {}, {}
    sepsg = P.layer_epsg(spl)
    tp = P.to_site(P.layer_epsg(pl)); ts = P.to_site(sepsg); polys = []
    for pf in pl:
        pg = pf.GetGeometryRef()
        if pg is not None and pf.GetField(key) is not None:
            pg = pg.Clone(); pg.Transform(tp); polys.append((int(pf.GetField(key)), pg))
    pl.ResetReading()
    for f in spl:
        g = f.GetGeometryRef()
        poly = P.polygon_containing(pl, g, sepsg) if g is not None else None
        k = int(poly.GetField(key)) if poly is not None and poly.GetField(key) is not None else None
        if k is None and g is not None:
            # final review 2026-10-14: the operator puts 1:16s ON the PON edge (Botshabelo 33 of 47): a PON within
            # EDGE_M counts, the one the `pon` attribute names first, else the nearest
            q = g.Clone(); q.Transform(ts)
            near = sorted((pg.Distance(q), num) for num, pg in polys if pg.Distance(q) <= EDGE_M)
            named = f.GetField("pon") if spl.GetLayerDefn().GetFieldIndex("pon") >= 0 else None
            k = next((num for _d, num in near if named is not None and str(num) == str(named)), near[0][1] if near else None)
        of[f.GetFID()] = k
        if k is None:
            add_issue(report, spl, f, "one_1to16_per_pon", "error", "1:16 stands outside every PON")
        else:
            have[k] = have.get(k, 0) + 1
    spl.ResetReading()
    missing = sorted(want - set(have)); dup = sorted(k for k, v in have.items() if v > 1)
    outside = sum(1 for v in of.values() if v is None)
    for f in pl:                                         # a PON without a 1:16: located on the approved wayleave pons
        k = f.GetField(key)
        if k is not None and int(k) in missing and f.GetGeometryRef() is not None:
            add_issue(report, pl, None, "one_1to16_per_pon", "error", f"PON {int(k)} has no 1:16", layer="pons",
                      source="wayleave", xy=inside_xy(f.GetGeometryRef()), match=f"pon_num={int(k)}",
                      why=why_no_1to16(rev, int(k)))
    for f in spl:
        if of.get(f.GetFID()) in dup:
            n = have[of[f.GetFID()]]
            add_issue(report, spl, f, "one_1to16_per_pon", "error", f"PON {of[f.GetFID()]} has a duplicate 1:16 ({n})")
    report.checks.append(CheckResult("one_1to16_per_pon", True, "passed" if not missing and not dup and not outside else "failed",
                                     f"{len(want)} PONs, {len(have)} with a 1:16; missing {missing[:10]}, duplicated {dup[:10]}, "
                                     f"{outside} outside every PON"))


if __name__ == "__main__":
    sys.exit(main(extra))
