"""P1 Feeder Check: the feeder beside the roads (midblock) and reaching every PON (2026-10-21 split; the 1:16 check
moved to P2, checks/p2_1to16.py)."""
import json
import sys
import numpy as np
from scipy.spatial import cKDTree
from osgeo import ogr
from plan_stages.checks.common import main, open_layer, add_issue, inside_xy
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

FEEDER_ROAD_WARN_M = 20.0
FEEDER_ROAD_HARD_M = 40.0
# how far the feeder may stop from a PON's span and still serve its 1:16 -- copied from CONNECTOR_MAX_M (default 25)
# in scripts/ml/step3_span_split.py, which routes the feeder and places the 1:16 on it with the same limit
CONNECTOR_MAX_M = 25.0


def _midblock(report, feeder):
    road = P.export_dir() / "road.shp"
    if feeder is None or not road.exists():
        for c in ("feeder_not_midblock", "feeder_midblock_hard"):
            report.checks.append(CheckResult(c, c == "feeder_midblock_hard", "skipped", "feeder layer or road.shp missing"))
        return
    rds = ogr.Open(str(road)); rl = rds.GetLayer(0)
    tree = cKDTree(P.densify(P.lines_site(rl)))
    warn = hard = total = 0; worst = 0.0
    for fid, ln in P.lines_site_fids(feeder):
        d, _ = tree.query(ln)
        total += len(ln); worst = max(worst, float(d.max()))
        for k in np.nonzero(d > FEEDER_ROAD_WARN_M)[0]:
            is_hard = d[k] > FEEDER_ROAD_HARD_M
            hard += is_hard; warn += not is_hard
            add_issue(report, feeder, None, "feeder_midblock_hard" if is_hard else "feeder_not_midblock",
                      "error" if is_hard else "warn", f"feeder vertex {d[k]:.0f} m from a road",
                      xy=P.back_to_layer(feeder, *ln[k]), fid=fid)
    report.checks.append(CheckResult("feeder_not_midblock", False, "passed" if warn + hard == 0 else "failed",
                                     f"{warn + hard} of {total} feeder vertices more than {FEEDER_ROAD_WARN_M:.0f} m from a road (worst {worst:.0f} m)"))
    report.checks.append(CheckResult("feeder_midblock_hard", True, "passed" if hard == 0 else "failed",
                                     f"{hard} feeder vertices more than {FEEDER_ROAD_HARD_M:.0f} m from a road"))


def _targets(rev, labels) -> dict:
    """P1's recorded target per PON label (site metres; None = none recorded), from p1_targets.json of this rev (or
    the earlier rev a hand Revise started from)."""
    from plan_stages.adapters._plan_common import p1_targets
    try:
        tg = json.loads(p1_targets(rev / "working.gpkg").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        tg = {}
    t = P.to_site(4326); out = {}
    for lab in labels:
        v = tg.get(lab)
        out[lab] = None if not v else tuple(t.TransformPoint(float(v["x"]), float(v["y"]))[:2])
    return out


def _reaches_pon(report, rev, feeder):
    """Spec 2026-10-21 (operator: "every single PON needs to have a 1:16 splitter, or at least a 1:16 needs to be close
    to that PON"): an error on each PON place_1to16 cannot serve from the WORKING feeder -- measured from what is
    drawn, so an edit counts at Check (D-PS.7), with place()'s reason as the Why."""
    span, pons = P.export_dir() / "Span.shp", P.export_dir() / "Pons.shp"
    if feeder is None or not span.exists() or not pons.exists():
        report.checks.append(CheckResult("feeder_reaches_pon", True, "skipped", "feeder layer, Span.shp or Pons.shp missing"))
        return
    pds, pl, key = P.open_pons(pons)
    if pl is None:
        report.checks.append(CheckResult("feeder_reaches_pon", True, "skipped", "no PON number field on Pons.shp"))
        return
    from place_1to16 import place                        # the bundled ml/ copy (on sys.path via checks/_plan)
    sds = ogr.Open(str(span)); pts = P.densify(P.lines_site(sds.GetLayer(0)), step=1.0)
    tp = P.to_site(P.layer_epsg(pl)); polys = {}
    for f in pl:
        g = f.GetGeometryRef()
        if g is not None and f.GetField(key) is not None:
            n = int(f.GetField(key)); h = g.Clone(); h.Transform(tp)
            polys[str(n)] = (n, h, inside_xy(g))
    pl.ResetReading()
    unnumbered = pl.GetFeatureCount() - len(polys)
    if not polys:                                        # cradock: pon_num empty on every PON -- nothing to name
        report.checks.append(CheckResult("feeder_reaches_pon", True, "skipped", "no PON on Pons.shp has a number"))
        return
    pon_span = {}
    for lab, (_n, g, _xy) in polys.items():
        x0, x1, y0, y1 = g.GetEnvelope()
        cand = pts[(pts[:, 0] >= x0) & (pts[:, 0] <= x1) & (pts[:, 1] >= y0) & (pts[:, 1] <= y1)] if len(pts) else pts
        inside = []
        for x, y in cand:
            q = ogr.Geometry(ogr.wkbPoint); q.AddPoint_2D(float(x), float(y))
            if g.Contains(q):
                inside.append((x, y))
        if inside:
            pon_span[lab] = np.array(inside, float)
    lines = [ln for ln in P.lines_site(feeder) if len(ln) >= 2]
    placed, why, _gap = place(lines, _targets(rev, list(polys)), pon_span, CONNECTOR_MAX_M)
    bad = sorted(why, key=lambda lab: polys[lab][0])
    for lab in bad:
        n, _g, xy = polys[lab]
        add_issue(report, pl, None, "feeder_reaches_pon", "error", f"the feeder does not reach PON {n}", layer="pons",
                  source="wayleave", xy=xy, match=f"pon_num={n}", why=why[lab])
    report.checks.append(CheckResult("feeder_reaches_pon", True, "passed" if not bad else "failed",
                                     f"{len(polys)} PONs, {len(placed)} reached by the feeder (a feeder point within "
                                     f"{CONNECTOR_MAX_M:.0f} m of the PON's span); not reached {[polys[b][0] for b in bad][:10]}"
                                     + (f"; {unnumbered} PONs without a number not checked" if unnumbered else "")))


def extra(report, rev):
    ds, feeder = open_layer(str(rev / "working.gpkg"), "feeder")
    _midblock(report, feeder)
    if feeder is not None:
        feeder.ResetReading()
    _reaches_pon(report, rev, feeder)


if __name__ == "__main__":
    sys.exit(main(extra))
