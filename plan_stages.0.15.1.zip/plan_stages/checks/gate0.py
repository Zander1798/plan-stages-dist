"""Gate 0 check: the Step 0 verdict (wayleave_<site>.json) as check rows, plus the findings Step 0 only counts:
demand points beyond the drop cap, poles off the span, span features overlapping another (the slivers).

Operator 2026-10-16: "The wayleave is done by the human operator before you even start, so having errors based on
the span and that kind of stuff is not at all acceptable." The wayleave findings are INFORMATION: status "info",
printed to check.log, never issues in the list and never blocking. Only a Step 0 failure (the plan cannot run)
stops the stage."""
import json, os, sys
from scipy.spatial import cKDTree
from osgeo import ogr
from plan_stages.checks.common import main
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

POLE_ON_SPAN_M = 2.0          # step0_wayleave: a pole "on the span" is within 2 m of it
SEG_M, STITCH_M = 0.5, 0.75   # step0's noding tolerances; overlap closer than STITCH_M is what it drops as slivers
SLIVER_MIN_M = 1.0


def step0_verdict(report, rev):
    j = rev / f"wayleave_{os.environ.get('PS_SITE', '')}.json"
    if not j.is_file():
        report.checks.append(CheckResult("step0_verdict", True, "skipped", f"{j.name} missing: Generate did not run Step 0"))
        return
    d = json.loads(j.read_text(encoding="utf-8"))
    for msg in d.get("fail", []):
        report.checks.append(CheckResult("step0_fail", True, "failed", msg))
    for msg in d.get("warn", []):
        info(report, "step0_warn", msg)
    nf, nw = len(d.get("fail", [])), len(d.get("warn", []))
    report.checks.append(CheckResult("step0_verdict", True, "failed" if nf else "passed", f"{nf} fail, {nw} warn"))


def info(report, code: str, msg: str) -> None:
    """A wayleave finding: information for the operator, never an issue (2026-10-16)."""
    report.checks.append(CheckResult(code, False, "info", msg))
    print(f"info {code}: {msg}")


def _near(report, tree, lyr, code, limit):
    if lyr is None:
        return None
    xy = P.points_site(lyr); n = 0
    if len(xy):
        d, _ = tree.query(xy)
        n = int((d > limit).sum())
    info(report, code, f"{n} of {len(xy)} {lyr.GetName()} more than {limit:g} m from the span")
    return n


def extra(report, rev):
    step0_verdict(report, rev)
    wl = P.approved_path("wayleave")
    ds = ogr.Open(wl) if wl else None
    span = ds.GetLayerByName("span") if ds else None
    if span is None:
        info(report, "dp_beyond_cap", "approved wayleave span missing")
        return
    parts = P.lines_site_fids(span)
    pts = P.densify([ln for _, ln in parts], 2.0)
    if not len(pts):
        info(report, "dp_beyond_cap", "span has no line geometry")
        return
    tree = cKDTree(pts)
    cap = P.spec_limit("drop_cap_m")
    if cap is None:
        info(report, "dp_beyond_cap", "drop_cap_m missing")
    else:
        _near(report, tree, ds.GetLayerByName("demand_points"), "dp_beyond_cap", cap)
    _near(report, tree, ds.GetLayerByName("poles"), "pole_off_span", POLE_ON_SPAN_M)
    # Slivers: metres of a span feature that run within STITCH_M of ANOTHER feature are welded away by Step 0.
    dense = [(fid, P.densify([ln], SEG_M)) for fid, ln in parts]
    allpts = [p for _, d in dense for p in d]; owner = [fid for fid, d in dense for _ in d]
    t2 = cKDTree(allpts); n_sliver = 0; total = 0.0
    for fid, d in dense:
        hits = t2.query_ball_point(d, STITCH_M)
        over = [any(owner[j] != fid for j in h) for h in hits]
        m = sum(SEG_M for a, b in zip(over[:-1], over[1:]) if a and b)
        if m >= SLIVER_MIN_M:
            n_sliver += 1; total += m
    info(report, "span_overlap", f"{n_sliver} span features overlap another ({total:.0f} m, dropped by Step 0 as slivers)")


if __name__ == "__main__":
    sys.exit(main(extra))
