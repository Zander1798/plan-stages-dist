"""P3 Distribution Check (2026-10-21 split): every approved 1:16 starts the distribution."""
import sys
from osgeo import ogr
from scipy.spatial import cKDTree
from plan_stages.checks.common import main, open_layer, add_issue
from plan_stages.checks import _plan as P
from plan_stages.core.checks import CheckResult

JOIN_M = 2.0               # spec 2026-10-21: a 1:16 with no distribution within 2 m is not joined to it


def extra(report, rev):
    """An error on each APPROVED P2 1:16 with no WORKING distribution within JOIN_M (the lines densified to 1 m first,
    so a 1:16 beside the middle of a long straight counts), located on the 1:16."""
    ds, dist = open_layer(str(rev / "working.gpkg"), "distribution")
    p2 = P.approved_path("p2_1to16")
    sds = ogr.Open(p2) if p2 else None
    spl = sds.GetLayerByName("splitters_1to16") if sds is not None else None
    if dist is None or spl is None:
        report.checks.append(CheckResult("1to16_joins_distribution", True, "skipped",
                                         "distribution layer or approved P2 1:16s missing"))
        return
    pts = P.densify(P.lines_site(dist), step=1.0)
    tree = cKDTree(pts) if len(pts) else None
    t = P.to_site(P.layer_epsg(spl)); n = lone = 0
    for f in spl:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        n += 1
        x, y = t.TransformPoint(g.GetX(), g.GetY())[:2]
        d = float(tree.query((x, y))[0]) if tree is not None else float("inf")
        if d > JOIN_M:
            lone += 1
            far = "no distribution at all" if tree is None else f"the nearest distribution is {d:.1f} m away"
            pon = f.GetField("pon") if spl.GetLayerDefn().GetFieldIndex("pon") >= 0 else None
            add_issue(report, spl, f, "1to16_joins_distribution", "error",
                      f"1:16 (PON {'?' if pon is None else pon}) is not joined to the distribution: {far}",
                      source="p2_1to16")
    report.checks.append(CheckResult("1to16_joins_distribution", True, "passed" if lone == 0 else "failed",
                                     f"{n} approved 1:16s, {lone} with no distribution within {JOIN_M:.0f} m"))


if __name__ == "__main__":
    sys.exit(main(extra))
