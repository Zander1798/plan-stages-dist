"""P4 adapter: step567 STAGE=poles on approved P1/P2/P3, then reconcile with the approved wayleave poles.

A generated pole within 2 m of an approved wayleave pole is replaced by that wayleave pole (position kept,
role/cable/height_m taken from the generated one). Wayleave poles with no generated counterpart are kept
with role "wayleave". Output stays in EPSG:4326 like every other plan layer.
"""
import os, sys
from pathlib import Path
import numpy as np
from osgeo import ogr, osr
from scipy.spatial import cKDTree
from plan_stages.adapters._plan_common import (site_dir, run_step, materialise_p1, materialise_p2,
                                               copy_layer, approved, transform, layer_epsg)

SNAP_M = 2.0
ONE16_M = 2.0      # 2026-10-14: an approved 1:16 with no pole this close gets one


def add_1to16_poles(gen_gpkg: Path, p1_gpkg: Path, epsg: int, height: float, tol: float = ONE16_M) -> int:
    """A feeder pole at every approved P1 1:16 splitter that has no pole within `tol` m (site metres), so P4
    honours the operator's 1:16 positions. Returns the number added."""
    pds = ogr.Open(str(p1_gpkg)); spl = pds.GetLayerByName("splitters_1to16")
    if spl is None:
        return 0
    gds = ogr.Open(str(gen_gpkg), 1); pl = gds.GetLayerByName("poles")
    pe = layer_epsg(pl, 4326); to_site = transform(pe, epsg); back = transform(epsg, pe)
    xy = [to_site.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2] for f in pl
          if f.GetGeometryRef() is not None]
    s_to_site = transform(layer_epsg(spl, epsg), epsg); added = 0
    for f in spl:
        g = f.GetGeometryRef()
        if g is None:
            continue
        p = s_to_site.TransformPoint(g.GetX(), g.GetY())[:2]
        if xy and float(cKDTree(np.array(xy)).query(p)[0]) <= tol:
            continue
        x, y = back.TransformPoint(p[0], p[1])[:2]
        o = ogr.Feature(pl.GetLayerDefn()); pt = ogr.Geometry(ogr.wkbPoint); pt.AddPoint_2D(x, y); o.SetGeometry(pt)
        o.SetField("role", "1to16"); o.SetField("cable", "feeder"); o.SetField("height_m", float(height))
        pl.CreateFeature(o); xy.append(p); added += 1
    gds = pds = None
    return added


def main():
    site_dir(); rev = Path(os.environ["PS_REV_DIR"]); epsg = int(os.environ["PS_EPSG"])
    materialise_p1(rev); materialise_p2(rev)
    xg = rev / "approved_crossings.gpkg"
    copy_layer(approved("p3_crossings"), "road_crossings", xg, "claude_road_crossings")
    rc = run_step("step567.py", {"STAGE": "poles", "PS_CROSSINGS_GPKG": str(xg)})
    if rc:
        return rc
    gds = ogr.Open(str(rev / "step567" / "claude_step567_poles.gpkg"))
    gen = gds.GetLayerByName("claude_poles")
    wds = ogr.Open(str(approved("wayleave")))
    wl = wds.GetLayerByName("poles")                # optional in the wayleave: absent means no operator poles
    to_site = transform(4326, epsg)                 # generated poles (4326) -> site metres
    to_wgs = transform(epsg, 4326)                  # site metres -> 4326
    if wl is None:
        print("wayleave has no poles layer: every pole is generated")
        wl_xy = np.zeros((0, 2))
    else:
        wl_to_site = transform(layer_epsg(wl, epsg), epsg)
        wl_xy = np.array([wl_to_site.TransformPoint(f.GetGeometryRef().GetX(), f.GetGeometryRef().GetY())[:2]
                          for f in wl if f.GetGeometryRef() is not None]).reshape(-1, 2)
    tree = cKDTree(wl_xy) if len(wl_xy) else None

    out_path = rev / "generated.gpkg"
    if out_path.exists():
        out_path.unlink()
    out = ogr.GetDriverByName("GPKG").CreateDataSource(str(out_path))
    srs = osr.SpatialReference(); srs.ImportFromEPSG(4326); srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    ol = out.CreateLayer("poles", srs, ogr.wkbPoint)
    for n, t in (("role", ogr.OFTString), ("cable", ogr.OFTString), ("height_m", ogr.OFTReal)):
        ol.CreateField(ogr.FieldDefn(n, t))

    def emit(x, y, role, cable, h):
        o = ogr.Feature(ol.GetLayerDefn()); p = ogr.Geometry(ogr.wkbPoint); p.AddPoint_2D(x, y)
        o.SetGeometry(p); o.SetField("role", role); o.SetField("cable", cable); o.SetField("height_m", h)
        ol.CreateFeature(o)

    used = set(); kept = added = 0
    for f in gen:
        g = f.GetGeometryRef()
        mx, my = to_site.TransformPoint(g.GetX(), g.GetY())[:2]
        hit = None
        if tree is not None:
            dists, idx = tree.query([mx, my], k=min(3, len(wl_xy)), distance_upper_bound=SNAP_M)
            for d, j in zip(np.atleast_1d(dists), np.atleast_1d(idx)):
                if np.isfinite(d) and int(j) not in used:
                    hit = int(j); break
        if hit is not None:
            used.add(hit)
            lon, lat = to_wgs.TransformPoint(float(wl_xy[hit][0]), float(wl_xy[hit][1]))[:2]
            kept += 1
        else:
            lon, lat = g.GetX(), g.GetY(); added += 1
        emit(lon, lat, f.GetField("role"), f.GetField("cable"), f.GetField("height_m"))
    for i in range(len(wl_xy)):
        if i in used:
            continue
        lon, lat = to_wgs.TransformPoint(float(wl_xy[i][0]), float(wl_xy[i][1]))[:2]
        emit(lon, lat, "wayleave", "", 0.0)
    out = None
    print(f"reconciled: {kept} on wayleave poles, {added} new, {len(wl_xy) - len(used)} wayleave-only "
          f"({len(wl_xy)} wayleave poles)")
    import client_spec                                   # the bundled ml/client_spec, on PYTHONPATH via env.build_env
    n = add_1to16_poles(out_path, approved("p1_feeder"), epsg, float(client_spec.limit("pole_feeder_m", 7.0)))
    print(f"1:16 splitters given a feeder pole: {n}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
